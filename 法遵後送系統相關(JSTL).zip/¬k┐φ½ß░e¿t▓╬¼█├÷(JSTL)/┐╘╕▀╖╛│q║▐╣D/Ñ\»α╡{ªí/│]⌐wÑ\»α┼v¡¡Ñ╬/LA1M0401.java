package com.kyc.la1.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.kyc.afl.utils.Employee;
import com.kyc.la1.dao.COM_LDEPDao;
import com.kyc.la1.dao.COM_LEMPDao;
import com.kyc.la1.forms.LA1M040f;
import com.kyc.sec.actions.WebAction;
import com.kyc.wms.dao.SecakDao;

/**
 * @author jieyu
 * @Create Date：2019/01/19
 */
public class LA1M0401 extends WebAction
{

	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
      if (form1.getActionCode() == 0)
          form1.setActionCode(GlobalKey.ACTION_SELECT);
      return;
	}
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
	// TODO Auto-generated method stub

		LA1M040f form1 = (LA1M040f)form;
		
		HttpSession session = request.getSession(false);
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String sysdate = tx_controller.getSystemDate();
		String systime = tx_controller.getSystemTime();
		
		List list,listLEM02 = null;
		Map map = null;
		
		tx_controller.begin(0);
		COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(tx_controller.getConnection(0));
		COM_LDEPDao COM_LDEPDao = new COM_LDEPDao(tx_controller.getConnection(0));
		
		if(form1.getActionCode() == 5 || form1.getActionCode() == 6)
		{
			list = queryCOM_LEMP(form1);
			request.setAttribute("list",list);
			
			listLEM02 = COM_LDEPDao.getCOM_LDEPAll();
			request.setAttribute("listLEM02",listLEM02);
		}		
		if(form1.getActionCode() == 1)//新增
		{
			boolean msgErr = false;
			if(!checkCOM_LEMPExists(form1.getLEM01()))
			{
				COM_LEMPDao.setLEM01(form1.getLEM01());
				COM_LEMPDao.setLEM02(form1.getLEM02());
				COM_LEMPDao.setLEM03(form1.getLEM03());
				COM_LEMPDao.setLEM04(form1.getLEM04());
				COM_LEMPDao.setLEM05(form1.getLEM05());
				COM_LEMPDao.setLEM06(form1.getLEM06());
				COM_LEMPDao.setLEM07(form1.getLEM07());
				COM_LEMPDao.setLEM08(form1.getLEM08());
				COM_LEMPDao.setLEM09(form1.getLEM09());
				COM_LEMPDao.setCRTDT(sysdate);
				COM_LEMPDao.setCRTTM(systime);
				COM_LEMPDao.setCRTUR(ui.getUserId());
				COM_LEMPDao.setUPDDT(sysdate);
				COM_LEMPDao.setUPDTM(systime);
				COM_LEMPDao.setUPDUR(ui.getUserId());
				COM_LEMPDao.insertCOM_LEMP();				
				
				insertSecak(form1,sysdate,systime,ui);
			}
			else
			{
				msgErr = true;
			}
			request.setAttribute("msgErr", String.valueOf(msgErr));
			
			list = queryCOM_LEMP(form1);
			request.setAttribute("list",list);
			
			listLEM02 = COM_LDEPDao.getCOM_LDEPAll();
			request.setAttribute("listLEM02",listLEM02);			
		}
		if(form1.getActionCode() == 2)//修改
		{
			COM_LEMPDao.setLEM01(form1.getLEM01());
			COM_LEMPDao.setLEM02(form1.getLEM02());
			COM_LEMPDao.setLEM03(form1.getLEM03());
			COM_LEMPDao.setLEM04(form1.getLEM04());
			COM_LEMPDao.setLEM05(form1.getLEM05());
			COM_LEMPDao.setLEM06(form1.getLEM06());
			COM_LEMPDao.setLEM07(form1.getLEM07());
			COM_LEMPDao.setLEM08(form1.getLEM08());
			COM_LEMPDao.setLEM09(form1.getLEM09());
			COM_LEMPDao.setUPDDT(sysdate);
			COM_LEMPDao.setUPDTM(systime);
			COM_LEMPDao.setUPDUR(ui.getUserId());
			COM_LEMPDao.updateCOM_LEMP();
			
			deleteSecak(form1);
			insertSecak(form1,sysdate,systime,ui);
			
			list = queryCOM_LEMP(form1);
			request.setAttribute("list",list);
			
			listLEM02 = COM_LDEPDao.getCOM_LDEPAll();
			request.setAttribute("listLEM02",listLEM02);
		}
		if(form1.getActionCode() == 4)//刪除
		{
			COM_LEMPDao.setLEM01(form1.getLEM01());
			COM_LEMPDao.deleteCOM_LEMP();
			
			deleteSecak(form1);
			
			list = queryCOM_LEMP(form1);
			request.setAttribute("list",list);
			
			listLEM02 = COM_LDEPDao.getCOM_LDEPAll();
			request.setAttribute("listLEM02",listLEM02);
		}
		
		form1.setNextPage(1);
		
	}

	/**
	 * 查詢COM_LEMP
	 * @param form1
	 * @return List
	 * @throws AsiException
	 */
	public List queryCOM_LEMP(LA1M040f form1) throws AsiException
	{
		COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(tx_controller.getConnection(0));
		List list = COM_LEMPDao.getCOM_LEMPAll();
		
		Employee emp = null;
		for(int i = 0;i < list.size();i++)
		{
			Map map = (Map) list.get(i);
			emp = Employee.getEmployee((String)map.get("LEM01"));
			String empName = emp.getName();			
			map.put("empName", empName);
		}
		return list;

	}
	
	public boolean checkCOM_LEMPExists(String LEM01) throws AsiException
	{
		boolean isCOM_LEMP = false;
		COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(tx_controller.getConnection(0));
		COM_LEMPDao.setLEM01(LEM01);
		isCOM_LEMP = COM_LEMPDao.checkCOM_LEMPExists();
		return isCOM_LEMP;
	}	
	
	/**
	 * 寫入Secak
	 * @param form1
	 * @throws AsiException
	 */
	public void insertSecak(LA1M040f form1,String sysdate,String systime,UserInfo ui) throws AsiException
	{
		SecakDao SecakDao = new SecakDao(tx_controller.getConnection(0));
		
		//寫入權限檔
		SecakDao.setUSERID(form1.getLEM01());
		SecakDao.setSYSTEM("LAW");
		SecakDao.setMODULE("LA1");
		SecakDao.setSPECIAL1("");
		SecakDao.setSPECIAL2("");
		SecakDao.setSPECIAL3("");
		SecakDao.setOWNER("FIRSTADMIN");
		SecakDao.setCRTDT(sysdate);
		SecakDao.setCRTTM(systime);
		SecakDao.setCRTUR(ui.getUserId());
		SecakDao.setUPDDT(sysdate);
		SecakDao.setUPDTM(systime);
		SecakDao.setUPDUR(ui.getUserId());
		
		if("13".equals(form1.getLEM02()))
		{
			SecakDao.setFUNCTION("LA1M010");
			SecakDao.setPOWER("66");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1M030");
			SecakDao.setPOWER("118");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1M040");
			SecakDao.setPOWER("118");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1M050");
			SecakDao.setPOWER("118");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1M060");
			SecakDao.setPOWER("118");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1I070");
			SecakDao.setPOWER("96");
			SecakDao.insertSecak();
			
			//法遵室增加諮詢列表查詢和諮詢年度統計權限
			SecakDao.setFUNCTION("LA1M120");
			SecakDao.setPOWER("70");
			SecakDao.insertSecak();
			
			SecakDao.setFUNCTION("LA1I130");
			SecakDao.setPOWER("96");
			SecakDao.insertSecak();
			
		}
		
		if("13".equals(form1.getLEM02()) || "99".equals(form1.getLEM02()))
		{
			SecakDao.setFUNCTION("LA1M020");
			SecakDao.setPOWER("118");
			SecakDao.insertSecak();
		}
		
		if(!"99".equals(form1.getLEM02()))
		{
			SecakDao.setFUNCTION("LA1I080");
			SecakDao.setPOWER("96");
			SecakDao.insertSecak();
			
			// 2019/11/29 增加逾期未回覆統計 by John Lai
			SecakDao.setFUNCTION("LA1I1001");
			SecakDao.setPOWER("96");
			SecakDao.insertSecak();
		}
		//法遵主管(LEM05)或法遵主管代理(LEM06)需增加 諮詢案件新增以及諮詢列表查詢
		if("Y".equals(form1.getLEM05()) || "Y".equals(form1.getLEM06())) {
			//新增諮詢案件權限
			SecakDao.setFUNCTION("LA1M110");
			SecakDao.setPOWER("66");
			SecakDao.insertSecak();
			
			//因前面已經加過法遵室的諮詢列表查詢所以這邊要排除
			if(!"13".equals(form1.getLEM02())) {
				SecakDao.setFUNCTION("LA1M120");
				SecakDao.setPOWER("70");
				SecakDao.insertSecak();
			}
		}
		
		SecakDao.setFUNCTION("LA1M090");
		SecakDao.setPOWER("118");
		SecakDao.insertSecak();
			
	}
	
	/**
	 * 刪除Secak
	 * @param form1
	 * @throws AsiException
	 */
	public void deleteSecak(LA1M040f form1) throws AsiException
	{
		SecakDao SecakDao = new SecakDao(tx_controller.getConnection(0));
		
		//刪除權限檔
		SecakDao.setUSERID(form1.getLEM01());
		SecakDao.setSYSTEM("LAW");
		SecakDao.setMODULE("LA1");	

		SecakDao.deleteSecak();				
	}
}
