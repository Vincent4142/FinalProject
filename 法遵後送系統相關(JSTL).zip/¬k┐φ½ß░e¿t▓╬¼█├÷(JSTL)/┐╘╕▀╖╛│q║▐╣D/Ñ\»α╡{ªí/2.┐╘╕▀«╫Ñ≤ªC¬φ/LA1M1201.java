package com.kyc.la1.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.forms.LA1M120f;
import com.kyc.la1.models.LA1M120m;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-法令遵循系統-諮詢溝通案件查詢
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1M1201 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			
			startDate += 1; // 查詢日期區間的起日從當月1日起
			request.setAttribute("queryStartDate", String.valueOf(startDate));
			request.setAttribute("queryEndDate", String.valueOf(sysDate));
			
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		
		HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String userId = ui.getUserId();
		
		LA1M120f form = (LA1M120f) arg1;
		LA1M120m model = new LA1M120m(tx_controller, arg2, form);
		model.init();

		Map ldep = model.queryLcm(userId);
		//所屬部門代號
		String depId=ldep.get("lde01").toString();
		String uname=ui.getName();

		int page = 1;
		
		//第一頁用案號查詢
		if (arg1.getActionCode() == 1){
			
			List lcmalist = model.queryCOM_LCMAListByLcm01(depId);
			
			arg2.setAttribute("lcmalist", lcmalist);
			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			arg2.setAttribute("queryLcm01", form.getQueryLcm01());

			page = 2;

		}else if (arg1.getActionCode() == 2){//第一頁用日期區間查詢
			
			List lcmalist = model.queryCOM_LCMAList(depId);
			
			arg2.setAttribute("lcmalist", lcmalist);
			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			arg2.setAttribute("queryLcm05", form.getQueryLcm05());

			page = 2;

		}else if (arg1.getActionCode() == 3){//第二頁回上頁
			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			page = 1;

		}else if (arg1.getActionCode() == 4){//第二頁選擇案號進入
			
			Map  lcm = model.queryLcmaByLcm01();
						
			List lctList = model.queryCOM_LCTEListByLct01();
			
			arg2.setAttribute("lctList", lctList);
			arg2.setAttribute("ldep", ldep);
			arg2.setAttribute("detail", lcm);
			
			String queryLcm01 = form.getQueryLcm01() == null ? "" : form.getQueryLcm01().toString().trim();				
			String queryStartDate = form.getQueryStartDate() == null ? "" : form.getQueryStartDate().toString().trim();				
			String queryEndDate = form.getQueryEndDate() == null ? "" : form.getQueryEndDate().toString().trim();				
			String queryLcm05 = form.getQueryLcm05() == null ? "" : form.getQueryLcm05().toString().trim();
			
			arg2.setAttribute("queryLcm01", queryLcm01);
			arg2.setAttribute("queryStartDate", queryStartDate);
			arg2.setAttribute("queryEndDate", queryEndDate);
			arg2.setAttribute("queryLcm05", queryLcm05);
			arg2.setAttribute("uName", uname);

			page = 3;

		}else if (arg1.getActionCode() == 6){//第三頁諮詢內容頁面按確認存檔
			
			model.processSaveLct(depId,uname);
			
			Map  lcm = model.queryLcmaByLcm01();
			List lctList = model.queryCOM_LCTEListByLct01();

			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			arg2.setAttribute("queryLcm05", form.getQueryLcm05());
			
			arg2.setAttribute("lctList", lctList);
			arg2.setAttribute("ldep", ldep);
			arg2.setAttribute("detail", lcm);
			arg2.setAttribute("uName", uname);
			String queryLcm01 = form.getQueryLcm01().toString().trim();
			arg2.setAttribute("queryLcm01", queryLcm01);

			page = 3;

		}else if (arg1.getActionCode() == 7){//第三頁諮詢內容頁面按修改
								
			Map  lct = model.queryCOM_LCTEByLct01AndLct05();

			arg2.setAttribute("lct", lct);
			String queryLcm01 = form.getQueryLcm01().toString().trim();
			arg2.setAttribute("queryLcm01", queryLcm01);
			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			arg2.setAttribute("queryLcm05", form.getQueryLcm05());

			page = 4;

		}else if (arg1.getActionCode() == 8){//第四頁修改諮詢內容頁面按確定修改
			
			model.processUpdateLct();
			
			Map  lcm = model.queryLcmaByLcm01();
			
			List lctList = model.queryCOM_LCTEListByLct01();
			
			arg2.setAttribute("lctList", lctList);
			arg2.setAttribute("ldep", ldep);
			arg2.setAttribute("detail", lcm);
			arg2.setAttribute("uName", uname);
			String queryLcm01 = form.getQueryLcm01().toString().trim();
			arg2.setAttribute("queryLcm01", queryLcm01);
			arg2.setAttribute("queryStartDate", form.getQueryStartDate());
			arg2.setAttribute("queryEndDate", form.getQueryEndDate());
			arg2.setAttribute("queryLcm05", form.getQueryLcm05());
			
			page = 3;

		}

		form.setNextPage(page);
	}
	
}
