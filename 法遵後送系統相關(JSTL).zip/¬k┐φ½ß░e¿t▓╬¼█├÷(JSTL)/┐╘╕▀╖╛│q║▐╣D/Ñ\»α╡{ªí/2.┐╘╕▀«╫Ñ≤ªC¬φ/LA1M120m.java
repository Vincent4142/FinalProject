/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.kyc.la1.models;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.dao.COM_LCMADao;
import com.kyc.la1.dao.COM_LCTEDao;
import com.kyc.la1.dao.PSM3PFDao;
import com.kyc.la1.forms.LA1M120f;

/**
 * <!--程式說明寫在此-->
 * 
 * 法令遵循系統-法令遵循系統-諮詢溝通案件查詢
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1M120m extends AsiModel
{

	private static Log logger = LogFactory.getLog(LA1M120m.class);

	private LA1M120f mform;

	private TransactionControl tx_controller;

	public LA1M120m(TransactionControl tx_controller,
			HttpServletRequest request, AsiActionForm form)
	{
		super(tx_controller, request, form);
		this.tx_controller = tx_controller;
	}

	//初始化
	public void init() throws AsiException
	{

		mform = new LA1M120f();
		// 把form做拷貝
		try
		{
			BeanUtils.copyProperties(mform, getForm());
		} catch (InvocationTargetException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		} catch (IllegalAccessException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		}
		setMainForm(mform);

	}

	
	//諮詢案號查詢該筆資明細
	public Map queryLcmaByLcm01() throws AsiException
	{
		COM_LCMADao dao = new COM_LCMADao(getTransaction());		
		dao.setLcm01(mform.getLcm01());		
		Map lcm = dao.getCOM_LCMAByLcm01();		
		Map ldep = queryLcm(lcm.get("lcm08").toString().trim());
		lcm.put("lcm02cn", ldep.get("M203").toString().trim());
		
		return lcm;
		
	}
	

	
	//userId取部門資料
	public Map queryLcm (String userId) throws AsiException
	{
		PSM3PFDao dao = new PSM3PFDao();		
		dao.setM301(userId);		
		Map lcm = dao.queryM203();
		return lcm;
		
	}
	
	//依照日期區間及狀態取得資料
	public List queryCOM_LCMAList(String depId) throws AsiException
	{
		COM_LCMADao dao = new COM_LCMADao(getTransaction());
		
		String lcm05 = mform.getQueryLcm05() == null ? "" : mform.getQueryLcm05().toString().trim();				
		dao.setLcm05(lcm05);			
		dao.setSdate(mform.getQueryStartDate());
		dao.setEdate(mform.getQueryEndDate());
				
		List lcm = dao.getCOM_LCMAList(depId);
		
		for (int i = 0; i < lcm.size(); i++) {
			
			Map mp = (Map) lcm.get(i);						
			Map ldep = queryLcm(mp.get("lcm08").toString().trim());			
			mp.put("lcm02cn", ldep.get("M203").toString().trim());						
			
		}		
		
		return lcm;
		
	}
	
	//輸入諮詢案號查詢列表
	public List queryCOM_LCMAListByLcm01(String depId) throws AsiException
	{
		COM_LCMADao dao = new COM_LCMADao(getTransaction());		
		String lcm01 = mform.getQueryLcm01() == null ? "" : mform.getQueryLcm01().toString().trim();			
		dao.setLcm01(lcm01);					
		List lcm = dao.getCOM_LCMAListByLcm01(depId);
		
		for (int i = 0; i < lcm.size(); i++) {
			
			Map mp = (Map) lcm.get(i);						
			Map ldep = queryLcm(mp.get("lcm08").toString().trim());			
			mp.put("lcm02cn", ldep.get("M203").toString().trim());						
			
		}
					
		return lcm;		
	}
	
	//查詢lct01的資料
	public List queryCOM_LCTEListByLct01() throws AsiException
	{
		
		COM_LCTEDao dao = new COM_LCTEDao(getTransaction());
		dao.setLct01(mform.getLcm01());							
		List lct = (List) dao.queryCOM_LCTE();
			
		for (int i = 0; i < lct.size(); i++) {
			
			Map mp = (Map) lct.get(i);						
			Map ldep = queryLcm(mp.get("lct08").toString().trim());			
			mp.put("lct02cn", ldep.get("M203").toString().trim());						
			
		}

		return lct;
		
	}
	
	//依據諮詢案號及序號查詢單筆lct資料
	public Map queryCOM_LCTEByLct01AndLct05() throws AsiException
	{
		COM_LCTEDao dao = new COM_LCTEDao(getTransaction());
		dao.setLct01(mform.getLct01());	
		dao.setLct05(mform.getLct05());			

		Map lct = (Map) dao.queryCOM_LCTEByKct01AndLct05();		
		Map ldep = queryLcm(lct.get("lct08").toString().trim());		
		lct.put("lct02cn", ldep.get("M203").toString().trim());
						
		return lct;
		
	}
	
	//新增諮詢回覆及更新諮詢主檔
	public void processSaveLct(String depId,String uname) throws AsiException
	{
		
		//Map mp = queryLcmaByLcm01();		
		String lcm01 = mform.getLcm01();		
		COM_LCTEDao lctedao = new COM_LCTEDao(getTransaction());

		lctedao.setLct01(lcm01);
		lctedao.setLct02(depId);
		lctedao.setLct03(uname);
		lctedao.setLct04(mform.getLct04());
		lctedao.setLct05(getlct05());
		lctedao.setLct06(DateUtil.getSysDate(getUsrInfo(), false));
		lctedao.setLct07(DateUtil.getSysTime(false));
		lctedao.setLct08(getUsrInfo().getUserId());
		lctedao.setLct09(DateUtil.getSysDate(getUsrInfo(), false));
		lctedao.setLct10(DateUtil.getSysTime(false));
		lctedao.setLct11(getUsrInfo().getUserId());	
		
		COM_LCMADao lcmadao = new COM_LCMADao(getTransaction());					
		lcmadao.setLcm01(lcm01);

		try {
			//新增諮詢內容檔
			lctedao.insertCOM_LCTE();
			//更新諮詢案件主檔
			lcmadao.updateStatusCOM_LCMA(depId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

		
	}
	
	//更新單筆回覆內容
	public void processUpdateLct() throws AsiException
	{
				
		String lct01 = mform.getLct01();
		String lct05 = mform.getLct05();		
		COM_LCTEDao lctedao = new COM_LCTEDao(getTransaction());

		lctedao.setLct01(lct01);
		lctedao.setLct04(mform.getLct04());
		lctedao.setLct05(lct05);
		lctedao.setLct09(DateUtil.getSysDate(getUsrInfo(), false));
		lctedao.setLct10(DateUtil.getSysTime(false));
		lctedao.setLct11(getUsrInfo().getUserId());

		try {
			lctedao.updateCOM_LCTE();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

	//編lct05序號
	public String getlct05() throws AsiException
	{
		COM_LCTEDao dao = new COM_LCTEDao(getTransaction());
		dao.setLct01(mform.getLcm01());

		Map mp = dao.queryLct05();
		
		String lct05 = "";	
		if(mp.get("LCT05") != null){
			lct05 = mp.get("LCT05").toString();			
		}else{
			lct05 = "1";
		}
		
		return lct05;

	}
	
	

	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}
}
