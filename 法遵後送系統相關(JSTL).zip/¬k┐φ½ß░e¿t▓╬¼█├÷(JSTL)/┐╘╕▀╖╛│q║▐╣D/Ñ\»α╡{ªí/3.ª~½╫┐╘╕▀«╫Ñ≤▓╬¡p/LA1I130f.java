package com.kyc.la1.forms;

import com.asi.common.struts.AsiActionForm;

/**
 * 法令遵循系統-年度諮詢統計
 * 
 * @author ：alexYang
 * 建立日期	：2021/10/25
 * 異動註記	：

 */

public class LA1I130f extends AsiActionForm
{
	private static final long serialVersionUID = 1L;
	
	private String queryStartDate;
	private String queryEndDate;
	private String selectNo;//選取部門
	private String selectYear;//選取年度
	
	public String getQueryStartDate() {
		return queryStartDate;
	}
	public void setQueryStartDate(String queryStartDate) {
		this.queryStartDate = queryStartDate;
	}
	public String getQueryEndDate() {
		return queryEndDate;
	}
	public void setQueryEndDate(String queryEndDate) {
		this.queryEndDate = queryEndDate;
	}
	public String getSelectNo() {
		return selectNo;
	}
	public void setSelectNo(String selectNo) {
		this.selectNo = selectNo;
	}
	public String getSelectYear() {
		return selectYear;
	}
	public void setSelectYear(String selectYear) {
		this.selectYear = selectYear;
	}
	@Override
	public String toString() {
		return "LA1I130f [queryStartDate=" + queryStartDate + ", queryEndDate=" + queryEndDate + ", selectNo="
				+ selectNo + ", selectYear=" + selectYear + "]";
	}

}
