package com.kyc.la1.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.forms.LA1I130f;
import com.kyc.la1.models.LA1I130m;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-年度諮詢統計
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1I1301 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		LA1I130f form = (LA1I130f) arg1;
		
		LA1I130m model = new LA1I130m(tx_controller, arg2, form);
		model.init();
		
		int page = 1;

		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String dateS = sysdate.substring(0, 5) + "01";
		String dateE = sysdate;
		HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String user = ui.getUserId(); 
		
		if (form.getActionCode() == 5)
		{				
			arg2.setAttribute("sysdate", sysdate);
			arg2.setAttribute("dateS", dateS);
			arg2.setAttribute("dateE", dateE);
			
			List<?> list = model.queryLcmaCount(dateS, dateE);
			
			arg2.setAttribute("lcmaList", list);
			page = 1;
		}
		else if (form.getActionCode() == 6)//查詢
		{
			String startDate = form.getQueryStartDate();
			String endDate = form.getQueryEndDate();
			
			arg2.setAttribute("sysdate", sysdate);
			arg2.setAttribute("dateS", startDate);
			arg2.setAttribute("dateE", endDate);
			
			List<?> list = model.queryLcmaCount(startDate, endDate);
			arg2.setAttribute("lcmaList", list);
			
			page = 1;
		}
		else if (form.getActionCode() == 7)//案件明細查詢
		{				
			String startDate = form.getQueryStartDate();
			String endDate = form.getQueryEndDate();
			String selectNo = form.getSelectNo();
			String selectYear = form.getSelectYear();
			arg2.setAttribute("sysdate", sysdate);
			arg2.setAttribute("dateS", startDate);
			arg2.setAttribute("dateE", endDate);
			List<?> list = model.queryLcmaCountDetail(startDate, endDate,selectNo);
			
			arg2.setAttribute("lcmaList", list);				
			page = 2;
			
		}
			

		form.setNextPage(page);
	}
		
		 
}
