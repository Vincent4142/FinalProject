/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.kyc.la1.models;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.kyc.la1.dao.COM_LCMADao;
import com.kyc.la1.dao.COM_LDEPDao;
import com.kyc.la1.forms.LA1I130f;

/**
 * 法令遵循系統-年度諮詢統計
 * 
 * @author ：alexYang
 * 建立日期	：2021/10/25
 * 異動註記	：

 */
public class LA1I130m extends AsiModel
{

	private static Log logger = LogFactory.getLog(LA1I130m.class);

	private LA1I130f mform;

	private TransactionControl tx_controller;

	public LA1I130m(TransactionControl tx_controller,
			HttpServletRequest request, AsiActionForm form)
	{
		super(tx_controller, request, form);
		this.tx_controller = tx_controller;
	}

	//初始化
	public void init() throws AsiException
	{

		mform = new LA1I130f();
		// 把form做拷貝
		try
		{
			BeanUtils.copyProperties(mform, getForm());
		} catch (InvocationTargetException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		} catch (IllegalAccessException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		}
		setMainForm(mform);

	}

	
	/**
	 * 年度諮詢統計表
	 * 
	 * @author alexYang
	 * @param startDate：諮詢開始日期
	 * @param endDate：諮詢結束日期
	 */
	public List<?> queryLcmaCount(String startDate, String endDate) throws AsiException
	{
		List<?> list = null;
		
		COM_LCMADao com_LcmaDao = new COM_LCMADao(getTransaction());
						
		list = 	com_LcmaDao.queryLcmaCount(startDate, endDate);

		for (int i = 0; i < list.size(); i++) {
			
			Map mp = (Map) list.get(i);
			
			System.err.println("mp == " + mp);
			
			Map ldep = queryLde02(mp.get("lcm02").toString().trim());
			
			mp.put("lcm02cn", ldep.get("LDE02").toString().trim());						
			
		}
		
		return list;
	}
	
	/**
	 * 年度諮詢統計明細
	 * 
	 * @author alexYang
	 * @param startDate：後送開始日期
	 * @param endDate：後送結束日期
	 * @param lcm02：部門代號
	 */
	public List<?> queryLcmaCountDetail(String startDate, String endDate, String lcm02) throws AsiException
	{
		List<?> list = null;
		
		COM_LCMADao com_LcmaDao = new COM_LCMADao(getTransaction());
						
		list = 	com_LcmaDao.queryLcmaCountDetail(startDate, endDate,lcm02);

		for (int i = 0; i < list.size(); i++) {
			
			Map mp = (Map) list.get(i);
			
			System.err.println("mp == " + mp);
			
			Map ldep = queryLde02(mp.get("lcm02").toString().trim());
			
			mp.put("lcm02cn", ldep.get("LDE02").toString().trim());						
			
		}
		
		return list;
	}
	
	//部門代碼轉換中文
	public Map queryLde02 (String lcm02) throws AsiException
	{
		COM_LDEPDao dao = new COM_LDEPDao();
		
		List lst = dao.getCOM_LDEPOne(lcm02);
				
		Map lcm = (Map) lst.get(0);

		return lcm;
		
	}
	
	
	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}
}
