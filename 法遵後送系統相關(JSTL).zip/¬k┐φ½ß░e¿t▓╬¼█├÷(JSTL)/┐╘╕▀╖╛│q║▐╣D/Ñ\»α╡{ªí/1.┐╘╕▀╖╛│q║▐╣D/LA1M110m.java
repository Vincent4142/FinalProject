/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.kyc.la1.models;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.upload.FormFile;

import com.asi.common.AsiModel;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.dao.COM_LCATDao;
import com.kyc.la1.dao.COM_LCMADao;
import com.kyc.la1.dao.COM_LCTEDao;
import com.kyc.la1.dao.PSM3PFDao;
import com.kyc.la1.forms.LA1M110f;

/**
 * <!--程式說明寫在此-->
 * 
 * 法令遵循系統-新增諮詢溝通案件
 * 
 * @author ：alexYang
 * 建立日期	：2021/10/25
 * 異動註記	：
 */
public class LA1M110m extends AsiModel
{

	private static Log logger = LogFactory.getLog(LA1M110m.class);

	private LA1M110f mform;

	private TransactionControl tx_controller;

	public LA1M110m(TransactionControl tx_controller,
			HttpServletRequest request, AsiActionForm form)
	{
		super(tx_controller, request, form);
		this.tx_controller = tx_controller;
	}

	//初始化
	public void init() throws AsiException
	{

		mform = new LA1M110f();
		// 把form做拷貝
		try
		{
			BeanUtils.copyProperties(mform, getForm());
		} catch (InvocationTargetException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		} catch (IllegalAccessException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		}
		setMainForm(mform);

	}

	
	// userid 取得部門資料
	public Map queryLcm (String userId) throws AsiException
	{
		PSM3PFDao dao = new PSM3PFDao();
		
		dao.setM301(userId);
		
		Map lcm = dao.queryM203();

		return lcm;
		
	}
	
	//儲存
	public void processSave(HttpServletRequest arg2,String lca04) throws AsiException
	{
		COM_LCMADao lcmadao = new COM_LCMADao(getTransaction());//新增主檔
		COM_LCTEDao lctedao = new COM_LCTEDao(getTransaction());//新增諮詢訊息
		COM_LCATDao lcatdao = new COM_LCATDao(getTransaction());//新增附件

		String lcm01 = getlcm01();
		lcmadao.setLcm01(lcm01);
		lcmadao.setLcm02(mform.getLcm02());
		lcmadao.setLcm03(mform.getLcm03());
		lcmadao.setLcm04(mform.getLcm04());
		lcmadao.setLcm05("N");
		lcmadao.setLcm06(DateUtil.getSysDate(getUsrInfo(), false));
		lcmadao.setLcm07(DateUtil.getSysTime(false));
		lcmadao.setLcm08(getUsrInfo().getUserId());
		lcmadao.setLcm09(DateUtil.getSysDate(getUsrInfo(), false));
		lcmadao.setLcm10(DateUtil.getSysTime(false));
		lcmadao.setLcm11(getUsrInfo().getUserId());

		lctedao.setLct01(lcm01);
		lctedao.setLct02(mform.getLcm02());
		lctedao.setLct03(mform.getLcm03());
		lctedao.setLct04(mform.getLct04());
		lctedao.setLct05(getlct05());
		lctedao.setLct06(DateUtil.getSysDate(getUsrInfo(), false));
		lctedao.setLct07(DateUtil.getSysTime(false));
		lctedao.setLct08(getUsrInfo().getUserId());
		lctedao.setLct09(DateUtil.getSysDate(getUsrInfo(), false));
		lctedao.setLct10(DateUtil.getSysTime(false));
		lctedao.setLct11(getUsrInfo().getUserId());

		int ret = 0;
		try {
			int lcma = lcmadao.insertCOM_LCMA();
			int lcte = lctedao.insertCOM_LCTE();
			//有上傳附件才作新增附件的動作
			if(!"".equals(mform.getUploadFileName()) && mform.getUploadFileName() !=null) {
				
				lcatdao.setLca01(lcm01);
				lcatdao.setLca02(mform.getLcm02());
				lcatdao.setLca03(getlca03());
				lcatdao.setLca04(DateUtil.getSysTime(false));
				lcatdao.setLca05(mform.getUploadFileName());//檔案名稱
				lcatdao.setLca06(mform.getLca06());//檔案說明
				lcatdao.setLca07(DateUtil.getSysDate(getUsrInfo(), false));
				lcatdao.setLca08(DateUtil.getSysTime(false));
				lcatdao.setLca09(getUsrInfo().getUserId());
				lcatdao.setLca10(DateUtil.getSysDate(getUsrInfo(), false));
				lcatdao.setLca11(DateUtil.getSysTime(false));
				lcatdao.setLca12(getUsrInfo().getUserId());
				
				int lcat=lcatdao.insertCOM_LCAT();
				processInsert(lca04);
			}
				
			if (lcma == 1 && lcte == 1) {
				ret = 1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(ret==1)
			arg2.setAttribute("msg", "諮詢案號" + lcm01 + "新增成功");
		
		
	}
	
	//編lcm01序號
	public String getlcm01() throws AsiException
	{
		COM_LCMADao lcmadao = new COM_LCMADao(getTransaction());
		String lcm01sn = lcmadao.getCOM_LCMASN(DateUtil.getSysDate(getUsrInfo(), false).substring(0,3),mform.getLcm02());
		
		String lcm01 = DateUtil.getSysDate(getUsrInfo(), false).substring(0,3) + mform.getLcm02() + lcm01sn;
				
		return lcm01;
	}
	
	
	//取得lct05序號
	public String getlct05() throws AsiException
	{
		COM_LCTEDao dao = new COM_LCTEDao(getTransaction());
		dao.setLct01("LCT0001");

		Map mp = dao.queryLct05();
		
		String lct05 = "";	
		if(mp.get("LCT05") != null){
			lct05 = mp.get("LCT05").toString();
		}else{
			lct05 = "1";
		}
		
		return lct05;

	}
	
	//編lca03上船序號
	public String getlca03() throws AsiException
	{
		COM_LCATDao dao = new COM_LCATDao(getTransaction());

		Map mp = dao.queryLca03();
		
		String lca03 = "";	
		if(mp.get("LCA03") != null){
			lca03 = mp.get("LCA03").toString();			
		}else{
			lca03 = "1";
		}
		
		return lca03;

	}
	
	//資料存檔
	public void processInsert( String lca04) throws AsiException 
	{
		try
		{
			FormFile file = mform.getUploadFile();				
			lca04 = lca04.replaceAll("^(0+)", "");
			InputStream fis = file.getInputStream();
			if (fis.available() != 0)
			{
				
				File dir_file = new File("C:\\KYCDOCUMENTS\\LA1M140\\");   /*路徑跟檔名*/
				if(!dir_file.exists()) {
					dir_file.mkdir();
					logger.info("建立檔案目錄： C:\\KYCDOCUMENTS\\LA1M140 ");
				}			    
			    
				String path = "C:\\KYCDOCUMENTS\\LA1M140\\" + lca04;
				
				OutputStream fos = new FileOutputStream(path);
				int bytesRead = 0;
				byte[] buffer = new byte[8192];
				while ((bytesRead = fis.read(buffer, 0, 8192)) != -1)
				{
					fos.write(buffer, 0, bytesRead);
				}
	            fos.close();
			}
	        fis.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}
}
