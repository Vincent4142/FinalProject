package com.kyc.la1.actions;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.la1.forms.LA1M110f;
import com.kyc.la1.models.LA1M110m;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-新增諮詢溝通案件
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1M1101 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		
		LA1M110f form = (LA1M110f)arg1;
		String systime = DateUtil.getSysTime();    
		
		LA1M110m model = new LA1M110m(tx_controller, arg2, form);
		model.init();
		
        HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String user = ui.getUserId();      
		String userName = Employee.getEmployee(user).getName();      

		Map lcm = model.queryLcm(user);
		
		arg2.setAttribute("lcm", lcm);
		arg2.setAttribute("userId", user);
		arg2.setAttribute("userName", userName);
		
		if (arg1.getActionCode() == 1){		
			model.processSave(arg2,systime);					
		}

		arg1.setNextPage(1);
	}
	
	
		
}
