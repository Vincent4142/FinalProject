/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of The First
 * Insurance Co, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with The First Insurance Co, Ltd.
 *
 */
package com.kyc.la1.dao;

import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;

/**
 * <--法遵管理系統-諮詢溝通案件主檔 -->
 *
 * @author alexYang
 * @Create Date：2021/10/25
 * @UpdateDate:
 * @FileName: COM_LCMADao.java
 */
public class COM_LCMADao extends com.kyc2.ccp.dao.IDao
{

	public COM_LCMADao(TransactionControl txc) {
		super(txc);
	}


	/**
	 * 新增諮詢溝通案件主檔
	 * @return ret
	 * @throws AsiException
	 */		
	public int insertCOM_LCMA() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO COM_LCMA (LCM01,LCM02,LCM03,LCM04,LCM05,");
			sql.append("LCM06,LCM07,LCM08,LCM09,LCM10,LCM11) VALUES");
			sql.append("(?,?,?,?,?,?,?,?,?,?,?) ");
			
			String args[] = new String[11];
			args[0] = lcm01;
			args[1] = lcm02;
			args[2] = lcm03;
			args[3] = lcm04;
			args[4] = lcm05;
			args[5] = lcm06;
			args[6] = lcm07;
			args[7] = lcm08;
			args[8] = lcm09;
			args[9] = lcm10;
			args[10] = lcm11;
			
			checkSqlArgs(args);
			txc.begin(0);
			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	public int updateCOM_LCMA() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE COM_LCMA set LCM02=?,LCM03=?,LCM04=?,LCM05=?,LCM09=?,LCM10=?,LCM11=? ");
			sql.append("WHERE LCM01=? ");
			
			String args[] = new String[8];
			args[0] = lcm02;
			args[1] = lcm03;
			args[2] = lcm04;
			args[3] = lcm05;
			args[4] = lcm09;
			args[5] = lcm10;
			args[6] = lcm11;
			args[7] = lcm01;
			
			checkSqlArgs(args);
			txc.begin(0);

			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	//新增諮詢內容後更新LCM05(諮詢狀態)
	public void updateStatusCOM_LCMA(String depId) throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE COM_LCMA set LCM05=? ");
			sql.append("WHERE LCM01=? ");
			
			String args[] = new String[2];
			//判斷：法遵(13)LCM05=Y，其餘部門LCM05=N
			if("13".equals(depId)) {
				args[0]="Y";
			}else {
				args[0]="N";
			}	
			args[1] = lcm01;

			
			checkSqlArgs(args);
			txc.begin(0);

			runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	public int deleteCOM_LCMA() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("DELETE from COM_LCMA WHERE LCM01=? ");
			
			String args[] = new String[1];
			args[0] = lcm01;
			
			checkSqlArgs(args);
			txc.begin(0);

			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	public List getCOM_LCMAList(String depId) throws AsiException
	{
		List ret = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			
			StringBuffer sql = new StringBuffer();
			
			int num;
			
			if(lcm05.equals("ALL")) {
				sql.append("SELECT * FROM COM_LCMA WHERE LCM06 BETWEEN ? AND ? AND LCM02 like ? order by LCM01 ");
				num=3;
			}
			else {
				sql.append("SELECT * FROM COM_LCMA WHERE LCM05 =? AND LCM06 BETWEEN ? AND ? AND LCM02 like ? order by LCM01 ");
				num=4;
			}		
						
			String args[] = new String[num];
			if(lcm05.equals("ALL")) {
				args[0] = sdate;
				args[1] = edate;
				//權限判斷：法遵可查所有案件，其餘部門只能查自己部門的案件
				if("13".equals(depId)) {
					args[2]="%";
				}else {
					args[2]=depId;
				}
			}
			else {
				args[0] = lcm05;
				args[1] = sdate;
				args[2] = edate;
				//權限判斷：法遵可查所有案件，其餘部門只能查自己部門的案件
				if("13".equals(depId)) {
					args[3]="%";
				}else {
					args[3]=depId;
				}
			}		
			
			checkSqlArgs(args);
			txc.begin(0);
			ret = (List) runner.query(txc.getConnection(), sql.toString(), args, new MapListHandler());
			runner = null;	
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		return ret;
	}
	
	public List getCOM_LCMAListByLcm01(String depId) throws AsiException
	{
		List ret = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM COM_LCMA WHERE LCM01 =? AND LCM02 like ? ");
						
			String args[] = new String[2];
			args[0] = lcm01;
			//權限判斷：法遵可查所有案件，其餘部門只能查自己部門的案件
			if("13".equals(depId)) {
				args[1]="%";
			}else {
				args[1]=depId;
			}
			
			checkSqlArgs(args);
			txc.begin(0);

			ret = (List) runner.query(txc.getConnection(), sql.toString(), args, new MapListHandler());
			runner = null;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		return ret;
	}
	
	public Map getCOM_LCMAByLcm01() throws AsiException
	{
		Map ret = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM COM_LCMA WHERE LCM01 =? ");
						
			String args[] = new String[1];
			args[0] = lcm01;	
			
			checkSqlArgs(args);
			txc.begin(0);
			
			ret = (Map) runner.query(txc.getConnection(), sql.toString(), args, new MapHandler());
			runner = null;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		return ret;
	}
	
	
	
	public String getCOM_LCMASN(String year,String lcm02) throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT MAX(SUBSTR(LCM01,6,10))+1 AS SN FROM COM_LCMA WHERE SUBSTR(LCM06,0,3) = ? AND LCM02 = ? ");
			
			String args[] = new String[2];
			args[0] = year;
			args[1] = lcm02;
			
			checkSqlArgs(args);
			txc.begin(0);

			Map  ret = (Map) runner.query(txc.getConnection(), sql.toString(), args , new MapHandler()  );
			
			String sn = "";
			runner = null;			

			if (ret.get("sn") == null) {
				sn = "0001";
			}else {				
				
				if(ret.get("sn").toString().length() == 1) {
					sn = "000" + ret.get("sn").toString();
				}else if(ret.get("sn").toString().length() == 2){
					sn = "00" + ret.get("sn").toString();
				}else if(ret.get("sn").toString().length() == 3){
					sn = "0" + ret.get("sn").toString();
				}else if(ret.get("sn").toString().length() == 4){
					sn = ret.get("sn").toString();
				}	
				
			}

			return sn;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		

	}



	public List<?> queryLcmaCount(String startDate, String endDate) throws AsiException
	{
		
		List<?> list = null;
		Integer yr = (int) Math.floor(Double.parseDouble(startDate) / 10000);
		
		try
		{
		
			String sql = "SELECT LCM02, ";
			sql = sql + "sum(case when floor(LCM06 / 10000) = ? then 1 else 0 end) LAWCNT1, ";
			sql = sql + "sum(case when floor(LCM06 / 10000) = ? then 1 else 0 end) LAWCNT2, ";
			sql = sql + "sum(case when floor(LCM06 / 10000) = ? then 1 else 0 end) LAWCNT3, ";
			sql = sql + "sum(case when floor(LCM06 / 10000) = ? then 1 else 0 end) LAWCNT4, ";
			sql = sql + "sum(case when floor(LCM06 / 10000) = ? then 1 else 0 end) LAWCNT5 ";
			sql = sql + "FROM COM_LCMA ";
			sql = sql + "WHERE LCM06 between ? and ? ";
			sql = sql + "Group By LCM02 ";
			
			String args[] = new String[7];
	        args[0] = yr.toString();
	        args[1] = Integer.toString(++yr);
	        args[2] = Integer.toString(++yr);
	        args[3] = Integer.toString(++yr);
	        args[4] = Integer.toString(++yr);
	        args[5] = startDate;
	        args[6] = endDate;

			QueryRunner run = new QueryRunner();	
			txc.begin(0);
			
			list = (List<?>) run.query(txc.getConnection(), sql, args, new MapListHandler());

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<?> queryLcmaCountDetail(String startDate, String endDate, String lcm02) throws AsiException
	{
		
		List<?> list = null;
		
		try
		{
		
			String sql = "SELECT * FROM COM_LCMA ";
			sql = sql + "WHERE LCM02 = ? AND LCM06 between ? and ? ";
			sql = sql + "ORDER BY LCM01,LCM06 ";
			
			String args[] = new String[3];
	        args[0] = lcm02;
	        args[1] = startDate;
	        args[2] = endDate;

			QueryRunner run = new QueryRunner();	
			txc.begin(0);
			
			list = (List<?>) run.query(txc.getConnection(), sql, args, new MapListHandler());
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	private String lcm01;	
	private String lcm02;	
	private String lcm03;	
	private String lcm04;	
	private String lcm05;		
	private String lcm06;	
	private String lcm07;	
	private String lcm08;	
	private String lcm09;	
	private String lcm10;	
	private String lcm11;
	
	private String sdate;// 起始日期
	private String edate;// 結束日期
	
	
	public String getLcm01() {
		return lcm01;
	}

	public void setLcm01(String lcm01) {
		this.lcm01 = lcm01;
	}

	public String getLcm02() {
		return lcm02;
	}

	public void setLcm02(String lcm02) {
		this.lcm02 = lcm02;
	}

	public String getLcm03() {
		return lcm03;
	}

	public void setLcm03(String lcm03) {
		this.lcm03 = lcm03;
	}

	public String getLcm04() {
		return lcm04;
	}

	public void setLcm04(String lcm04) {
		this.lcm04 = lcm04;
	}

	public String getLcm05() {
		return lcm05;
	}

	public void setLcm05(String lcm05) {
		this.lcm05 = lcm05;
	}

	public String getLcm06() {
		return lcm06;
	}

	public void setLcm06(String lcm06) {
		this.lcm06 = lcm06;
	}

	public String getLcm07() {
		return lcm07;
	}

	public void setLcm07(String lcm07) {
		this.lcm07 = lcm07;
	}

	public String getLcm08() {
		return lcm08;
	}

	public void setLcm08(String lcm08) {
		this.lcm08 = lcm08;
	}

	public String getLcm09() {
		return lcm09;
	}

	public void setLcm09(String lcm09) {
		this.lcm09 = lcm09;
	}

	public String getLcm10() {
		return lcm10;
	}

	public void setLcm10(String lcm10) {
		this.lcm10 = lcm10;
	}

	public String getLcm11() {
		return lcm11;
	}

	public void setLcm11(String lcm11) {
		this.lcm11 = lcm11;
	}


	public String getSdate() {
		return sdate;
	}


	public void setSdate(String sdate) {
		this.sdate = sdate;
	}


	public String getEdate() {
		return edate;
	}


	public void setEdate(String edate) {
		this.edate = edate;
	}

	

	
}
