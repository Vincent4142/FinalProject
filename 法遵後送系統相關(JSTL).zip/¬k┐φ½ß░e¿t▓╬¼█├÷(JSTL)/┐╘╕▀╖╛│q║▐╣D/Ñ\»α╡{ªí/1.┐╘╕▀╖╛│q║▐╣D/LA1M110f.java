package com.kyc.la1.forms;

import org.apache.struts.upload.FormFile;

import com.asi.common.struts.AsiActionForm;

/**
 * 法令遵循系統-新增諮詢溝通案件
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */

public class LA1M110f extends AsiActionForm
{
	private static final long serialVersionUID = 1L;
	
	private String lcm01;// 諮詢案號
	private String lcm02;// 諮詢部門
	private String lcm03;// 姓名
	private String lcm04;// 諮詢摘要
	private String lcm05;// 諮詢狀態
	private String lcm02cn;// 諮詢部門中文
	private String lct04;// 諮詢內容
	private String lca06;
	private FormFile uploadFile;//上傳附件
	private String uploadFileName;

	public String getLca06() {
		return lca06;
	}
	public void setLca06(String lca06) {
		this.lca06 = lca06;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public FormFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(FormFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getLcm01() {
		return lcm01;
	}
	public void setLcm01(String lcm01) {
		this.lcm01 = lcm01;
	}
	public String getLcm02() {
		return lcm02;
	}
	public void setLcm02(String lcm02) {
		this.lcm02 = lcm02;
	}
	public String getLcm03() {
		return lcm03;
	}
	public void setLcm03(String lcm03) {
		this.lcm03 = lcm03;
	}
	public String getLcm04() {
		return lcm04;
	}
	public void setLcm04(String lcm04) {
		this.lcm04 = lcm04;
	}
	public String getLcm05() {
		return lcm05;
	}
	public void setLcm05(String lcm05) {
		this.lcm05 = lcm05;
	}
	public String getLcm02cn() {
		return lcm02cn;
	}
	public void setLcm02cn(String lcm02cn) {
		this.lcm02cn = lcm02cn;
	}
	public String getLct04() {
		return lct04;
	}
	public void setLct04(String lct04) {
		this.lct04 = lct04;
	}
	@Override
	public String toString() {
		return "LA1M110f [lcm01=" + lcm01 + ", lcm02=" + lcm02 + ", lcm03=" + lcm03 + ", lcm04=" + lcm04 + ", lcm05="
				+ lcm05 + ", lcm02cn=" + lcm02cn + ", lct04=" + lct04 + "]";
	}

}
