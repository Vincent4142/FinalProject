/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of The First
 * Insurance Co, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with The First Insurance Co, Ltd.
 *
 */
package com.kyc.la1.dao;

import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;

/**
 * <--法遵管理系統-諮詢溝通訊息紀錄檔 -->
 *
 * @author alexYang
 * @Create Date：2021/10/25
 * @UpdateDate:
 * @FileName: COM_LCTEDao.java
 */
public class COM_LCTEDao extends com.kyc2.ccp.dao.IDao
{

	public COM_LCTEDao(TransactionControl txc) {
		super(txc);
	}

	
	//新增
	public int insertCOM_LCTE() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO COM_LCTE (LCT01,LCT02,LCT03,LCT04,LCT05,");
			sql.append("LCT06,LCT07,LCT08,LCT09,LCT10,LCT11) VALUES");
			sql.append("(?,?,?,?,?,?,?,?,?,?,?) ");
			
			String args[] = new String[11];
			args[0] = lct01;
			args[1] = lct02;
			args[2] = lct03;
			args[3] = lct04;
			args[4] = lct05;
			args[5] = lct06;
			args[6] = lct07;
			args[7] = lct08;
			args[8] = lct09;
			args[9] = lct10;
			args[10] = lct11;
			
			checkSqlArgs(args);
			txc.begin(0);

			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	//修改
	public int updateCOM_LCTE() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE COM_LCTE set LCT04=?,LCT09=?,LCT10=?,LCT11=? ");
			sql.append("WHERE LCT01=? AND LCT05=? ");
			
			String args[] = new String[6];
			args[0] = lct04;
			args[1] = lct09;
			args[2] = lct10;
			args[3] = lct11;
			args[4] = lct01;
			args[5] = lct05;

			
			checkSqlArgs(args);
			txc.begin(0);

			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	public int deleteCOM_LCTE() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("DELETE from COM_LCTE WHERE LCT01=? ");
			
			String args[] = new String[1];
			args[0] = lct01;
			
			checkSqlArgs(args);
			txc.begin(0);

			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	
	public List queryCOM_LCTE() throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT * FROM COM_LCTE WHERE LCT01 = ? ORDER BY LCT05 ");
			
			String args[] = new String[1];
			args[0] = lct01;
			
			checkSqlArgs(args);
			txc.begin(0);

			List ret = null ;
			ret = (List) runner.query(txc.getConnection(), sql.toString(), args , new MapListHandler()  );
			
			runner = null;
	
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		

	}
	
	public Map queryCOM_LCTEByKct01AndLct05() throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT * FROM COM_LCTE WHERE LCT01 = ? AND LCT05 = ? ");
			
			String args[] = new String[2];
			args[0] = lct01;
			args[1] = lct05;

			
			checkSqlArgs(args);
			txc.begin(0);

			Map ret = null ;
			ret = (Map) runner.query(txc.getConnection(), sql.toString(), args , new MapHandler()  );
			
			runner = null;
	
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		

	}

	public Map queryLct05() throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT MAX(LCT05)+1 LCT05 FROM COM_LCTE WHERE LCT01 = ? ");
			
			String args[] = new String[1];
			args[0] = lct01;
			
			checkSqlArgs(args);
			txc.begin(0);

			Map ret = null ;
			ret = (Map) runner.query(txc.getConnection(), sql.toString(), args , new MapHandler()  );
		
			runner = null;
	
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		

	}
	
	
	private String lct01;
	private String lct02;
	private String lct03;
	private String lct04;
	private String lct05;
	private String lct06;
	private String lct07;
	private String lct08;
	private String lct09;
	private String lct10;
	private String lct11;
	
	
	public String getLct01() {
		return lct01;
	}

	public void setLct01(String lct01) {
		this.lct01 = lct01;
	}

	public String getLct02() {
		return lct02;
	}

	public void setLct02(String lct02) {
		this.lct02 = lct02;
	}

	public String getLct03() {
		return lct03;
	}

	public void setLct03(String lct03) {
		this.lct03 = lct03;
	}

	public String getLct04() {
		return lct04;
	}

	public void setLct04(String lct04) {
		this.lct04 = lct04;
	}

	public String getLct05() {
		return lct05;
	}

	public void setLct05(String lct05) {
		this.lct05 = lct05;
	}

	public String getLct06() {
		return lct06;
	}

	public void setLct06(String lct06) {
		this.lct06 = lct06;
	}

	public String getLct07() {
		return lct07;
	}

	public void setLct07(String lct07) {
		this.lct07 = lct07;
	}

	public String getLct08() {
		return lct08;
	}

	public void setLct08(String lct08) {
		this.lct08 = lct08;
	}

	public String getLct09() {
		return lct09;
	}

	public void setLct09(String lct09) {
		this.lct09 = lct09;
	}

	public String getLct10() {
		return lct10;
	}

	public void setLct10(String lct10) {
		this.lct10 = lct10;
	}

	public String getLct11() {
		return lct11;
	}

	public void setLct11(String lct11) {
		this.lct11 = lct11;
	}
	
	
	
	
}
