/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of The First
 * Insurance Co, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with The First Insurance Co, Ltd.
 *
 */
package com.kyc.la1.dao;

import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;

/**
 * <--法遵管理系統-諮詢溝通上傳附件檔 -->
 *
 * @author alexYang
 * @Create Date：2021/10/25
 * @UpdateDate:
 * @FileName: COM_LCATDao.java
 */
public class COM_LCATDao extends com.kyc2.ccp.dao.IDao
{
	
	public COM_LCATDao(TransactionControl txc) {
		super(txc);
	}

	//新增	
	public int insertCOM_LCAT() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO COM_LCAT (LCA01,LCA02,LCA03,LCA04,LCA05,");
			sql.append("LCA06,LCA07,LCA08,LCA09,LCA10,LCA11,LCA12) VALUES ");
			sql.append("(?,?,?,?,?,?,?,?,?,?,?,?) ");
			
			String args[] = new String[12];
			args[0] = lca01;
			args[1] = lca02;
			args[2] = lca03;
			args[3] = lca04;
			args[4] = lca05;
			args[5] = lca06;
			args[6] = lca07;
			args[7] = lca08;
			args[8] = lca09;
			args[9] = lca10;
			args[10] = lca11;
			args[11] = lca12;
			
			checkSqlArgs(args);
			
			txc.begin(0);
			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	//刪除
	public int deleteCOM_LCATByLca01AdndLca03() throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("DELETE from COM_LCAT WHERE LCA01=? AND LCA03=? ");
			
			String args[] = new String[2];
			args[0] = lca01;
			args[1] = lca03;

			checkSqlArgs(args);
			txc.begin(0);
			int ret = runner.update(txc.getConnection(), sql.toString(), args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
	
	public Map queryLca03() throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT MAX(LCA03)+1 LCA03 FROM COM_LCAT ");
			
			txc.begin(0);

			Map ret = null ;
			ret = (Map) runner.query(txc.getConnection(), sql.toString(), new MapHandler()  );
		
			runner = null;
	
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
	}
		
	public List queryCOM_LCATByLca01() throws AsiException
	{
	
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			 
			sql.append("SELECT * FROM COM_LCAT WHERE LCA01 = ? ");
			
			String args[] = new String[1];
			args[0] = lca01;
			
			checkSqlArgs(args);
			
			txc.begin(0);
			List ret = null ;
			ret = (List) runner.query(txc.getConnection(), sql.toString(), args , new MapListHandler()  );
			
			runner = null;
	
			return ret;
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		

	}


	
	
	private String lca01;
	private String lca02;
	private String lca03;
	private String lca04;
	private String lca05;
	private String lca06;
	private String lca07;
	private String lca08;
	private String lca09;
	private String lca10;
	private String lca11;
	private String lca12;
	public String getLca01() {
		return lca01;
	}

	public void setLca01(String lca01) {
		this.lca01 = lca01;
	}

	public String getLca02() {
		return lca02;
	}

	public void setLca02(String lca02) {
		this.lca02 = lca02;
	}

	public String getLca03() {
		return lca03;
	}

	public void setLca03(String lca03) {
		this.lca03 = lca03;
	}

	public String getLca04() {
		return lca04;
	}

	public void setLca04(String lca04) {
		this.lca04 = lca04;
	}

	public String getLca05() {
		return lca05;
	}

	public void setLca05(String lca05) {
		this.lca05 = lca05;
	}

	public String getLca06() {
		return lca06;
	}

	public void setLca06(String lca06) {
		this.lca06 = lca06;
	}

	public String getLca07() {
		return lca07;
	}

	public void setLca07(String lca07) {
		this.lca07 = lca07;
	}

	public String getLca08() {
		return lca08;
	}

	public void setLca08(String lca08) {
		this.lca08 = lca08;
	}

	public String getLca09() {
		return lca09;
	}

	public void setLca09(String lca09) {
		this.lca09 = lca09;
	}

	public String getLca10() {
		return lca10;
	}

	public void setLca10(String lca10) {
		this.lca10 = lca10;
	}

	public String getLca11() {
		return lca11;
	}

	public void setLca11(String lca11) {
		this.lca11 = lca11;
	}

	public String getLca12() {
		return lca12;
	}

	public void setLca12(String lca12) {
		this.lca12 = lca12;
	}
	
	
	
	
	
}
