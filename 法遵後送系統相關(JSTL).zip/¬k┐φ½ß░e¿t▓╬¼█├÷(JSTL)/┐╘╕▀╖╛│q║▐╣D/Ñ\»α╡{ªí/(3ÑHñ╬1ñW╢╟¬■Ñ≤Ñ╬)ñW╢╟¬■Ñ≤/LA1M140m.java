/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.kyc.la1.models;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.upload.FormFile;

import com.asi.common.AsiModel;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.dao.COM_LCATDao;
import com.kyc.la1.dao.COM_LCMADao;
import com.kyc.la1.dao.COM_LCTEDao;
import com.kyc.la1.dao.PSM3PFDao;
import com.kyc.la1.forms.LA1M110f;
import com.kyc.la1.forms.LA1M120f;
import com.kyc.la1.forms.LA1M140f;

/**
 * <!--程式說明寫在此-->
 * 
 * 法令遵循系統-諮詢溝通案件-上傳附件
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1M140m extends AsiModel
{

	private static Log logger = LogFactory.getLog(LA1M140m.class);

	private LA1M140f mform;

	private TransactionControl tx_controller;

	public LA1M140m(TransactionControl tx_controller,
			HttpServletRequest request, AsiActionForm form)
	{
		super(tx_controller, request, form);
		this.tx_controller = tx_controller;
	}

	//初始化
	public void init() throws AsiException
	{

		mform = new LA1M140f();
		// 把form做拷貝
		try
		{
			BeanUtils.copyProperties(mform, getForm());
		} catch (InvocationTargetException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		} catch (IllegalAccessException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		}
		setMainForm(mform);

	}

	
	//查詢諮詢案號資料
	public Map queryLcmaByLcm01() throws AsiException
	{
		COM_LCMADao dao = new COM_LCMADao(getTransaction());		
		dao.setLcm01(mform.getLcm01());
		Map lcm = dao.getCOM_LCMAByLcm01();		
		Map ldep = queryLcm(lcm.get("lcm08").toString().trim());		
		lcm.put("lcm02cn", ldep.get("M203").toString().trim());
		
		return lcm;
		
	}
	
	//查詢諮詢案號資料
	public Map queryLcmaByLca01() throws AsiException
	{
		COM_LCMADao dao = new COM_LCMADao(getTransaction());		
		dao.setLcm01(mform.getLca01());
		Map lcm = dao.getCOM_LCMAByLcm01();		
		Map ldep = queryLcm(lcm.get("lcm08").toString().trim());		
		lcm.put("lcm02cn", ldep.get("M203").toString().trim());
		
		return lcm;
		
	}
	
	//儲存
	public int processSaveLca(String lca04) throws AsiException
	{
				
		int ret = 0 ;
		
		String lca01 = mform.getLca01();
		String lca02 = mform.getLca02();

		COM_LCATDao lcatdao = new COM_LCATDao(getTransaction());

		lcatdao.setLca01(lca01);
		lcatdao.setLca02(lca02);
		lcatdao.setLca03(getlca03());
		lcatdao.setLca04(DateUtil.getSysTime(false));
		lcatdao.setLca05(mform.getUploadFileName());
		lcatdao.setLca06(mform.getLca06());
		lcatdao.setLca07(DateUtil.getSysDate(getUsrInfo(), false));
		lcatdao.setLca08(DateUtil.getSysTime(false));
		lcatdao.setLca09(getUsrInfo().getUserId());
		lcatdao.setLca10(DateUtil.getSysDate(getUsrInfo(), false));
		lcatdao.setLca11(DateUtil.getSysTime(false));
		lcatdao.setLca12(getUsrInfo().getUserId());

		try {
			
			ret = lcatdao.insertCOM_LCAT();
			processInsert(lca04);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ret;
		
	}
	
	//資料存檔
	public void processInsert( String lca04) throws AsiException 
	{
		try
		{
			FormFile file = mform.getUploadFile();				
			lca04 = lca04.replaceAll("^(0+)", "");
			InputStream fis = file.getInputStream();
			if (fis.available() != 0)
			{
				
				File dir_file = new File("C:\\KYCDOCUMENTS\\LA1M140\\");   /*路徑跟檔名*/
				if(!dir_file.exists()) {
					dir_file.mkdir();
					logger.info("建立檔案目錄： C:\\KYCDOCUMENTS\\LA1M140 ");
				}			    
			    
				String path = "C:\\KYCDOCUMENTS\\LA1M140\\" + lca04;
				
				OutputStream fos = new FileOutputStream(path);
				int bytesRead = 0;
				byte[] buffer = new byte[8192];
				while ((bytesRead = fis.read(buffer, 0, 8192)) != -1)
				{
					fos.write(buffer, 0, bytesRead);
				}
	            fos.close();
			}
	        fis.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	//取得userId部門資訊
	public Map queryLcm (String userId) throws AsiException
	{
		PSM3PFDao dao = new PSM3PFDao();		
		dao.setM301(userId);		
		Map lcm = dao.queryM203();

		return lcm;
		
	}
	
	
	
	//取得檔案資訊列表
	public List queryCOM_LCATListByLca01() throws AsiException
	{
		COM_LCATDao dao = new COM_LCATDao(getTransaction());
		dao.setLca01(mform.getLca01());							
		List lca = (List) dao.queryCOM_LCATByLca01();			

		return lca;
		
	}
	
	//下載檔案
	public void processDownload(HttpServletResponse response)
	{
		try
		{
			response.setContentType("application/octect-stream");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "attachment;filename=" + new String(mform.getLca05().getBytes("Big5"), "ISO8859_1"));
			InputStream is = new FileInputStream("C:\\KYCDOCUMENTS\\LA1M140\\" + mform.getLca04());
			OutputStream os = response.getOutputStream();
			int n = 0;
			while ((n = is.read()) != -1)
			{
				os.write(n);
			}
			is.close();
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
	}
	
	//刪除檔案
	public void processDelete() throws AsiException 
	{
		
		COM_LCATDao dao = new COM_LCATDao(getTransaction());

		dao.setLca01(mform.getLca01());
		dao.setLca03(mform.getLca03());		
		dao.deleteCOM_LCATByLca01AdndLca03();
		
		File f = new File("C:\\KYCDOCUMENTS\\LA1M140\\" + mform.getLca04());
		 
        if (f.exists()) 
        {
            delFile(f);
        }
        

	}
	
	//編lca03上船序號
	public String getlca03() throws AsiException
	{
		COM_LCATDao dao = new COM_LCATDao(getTransaction());

		Map mp = dao.queryLca03();
		
		String lca03 = "";	
		if(mp.get("LCA03") != null){
			lca03 = mp.get("LCA03").toString();			
		}else{
			lca03 = "1";
		}
		
		return lca03;

	}
	
	
	private void delFile(File f)
	{
		if (f.isDirectory())
		{
			recursive(f, true);
		}
		else
		{
			f.delete();
		}
	}
	
	private void recursive(File f, boolean flag)
	{
		File[] fs = f.listFiles();
		for (int i = 0; i < fs.length; i++)
		{
			if (fs[i].isDirectory())
			{
				recursive(fs[i], true);
			}
			else
			{
				fs[i].delete();
			}
		}
		if (flag)
		{
			f.delete();
		}
	}
	
	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}
}
