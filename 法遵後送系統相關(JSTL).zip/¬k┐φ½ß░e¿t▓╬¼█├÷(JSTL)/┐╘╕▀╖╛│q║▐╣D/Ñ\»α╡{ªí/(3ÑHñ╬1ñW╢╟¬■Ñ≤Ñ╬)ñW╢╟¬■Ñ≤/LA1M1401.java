package com.kyc.la1.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.la1.forms.LA1M140f;
import com.kyc.la1.models.LA1M140m;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-諮詢溝通案件-上傳附件
 * 
 * @author alexYang
 * @Create Date：2021/10/25
 */
public class LA1M1401 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		LA1M140f form = (LA1M140f) arg1;
				
		LA1M140m model = new LA1M140m(tx_controller, arg2, form);
		model.init();
		
        String systime = DateUtil.getSysTime();        
        HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		
		int page = 1;
		try
		{
			if (form.getActionCode() == GlobalKey.ACTION_SELECT || form.getActionCode() == 8) //上傳附件與附件查詢
			{
				
				Map mp = null;
				mp = model.queryLcmaByLcm01();								
				arg2.setAttribute("lcm", mp);
				
				List lcaList = model.queryCOM_LCATListByLca01();
				arg2.setAttribute("lcaList", lcaList);
	
				if (form.getActionCode() == 8)
				{					
					page = 2;					
				}
			}
			else if (form.getActionCode() == 10) //新增附件
			{
						
				int ret = model.processSaveLca(systime);									
				if(ret==1)
					arg2.setAttribute("msg", "諮詢案號" + form.getLca01() + "新增附件成功");
							
				List lcaList = model.queryCOM_LCATListByLca01();
				arg2.setAttribute("lcaList", lcaList);

				Map mp = null;
				mp = model.queryLcmaByLca01();
								
				arg2.setAttribute("lcm", mp);

			}
			else if (form.getActionCode() == 9) //下載附件
			{
				model.processDownload(arg3);
				page = -1;
			}

			else if(form.getActionCode() == 4) //刪除
			{				
				model.processDelete();				
				arg2.setAttribute("msg", "後送案號" + form.getLca01() + "刪除附件成功");
				
				Map mp = null;
				mp = model.queryLcmaByLcm01();								
				arg2.setAttribute("lcm", mp);
				
				List lcaList = model.queryCOM_LCATListByLca01();
				arg2.setAttribute("lcaList", lcaList);
			}
			else if(form.getActionCode() == 15)    //九大原則
			{				
				page=3;
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		form.setNextPage(page);
	}
		
}
