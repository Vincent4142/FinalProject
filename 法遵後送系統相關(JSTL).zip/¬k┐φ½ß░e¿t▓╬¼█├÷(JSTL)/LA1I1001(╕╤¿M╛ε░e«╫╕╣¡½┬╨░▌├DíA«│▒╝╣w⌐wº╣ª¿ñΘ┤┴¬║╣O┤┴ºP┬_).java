package com.kyc.la1.actions;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.la1.dao.COM_LEMPDao;
import com.kyc.la1.forms.LA1I100f;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-逾期未回覆統計
 * 
 * @author Johnlai
 * @Create Date：2019/11/15
 */
public class LA1I1001 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		LA1I100f form = (LA1I100f) arg1;
		Connection con = null;
		int page = 1;
		try
		{
			con = AS400Connection.getOracleConnection();
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String DateS = sysdate.substring(0, 5) + "01";
			String DateE = sysdate;
			HttpSession session = arg2.getSession();
			UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
			String user = ui.getUserId(); 
			
			if (form.getActionCode() == 5)
			{				
				arg2.setAttribute("sysdate", sysdate);
				arg2.setAttribute("DateS", DateS);
				arg2.setAttribute("DateE", DateE);
//				List<?> list = getDelay(DateS, DateE, user); (法遵室聯繫單需求拿掉後送項目逾期統計)
				List<?> list2 = getDelay2(DateS, DateE, user);
				List<?> list3 = getDelay3(DateS, DateE, user);
//				arg2.setAttribute("com_lmanList", list);     (法遵室聯繫單需求拿掉後送項目逾期統計)
				arg2.setAttribute("com_lmanList2", list2);
				arg2.setAttribute("com_lmanList3", list3);
				page = 1;
			}
			else if (form.getActionCode() == 6)//查詢
			{
				String startDate = form.getStartDate();
				String endDate = form.getEndDate();
				arg2.setAttribute("sysdate", sysdate);
				arg2.setAttribute("DateS", startDate);
				arg2.setAttribute("DateE", endDate);
//				List<?> list = getDelay(startDate, endDate, user);   (法遵室聯繫單需求拿掉後送項目逾期統計)
				List<?> list2 = getDelay2(startDate, endDate, user);
				List<?> list3 = getDelay3(startDate, endDate, user);
//				arg2.setAttribute("com_lmanList", list);             (法遵室聯繫單需求拿掉後送項目逾期統計)
				arg2.setAttribute("com_lmanList2", list2);
				arg2.setAttribute("com_lmanList3", list3);
				page = 1;
			}
			else if (form.getActionCode() == 7)//案件明細查詢
			{				
				String startDate = form.getStartDate();
				String endDate = form.getEndDate();
				String selectNo = form.getSelectNo();
				String selectYear = form.getSelectYear();
				arg2.setAttribute("sysdate", sysdate);
				arg2.setAttribute("DateS", startDate);
				arg2.setAttribute("DateE", endDate);
				List<?> list = getDelayDetail(selectNo, selectYear, startDate, endDate);
				arg2.setAttribute("com_lmanList", list);				
				page = 2;
				
			}
			/**(法遵室聯繫單需求拿掉後送項目逾期統計)
			else if (form.getActionCode() == 8)//案件項目明細查詢
			{				
				String startDate = form.getStartDate();
				String endDate = form.getEndDate();
				String selectNo = form.getSelectNo();
				String selectYear = form.getSelectYear();
				arg2.setAttribute("sysdate", sysdate);
				arg2.setAttribute("DateS", startDate);
				arg2.setAttribute("DateE", endDate);
				List<?> list = getDelayDetail2(selectNo, selectYear, startDate, endDate);
				arg2.setAttribute("com_lmanList", list);				
				page = 3;
				
			}
			*/
			else if (form.getActionCode() == 9)//案件退件明細查詢
			{				
				String startDate = form.getStartDate();
				String endDate = form.getEndDate();
				String selectNo = form.getSelectNo();
				String selectYear = form.getSelectYear();
				arg2.setAttribute("sysdate", sysdate);
				arg2.setAttribute("DateS", startDate);
				arg2.setAttribute("DateE", endDate);
				List<?> list = getDelayDetail3(selectNo, selectYear, startDate, endDate);
				arg2.setAttribute("com_lmanList", list);				
				page = 4;
				
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		form.setNextPage(page);
	}
	
	/**
	 * 後送案件項目逾期未回覆覆統計(法遵室聯繫單需求拿掉後送項目逾期統計)
	 * 
	 * @author Johnlai
	 * @param startDate：後送開始日期
	 * @param endDate：後送結束日期
	 * @param userId：使用者代號
	 
	public List<?> getDelay(String startDate, String endDate, String userId) throws AsiException
	{
		List<?> list = null;
		Integer yr = (int) Math.floor(Double.parseDouble(startDate) / 10000);
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			COM_LEMPDao com_LempDao = new COM_LEMPDao(con);
			
			String depId = com_LempDao.getDep(userId);
			
//			String sql = "SELECT lpt02, lde02, ";
//			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT1, ";
//			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT2, ";
//			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT3, ";
//			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT4, ";
//			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT5 ";
//			sql = sql + "FROM com_lptt inner join com_ldep on lpt02 = lde01 ";
//			sql = sql + "WHERE LPT05 = 'Y' and ";
//			sql = sql + "(case when lpt07 = 0 then case when lpt06 < ? then 1 else 0 end ";
//			sql = sql + "else case when lpt06 < lpt07 then 1 else 0 end end = 1) and ";
//			sql = sql + "com_lptt.crtdt between ? and ? ";
//			sql = sql + "and lpt02 like ? ";
//			sql = sql + "Group By lpt02, lde02 Order By lpt02";
			String sql = "SELECT lpt02, lde02,lpd02, ";
			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT1, ";
			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT2, ";
			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT3, ";
			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT4, ";
			sql = sql + "sum(case when floor(com_lptt.crtdt / 10000) = ? then 1 else 0 end) LAWCNT5 ";
			sql = sql + "FROM com_lptt inner join com_ldep on lpt02 = lde01 ";
			sql = sql + "inner join com_lpde on lpt01=com_lpde.lpd01 ";
			sql = sql + "WHERE LPT05 = 'Y' and ";
			sql = sql + "(case when lpt07 = 0 then case when lpt06 < ? then 1 else 0 end ";
			sql = sql + "else case when lpt06 < lpt07 then 1 else 0 end end = 1) and ";
			sql = sql + "com_lptt.crtdt between ? and ? ";
			sql = sql + "and lpt02 like ? ";
			sql = sql + "and lpt02 = lpd02 ";
			sql = sql + "and com_lpde.lpd07 is null ";
			sql = sql + "Group By lpt02, lde02,lpd02 Order By lpt02";
			
			String args[] = new String[9];
	        args[0] = yr.toString();
	        args[1] = Integer.toString(++yr);
	        args[2] = Integer.toString(++yr);
	        args[3] = Integer.toString(++yr);
	        args[4] = Integer.toString(++yr);
	        args[5] = sysdate;
	        args[6] = startDate;
	        args[7] = endDate;
	        if ("13".equals(depId)) 
	        	args[8] = "%";
	        else
	        	args[8] = depId;
			QueryRunner run = new QueryRunner();
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}
	*/

	/**
	 * 後送案件逾期未回覆統計
	 * 
	 * @author Johnlai
	 * @param startDate：後送開始日期
	 * @param endDate：後送結束日期
	 * @param userId：使用者代號
	 */
	public List<?> getDelay2(String startDate, String endDate, String userId) throws AsiException
	{
		List<?> list = null;
		Integer yr = (int) Math.floor(Double.parseDouble(startDate) / 10000);
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			COM_LEMPDao com_LempDao = new COM_LEMPDao(con);
			
			String depId = com_LempDao.getDep(userId);
			
			String sql = "SELECT lpd02, lde02, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT1, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT2, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT3, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT4, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT5 ";
			sql = sql + "FROM com_lman INNER JOIN com_lpde ON lma01 = lpd01 inner join com_ldep on lpd02 = lde01 ";
			sql = sql + "WHERE (case when (LPD08 is null or LPD08 = 0) then case when LMA09 < ? then 1 else 0 end else case when (LMA09 < LPD08 and LPD04 < LPD08) then 1 else 0 end end = 1) ";
			sql = sql + "and com_lman.crtdt between ? and ? ";
			sql = sql + "and lpd02 like ? ";
			sql = sql + "and (lpd07 is null or lpd07 ='Y')  ";
			sql = sql + "Group By lpd02, lde02 Order By lpd02";
//			String sql = "SELECT lpd02, lde02, ";
//			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT1, ";
//			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT2, ";
//			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT3, ";
//			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT4, ";
//			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT5 ";
//			sql = sql + "FROM com_lman INNER JOIN com_lpde ON lma01 = lpd01 inner join com_ldep on lpd02 = lde01 inner join com_lptt on lma01 = lpt01 ";
//			sql = sql + "WHERE (case when (LPD08 is null or LPD08 = 0 or LPT07 is null or LPT07 = 0) then case when (LMA09 < ? and LPT06 < ?) then 1 else 0 end else case when (LMA09 < LPD08 and LPD04 < LPD08) then 1 else 0 end end = 1) ";
//			sql = sql + "and com_lman.crtdt between ? and ? ";
//			sql = sql + "and lpd02 like ? ";
//			sql = sql + "and (lpd07 is null or lpd07 ='Y')  ";
//			sql = sql + "group By lpd02,lde02 Order By lpd02";
			String args[] = new String[9];
	        args[0] = yr.toString();
	        args[1] = Integer.toString(++yr);
	        args[2] = Integer.toString(++yr);
	        args[3] = Integer.toString(++yr);
	        args[4] = Integer.toString(++yr);
	        args[5] = sysdate;
//	        args[6] = sysdate;
	        args[6] = startDate;
	        args[7] = endDate;
	        if ("13".equals(depId)) 
	        	args[8] = "%";
	        else
	        	args[8] = depId;
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}
	
	/**
	 * 法遵後送案件退件統計
	 * 
	 * @author Johnlai
	 * @param startDate：後送開始日期
	 * @param endDate：後送結束日期
	 * @param userId：使用者代號
	 */
	public List<?> getDelay3(String startDate, String endDate, String userId) throws AsiException
	{
		List<?> list = null;
		Integer yr = (int) Math.floor(Double.parseDouble(startDate) / 10000);
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			COM_LEMPDao com_LempDao = new COM_LEMPDao(con);
			
			String depId = com_LempDao.getDep(userId);
			
			String sql = "SELECT lpd02, lde02, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT1, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT2, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT3, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT4, ";
			sql = sql + "sum(case when floor(com_lman.crtdt / 10000) = ? then 1 else 0 end) LAWCNT5 ";
			sql = sql + "FROM com_lman INNER JOIN com_lpdelog ON lma01 = lpd01 inner join com_ldep on lpd02 = lde01 ";
			sql = sql + "WHERE com_lman.crtdt between ? and ? ";
			sql = sql + "and lpd02 like ? ";
			sql = sql + "Group By lpd02, lde02 Order By lpd02";
			String args[] = new String[8];
	        args[0] = yr.toString();
	        args[1] = Integer.toString(++yr);
	        args[2] = Integer.toString(++yr);
	        args[3] = Integer.toString(++yr);
	        args[4] = Integer.toString(++yr);
	        args[5] = startDate;
	        args[6] = endDate;
	        if ("13".equals(depId)) 
	        	args[7] = "%";
	        else
	        	args[7] = depId;
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}


	/**
	 * 後送案件逾期未回覆明細
	 * 
	 * @author Johnlai
	 * @param selectNo：部門代號
	 * @param selectYear：年度
	 */	
	public List<?> getDelayDetail(String selectNo, String selectYear, String startDate, String endDate) throws AsiException
	{
		List<?> list = null;
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			String sql = "SELECT lma01,lma06, lma09, case when lpd07='Y' then '符合' else case when lpd07='N' then '退件' else ' ' end end as lpd07, lpd08, lpd09 ";
			sql = sql + "FROM com_lman ";
			sql = sql + "INNER JOIN com_lpde ON lma01 = lpd01 ";
			sql = sql + "INNER JOIN com_ldep on lpd02 = lde01 ";
			sql = sql + "WHERE (case when (LPD08 is null or LPD08 = 0 or lpd07 = 'N') then case when LMA09 < ? then 1 else 0 end else case when (LMA09 < LPD08 and LPD04 < LPD08) then 1 else 0 end end = 1) ";
			sql = sql + "AND floor(com_lpde.crtdt / 10000) = ? ";
			sql = sql + "AND com_lpde.crtdt between ? and ? ";
			sql = sql + "AND lpd02 like ? ";
			sql = sql + "and (lpd07 is null or lpd07 ='Y') ";
			sql = sql + "ORDER BY lma01 ";
//			String sql = "SELECT lma01,lma06, lma09, case when lpd07='Y' then '符合' else case when lpd07='N' then '退件' else ' ' end end as lpd07, lpd08, lpd09 ,lpt06 ";
//			sql = sql + "FROM com_lman ";
//			sql = sql + "INNER JOIN com_lpde ON lma01 = lpd01 ";
//			sql = sql + "INNER JOIN com_ldep on lpd02 = lde01 ";
//			sql = sql + "INNER JOIN com_lptt on lma01 = lpt01  ";
//			sql = sql + "WHERE (case when (LPD08 is null or LPD08 = 0 or LPT07 is null or LPT07 = 0) then case when (LMA09 < ? and LPT06 < ?) then 1 else 0 end else case when (LMA09 < LPD08 and LPD04 < LPD08) then 1 else 0 end end = 1) ";
//			sql = sql + "AND floor(com_lpde.crtdt / 10000) = ? ";
//			sql = sql + "AND com_lpde.crtdt between ? and ? ";
//			sql = sql + "AND lpd02 like ? ";
//			sql = sql + "and (lpd07 is null or lpd07 ='Y') ";
//			sql = sql + "ORDER BY lma01 ";

			String args[] = new String[5];
	        args[0] = sysdate;
//	        args[1] = sysdate;
	        args[1] = selectYear;
	        args[2] = startDate;
	        args[3] = endDate;
	        args[4] = selectNo;
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}
	 
	/**
	 * 後送案件項目逾期未回覆明細(法遵室聯繫單需求拿掉後送項目逾期統計)
	 * 
	 * @author Johnlai
	 * @param selectNo：部門代號
	 * @param selectYear：年度
	 * @param startDate：開始日期
	 * @param endDate：結束日期
	 	
	public List<?> getDelayDetail2(String selectNo, String selectYear, String startDate, String endDate) throws AsiException
	{
		List<?> list = null;
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
//			String sql = "SELECT lpt01, lma06, lpt05, lpt06, lpt07, lpt08, secaz.codedesc as sendItem, secaz1.codedesc AS viewItem ";
//			sql = sql + "FROM com_lptt ";
//			sql = sql + "INNER JOIN com_lman ON lpt01 = lma01 ";
//			sql = sql + "INNER JOIN secaz secaz1 ON lpt03 = secaz1.codetype AND lpt04 = secaz1.codeid ";
//			sql = sql + "INNER JOIN secaz ON secaz1.codetype = secaz.codeid ";
//			sql = sql + "WHERE lpt05 = 'Y' AND ";
//			sql = sql + "CASE WHEN lpt07 = 0 THEN CASE WHEN lpt06 < ? THEN 1 ELSE 0 END ";
//			sql = sql + "ELSE CASE WHEN lpt06 < lpt07 THEN 1 ELSE 0 END END = 1 ";
//			sql = sql + "AND floor(com_lptt.crtdt / 10000) = ? ";
//			sql = sql + "AND com_lptt.crtdt between ? and ? ";
//			sql = sql + "AND lpt02 = ? ";
//			sql = sql + "AND secaz.codetype = 'COMPLIANCE' ";
//			sql = sql + "ORDER BY lpt01, lpt03, lpt04 ";
			String sql = "SELECT distinct lpt01, lma06, lpt05, lpt06, lpt07, lpt08, secaz.codedesc as sendItem, secaz1.codedesc AS viewItem ";
			sql = sql + "FROM com_lptt ";
			sql = sql + "INNER JOIN com_lman ON lpt01 = lma01 ";
			sql = sql + "INNER JOIN secaz secaz1 ON lpt03 = secaz1.codetype AND lpt04 = secaz1.codeid ";
			sql = sql + "INNER JOIN secaz ON secaz1.codetype = secaz.codeid ";
			sql = sql + "left join com_lpde on lpt01=com_lpde.lpd01 ";
			sql = sql + "WHERE lpt05 = 'Y' AND ";
			sql = sql + "CASE WHEN lpt07 = 0 THEN CASE WHEN lpt06 < ? THEN 1 ELSE 0 END ";
			sql = sql + "ELSE CASE WHEN lpt06 < lpt07 THEN 1 ELSE 0 END END = 1 ";
			sql = sql + "AND floor(com_lptt.crtdt / 10000) = ? ";
			sql = sql + "AND com_lptt.crtdt between ? and ? ";
			sql = sql + "AND lpt02 = ? ";
			sql = sql + "AND secaz.codetype = 'COMPLIANCE' ";
			sql = sql + "and com_lpde.lpd07 is null "; 
			sql = sql + "ORDER BY lpt01";

			String args[] = new String[5];
	        args[0] = sysdate;
	        args[1] = selectYear;
	        args[2] = startDate;
	        args[3] = endDate;
	        args[4] = selectNo;
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}
	*/
 
	 /**
	 * 法遵後送案件退件明細
	 * 
	 * @author Johnlai
	 * @param selectNo：部門代號
	 * @param selectYear：年度
	 * @param startDate：開始日期
	 * @param endDate：結束日期
	 */	public List<?> getDelayDetail3(String selectNo, String selectYear, String startDate, String endDate) throws AsiException
	{
		List<?> list = null;
		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			String sql = "SELECT lpd01, lma06, com_lpdelog.upddt, lpd09 ";
			sql = sql + "FROM com_lman INNER JOIN com_lpdelog ON lma01 = lpd01 ";
			sql = sql + "AND floor(com_lman.crtdt / 10000) = ? ";
			sql = sql + "WHERE com_lman.crtdt between ? and ? ";
			sql = sql + "and lpd02 = ?  ";
			sql = sql + "Order By lpd02 ";

			String args[] = new String[4];
	        args[0] = selectYear;
	        args[1] = startDate;
	        args[2] = endDate;
	        args[3] = selectNo;
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		return list;
	}
		 
}
