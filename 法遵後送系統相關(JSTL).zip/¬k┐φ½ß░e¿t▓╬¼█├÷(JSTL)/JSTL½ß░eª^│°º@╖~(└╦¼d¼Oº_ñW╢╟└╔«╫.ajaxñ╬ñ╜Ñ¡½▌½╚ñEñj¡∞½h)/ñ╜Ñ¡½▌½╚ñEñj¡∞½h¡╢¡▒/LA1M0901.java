package com.kyc.la1.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.la1.dao.COM_LDEPDao;
import com.kyc.la1.dao.COM_LFCPDao;
import com.kyc.la1.dao.COM_LMANDao;
import com.kyc.la1.dao.COM_LUPLDao;
import com.kyc.la1.dao.SECAYDao;
import com.kyc.la1.forms.LA1M090f;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-上傳附件
 * 
 * @author chrislee
 * @Create Date：2019/2/13
 */
public class LA1M0901 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		LA1M090f form = (LA1M090f) arg1;
		Connection con = null;
		List<?> com_luplList = null;
		COM_LUPLDao com_LUPLDao;
		COM_LFCPDao com_LFCPDao;
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        String systime = DateUtil.getSysTime();
        
        HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String user = ui.getUserId(); 
		int page = 1;
		try
		{
			if (form.getActionCode() == GlobalKey.ACTION_SELECT || form.getActionCode() == 8) //上傳附件與附件查詢
			{
				con = AS400Connection.getOracleConnection();
				com_luplList = doAction1(con, form);
				String lde02 = doAction2(con, form);
				arg2.setAttribute("lde02", lde02);
				arg2.setAttribute("com_luplList", com_luplList);
				if (form.getActionCode() == 8)
				{
					String lfc=arg2.getParameter("lfc");
					String s = new String(lfc.getBytes("ISO8859-1"), "utf-8");
					if(s.equals("是否涉及公平待客九大原則")){
						COM_LFCPDao lfcDao=new COM_LFCPDao(con);						
						List<Map> list=lfcDao.getCOM_LFCP(form.getLup01(),form.getLup02(), form.getLup03(), form.getLup04());
						arg2.setAttribute("listdata", list);
					}
					page = 2;
				}
			}
			else if (form.getActionCode() == 10) //新增附件
			{
				con = AS400Connection.getOracleConnection();
				com_LUPLDao = new COM_LUPLDao(con);
				String lup01 = form.getLup01();
				String lup02 = form.getLup02();
				String lup03 = form.getLup03();
				String lup04 = form.getLup04();
				String lup05 = com_LUPLDao.getLup05Max();
				String lup06 = systime;
				String lup07 = form.getUploadFileName();
				String lup08 = form.getLup08();
				
				int ret = com_LUPLDao.insertCOM_LUPL(lup01, lup02, lup03, lup04, lup05, lup06, lup07, lup08, sysdate, systime, user);
				
				FormFile file = form.getUploadFile();				
				processInsert(file, lup06);
				com_luplList = doAction1(con, form);
				String lde02 = doAction2(con, form);
				
				if(ret==1)
					arg2.setAttribute("msg", "後送案號" + lup01 + "新增附件成功");
				
				arg2.setAttribute("lde02", lde02);
				arg2.setAttribute("com_luplList", com_luplList);
			}
			else if (form.getActionCode() == 9) //下載附件
			{
				String lup06 = form.getLup06();
				String lup07 = form.getLup07();
				processDownload(arg3, lup06, lup07);
				page = -1;
			}
			else if (form.getActionCode() == 11) //Email通知 by John Lai 2019/12/24
			{
				con = AS400Connection.getOracleConnection();
				SECAYDao secayDao = new SECAYDao(con);
				COM_LMANDao com_LMANDao = new COM_LMANDao(con);
				String lup01 = form.getLup01();
				String lup03 = form.getLup03();
				List<?> secayList = secayDao.getType(lup03);
				List<?> com_lmanList = com_LMANDao.getListByLma01(lup01);
				com_luplList = doAction1(con, form);
				processMail(arg3, lup01, secayList, com_lmanList, com_luplList);
				page = -1;
			}
			else if(form.getActionCode() == 4) //刪除
			{
				con = AS400Connection.getOracleConnection();
				com_LUPLDao = new COM_LUPLDao(con);
				String lup01 = form.getLup01();
				String lup02 = form.getLup02();
				String lup03 = form.getLup03();
				String lup04 = form.getLup04();
				String lup05 = form.getLup05();
				String lup06 = form.getLup06();
				com_LUPLDao.deleteCOM_LUPL(lup01, lup02, lup03, lup04, lup05, lup06);
		        File f = new File("C:\\KYCDOCUMENTS\\LA1M090\\" + lup06);
		        if (f.exists()) 
		        {
		            delFile(f);
		        }
				com_luplList = doAction1(con, form);
				String lde02 = doAction2(con, form);
				arg2.setAttribute("msg", "後送案號" + lup01 + "刪除附件成功");
				arg2.setAttribute("lde02", lde02);
				arg2.setAttribute("com_luplList", com_luplList);
			}
			else if(form.getActionCode() == 15)    //九大原則
			{				
				page=3;
			}
			else if(form.getActionCode() == 16){	//九大原則確認送出
				con = AS400Connection.getOracleConnection();
				com_LFCPDao=new COM_LFCPDao(con);
				
				String[] fc=arg2.getParameterValues("FC");
				String lfc01=arg2.getParameter("lfc01");
				String lfc02=arg2.getParameter("lfc02");
				String lfc03=arg2.getParameter("lfc03");
				String lfc04=arg2.getParameter("lfc04");
				
				String lfc05="N",lfc06="N",lfc07="N",lfc08="N",lfc09="N",lfc10="N",lfc11="N",lfc12="N",lfc13="N";
				
				for(int i=0;i<fc.length;i++){
					if(fc[i].equals("01")){
						lfc05="Y";
					}
					else if(fc[i].equals("02")){
						lfc06="Y";
					}
					else if(fc[i].equals("03")){
						lfc07="Y";
					}
					else if(fc[i].equals("04")){
						lfc08="Y";
					}
					else if(fc[i].equals("05")){
						lfc09="Y";
					}
					else if(fc[i].equals("06")){
						lfc10="Y";
					}
					else if(fc[i].equals("07")){
						lfc11="Y";
					}
					else if(fc[i].equals("08")){
						lfc12="Y";
					}
					else if(fc[i].equals("09")){
						lfc13="Y";
					}
				}
				
				List<?> list=com_LFCPDao.getCOM_LFCP(lfc01, lfc02, lfc03, lfc04);
				
				if(list.isEmpty()){
					com_LFCPDao.insertCOM_LFCP(lfc01, lfc02, lfc03, lfc04, lfc05, lfc06, lfc07, lfc08, lfc09, lfc10, lfc11, lfc12, lfc13, sysdate, systime, user);
					arg2.setAttribute("msg","儲存成功");
					arg2.setAttribute("close", "c");
				}
				else{
					arg2.setAttribute("msg","您已新增過，若要修改請選擇按修改按鈕");
					arg2.setAttribute("lfc01",lfc01);
					arg2.setAttribute("lfc02",lfc02);
					arg2.setAttribute("lfc03",lfc03);
					arg2.setAttribute("lfc04",lfc04);					
				}			
				page=3;
			}
			else if(form.getActionCode() == 17){	//九大原則修改
				
				con = AS400Connection.getOracleConnection();
				com_LFCPDao=new COM_LFCPDao(con);
				
				String[] fc=arg2.getParameterValues("FC");
				String lfc01=arg2.getParameter("lfc01");
				String lfc02=arg2.getParameter("lfc02");
				String lfc03=arg2.getParameter("lfc03");
				String lfc04=arg2.getParameter("lfc04");
				
				String lfc05="N",lfc06="N",lfc07="N",lfc08="N",lfc09="N",lfc10="N",lfc11="N",lfc12="N",lfc13="N";
				
				for(int i=0;i<fc.length;i++){
					if(fc[i].equals("01")){
						lfc05="Y";
					}
					else if(fc[i].equals("02")){
						lfc06="Y";
					}
					else if(fc[i].equals("03")){
						lfc07="Y";
					}
					else if(fc[i].equals("04")){
						lfc08="Y";
					}
					else if(fc[i].equals("05")){
						lfc09="Y";
					}
					else if(fc[i].equals("06")){
						lfc10="Y";
					}
					else if(fc[i].equals("07")){
						lfc11="Y";
					}
					else if(fc[i].equals("08")){
						lfc12="Y";
					}
					else if(fc[i].equals("09")){
						lfc13="Y";
					}
				}
				
				List<?> list=com_LFCPDao.getCOM_LFCP(lfc01, lfc02, lfc03, lfc04);
				
				if(list.isEmpty()){
					arg2.setAttribute("msg","您還未新增過，請選擇按確認按鈕");
					arg2.setAttribute("lfc01",lfc01);
					arg2.setAttribute("lfc02",lfc02);
					arg2.setAttribute("lfc03",lfc03);
					arg2.setAttribute("lfc04",lfc04);
				}
				else{
					com_LFCPDao.updateCOM_LFCP(lfc01, lfc02, lfc03, lfc04, lfc05, lfc06, lfc07, lfc08, lfc09, lfc10, lfc11, lfc12, lfc13, sysdate, systime, user);
					arg2.setAttribute("msg","儲存成功");
					arg2.setAttribute("close", "c");					
				}			
				page=3;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		form.setNextPage(page);
	}
	
	private List<?> doAction1(Connection con, LA1M090f form)
	{
		List<?> list = null;
		COM_LUPLDao com_LUPLDao;
		try
		{
			com_LUPLDao = new COM_LUPLDao(con);
			 list = com_LUPLDao.getCOM_LUPL(form.getLup01(), form.getLup02(), form.getLup03(), form.getLup04());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	
	private String doAction2(Connection con, LA1M090f form)
	{
		String lde02 = null;
		COM_LDEPDao com_LDEPDao;
		try
		{
			com_LDEPDao = new COM_LDEPDao(con);
			List<?> list = com_LDEPDao.getCOM_LDEPOne(form.getLup02());	
			Map<?, ?> map = (Map<?, ?>)list.get(0);
			lde02 = map.get("lde02").toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return lde02;
	}
	
	public void processDownload(HttpServletResponse response, String lup06, String lup07)
	{
		try
		{
			response.setContentType("application/octect-stream");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "attachment;filename=" + new String(lup07.getBytes("Big5"), "ISO8859_1"));
			InputStream is = new FileInputStream("C:\\KYCDOCUMENTS\\LA1M090\\" + lup06);
			OutputStream os = response.getOutputStream();
			int n = 0;
			while ((n = is.read()) != -1)
			{
				os.write(n);
			}
			is.close();
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
	}
	
	/**
	 * 法遵後送郵件通知
	 * 
	 * @author John Lai
	 * @Create Date：2019/12/24
	 */
	public void processMail(HttpServletResponse response,String lup01,List<?> secayList, List<?> com_lmanList, List<?> com_luplList) throws AddressException, MessagingException
	{
		try
		{
			File tempFile = File.createTempFile("lawMail", "eml");

			MimeMessage message = new MimeMessage(Session.getInstance(System.getProperties()));
			message.addHeader("X-Unsent", "1");
			Map<?, ?> secay = (Map<?, ?>)secayList.get(0);
			Map<?, ?> com_lman = (Map<?, ?>)com_lmanList.get(0);
			message.setSubject(MimeUtility.encodeText("法遵後送案號 " + lup01 + ": "+ secay.get("TYPEDESC").toString(),MimeUtility.mimeCharset("UTF-8"),null));
	        MimeBodyPart content = new MimeBodyPart();
	        MimeMultipart multipart = new MimeMultipart();
	        content.setContent("<p class=MsoNormal style='white-space: pre;'>" + com_lman.get("LMA06").toString() + "</p>", "text/html; charset=utf-8");
	        multipart.addBodyPart(content);
	        for (int i = 0; i < com_luplList.size(); i++) {
	        	Map<?, ?> map = (Map<?, ?>)com_luplList.get(i);
	        	File file = new File("C:\\KYCDOCUMENTS\\LA1M090\\" + map.get("lup06").toString());
	        	if (file.exists()) {
	        		MimeBodyPart attachment = new MimeBodyPart();
		            DataSource source = new FileDataSource(file);
		            attachment.setDataHandler(new DataHandler(source));
		            attachment.setFileName(MimeUtility.encodeText(map.get("lup07").toString(),MimeUtility.mimeCharset("UTF-8"),null));
		            multipart.addBodyPart(attachment);
	        	}
			}
	        message.setContent(multipart);
	        message.writeTo(new FileOutputStream(tempFile));
			
			response.setContentType("message/rfc822");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "filename=" + new String("法遵後送郵件通知.eml".getBytes("Big5"), "ISO8859_1"));
			InputStream is = new FileInputStream(tempFile.getAbsolutePath());
			OutputStream os = response.getOutputStream();
			int n = 0;
			while ((n = is.read()) != -1)
			{
				os.write(n);
			}
			is.close();
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
	}
	
	public void processInsert(FormFile file, String lup06) throws AsiException 
	{
		try
		{
			lup06 = lup06.replaceAll("^(0+)", "");
			InputStream fis = file.getInputStream();
			if (fis.available() != 0)
			{
				String path = "C:\\KYCDOCUMENTS\\LA1M090\\" + lup06;
				OutputStream fos = new FileOutputStream(path);
				int bytesRead = 0;
				byte[] buffer = new byte[8192];
				while ((bytesRead = fis.read(buffer, 0, 8192)) != -1)
				{
					fos.write(buffer, 0, bytesRead);
				}
	            fos.close();
			}
	        fis.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	private void delFile(File f)
	{
		if (f.isDirectory())
		{
			recursive(f, true);
		}
		else
		{
			f.delete();
		}
	}
    
	private void recursive(File f, boolean flag)
	{
		File[] fs = f.listFiles();
		for (int i = 0; i < fs.length; i++)
		{
			if (fs[i].isDirectory())
			{
				recursive(fs[i], true);
			}
			else
			{
				fs[i].delete();
			}
		}
		if (flag)
		{
			f.delete();
		}
	}
}
