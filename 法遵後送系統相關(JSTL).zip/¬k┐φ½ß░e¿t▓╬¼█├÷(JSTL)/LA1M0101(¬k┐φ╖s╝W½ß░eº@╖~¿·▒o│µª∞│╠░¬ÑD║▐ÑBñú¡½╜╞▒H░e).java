package com.kyc.la1.actions;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.la1.dao.COM_LDEPDao;
import com.kyc.la1.dao.COM_LEMPDao;
import com.kyc.la1.dao.COM_LMANDao;
import com.kyc.la1.dao.COM_LMDTDao;
import com.kyc.la1.dao.COM_LPDEDao;
import com.kyc.la1.dao.COM_LPTTDao;
import com.kyc.la1.dao.SECAZDao;
import com.kyc.la1.forms.LA1M010f;
import com.kyc.sec.actions.WebAction;

/**
 * 法令遵循系統-新增後送作業
 * 
 * @author chrislee
 * @Create Date：2019/1/22
 */
public class LA1M0101 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		LA1M010f form = (LA1M010f)arg1;
		Connection con = null;
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        String systime = DateUtil.getSysTime();
        
        HttpSession session = arg2.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String user = ui.getUserId();      
		
		try
		{
			con = AS400Connection.getOracleConnection();
			
			COM_LDEPDao com_LdepDao = new COM_LDEPDao(con);
			SECAZDao secazDao = new SECAZDao(con);
			COM_LEMPDao com_LempDao = new COM_LEMPDao(con);
			
			List<?> com_ldepList = com_LdepDao.getCOM_LDEP();
			List<?> secazList = secazDao.getcodetype("COMPLIANCE");
			List<?> com_lempList = com_LempDao.getListByLem02();
			String lma01 = "CP" + sysdate.substring(0, 3) + getLma01();
			arg2.setAttribute("lma01", lma01);
			arg2.setAttribute("com_ldepList", com_ldepList);//部門名單
			arg2.setAttribute("secazList", secazList);//項目名單
			arg2.setAttribute("com_lempList", com_lempList);//高階主管名單
			arg2.setAttribute("sysdate", sysdate);
			
			if (arg1.getActionCode() == 1)
			{
				COM_LMANDao com_LMANDao = new COM_LMANDao(con);
				COM_LMDTDao com_LMDTDao = new COM_LMDTDao(con);
				COM_LPDEDao com_LPDEDao = new COM_LPDEDao(con);
				COM_LPTTDao com_LPTTDao = new COM_LPTTDao(con);
				
				com_LMANDao.insertCOM_LMAN(form, sysdate, systime, user);
				com_LMDTDao.insertCOM_LMDT(form, sysdate, systime, user);
				com_LPDEDao.insertCOM_LPDE(form, sysdate, systime, user);
				com_LPTTDao.insertCOM_LPTT(form, sysdate, systime, user);
				
				arg2.setAttribute("msg", "後送案號" + form.getLma01() + "新增成功");
				
				String[] deps = form.getDep();
				String liaison = form.getIsAccept();
				List<?> sendEmailList = null;
				Employee emp = null;
				List<?> secay = secazDao.getCodetypeAndCodeId("COMPLIANCE", form.getSecay());
				Map secayTemp = (Map) secay.get(0);
				String secayDesc = (String) secayTemp.get("CODEDESC");
				for (int i = 0; i < deps.length; i++)//寄信給該單位洗錢、個資、法遵主管及其單位最高主管
				{
					sendEmailList = com_LempDao.getEmailList(deps[i].substring(0, 2), liaison);
					String recipient = null;
					
					//存放該單位洗錢、個資、法遵主管的mail
					List<String> manager=new ArrayList<String>();
					 
					for (int j = 0; j < sendEmailList.size(); j++)
					{
						Map<?, ?> map = (Map<?, ?>)sendEmailList.get(j);
						recipient = map.get("lem01").toString();		
						emp = Employee.getEmployee(recipient);
						String email = emp.getEmail();
						System.out.println(email);
						manager.add(email);
						sendMail(email, form.getLma01(), secayDesc);
					}
					
					//單位最高主管若又為洗錢、個資、法遵主管則不重複寄送
					String[] manager2=new  String[manager.size()];
					for(int k=0;k<manager.size();k++){
						manager2[k]=manager.get(k);
					}
					String email = emp.getDept().getBoss().getEmail();
					int a = Arrays.binarySearch(manager2, email);
					if(a<0){
						System.out.println(email);
					    sendMail(email, form.getLma01(), secayDesc);
					}		
				}
				
				String[] lemp = form.getLemp();				
				if (lemp != null)//寄信給有勾選的高階主管
				{
					for (int i = 0; i < lemp.length; i++)
					{
						String lempId = lemp[i];
						emp = Employee.getEmployee(lempId);
						String email = emp.getEmail();
						System.out.println(email);
						sendMail(email, form.getLma01(), secayDesc);
					}
				}
			}			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		arg1.setNextPage(1);
	}
	
	/**
	 * 取得後送案號
	 * @return 序號
	 */
	public String getLma01()
	{
		Connection con = null;
		String number = null;
		List<?> list = null;
		
		 try
		{
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		    String systime = DateUtil.getSysTime();
			String date[] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, true).split("/");
			con = AS400Connection.getOracleConnection();
			String sql = "SELECT KH01, KH02, KH03, KH04, KH05, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM, UPDUR FROM KYCKH WHERE KH01=? AND KH02=? AND KH05=?";
			String args[] = new String[3];
	        args[0] = "CP";
	        args[1] = date[0];
	        args[2] = "A";
			QueryRunner run = new QueryRunner();			
			list = (List<?>) run.query(con, sql, args, new MapListHandler());
			
			if (list.size() == 0)
			{
				String newsql = "INSERT INTO KYCKH (KH01,KH02,KH03,KH04,KH05,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
				String newArgs[] = new String[11];
				newArgs[0] = "CP";
				newArgs[1] = date[0];
				newArgs[2] = "0";
				newArgs[3] = "1";
		        newArgs[4] = "A";
		        newArgs[5] = sysdate;
		        newArgs[6] = systime;
		        newArgs[7] = "LA1M010";
		        newArgs[8] = sysdate;
		        newArgs[9] = systime;
		        newArgs[10] = "LA1M010";
				run.update(con, newsql, newArgs);
			}
			Map<?,?> ret = (Map<?,?>) run.query(con, sql, args, new TrimedMapHandler());
			int KH03 = Integer.parseInt(ret.get("KH03").toString());
			int KH04 = Integer.parseInt(ret.get("KH04").toString());
			int total = KH04 + 1;
			if (total > 9999)
			{
				total = 1;
				KH03 ++;
			}
			
			String updateSql = "UPDATE KYCKH SET KH03=?,KH04=?,UPDDT=?,UPDTM=?,UPDUR=? WHERE KH01=? AND KH02=? AND KH05=?";
			String updateArgs[] = new String[8];
			updateArgs[0] = String.valueOf(KH03);
			updateArgs[1] = String.valueOf(total);
			updateArgs[2] = sysdate;
			updateArgs[3] = systime;
			updateArgs[4] = "LA1M010";
	        updateArgs[5] = "CP";
	        updateArgs[6] = date[0];
	        updateArgs[7] = "A";
	        run.update(con, updateSql, updateArgs);
			number = String.format("%04d", KH04);	        	  
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		return number;
	}
	
	/**
	 * 寄送EMAIL
	 * @param email
	 * @param number
	 */
	public void sendMail(String email, String number, String secayDesc)
	{
		try
		{			
			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setSubject("法令遵循室後送案件通知 - "+secayDesc+"(" + number + ")");
			StringBuffer sb = new StringBuffer();
			sb.append("各位單位主管或代理人請連到");
			sb.append("<a href='http://kycapj.firstins.com.tw:9080/kyc/Login.do'>KYC系統</a>");
			sb.append("做法遵管理系統後送案件回覆");
			
			kmu.setMessage(sb.toString());
			kmu.addTo(email);
			//kmu.addTo("chrislee@firstins.com.tw");
			kmu.sendMailWithAttachments();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
