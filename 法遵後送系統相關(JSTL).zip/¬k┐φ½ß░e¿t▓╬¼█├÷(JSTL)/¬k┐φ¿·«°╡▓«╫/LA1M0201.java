package com.kyc.la1.actions;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.la1.dao.COM_LDEPDao;
import com.kyc.la1.dao.COM_LEMPDao;
import com.kyc.la1.dao.COM_LMANDao;
import com.kyc.la1.dao.COM_LMDTDao;
import com.kyc.la1.dao.COM_LPDEDao;
import com.kyc.la1.dao.COM_LPTTDao;
import com.kyc.la1.dao.SECAZDao;
import com.kyc.la1.forms.LA1M020f;
import com.kyc.sec.actions.WebAction;

/**
 * @author jieyu
 * @Create Date：2019/01/28
 */
public class LA1M0201 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(5);
		}
	}
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		LA1M020f form1 = (LA1M020f) form;
		
		HttpSession session = request.getSession(false);
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String user = ui.getUserId();
        String systime = DateUtil.getSysTime();
		String dateS = sysdate.substring(0, 5) + "01";
		String dateE = sysdate;
		
		tx_controller.begin(0);		
		COM_LDEPDao COM_LDEPDao = new COM_LDEPDao(tx_controller.getConnection(0));
		
		if(form1.getActionCode() == 5) //初始畫面
		{	
			SECAZDao SECAZDao = new SECAZDao(tx_controller.getConnection(0));
			List listLMA07 = SECAZDao.getcodetype("COMPLIANCE");
			request.setAttribute("listLMA07",listLMA07);			

			request.setAttribute("dateS", dateS);
			request.setAttribute("dateE", dateE);
			
			form1.setNextPage(1);
		}
		
		if(form1.getActionCode() == 6) //快速查詢
		{
			List list = query1(form1);
			
			request.setAttribute("list", list);			
			form1.setNextPage(2);
		}
		
		if(form1.getActionCode() == 12) //進階查詢
		{		
			List list = query2(form1);
			
			request.setAttribute("list", list);			
			form1.setNextPage(2);
		}
		
		if((form1.getActionCode() == 3 || (form1.getActionCode() == 8))) //3：於查詢結果點選後送案號、8：於維護畫面點選部門進度
		{
			//Page3 主檔資料
			Map mapMain = page3Main(form1);	
			
			//Page3 部門資料
			List listDeptTemp = COM_LDEPDao.getCOM_LDEPAll(); //先讀取全部的部門
			List listDept = getListDept(form1,listDeptTemp); //判斷哪些為有勾選的部門
			
			//Page3 項次資料			
			List listItem = page3Item(form1,mapMain.get("LMA07").toString()); 
			
			request.setAttribute("mapMain", mapMain);
			request.setAttribute("listDept", listDept);
			request.setAttribute("listItem", listItem);
			form1.setNextPage(3);
		}
		
		if(form1.getActionCode() == 2) //確認存檔
		{
			updateCOM_LMAN(form1, sysdate, systime, user); //異動法遵後送主檔
			updateCOM_LMDT(form1, sysdate, systime, user); //異動法遵後送主檔項次明細
			updateCOM_LPDE(form1, sysdate, systime, user); //異動法遵後送部門明細檔
			updateCOM_LPTT(form1, sysdate, systime, user); //異動法遵後送部門檢視明細檔

			request.setAttribute("dateS", dateS);
			request.setAttribute("dateE", dateE);
			request.setAttribute("msg", "存檔完成");
			
			form1.setNextPage(1);
		}
		
		if(form1.getActionCode() == 9) //案號刪除 2019/12/16 By John Lai
		{

			Connection con = null;
			
			try
			{
				con = AS400Connection.getOracleConnection();
				COM_LMANDao com_LMANDao = new COM_LMANDao(con);
				COM_LMDTDao com_LMDTDao = new COM_LMDTDao(con);
				COM_LPDEDao com_LPDEDao = new COM_LPDEDao(con);
				COM_LPTTDao com_LPTTDao = new COM_LPTTDao(con);
				
				String lma01 = form1.getSelectNo();
				com_LMANDao.deleteCOM_LMAN(lma01);
				com_LMDTDao.deleteCOM_LMDT(lma01);
				com_LPDEDao.deleteCOM_LPDE(lma01);
				com_LPTTDao.deleteCOM_LPTT(lma01);
				
				request.setAttribute("dateS", dateS);
				request.setAttribute("dateE", dateE);
				request.setAttribute("msg", "後送案號" + lma01 + "刪除成功");
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				AS400Connection.closeConnection(con);
			}
			
			form1.setNextPage(1);
		}
		
		if(form1.getActionCode() == 7) //再通知部門
		{
			updateCOM_LMDT(form1, sysdate, systime, user); //異動法遵後送主檔項次明細
			updateCOM_LPDE(form1, sysdate, systime, user); //異動法遵後送部門明細檔
			String[] depMail = updateCOM_LPTT(form1, sysdate, systime, user); //異動法遵後送部門檢視明細檔
			
			//Page3 主檔資料
			Map mapMain = page3Main(form1);	
			
			//Page3 部門資料
			List listDeptTemp = COM_LDEPDao.getCOM_LDEPAll(); //先讀取全部的部門
			List listDept = getListDept(form1,listDeptTemp); //判斷哪些為有勾選的部門
			
			//Page3 項次資料			
			List listItem = page3Item(form1,mapMain.get("LMA07").toString());
			
			getSendMail(form1, depMail, mapMain);
			
			request.setAttribute("mapMain", mapMain);
			request.setAttribute("listDept", listDept);
			request.setAttribute("listItem", listItem);
			request.setAttribute("msg", "已通知部門並更新部門及項次資料");
			
			form1.setNextPage(3);
		}
		//取消結案
		if(form1.getActionCode() == 10){
			cancel(form1, sysdate, systime, user);
			
			//Page3 主檔資料
			Map mapMain = page3Main(form1);	
			
			//Page3 部門資料
			List listDeptTemp = COM_LDEPDao.getCOM_LDEPAll(); //先讀取全部的部門
			List listDept = getListDept(form1,listDeptTemp); //判斷哪些為有勾選的部門
			
			//Page3 項次資料			
			List listItem = page3Item(form1,mapMain.get("LMA07").toString());
			
			request.setAttribute("mapMain", mapMain);
			request.setAttribute("listDept", listDept);
			request.setAttribute("listItem", listItem);
			request.setAttribute("msg", "已取消結案");
			
			form1.setNextPage(3);
		}
	}
	
	/**
	 * 快速查詢
	 * @param form1
	 * @return list 查詢結果
	 * @throws AsiException
	 */
	public List query1(LA1M020f form1) throws AsiException
	{
		COM_LMANDao COM_LMANDao = new COM_LMANDao(tx_controller.getConnection(0));
		StringBuffer str = new StringBuffer();
		
		if(form1.getOptText()!=null && !form1.getOptText().equals("")){
			if(form1.getCondition().equals("01"))//後送案號
				str.append(" AND LMA01 = '").append(form1.getOptText()).append("' ");
			if(form1.getCondition().equals("02"))//來文文號
				str.append(" AND LMA04 = '").append(form1.getOptText()).append("' ");
		}
	
		List list = COM_LMANDao.getCOM_LMAN(str.toString());
		List listQuery = queryDeptDesc(form1,list); //加入部門中文欄位
		
		return listQuery;
	}	
	
	/**
	 * 進階查詢
	 * @param form1
	 * @return list 查詢結果
	 * @throws AsiException
	 */
	public List query2(LA1M020f form1) throws AsiException
	{
		COM_LMANDao COM_LMANDao = new COM_LMANDao(tx_controller.getConnection(0));
		StringBuffer str = new StringBuffer();
		
		if(form1.getConfirmSts().equals("1"))//後送日期			
			str.append(" AND A.CRTDT >= ").append(form1.getDateS()).append(" AND A.CRTDT <= ").append(form1.getDateE());
		if(form1.getConfirmSts().equals("2"))//來文日期			
			str.append(" AND LMA05 >= ").append(form1.getDateS()).append(" AND LMA05 <= ").append(form1.getDateE());	
		if(form1.getConfirmSts().equals("3"))//預定回覆日期			
			str.append(" AND LMA09 >= ").append(form1.getDateS()).append(" AND LMA09 <= ").append(form1.getDateE());	
		if(form1.getConfirmSts().equals("4"))//實際結案日期			
			str.append(" AND LMA10 >= ").append(form1.getDateS()).append(" AND LMA10 <= ").append(form1.getDateE());
		
		if(!form1.getConfirmStc().equals("0"))//類別			
			str.append(" AND LMA02 = '").append(form1.getConfirmStc()).append("'");
		
		if(form1.getOrganize()!=null && !form1.getOrganize().equals(""))//來文機關
			str.append(" AND LMA03 = '").append(form1.getOrganize()).append("'");
		
		if(form1.getLMA07()!=null && !form1.getLMA07().equals(""))//後送項目
			str.append(" AND LMA07 = '").append(form1.getLMA07()).append("'");
		
		List list = COM_LMANDao.getCOM_LMAN(str.toString()); //先取得資料
		List listQuery = queryDeptDesc(form1,list); //加入部門中文欄位
		
		return listQuery;
	}	

	/**
	 * 查詢維護畫面-取得主檔資料
	 * @param form1
	 * @return map 主檔資料
	 * @throws AsiException
	 */
	public Map page3Main(LA1M020f form1) throws AsiException
	{
		COM_LMANDao COM_LMANDao = new COM_LMANDao(tx_controller.getConnection(0));
		
		StringBuffer str = new StringBuffer();			
		str.append(" AND LMA01 = '").append(form1.getSelectNo()).append("'");
		List listMain = COM_LMANDao.getCOM_LMAN(str.toString());
		
		return (Map) listMain.get(0);
	}
	
	/**
	 * 查詢維護畫面-取得項次資料
	 * @param form1
	 * @param LMA07 後送項目
	 * @return list 項次資料
	 * @throws AsiException
	 */
	public List page3Item(LA1M020f form1,String LMA07) throws AsiException
	{
		SECAZDao SECAZDao = new SECAZDao(tx_controller.getConnection(0));
		COM_LPDEDao COM_LPDEDao = new COM_LPDEDao(tx_controller.getConnection(0));
		
		String deptTemp="";
		if(form1.getActionCode() != 8){
			List listDeptCkeck = COM_LPDEDao.getCOM_LPDEOne((String)form1.getSelectNo());
			Map mapListDeptCkeck = (Map) listDeptCkeck.get(0);
			deptTemp = mapListDeptCkeck.get("LPD02").toString(); //記錄第一個勾選的部門，帶出檢視項次(預設)
		}
		if(form1.getActionCode() == 8)
			deptTemp = form1.getItemDetail(); //點選部門通知，選取該部門的項次資料

		List list = SECAZDao.getcodetype(LMA07); //從代碼檔取得所有項次
		List listItem = getListItem(form1,list,deptTemp); //判斷哪些為有勾選的項次
		
		return listItem;
	}
	
	/**
	 * 查詢結果-通知部門欄位
	 * @param form1
	 * @param list
	 * @return
	 * @throws AsiException
	 */
	public List queryDeptDesc(LA1M020f form1,List list) throws AsiException
	{
		COM_LPDEDao COM_LPDEDao = new COM_LPDEDao(tx_controller.getConnection(0));
		COM_LDEPDao COM_LDEPDao = new COM_LDEPDao(tx_controller.getConnection(0));		
	
		for(int i = 0;i < list.size();i++) //依查詢結果(主檔)逐筆讀取
		{
			Map mapLMAN = (Map) list.get(i);
			String LPDEDesc="";
			
			List listLPDE = COM_LPDEDao.getCOM_LPDEOne((String)mapLMAN.get("LMA01")); //讀取後送部門明細檔，取得該案號的所有部門
			for(int j = 0;j < listLPDE.size();j++)
			{
				Map mapLPDE = (Map) listLPDE.get(j);
				List listLDEP = COM_LDEPDao.getCOM_LDEPOne((String)mapLPDE.get("LPD02")); //讀取部門代號檔
				
				if (listLDEP.size() > 0){
					Map mapLDEP = (Map) listLDEP.get(0); 
					if (LPDEDesc!="")
						LPDEDesc += "，";
					LPDEDesc += (String)mapLDEP.get("LDE02"); //取得部門中文並存入自串
				}				
			}
			
			mapLMAN.put("LPDEDesc", LPDEDesc);
		}
		return list;

	}
	
	/**
	 * 判斷各部門是否有勾選通知，並取得其他需要欄位
	 * @param form1
	 * @param list 全部的部門
	 * @return list 查詢結果(新增Check欄位：N-沒勾選通知、Y-有勾選通知)
	 * @throws AsiException
	 */
	public List getListDept(LA1M020f form1,List list) throws AsiException
	{
		COM_LPDEDao COM_LPDEDao = new COM_LPDEDao(tx_controller.getConnection(0));
		List listDeptCkeck = COM_LPDEDao.getCOM_LPDEOne((String)form1.getSelectNo()); //有勾選的部門
		
		for(int i = 0;i < list.size();i++)
		{
			Map mapDept = (Map) list.get(i);
			String chk = "N";
			
			for(int j = 0;j < listDeptCkeck.size();j++)
			{
				Map mapListDeptCkeck = (Map) listDeptCkeck.get(j);
				if (mapDept.get("LDE01").equals(mapListDeptCkeck.get("LPD02"))){ //存在於明細檔-->有勾選通知
					mapDept.put("Check", "checked");
					
					//回覆日期
					if (mapListDeptCkeck.get("LPD08")==null || "0".equals(mapListDeptCkeck.get("LPD08").toString())){
						mapDept.put("LPD08","");
					}else{
						mapDept.put("LPD08",mapListDeptCkeck.get("LPD08"));
					}
					
					//法遵確認OK
					mapDept.put("LPD07", mapListDeptCkeck.get("LPD07")==null?"":mapListDeptCkeck.get("LPD07"));
					chk = "Y";
				}
			}
			
			if (chk == "N"){ //不存在於明細檔
				mapDept.put("Check", "");
				mapDept.put("LPD08", "");
				mapDept.put("LPD07", "");
			}
			
			if (mapDept.get("LDE01").equals("99")) //高階主管部門不顯示(原因不明)
				list.remove(i);
		}
		return list;
	}
	
	/**
	 * 判斷各項次是否有勾選，並取得其他需要欄位
	 * @param form1
	 * @param list 全部項次
	 * @param deptTemp 要帶出的部門項次
	 * @return list 查詢結果(新增Check欄位：N-沒勾選通知、Y-有勾選通知)
	 * @throws AsiException
	 */
	public List getListItem(LA1M020f form1,List list,String deptTemp) throws AsiException
	{
		COM_LPTTDao COM_LPTTDao = new COM_LPTTDao(tx_controller.getConnection(0));
		List listItemCkeck = COM_LPTTDao.getByLPT01andLPT02((String)form1.getSelectNo(), deptTemp); //讀取後送部門檢視明細檔，取得該部門項次
		
		for(int i = 0;i < list.size();i++)
		{
			Map mapItem = (Map) list.get(i);
			String chk = "N";
			
			for(int j = 0;j < listItemCkeck.size();j++)
			{
				Map mapListItemCkeck = (Map) listItemCkeck.get(j);
				if (mapItem.get("CODEID").equals(mapListItemCkeck.get("LPT04"))){ //存在於明細檔-->有該部門該項次有勾選
					mapItem.put("Check", "checked");
					
					//要處理否
					mapItem.put("LPT05", mapListItemCkeck.get("LPT05")==null?"":mapListItemCkeck.get("LPT05"));
					
					//預定完成日期
					if (mapListItemCkeck.get("LPT06")==null || "0".equals(mapListItemCkeck.get("LPT06").toString())){
						mapItem.put("LPT06","");
					}else{
						mapItem.put("LPT06",mapListItemCkeck.get("LPT06"));
					}
					
					//實際完成日期
					if (mapListItemCkeck.get("LPT07")==null || "0".equals(mapListItemCkeck.get("LPT07").toString())){
						mapItem.put("LPT07","");
					}else{
						mapItem.put("LPT07",mapListItemCkeck.get("LPT07"));
					}

					//處理說明
					mapItem.put("LPT08", mapListItemCkeck.get("LPT08")==null?"":mapListItemCkeck.get("LPT08"));
					chk = "Y";
				}
			}
			
			if (chk == "N"){ //不存在於明細檔
				mapItem.put("Check", "");
				mapItem.put("LPT05", "");
				mapItem.put("LPT06", "");
				mapItem.put("LPT07", "");
				mapItem.put("LPT08", "");
			}
			
			mapItem.put("deptTemp", deptTemp);
		}
		return list;
	}
		
	/**
	 * 異動法遵後送部門明細檔
	 * @param form1
	 * @param sysdate 系統日
	 * @param systime 系統時間
	 * @param user 使用者
	 * @throws AsiException
	 */
	public void updateCOM_LPDE(LA1M020f form1,String sysdate,String systime,String user) throws AsiException
	{
		COM_LPDEDao COM_LPDEDao = new COM_LPDEDao(tx_controller.getConnection(0));
		
		String[] newDept = form1.getNewDept(); //畫面上有勾選的部門
		String[] newCheck = form1.getNewCheckDept(); //畫面上處理確認有勾選的"符合"的部門
		String[] newBack = form1.getSendBackDept(); //畫面上處理確認有勾選的"退件"的部門
		String check =""; //處理確認的狀態，預設為""		
		
		for(int i = 0;i < newDept.length;i++)
		{
			//每次跑迴圈先清空，否則check會記住上一個的選項
			check ="";
			if(null != newCheck)
			{
				for(int j = 0;j < newCheck.length;j++)
				{
					if(newDept[i].equals(newCheck[j])){ //該部門有勾選處理確認
						check ="Y";
						break;
					}
				}
			}
			if(null != newBack)
			{
				for(int j = 0;j < newBack.length;j++)
				{
					if(newDept[i].equals(newBack[j])){ //該部門有勾選處理確認
						check ="N";
						break;
					}
				}
			}
			
			if(!COM_LPDEDao.checkCOM_LPDEExists(form1.getSelectNo(),newDept[i].toString())) //該部門不存在餘明細檔則新增
			{
				COM_LPDEDao.setLPD01(form1.getSelectNo());
				COM_LPDEDao.setLPD02(newDept[i].toString());
				COM_LPDEDao.setLPD03(form1.getTypeItem());
				COM_LPDEDao.setLPD04("0");
				COM_LPDEDao.setLPD05("0");
				COM_LPDEDao.setLPD06("");
				COM_LPDEDao.setLPD07(check);
				COM_LPDEDao.setLPD08("0");
				COM_LPDEDao.setLPD09("");
				COM_LPDEDao.setCRTDT(sysdate);
				COM_LPDEDao.setCRTTM(systime);
				COM_LPDEDao.setCRTUR(user);
				COM_LPDEDao.setUPDDT(sysdate);
				COM_LPDEDao.setUPDTM(systime);
				COM_LPDEDao.setUPDUR(user);
				COM_LPDEDao.insertNewCOM_LPDE();
			}else{
				if((!COM_LPDEDao.getDeptCheck(form1.getSelectNo(), newDept[i].toString()).equals(check))&&(!"N".equals(check))) //有存在且處理狀待有變更(與明細檔不同)
				{
					COM_LPDEDao.updateNewCkeck(check,"",form1.getSelectNo(),newDept[i].toString(),sysdate,systime,user);
					check ="";
				}					
			}
		}
	}
		
	/**
	 * 新增法遵後送部門檢視明細檔(有勾選新部門或新項次時)
	 * @param form1
	 * @param sysdate 系統日
	 * @param systime 系統時間
	 * @param user 使用者
	 * @throws AsiException
	 */
	public String[] updateCOM_LPTT(LA1M020f form1,String sysdate,String systime,String user) throws AsiException
	{
		COM_LPTTDao COM_LPTTDao = new COM_LPTTDao(tx_controller.getConnection(0));
		COM_LDEPDao COM_LDEPDao = new COM_LDEPDao(tx_controller.getConnection(0));
		
		String[] newDept = form1.getNewDept();
		String[] newItem = form1.getWhattodo();
		String[] depsMail = form1.getNewDept();
		
		String mailCkeck ="N"; //是否寄信通知該部門
		
		for(int i = 0;i < newDept.length;i++)
		{
			mailCkeck ="N";
			for(int j = 0;j < newItem.length;j++)
			{
				//判斷該部門的該項次是否存在明細檔，不存在則新增
				if(!COM_LPTTDao.checkCOM_LPTTExists(form1.getSelectNo(),newDept[i].toString(), newItem[j].toString()))
				{
					COM_LPTTDao.setLPT01(form1.getSelectNo());
					COM_LPTTDao.setLPT02(newDept[i].toString());
					COM_LPTTDao.setLPT03(form1.getTypeItem());
					COM_LPTTDao.setLPT04(newItem[j].toString());
					COM_LPTTDao.setLPT05("");
					COM_LPTTDao.setLPT06("0");
					COM_LPTTDao.setLPT07("0");
					COM_LPTTDao.setLPT08("");
					COM_LPTTDao.setCRTDT(sysdate);
					COM_LPTTDao.setCRTTM(systime);
					COM_LPTTDao.setCRTUR(user);
					COM_LPTTDao.setUPDDT(sysdate);
					COM_LPTTDao.setUPDTM(systime);
					COM_LPTTDao.setUPDUR(user);
					COM_LPTTDao.insertNewCOM_LPTT();

					mailCkeck ="Y";
				}
			}
			if(mailCkeck.equals("N"))
				depsMail[i] = "N";
		}
		return depsMail;
	}	
	
	/**
	 * 更新法遵後送主檔
	 * @param form1
	 * @param sysdate 系統日
	 * @param systime 系統時間
	 * @param user 使用者
	 * @throws AsiException
	 */
	public void updateCOM_LMAN(LA1M020f form1,String sysdate,String systime,String user) throws AsiException
	{
		COM_LMANDao COM_LMANDao = new COM_LMANDao(tx_controller.getConnection(0));
		
		COM_LMANDao.setLMA01(form1.getSelectNo());
		COM_LMANDao.setLMA02(form1.getConfirmStc());
		COM_LMANDao.setLMA03(form1.getOrganize());
		COM_LMANDao.setLMA04(form1.getPaperNo());
		COM_LMANDao.setLMA05(form1.getPaperDate());
		COM_LMANDao.setLMA06(form1.getContent());
		COM_LMANDao.setLMA07(form1.getTypeItem());
		COM_LMANDao.setLMA08(form1.getIsAccept());
		COM_LMANDao.setLMA09(form1.getExpectDate());
		//取消結案功能清空結案日期及結案說明
		if(form1.getActionCode() == 10){
			COM_LMANDao.setLMA10("0");
			COM_LMANDao.setLMA11("");
		}
		else{
			COM_LMANDao.setLMA10(form1.getCloseDate() ==""?"0":form1.getCloseDate());
			COM_LMANDao.setLMA11(form1.getCloseContent());
		}
		COM_LMANDao.setCRTDT(sysdate);
		COM_LMANDao.setCRTTM(systime);
		COM_LMANDao.setCRTUR(user);
		COM_LMANDao.setUPDDT(sysdate);
		COM_LMANDao.setUPDTM(systime);
		COM_LMANDao.setUPDUR(user);
		COM_LMANDao.updateCOM_LMAN();					

	}
	
	/**
	 * 新增法遵後送主檔項次明細(新勾選項次時)
	 * @param form1
	 * @param sysdate 系統日
	 * @param systime 系統時間
	 * @param user 使用者
	 * @throws AsiException
	 */
	public void updateCOM_LMDT(LA1M020f form1,String sysdate,String systime,String user) throws AsiException
	{
		COM_LMDTDao COM_LMDTDao = new COM_LMDTDao(tx_controller.getConnection(0));		
		String[] newItem = form1.getWhattodo();
			
		for(int i = 0;i < newItem.length;i++)
		{
			//判斷是否存在於主檔項次明細，不存在則新增
			if(!COM_LMDTDao.checkCOM_LMDTExists(form1.getSelectNo(),form1.getTypeItem(),newItem[i].toString()))
			{
				COM_LMDTDao.setLMD01(form1.getSelectNo());
				COM_LMDTDao.setLMD02(form1.getTypeItem());
				COM_LMDTDao.setLMD03(newItem[i].toString());
				COM_LMDTDao.setCRTDT(sysdate);
				COM_LMDTDao.setCRTTM(systime);
				COM_LMDTDao.setCRTUR(user);
				COM_LMDTDao.setUPDDT(sysdate);
				COM_LMDTDao.setUPDTM(systime);
				COM_LMDTDao.setUPDUR(user);
				COM_LMDTDao.insertNewCOM_LMDT();					
			}
		}
	}
	
	/**
	 * 取得要寄送的名單
	 * @param form1
	 * @param depMail 要寄送的部門
	 */
	public void getSendMail(LA1M020f form1, String[] depMail, Map mapMain)
	{
		try
		{			
			String liaison = form1.getIsAccept();
			List<?> sendEmailList = null;
			Employee emp = null;
			COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(tx_controller.getConnection(0));
			
			for (int i = 0; i < depMail.length; i++)//寄信給該單位洗錢、個資、法遵主管及其單位最高主管
			{
				if (depMail[i].equals("N"))
					continue;
					
				sendEmailList = COM_LEMPDao.getEmailList(depMail[i], liaison);
				String recipient = null;
				
				for (int j = 0; j < sendEmailList.size(); j++)
				{
					Map<?, ?> map = (Map<?, ?>)sendEmailList.get(j);
					recipient = map.get("lem01").toString();		
					emp = Employee.getEmployee(recipient);
					String email = emp.getEmail();
					System.out.println(email);
					sendMail(email, form1.getSelectNo(), mapMain);
				}
				
				if (emp != null){
					String email = emp.getDept().getBoss().getEmail();
					System.out.println(email);
					sendMail(email, form1.getSelectNo(), mapMain);
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 寄送Mail
	 * @param email
	 * @param number
	 */
	public void sendMail(String email, String number, Map mapMain)
	{
		try
		{			
			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setSubject("法令遵循室後送案件通知 - "+mapMain.get("CODEDESC")+"(" + number + ")");
			StringBuffer sb = new StringBuffer();
			sb.append("各位單位主管或代理人請連到");
			sb.append("<a href='http://kycapj.firstins.com.tw:9080/kyc/Login.do'>KYC系統</a>");
			sb.append("做法遵管理系統後送案件回覆");
			
			kmu.setMessage(sb.toString());
			kmu.addTo(email);
			kmu.sendMailWithAttachments();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 取消結案功能
	 * @param form1
	 * @param sysdate 系統日
	 * @param systime 系統時間
	 * @param user 使用者
	 * @throws AsiException
	 */
	public void cancel(LA1M020f form1,String sysdate,String systime,String user) throws AsiException
	{
		updateCOM_LMAN(form1, sysdate, systime, user); //清空結案日期及說明
		
		COM_LPDEDao COM_LPDEDao = new COM_LPDEDao(tx_controller.getConnection(0));
		String[] newDept = form1.getNewDept(); //畫面上有勾選的部門
		//將部門的符合及退件都清空
		for(int i = 0;i < newDept.length;i++)
		{
			COM_LPDEDao.updateNewCkeck("","",form1.getSelectNo(),newDept[i].toString(),sysdate,systime,user);
		}
	}
}
