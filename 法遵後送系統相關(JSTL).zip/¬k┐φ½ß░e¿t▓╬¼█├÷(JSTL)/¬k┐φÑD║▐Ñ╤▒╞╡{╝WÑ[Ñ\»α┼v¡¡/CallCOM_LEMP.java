/**
 * 
 */
package com.kyc.schedule;

import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.dao.PT15PFDao;
import com.asi.kyc.dao.PT16PFDao;
import com.asi.kyc.dao.PT17PFDao;
import com.firstins.CarInsCardService;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.la1.dao.COM_LEMPDao;
import com.kyc.la1.forms.LA1M040f;
import com.kyc.wms.dao.SecakDao;

/**
 * 法遵後送平台-單位最高主管異動(每日根據COM_LEMP重跑LA1M020權限)
 * @author jieyu
 * @Create Date 2019年08月21日
 */
public class CallCOM_LEMP extends AsiAction
{	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{			
		try
		{
			tx_controller.begin(0);

			//刪除高階主管的LA1M020、LA1M090權限，並重新寫入(高階主管異動)
			List delEmpList = getDelEmp();
			for(int i=0;i<delEmpList.size();i++){
				Map mapDelEmp = (Map) delEmpList.get(i);
				String delEmpID = mapDelEmp.get("USERID").toString().trim();
				
				deleteSecak(delEmpID,"LA1M020");
				
				//如該員工編號存在COM_LEMP則不刪除LA1M090功能
				if(!checkCOM_LEMPExists(delEmpID))
					deleteSecak(delEmpID,"LA1M090");				
			}
			
			//重新寫入高階主管的LA1M020、LA1M090權限(高階主管異動)  VI008007K需求刪除此功能
//			List insertBossList = getInsertBoss();
//			for(int i=0;i<insertBossList.size();i++){
//				Map insertBossMap = (Map) insertBossList.get(i);
//				String insertBossID = insertBossMap.get("M283").toString().trim();
//						
//				//不存在SECAK才寫入
//				if(!checkSecakExists(insertBossID,"LA1M020"))
//					insertSecak(insertBossID,"LA1M020");							
//				if(!checkSecakExists(insertBossID,"LA1M090"))
//					insertSecak(insertBossID,"LA1M090");			
//			}
			
			//撈法遵室全部人員，然後判斷法遵室全部人員(LA1M020法遵後送案查詢作業)的權限如果沒有就加入此權限
			List InsertEmployeeList = getInsertEmployee();
			for(int i=0;i<InsertEmployeeList.size();i++){
				Map insertEmployeeMap = (Map) InsertEmployeeList.get(i);
				String insertEmployeeID = insertEmployeeMap.get("M301").toString().trim();
						
				//不存在SECAK才寫入
				if(!checkSecakExists(insertEmployeeID,"LA1M020"))
					insertSecak(insertEmployeeID,"LA1M020");							
				if(!checkSecakExists(insertEmployeeID,"LA1M090"))
					insertSecak(insertEmployeeID,"LA1M090");			
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);
	}
	
	/**
	 * 取得欲刪除的員工資料
	 * @return ret
	 * @throws AsiException
	 */	
	public List getDelEmp() throws AsiException
	{
		List delEmp,noDelMis = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			QueryRunner runner2 = new QueryRunner();
			
			//LA1M020使用者：法遵室(10)、高階主管(99)、單位最高主管、個別授權資訊室人員
			//取得欲刪除的最高主管名單，排出法遵室、高階主管			
			String sqlDelEmp = "SELECT * FROM SECAK ";
			sqlDelEmp += "LEFT JOIN COM_LEMP ON LEM01=USERID ";
			sqlDelEmp += "WHERE FUNCTION='LA1M020' AND ";
			sqlDelEmp += "nvl(LEM02,'NVL') <>'13' AND nvl(LEM02,'NVL') <>'99' ";	
			
			delEmp = (List) runner.query(tx_controller.getConnection(0), sqlDelEmp, new MapListHandler());
			
			//挑出個別授權的資訊室人員(LA1的FUNCTION>3)
			String sqlMisEmp = "SELECT USERID,SYSTEM,MODULE,COUNT(FUNCTION) FROM SECAK ";
			sqlMisEmp += "JOIN PSM3PF ON USERID=M301 AND M303='0034' ";
			sqlMisEmp += "WHERE SYSTEM='LAW' AND MODULE='LA1' ";
			sqlMisEmp += "GROUP BY USERID,SYSTEM,MODULE ";	
			sqlMisEmp += "HAVING COUNT(FUNCTION)>3 ";
			
			noDelMis = (List) runner2.query(tx_controller.getConnection(0), sqlMisEmp, new MapListHandler());
			
			//剔除個別授權的資訊室人員
			for(int i=0;i<delEmp.size();i++){
				Map mapDelEmp = (Map) delEmp.get(i);
				String delEmpID = mapDelEmp.get("USERID").toString().trim();
				
				for(int j=0;j<noDelMis.size();j++){
					Map mapNoDelMis = (Map) noDelMis.get(j);
					String noDelMisID = mapNoDelMis.get("USERID").toString().trim();
					
					if(delEmpID.equals(noDelMisID)){
						delEmp.remove(i);
						i--;
						break;
					}
				}
			}			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		return delEmp;
	}
	
	/**
	 * 檢查該員工編號是否存在COM_LEMP檔
	 * @param LEM01 員工代號
	 * @throws AsiException
	 */
	public boolean checkCOM_LEMPExists(String LEM01) throws AsiException
	{
		try
		{
			boolean isCOM_LEMP = false;
			COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(tx_controller.getConnection(0));
			COM_LEMPDao.setLEM01(LEM01);
			isCOM_LEMP = COM_LEMPDao.checkCOM_LEMPExists();
			return isCOM_LEMP;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
	}
	
	/**
	 * 刪除Secak功能權限
	 * @param USERID 員工代號
	 * @param FUNCTION 程式名稱
	 * @throws AsiException
	 */
	public void deleteSecak(String USERID,String FUNCTION) throws AsiException
	{
		try
		{
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM SECAK WHERE USERID=? AND SYSTEM='LAW' AND MODULE='LA1' AND FUNCTION=? ");
			String args[] = new String[2];
			args[0] = USERID;
			args[1] = FUNCTION;

			int ret = runner.update(tx_controller.getConnection(0), sql.toString(), args);
			if (ret == 0)
				throw new AsiException("");
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
	}
	
	/**
	 * 取得法遵室所有員工(員工編號)
	 * @return insertBoss
	 * @throws AsiException
	 */	
	public List getInsertEmployee() throws AsiException
	{
		List insertEmployee = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			
			String sqlInsertBoss = "SELECT M301 FROM PSM3PF WHERE M303=0009 ";
			
			insertEmployee = (List) runner.query(tx_controller.getConnection(0), sqlInsertBoss, new MapListHandler());		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		return insertEmployee;
	}
	
	/**
	 * 取得欲新增的主管(員工編號)
	 * @return insertBoss
	 * @throws AsiException
	 */	
	public List getInsertBoss() throws AsiException
	{
		List insertBoss = null;
		try
		{
			QueryRunner runner = new QueryRunner();
			
			//從COM_LEMP的員工代號串回該部門，在取得單位最高主管
			//如有部門的所有人員都不存在COM_LEMP，則該單位最高主管亦沒有權限
			String sqlInsertBoss = "SELECT DISTINCT M283 FROM COM_LEMP ";
			sqlInsertBoss += "JOIN PSM3PF ON LEM01=M301 ";
			sqlInsertBoss += "JOIN PSM2PF ON M201='A1' AND M303=M202 ";
			
			insertBoss = (List) runner.query(tx_controller.getConnection(0), sqlInsertBoss, new MapListHandler());		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		return insertBoss;
	}
	
	/**
	 * 檢查該權限是否已存在SECAK
	 * @param USERID 員工代號
	 * @param FUNCTION 程式名稱
	 * @return isSecak
	 * @throws AsiException
	 */
	public boolean checkSecakExists(String USERID,String FUNCTION) throws AsiException
	{
		try
		{
			boolean isSecak = false;
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT COUNT(*) AS NUM FROM SECAK WHERE USERID=? AND SYSTEM='LAW' AND MODULE='LA1' AND FUNCTION=? ");
			
			String args[] = new String[2];
			args[0] = USERID;
			args[1] = FUNCTION;
			
			Map ret = (Map) runner.query(tx_controller.getConnection(0), sql.toString(), args, new MapHandler());
			int count = 0;
			if(ret.size()>0)
				count = ((BigDecimal) ret.get("NUM")).intValue();
			if(count>0)
				isSecak = true;
			
			return isSecak;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
	}
	
	/**
	 * 寫入Secak
	 * @param form1
	 * @throws AsiException
	 */
	public void insertSecak(String USERID,String FUNCTION) throws AsiException
	{
		try
		{
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	        String systime = DateUtil.getSysTime();
	        
			SecakDao SecakDao = new SecakDao(tx_controller.getConnection(0));
			
			//寫入權限檔
			SecakDao.setUSERID(USERID);
			SecakDao.setSYSTEM("LAW");
			SecakDao.setMODULE("LA1");
			SecakDao.setFUNCTION(FUNCTION);
			SecakDao.setPOWER("118");
			SecakDao.setSPECIAL1("");
			SecakDao.setSPECIAL2("");
			SecakDao.setSPECIAL3("");
			SecakDao.setOWNER("FIRSTADMIN");
			SecakDao.setCRTDT(sysdate);
			SecakDao.setCRTTM(systime);
			SecakDao.setCRTUR("FIRSTADMIN");
			SecakDao.setUPDDT(sysdate);
			SecakDao.setUPDTM(systime);
			SecakDao.setUPDUR("FIRSTADMIN");
			SecakDao.insertSecak();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
	}
	
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}
