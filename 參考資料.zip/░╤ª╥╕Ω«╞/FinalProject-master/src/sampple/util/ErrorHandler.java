package sampple.util;

public class ErrorHandler {
	
}
