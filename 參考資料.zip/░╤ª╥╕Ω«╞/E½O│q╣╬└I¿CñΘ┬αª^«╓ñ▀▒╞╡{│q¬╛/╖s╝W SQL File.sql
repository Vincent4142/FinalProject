--信件原始資料
SELECT WB011 || WB021 INSNO, T408, WB96, sum(WB15) AMOUNT 
from FGFLIB/EPXBWF inner join FGFLIB/EPS4PF on SUBSTR(WB30,10,14) = T402 || T403 
where WB96 = 1100319 AND SUBSTR(WB021,1,1) = 'V'  AND SUBSTR(WB021,5,4) >= 'A001' AND SUBSTR(WB021,5,4) <= 'J999' and LENGTH(TRIM(WB021)) = 8
group by WB011 || WB021, T408, WB96

select * from FGFLIB/EPS4PF
where T402 || T403 ='100009GP700089'

select * from FGFLIB/EPXBWF where WB011 || WB021='1000VT10A194'

--缺少加總的資料
SELECT WH011 || WH021 INSNO, WH98, sum(WH02) AMOUNT 
from FGFLIB/EPXHWF 
where WH98 = 1100319 AND SUBSTR(WH021,1,1) = 'V'  AND SUBSTR(WH021,5,4) >= 'A001' AND SUBSTR(WH021,5,4) <= 'J999' and LENGTH(TRIM(WH021)) = 8
group by WH011 || WH021, WH98

select * from FGFLIB/EPXHWF where WH011 || WH021='1000VT10A194' AND WH98=1100319



1100319有問題的資料

FGFLIB/EPXBWF
WB011(處理單位)		WB021(批單號碼)			WB030(組別)		  WB03(標的物編號)		WB04(被保險人)
1000                VT10A194                0                 9    					鍾艾娜

FGFLIB/EPS4PF
T401(險別)	T402(處理單位)	T403(保單號碼)		T404(處理單位-續保)	  T405(續保單號碼)	T406(保單狀況碼)
O       	1000        	09GP700089      	1000              	  08GP000398        F

FGFLIB/EPXHWF
WH011(處理單位)		WH021(批單號碼)			WH0030(組別)	WH003(編號)		WH07(類別代碼)
1000        		VT10A194    0           9   			PA02        	A1
1000        		VT10A194    0           9   			PA09        	D3
1000        		VT10A194    0           9   			PA21        	G1