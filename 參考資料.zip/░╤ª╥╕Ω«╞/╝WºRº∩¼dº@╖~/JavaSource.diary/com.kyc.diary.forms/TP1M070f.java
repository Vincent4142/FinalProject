/*
 * Created on 2020/7/29
 */
package com.kyc.diary.forms;

import com.asi.common.struts.AsiActionForm;

/**
 * @author Vincent
 * 作業：工作日誌維護
 */

public class TP1M070f extends AsiActionForm {
	private String cNumber;//聯繫單編號
	
	private String require;//需求
	
	private int creationDate;//建立日期
	
	private int finishDate;//完成日期
	
	private String progress;//工作進度

	/**
	 * @return the cNumber
	 */
	public String getcNumber() {
		return cNumber;
	}

	/**
	 * @param cNumber the cNumber to set
	 */
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}

	/**
	 * @return the require
	 */
	public String getRequire() {
		return require;
	}

	/**
	 * @param require the require to set
	 */
	public void setRequire(String require) {
		this.require = require;
	}

	/**
	 * @return the creationDate
	 */
	public int getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(int creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the finishDate
	 */
	public int getFinishDate() {
		return finishDate;
	}

	/**
	 * @param finishDate the finishDate to set
	 */
	public void setFinishDate(int finishDate) {
		this.finishDate = finishDate;
	}

	/**
	 * @return the progress
	 */
	public String getProgress() {
		return progress;
	}

	/**
	 * @param progress the progress to set
	 */
	public void setProgress(String progress) {
		this.progress = progress;
	}
	
}
