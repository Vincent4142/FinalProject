
package com.asi.kyc.wb1.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import ws.first.FirstInsWebService;

import com.asi.adm.ad1.actions.KycklaTransfer;
import com.asi.adm.ad1.models.ConfirmHandlerFac;
import com.asi.adm.ad1.models.IConfirmHandler;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.Record;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.manager.IConfigManager;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.ManagerUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.CharacterUtil;
import com.asi.kyc.common.utils.HitrustUtil;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.MD5Encode;
import com.asi.kyc.common.utils.NCCCUtil;
import com.asi.kyc.common.utils.TradeCounter;
import com.asi.kyc.common.utils.UpdateState;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.asi.kyc.wb1.forms.WB1M040f;
import com.asi.kyc.wb1.forms.WB1M050f;
import com.firstins.dao.procedure.FAS24Input;
import com.firstins.dao.procedure.FAS24PRC;
import com.firstins.dao.procedure.FAS24Return;
import com.kyc.afl.utils.WorkDay;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.kycAction;

/**
 * @author vsg
 * 新版 旅平險網路投保
 */
public class NWB1M0401 extends kycAction {

	String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
	String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
	String omitLiaUpload = SystemParam.getParam("INS_OMITUPLOAD");// 是否略過收件及承保通報，平常-N 測試-Y

    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
        
    	WB1M040f form1 = (WB1M040f) form;
    	
    	//系統參數
    	String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
    	String omitcredit = SystemParam.getParam("INS_OMITCREDIT");// 是否略過聯合信用卡刷卡機制，平常-N 測試-Y
    	tx_controller.begin(0);
    	RG1M010m model2 = new RG1M010m(tx_controller, request, form);
    	//專案代號
        String pjcode = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";       
        if(!pjcode.equals(""))
        	pjcode = CodeUtil.getCodeDesc(getServlet(), request, "PROJSOURCE", pjcode.toUpperCase());//由專案代碼找對應的業務來源       
        
        request.setAttribute("pjcode", pjcode);
    	
        //session time out
        HttpSession session = request.getSession(false);
        UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
        String userid = "";

        String source = form1.getSource();
        String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        String plusDay = SystemParam.getParam("TA_STRDATE");//旅平險起保加工作天數
        String strworkday = WorkDay.getStrWorkDatebyDays("00", sysdate, true, String.valueOf(plusDay)); 
        request.setAttribute("strdate", strworkday);//起保日期放到畫面
        
        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("TA", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("TA", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("TA", "description"));
        request.setAttribute("meta_ogtitle", getKYCWHDbyKey("TA", "ogtitle"));
        request.setAttribute("meta_ogdescription", getKYCWHDbyKey("TA", "ogdescription"));
       
        HashMap<String, Object> travel;
        if ("WB1M040p1".equals(source)) {
            travel = new HashMap<String, Object>();
        } else {
            travel = (HashMap<String, Object>) session.getAttribute("travel");
            if (travel == null) {
                form1.setNextPage(1);
                return;
            }
        }

        int pageIndex = 1;
        
        String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商信箱
        String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
        String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
        request.setAttribute("ecom_email", ecom_email);
        request.setAttribute("telno", ecom_tel);
        request.setAttribute("faxno", ecom_fax);

        //由金流網頁返回
        if (form.getActionCode() == 21) {
        	
        	setUserinfo();
            pageIndex = 8;

            String seqnumT = (String) travel.get("seqnumT");//交易序號
            String entry = (String) travel.get("entry");//投保要保區別
            String ta1518 = (String) travel.get("ta1518");//通報查詢序號
            
            String t1575 = (String) travel.get("t1575");//電子保單選項
            String t1546a = (String) travel.get("t1546A");//英文姓名
            request.setAttribute("t1575", t1575);
            request.setAttribute("t1546a", t1546a);
            
            String notifyno ="";
            String uploadInsActRvNo = "";//收件通報序號
            String uploadInsActNo = "";//承保通報序號
            boolean isNotifyOK = false;
            boolean isUploadInsOK = false;
            
            FirstInsWebService fiws = null;
            List resultlist = null;
            
            //檢查是否進行過狀態更新及寄送email
            if (!"Yes".equals(session.getAttribute(seqnumT))) {
                //檢查交易是否有授權成功，交易失敗不寫檔
                if ("00".equals(form1.getRetcode())) {
                    //更新金流狀態
                    UpdateState.updateKL80_State(tx_controller, seqnumT, "3");

                    //交易主檔查詢
                    DBO kyckla = tx_controller.getDBO("kyc.KYCKLAs03", 0);
                    kyckla.addParameter("T1501", seqnumT);
                    kyckla.executeSelect();

					//查詢被保險人明細資料
					DBO kyckld = tx_controller.getDBO("kyc.KYCKLDs01", 0);
					kyckld.addParameter("T1801", seqnumT);
					kyckld.execute();

					//查詢被保險人明細資料
					DBO kyckle = tx_controller.getDBO("kyc.KYCKLEs01", 0);
					kyckle.addParameter("T1901", seqnumT);
					kyckle.execute();
					System.out.print(kyckle.getAssembledSQL());

					//要保人id
					String t1547 = kyckla.getRecordData("T1547");
					
					//保單號碼
					String t1504 = "";
					
					//通報序號
					notifyno = getNotificationNo();
					fiws = new FirstInsWebService();
					
					//網路投保-收件通報作業
                    if(entry.equals("1")){
                    	uploadInsActRvNo = Number.getWSUploadInsActRvCheckNo(servlet, request);
                    	//網路投保，進行WebService收件通報
                    	resultlist = fiws.getUploadInsActRv(travel, uploadInsActRvNo, t1504);
                    	
                    	if(isResultOK(resultlist))
                    	{
	                        //網路投保，保單號碼直接配號
	    					updatePnumber(request, seqnumT, kyckla);
	    					t1504 = kyckla.getRecordData("T1504").toString();
	    					
	    					List handlerList = ConfirmHandlerFac.getHandler(kyckla);
	    					for(int i=0;i<handlerList.size();i++)
	    					{
	    						IConfirmHandler handler = (IConfirmHandler) handlerList.get(i);
	    						handler.kycklaDbo = kyckla;
	    						// 新增保單檔IC02
	    						handler.modifyIC02(tx_controller,request);
	    						// 更新或新增客戶IC01
	    						if(i>0)
	    							continue;
	    						handler.modifyIC01(tx_controller,request);
	    					}
	    					
	    					KycklaTransfer.transferKL(tx_controller,seqnumT);
	    					update80(t1547, seqnumT, "4");
                    	}
                    }

					//進行收件通報寫檔作業
					isNotifyOK = insertEPB501Files(entry , request , seqnumT , kyckla , kyckld , notifyno);
					//更新收件通報序號
					if(isNotifyOK)
						updateKYCKLA_TA1516(request, seqnumT, notifyno , "" , ta1518 , uploadInsActRvNo);       	

					//網路投保-承保通報作業
                    if(entry.equals("1")){
                    	
                        //網路投保，進行WebService承保通報
                    	uploadInsActNo = Number.getWSUploadInsActCheckNo(servlet, request);
                    	resultlist = fiws.getUploadInsAct(travel, uploadInsActNo, t1504);  
                    	
                    	if(isResultOK(resultlist))
                    	{
                            //承保通報寫檔
                        	isUploadInsOK = insertEPB500Files(entry, request, t1504, kyckla, kyckld, kyckle);
                        	
                        	if(isUploadInsOK)
                        		updatePT15PF_TA1516(request, seqnumT, notifyno, uploadInsActNo, ta1518 , uploadInsActRvNo);
                    	}
                    	
                    }
					
                } else {
                    //更新金流狀態
                    UpdateState.updateKL80_State(tx_controller, seqnumT, "2");
                }
                //完成註記
                session.setAttribute(seqnumT, "Yes");
            }
            
            //將結果頁面需要的值再放進去，供畫面取用
            form1 = reForm(travel, form1);
            request.setAttribute("MSG", session.getAttribute("errmsg") != null ? session.getAttribute("errmsg").toString() : "");
        }else if(form.getActionCode() == 5){
        	pageIndex = 1;
        }else{
        	
            //page1-投保要保選擇頁
        	if ("WB1M040p1".equals(source)) {
                if (ui == null)//登入時導向page4
                	pageIndex = 4;
                else//未登入時導向page2
                	pageIndex = 2;     
                
                travel.put("entry", form1.getEntry());
            //page2-試算條件輸入
            } else if ("WB1M040p2".equals(source)) { 
            	//先記住客戶是否同意行銷
            	String C01A18= request.getParameter("agreeChk4")== null ? "" : request.getParameter("agreeChk4");
            	session.setAttribute("C01A18",C01A18);
            	//附加旅遊不便
                String isAdd = request.getParameter("isAdd");
                if("true".equals(isAdd)) form1.setAdd(true);
        		//附加海突
                String isAddohs = request.getParameter("isAddOHS");
                if("true".equals(isAddohs)) form1.setAddOHS(true);
                
                //投保方案
                String tarea = request.getParameter("tarea");
                form1.setTarea(tarea);
                
                travel = doPage1(travel, form1);
                pageIndex = 3;
            //page3-試算結果
            } else if ("WB1M040p3".equals(source)) {
                
            	pageIndex = 5;
            	//啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
                tx_controller.begin(0);

                setUserinfo();
                TradeCounter.count("TA", (UserInfo) session.getAttribute(GlobalKey.USER_INFO), tx_controller);               
                
                travel = doPage2(travel, form1);
                
                //檢查使用者由那一個網站進入線上投保，用於判斷要用哪個條件查詢業務來源及招攬人
                String KD19 = form1.getPjcode();
                
                if(!KD19.equals(""))
                	KD19 = CodeUtil.getCodeDesc(getServlet(), request, "PROJSOURCE", KD19.toUpperCase());
                else
                	KD19 = "KYC";
                
                travel = getKYCkd(travel, KD19);
                
                travel = checkAmountLimit(request, travel, KD19);//檢核保額
                
                String[] AS400Status = (String[]) travel.get("AS400Status");
                
                //測試用，略過檢核***************只能2人
//                AS400Status = new String[3];
//                AS400Status[0] = "";
//                AS400Status[1] = "";
//                AS400Status[2] = "Y";
//
//                String[] arg11 = new String[2];
//                arg11[0] = "0";
//                arg11[1] = "0";
//                
//                travel.put("ta1518", "00000000000");//查詢序號
//                travel.put("inscmps", arg11);
//                travel.put("insamounts", arg11);
                //***********************
                
                if ("ERROR".equals(AS400Status[0]) || "ERROR".equals(AS400Status[1])) {
                    pageIndex = 8;
                	request.setAttribute("ERROR", "Y");
                	request.setAttribute("MSG", "查詢程式錯誤，請洽專員處理！");

                } else {
                    if (!"Y".equals(AS400Status[2])) {
                    	pageIndex = 8;
                    	request.setAttribute("ERROR", "Y");
                    	request.setAttribute("MSG", AS400Status[2] + " " + AS400Status[1]);                       
                    }
                }
                
            //page5-試算完成頁
            }else if ("WB1M040p5".equals(source)) {
                pageIndex = 6;

            //page4-會員登入
            } else if ("WB1M040p4".equals(source)) {
                
            	if(form.getActionCode()==9)
            	{
            		DBO dbo = new SelectDBO();
            		dbo.addRecordData("C101",request.getParameter("UID"));
            		request.getSession(false).setAttribute(KycGlobal.Kyc_UserInfo, dbo);

            		pageIndex = 5;
            	}
            	else
            	{
                    if(ui != null )
                    	userid = ui.getUserId();              	
                    request.setAttribute("userid", userid);

            		if(form.getActionCode()== 2)
            		{
            			form1.setT1547(form1.getUID());
                        travel.put("isNew", "true");

            			pageIndex = 2;
            		}
            		else{
            			DBO dbo = selectSECAJ(form1.getUID());
                		if (dbo.getRecordCount() == 1) {
                            
                            pageIndex = 99;
                            travel.put("isNew", "false");
                		}else {
                        	
                            form1.setT1547(form1.getUID());
                            travel.put("isNew", "true");
                            pageIndex = 2;
                            
                		}      
                		dbo.destroy();
            		}

            	}
            	
            	travel.put("entry", form1.getEntry());
            	
            //page6-要保資料輸入
            } else if ("WB1M040p6".equals(source)) {           	
                pageIndex = 7;

                travel.put("t1511", getZip(form1.getT1511(), request)); //郵遞區號
                                
                //檢查使用者由那一個網站進入線上投保，用於判斷要用哪個條件查詢業務來源及招攬人
                String KD19 = (String) session.getAttribute(KycGlobal.CaseFrom);
                if (KD19 == null) {
                    KD19 = "KYC";
                }
                travel = doPage5(travel, form1, KD19 , request);
                String[] AS400Status = (String[]) travel.get("AS400Status");
                if ("ERROR".equals(AS400Status[0]) || "ERROR".equals(AS400Status[1])) {
                    pageIndex = 8;
                	request.setAttribute("ERROR", "Y");
                	request.setAttribute("MSG", "查詢程式錯誤，請洽專員處理！");

                } else {
                    if (!"Y".equals(AS400Status[2])) {
                    	pageIndex = 8;
                    	request.setAttribute("ERROR", "Y");
                    	request.setAttribute("MSG", AS400Status[2] + " " + AS400Status[1]);                       
                    }
                }

            //page7-注意事項確認
            } else if ("WB1M040p7".equals(source)) {
            	
            	//紀錄客戶是否同意行銷(IC01PFA)(IC01PF)
            	String C01A18= session.getAttribute("C01A18").toString();
            	boolean exist=model2.isExistIC01PFA(form1.getT1547());
            	model2.updateIC01PFA(form1.getT1547(), C01A18, exist);
            	model2.insertIC01PF_Insured(form1.getT1547());
            	session.removeAttribute("C01A18");
                
            	travel.put("entry", form1.getEntry());//投保要保判斷
                String channelCode = (form1.getEntry() != null && form1.getEntry().equals("2")) ? "40" : "41";//通路別判斷
                travel.put("channel", channelCode);

                //瀏覽器資訊
            	travel.put("ismobile", form1.getIsmobile() != null ? form1.getIsmobile() : "");
            	travel.put("os", form1.getOs() != null ? form1.getOs() : "");
            	travel.put("browser", form1.getBrowser() != null ? form1.getBrowser() : "");
            	travel.put("bro_version", form1.getBro_version() != null ? form1.getBro_version() : "");     
            	//IP
            	travel.put("remoteaddr", request.getRemoteAddr());     

                //取交易序號
                String seqnumT = Number.getNumber_O("TA", getServlet(), request, "T");
                travel.put("seqnumT", seqnumT);

                String t1539 = (String) travel.get("t1539");
                String t1546 = (String) travel.get("t1546");
                String t1547 = (String) travel.get("t1547");

                Calendar calendar = Calendar.getInstance();
                int hhmmss = calendar.get(Calendar.HOUR_OF_DAY) * 10000 + calendar.get(Calendar.MINUTE) * 100 + calendar.get(Calendar.SECOND);
                travel.put("sysHHMMSS", String.valueOf(hhmmss));
                //取中文值
                travel.put("travelArea", CodeUtil.getCodeDesc(this.getServlet(), request, "TRAVELAREA", (String) travel.get("t1550")));
                travel.put("t15d3", CodeUtil.getCodeDesc(this.getServlet(), request, "TA_SECTION", (String) travel.get("t1550")));
                travel.put("t1626_1", MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT91"));
                travel.put("t1626_2", MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT92"));
                travel.put("t1626_3", MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT93"));
                travel.put("t1629_3", MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT89"));
                travel.put("t1630_3", MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT90"));
                travel.put("t1575", form1.getKyc_T1575()); //電子保單選項
                
                setUserinfo();

                //KYC網路出單交易主檔(LOG檔) KYCKLA
                insertPT15PF(travel, seqnumT,request); //保單號碼傳空白, 寫入交易LOG檔

                //KYC網路出單交易明細檔1(LOG檔) KYCKLB
                boolean isAdd = "true".equals(String.valueOf(travel.get("isAdd")));
                if(isAdd){
                    insertPT16PF(travel, seqnumT); //寫入交易LOG檔
                }

                //KYC網路出單交易明細檔2(LOG檔) KYCKLD
                insertPT18PF(travel, seqnumT); //寫入交易LOG檔
            	
                //KYC網路出單交易明細檔3(LOG檔)
                insertPT19PF(travel, seqnumT);
                 
                //存檔完動作
            	if(form.getActionCode()==41)
            	{
            		if(otpswitch.equals("Y"))
            			sendMobileMsg(travel.get("t1546").toString(), travel.get("otp").toString(), travel.get("t1515").toString());//發送投保簡訊
            		else
            			sendOTPMail(request, travel.get("t1516").toString(), travel.get("t1546").toString(), travel.get("otp").toString());//發送投保email

            		request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
            		pageIndex = 9;

            	}else{
            	
                    //檢查是否為線上金流停用時間
                    ui = this.tx_controller.getUserInfo();
                	String stopTime = SystemParam.getParam(KycGlobal.SysParam_HITRUSTSTOPTIME);
                	        
                	long stopTime_from = Long.parseLong(stopTime.substring(0,12));
                	long stopTime_end = Long.parseLong(stopTime.substring(13,25));
                	long sysTime = Long.parseLong(DateUtil.getSysDate(ui,false)+DateUtil.getSysTime(false));
                    try {
                    	if (stopTime_from <= sysTime && stopTime_end >= sysTime){  	      		  	
                    		UpdateState.updateKL80_HitrustStop((String)travel.get("seqnumT"), tx_controller);//更新交易狀態碼 9-未開放線上刷卡
          	      		 
                    		//取得參數
                    		IConfigManager conf = (IConfigManager) ManagerUtil.getConfigManager(servlet); 	      	        	      	       
                    		String stopPage = conf.getConfig("hitrust.stopPage"); 	      	        
                    		response.sendRedirect( RequestUtils.serverURL(request) + request.getContextPath() + stopPage); 	      		 
                    		return; 	      		  
                    	}
                    } catch (IOException e) {
                    	throw new UserException("errors.1000", e);
                    }            
                               
                    //******本機測試用 起*****
//                    pageIndex = 8; //測試用
//                    form1.setRetcode("00");//成功
//                    form1.setRetcode("99");//失敗

//                    //檢查是否進行過狀態更新及寄送email
//                    if (!"Yes".equals(session.getAttribute(seqnumT))) {
//                        //檢查交易是否有授權成功，交易失敗不寫檔
//                        if ("00".equals(form1.getRetcode())) {
//                            //更新金流狀態
//                            UpdateState.updateKL80_State(tx_controller, seqnumT, "3");
//                            //交易成功確認信
//                            //sendMail(request, travel);
//                        } else {
//                            //更新金流狀態
//                            UpdateState.updateKL80_State(tx_controller, seqnumT, "2");
//                        }
//                        //完成註記
//                        session.setAttribute(seqnumT, "Yes");
//                    }
                    
					//組交易結果頁面
//                    form1 = reForm(travel, form1);
                     
                    //******本機測試用 止*****
                                    
                    //連至HiTrust網頁輸入信用卡號，若本機欲測試寫檔，以下mark起來
                    HitrustUtil.callHitrust(seqnumT, MathUtil.getDouble(t1539), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
                            + CodeUtil.getCodeDesc(servlet, request, "GOODSID", "TA") + t1547 + t1546, 40), "/NWB1M0401.do", this.getServlet(), request, response);         		
                    pageIndex = -1;
            	}
            	
            //page8-完成頁刷卡錯誤處理
            } else if ("WB1M040p8".equals(source)) {
                pageIndex = 7;
                request.setAttribute("AS400Error", "ERROR");

                form1 = reForm(travel, form1);
            }
        	//page9-OTP驗證頁
            else if (form.getSource().equals("WB1M040p9")) 
            {  
            	if(form.getActionCode() == 28)
            	{ 			  
            		boolean isUpdatetok = isUpdateOTP(travel);
       				if(isUpdatetok){
       					if(otpswitch.equals("Y"))
       						sendMobileMsg(travel.get("t1546").toString(), travel.get("otp").toString(), travel.get("t1515").toString());//發送投保簡訊
       		        	else
       		        		sendOTPMail(request, travel.get("t1516").toString(), travel.get("t1546").toString(), travel.get("otp").toString());//發送投保email

       					request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");
       					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

       				}else{
       					request.setAttribute("exmin", "0");
       				}

       				pageIndex = 9;
       		  }
       		  else{
       			  if(isRightOTP(travel, form1))
          		  {
                      request.getSession(false).setAttribute("WB1M040f", reForm(travel, form1));
                      
                      //略過網路投保刷卡動作，測試用
                      if(omitcredit.equals("Y"))
                      {
                          try {
                        	  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M0401.do?actionCode=21&retcode=00&ordernumber=" + travel.get("seqnumT").toString());
                        	  return;
                          } catch (MalformedURLException e) {

                        	  e.printStackTrace();
                          } catch (IOException e) {

                        	  e.printStackTrace();
                          }

                      }else{
                          NCCCUtil.callNCCC(travel.get("t1547").toString() , travel.get("seqnumT").toString(), MathUtil.getDouble(travel.get("t1539").toString()), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
                                  + CodeUtil.getCodeDesc(servlet,request,"GOODSID","TA") + travel.get("t1547").toString() + travel.get("t1546").toString(), 40), "NWB1M0401", getServlet(), request, response);
                          pageIndex = -1;
                      }
                              
          		  }
          		  else{
          			  throw new UserException("errors.1000", "OTP輸入錯誤，請重新輸入！");
          		  }
       			  
       		  } 	  
            }
        }

        session.setAttribute("travel", travel);
        request.setAttribute("action", "NWB1M0401");
        form1.setNextPage(pageIndex);
    }

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        WB1M040f form1 = (WB1M040f) arg1;
        if (form1.getActionCode() == 0 && form1.getRetcode() != null) {
            form1.setActionCode(21);
        }else if(form1.getActionCode() == 0)
        {
        	form1.setActionCode(5);
        }       
    }

    private HashMap<String, Object> doPage1(HashMap<String, Object> travel, WB1M040f form1)
    {
        
        String channelCode = (form1.getEntry() != null && form1.getEntry().equals("2")) ? "40" : "41";//通路別判斷
        travel.put("entry", form1.getEntry());
        travel.put("channel", channelCode);    	
    	travel.put("t1550", form1.getT1550());
        travel.put("yearFrom", form1.getYearFrom());
        travel.put("monthFrom", form1.getMonthFrom());
        travel.put("dateFrom", form1.getDateFrom());
        travel.put("hourFrom", form1.getHourFrom());
        String dateBegin = form1.getYearFrom() + form1.getMonthFrom() + form1.getDateFrom();
        travel.put("dateBegin", dateBegin);
        travel.put("yearTo", form1.getYearTo());
        travel.put("monthTo", form1.getMonthTo());
        travel.put("dateTo", form1.getDateTo());
        String dateEnd = form1.getYearTo() + form1.getMonthTo() + form1.getDateTo();
        travel.put("dateEnd", dateEnd);
        travel.put("totalDays", form1.getTotalDays());
        travel.put("headCount", form1.getHeadCount());
        travel.put("isAdd", String.valueOf(form1.isAdd()));
        travel.put("isAddOHS", String.valueOf(form1.isAddOHS()));
        travel.put("tarea", String.valueOf(form1.getTarea()));
        travel.put("t15501", form1.getT15501()); //旅遊國家 
        
        return travel;
    }

    private HashMap<String, Object> doPage2(HashMap<String, Object> travel, WB1M040f form1) throws AsiException {
        travel = page2Action(travel, form1);

        travel.put("birthYear", form1.getBirthYear());
        travel.put("birthMonth", form1.getBirthMonth());
        travel.put("birthDate", form1.getBirthDate());
        travel.put("t1808", form1.getT1808()); //被保險人ID
        travel.put("t1825", form1.getT1825());
        travel.put("t1826", form1.getT1826());
        travel.put("amount", form1.getAmount());
        travel.put("t1539", form1.getT1539());
        travel.put("pjcode", form1.getPjcode());
        travel.put("t1584", form1.getT1584());

        return travel;
    }

    private HashMap<String, Object> doPage5(HashMap<String, Object> travel, WB1M040f form1, String KD19 , HttpServletRequest request) throws AsiException {
        travel = page5Action(travel, form1 , request);//蒐集整理資料
//        travel = checkAmountLimit(request , travel, KD19);//檢核保額
        return travel;
    }

    /**
     * 查詢費率檔，計算保費
     * @param travel
     * @param form1
     * @return
     * @throws AsiException
     */
    private HashMap<String, Object> page2Action(HashMap<String, Object> travel, WB1M040f form1) throws AsiException {
        String strdate = (String) travel.get("yearFrom") + travel.get("monthFrom") + travel.get("dateFrom");
        String p8101 = "0";
    	
    	//組sql
        StringBuffer sql1 = new StringBuffer();
        StringBuffer sql2 = new StringBuffer();
        StringBuffer sql3 = new StringBuffer();
        sql1.append(" AND P8104 in(");
        sql3.append(" AND P8104 in(");

        String[] t1825 = form1.getT1825();//死殘保額
        String[] t1826 = form1.getT1826();//醫療保額
        String[] t1909 = form1.getT1909();//海突保額
        String[] t1909pub = form1.getT1909pub();//公共交通工具保額
        
        int len = t1825.length;
        for (int i = 0; i < len; i++) {
            sql1.append(t1825[i]).append("0000,");
            sql3.append(t1826[i]).append("0000,");
        }
        sql1.deleteCharAt(sql1.length() - 1);
        sql1.append(")");
        sql3.deleteCharAt(sql3.length() - 1);
        sql3.append(")");
        
        sql1.append(" AND P8101=(SELECT MAX(P8101) FROM EP81PF	WHERE P8101<=").append(strdate);
        sql1.append(" AND P8102=A.P8102 AND P8103=A.P8103 AND P8104=A.P8104)");
        sql2.append(" AND P8101=(SELECT MAX(P8101) FROM EP81PF	WHERE P8101<=").append(strdate);
        sql2.append(" AND P8102=A.P8102 AND P8103=A.P8103)");
        sql3.append(" AND P8101=(SELECT MAX(P8101) FROM EP81PF	WHERE P8101<=").append(strdate);
        sql3.append(" AND P8102=A.P8102 AND P8103=A.P8103 AND P8104=A.P8104)");
        //旅遊傷害保險費
        DBO dbo = (DBO) tx_controller.getDBO("kyc.EP81PFs01", 1);
        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
        dbo.addParameter("P8103", "C");
        dbo.addParameter("WHERE", sql1.toString());
        dbo.execute();
        System.out.println(dbo.getAssembledSQL());  

        int count = dbo.getRecordCount();
        HashMap<String, Integer> hm = new HashMap<String, Integer>(count);

        Record record;
        for (int i = 1; i <= count; i++) {
            record = dbo.getRecord(i);
            hm.put(record.getData("P8104"), new Integer(record.getInt("P8106")));//優惠保費（保費B）
            hm.put("14="+record.getData("P8104"), new Integer(record.getInt("P8108")));//15歲以下客戶的死殘保費抓P8108（保費 D）
        }
        int[] t1828 = reAmount(hm, t1825,form1.getBirthYear(),form1.getBirthMonth(),form1.getBirthDate() , strdate); //死殘保費

        //個人責任暨旅遊不便險
        int valA = 0;
        int valB = 0;
        boolean isAdd = "true".equals(String.valueOf(travel.get("isAdd")));
        if(isAdd){
	        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
	        dbo.addParameter("P8103", "A");//責任保險費
	        dbo.addParameter("WHERE", sql2.toString());
	        dbo.execute();
	        System.out.println(dbo.getAssembledSQL());  
	        valA = dbo.getRecord(1).getInt("P8106"); 
	        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
	        dbo.addParameter("P8103", "B");//旅遊不便保險費
	        dbo.addParameter("WHERE", sql2.toString());
	        dbo.execute();
	        System.out.println(dbo.getAssembledSQL());  
	        valB = dbo.getRecord(1).getInt("P8106"); 
        }
        
        //旅遊醫療保險費
        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
        dbo.addParameter("P8103", "D");
        dbo.addParameter("WHERE", sql3.toString());
        dbo.execute();
        System.out.println(dbo.getAssembledSQL());
        p8101 = dbo.getRecord(1).getData("P8101").toString();//費率基準日
        
        hm.clear();
        count = dbo.getRecordCount();
        hm = new HashMap<String, Integer>(count);

        for (int i = 1; i <= count; i++) {
            record = dbo.getRecord(i);
            hm.put(record.getData("P8104"), new Integer(record.getInt("P8106")));
        }
        int[] t1829 = reAmount(hm, t1826); //醫療保費

        hm.clear();
        
        //海外突發疾病
        boolean isAddOHS = "true".equals(String.valueOf(travel.get("isAddOHS")));
        //有附加時
        if(isAddOHS){
	        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
	        dbo.addParameter("P8103", "E");//海突
	        dbo.addParameter("WHERE", sql2.toString());
	        dbo.execute();     	
	        System.out.println(dbo.getAssembledSQL());
	        
	        count = dbo.getRecordCount();
	        hm = new HashMap<String, Integer>(count);
	        
	        for (int i = 1; i <= count; i++) {
	            record = dbo.getRecord(i);
	            hm.put(record.getData("P8104"), new Integer(record.getInt("P8106")));
	        }
	    //無附加時
        }else{
        	//無資料時，以死殘列數新增map及陣列
        	hm = new HashMap<String, Integer>(len);
            if(t1909 == null){
            	t1909 = new String[len];
            	for (int i = 0; i < len; i++) {
    				t1909[i] = "0";
    			}
            }
        }
       
        int[] t1910 = reAmount(hm, t1909); //海突保費

        //公共交通工具保費計算
        dbo.addParameter("P8102", String.valueOf(travel.get("totalDays")));
        dbo.addParameter("P8103", "F");
        dbo.addParameter("WHERE", sql2.toString());
        dbo.execute();     	
        System.out.println(dbo.getAssembledSQL());

        count = dbo.getRecordCount();
        hm = new HashMap<String, Integer>(count);
        
        for (int i = 1; i <= count; i++) {
            record = dbo.getRecord(i);
            hm.put(record.getData("P8104"), new Integer(record.getInt("P8106")));
        }

        int[] t1910pub = reAmount(hm, t1909pub); //公交保費
        
        dbo.destroy();

        int t1539 = 0; //總應收保費
        int t1560 = 0; //主險保費
        int t1561 = 0; //附加險保費
        int[] charges = new int[len]; //個人總保費
        for (int i = 0; i < len; i++) {
        	charges[i] = t1828[i] + valA + valB + t1829[i] + t1910[i] + t1910pub[i];
            t1539 += charges[i];
            t1560 += (valA + valB + t1910[i] + t1910pub[i]);
        }

        t1561 = t1539 - t1560;

        form1.setAmount(charges);
        form1.setT1539(String.valueOf(t1539));
        form1.setAdd(isAdd);
        form1.setAddOHS(isAddOHS);
        
        form1.setP8101(p8101);
        form1.setTotalDays(String.valueOf(travel.get("totalDays")));
        form1.setT1632_A_per(String.valueOf(valA));
        form1.setT1632_B_per(String.valueOf(valB));
        form1.setT1828(Arrays.toString(t1828).split("[\\[\\]]")[1].split(", "));
        form1.setT1829(Arrays.toString(t1829).split("[\\[\\]]")[1].split(", "));
        form1.setT1909(Arrays.toString(t1909).split("[\\[\\]]")[1].split(", "));
        form1.setT1910(Arrays.toString(t1910).split("[\\[\\]]")[1].split(", "));
        form1.setT1909pub(Arrays.toString(t1909pub).split("[\\[\\]]")[1].split(", "));
        form1.setT1910pub(Arrays.toString(t1910pub).split("[\\[\\]]")[1].split(", "));

        travel.put("t1560", String.valueOf(t1560));
        travel.put("t1561", String.valueOf(t1561));
        travel.put("t1828", t1828);
        travel.put("t1829", t1829);
        travel.put("addValueA", String.valueOf(valA));//個責保費-固定式
        travel.put("addValueB", String.valueOf(valB));//遊遊不便保費-固定式
        travel.put("t1909", t1909);//海突保額
        travel.put("t1910", t1910);//海突保費
        travel.put("t1909pub", t1909pub);//公交保額
        travel.put("t1910pub", t1910pub);//公交保費

        return travel;
    }

    /**
     * 整理輸入資料
     * @param travel
     * @param form1
     * @param request
     * @return
     */
    private HashMap<String, Object> page5Action(HashMap<String, Object> travel, WB1M040f form1 , HttpServletRequest request) {
		
    	travel.put("entry", form1.getEntry());//要保投保區別
    	String channelCode = (form1.getEntry() != null && form1.getEntry().equals("2")) ? "40" : "41";//判斷給予通路別
    	travel.put("channel", channelCode);//通路別代號
    	
    	//travel.put("t15501", form1.getT15501()); //旅遊國家 
		travel.put("ta1501", form1.getTa1501()); //旅遊目的
		travel.put("ta1502", form1.getTa1502()); //交通工具
		travel.put("t15a8", form1.getT15a8()); //要保人年收入
		travel.put("ta1504", form1.getTa1504()); //服務單位
		travel.put("ta1505", form1.getTa1505()); //工作性質
		travel.put("ta1506o", form1.getTa1506o()); //收入來源-其他
		travel.put("t1546", form1.getT1546()); //要保人
		travel.put("t1547", form1.getT1547()); //身份證字號
		travel.put("t1509", form1.getT1509()); //性別
		travel.put("byear", form1.getByear()); //要保人出生年
		travel.put("bmonth", form1.getBmonth()); //要保人出生月
		travel.put("bdate", form1.getBdate()); //要保人出生日
		travel.put("birthDay", form1.getByear() + form1.getBmonth() + form1.getBdate()); //要保人出生年月日
		travel.put("t1515", form1.getT1515()); //行動電話
		travel.put("t1513", form1.getT1513()); //聯絡電話 H
		travel.put("t1514", form1.getT1514()); //聯絡電話 O
        travel.put("t3004", form1.getT3004()); //所在區域
        travel.put("t1512", form1.getT1512()); //通訊地址
        travel.put("t1516", form1.getT1516()); //Email
        travel.put("t1807", form1.getT1807()); //被保險人姓名
        travel.put("t1808", form1.getT1808()); //被保險人ID
        travel.put("t1813", form1.getT1813()); //受益人姓名
        travel.put("t1815", form1.getT1815()); //與受益人關係
        travel.put("t1822", form1.getT1822()); //與要保人關係
        travel.put("t1814", form1.getT1814()); //受益人ID
        travel.put("t1837", form1.getT1837()); //受益人生日
		travel.put("t1546A", form1.getT1546A()); //要保人英文姓名
		travel.put("t1547A", form1.getT1547A()); //要保人護照號碼
        travel.put("t1807A", form1.getT1807A()); //被保險人英文姓名
        travel.put("t1808A", form1.getT1808A()); //被保險人護照號碼
        
        String[] pf36 = new String[form1.getT1808().length];
        for (int i = 0; i < form1.getT1808().length; i++) {
			pf36[i] = getConvertRelation(form1.getT1822()[i]);//與要被保人關係
		}
        travel.put("pf36", pf36); //轉換被保人與要保人關係，for通報用
               
        //要保人收入來源
        String t1506 = "";
        String[] items = form1.getTa1506();
        String t1506desc = "";
        for(int i=0;i<items.length;i++)
        {
        	t1506 += items[i] + ",";
        	t1506desc += CodeUtil.getCodeDesc(this.getServlet(), request, "TA_INCOME", items[i]) + ",";
         }
        travel.put("ta1506", t1506.substring(0, t1506.length()-1));
        travel.put("ta1506o", form1.getTa1506o());
        travel.put("ta1506oDesc", t1506desc.substring(0, t1506desc.length()-1));//畫面顯示用
        
        travel.put("ta1507", form1.getT1515()); //要保人聯絡電話
        travel.put("ta1508", form1.getTa1508()); //被保險人年收入
        
        //被保險人收入來源
        String ta1509 = "";
        String ta1509desc = "";
        items = form1.getTa1509();
        for(int i=0;i<items.length;i++)
        {
        	ta1509 += items[i] + ",";
        	ta1509desc += CodeUtil.getCodeDesc(this.getServlet(), request, "TA_INCOME", items[i]) + ",";
        }
        travel.put("ta1509", ta1509.substring(0, ta1509.length()-1));
        travel.put("ta1509o", form1.getTa1509o());
        travel.put("ta1509oDesc", ta1509desc.substring(0, ta1509desc.length()-1));//畫面顯示用

        //被保險人交通工具
        String ta1510 = "";
        String ta1510desc = "";
        items = form1.getTa1510();
        for(int i=0;i<items.length;i++)
        {
        	ta1510 += items[i] + ",";   	
        	ta1510desc += CodeUtil.getCodeDesc(this.getServlet(), request, "TA_TRAFFIC", items[i]) + ",";
        }
        travel.put("ta1510", ta1510.substring(0, ta1510.length()-1));
        travel.put("ta1510o", form1.getTa1510o());
        travel.put("ta1510oDesc", ta1510desc.substring(0, ta1510desc.length()-1));//畫面顯示用
        
        travel.put("ta1511", form1.getTa1511()); //要保人評估職業
        travel.put("ta1512", form1.getTa1512()); //被保險人評估職業
        
        //投保目的
        String ta1513 = "";
        String ta1513desc = "";
        items = form1.getTa1513();
        for(int i=0;i<items.length;i++)
        {
        	ta1513 += items[i] + ",";    
        	ta1513desc += CodeUtil.getCodeDesc(this.getServlet(), request, "TA_PURPOSE", items[i]) + ",";
         }
        travel.put("ta1513", ta1513.substring(0, ta1513.length()-1));
        travel.put("ta1513o", form1.getTa1513o());  
        travel.put("ta1513oDesc", ta1513desc.substring(0, ta1513desc.length()-1));//畫面顯示用
        
        //是否投保其他商業險
        travel.put("ta1514", form1.getTa1514());
        travel.put("t1836", form1.getTa1514());

        //主要經濟者為要保人之
        String ta1515 = "";
        String ta1515desc = "";
        items = form1.getTa1515();
        for(int i=0;i<items.length;i++)
        {
        	ta1515 += items[i] + ",";    
        	ta1515desc += CodeUtil.getCodeDesc(this.getServlet(), request, "TA_FUNDING", items[i]) + ",";
         }
        travel.put("ta1515", ta1515.substring(0, ta1515.length()-1));
        travel.put("ta1515o", form1.getTa1515o());
        travel.put("ta1515oDesc", ta1515desc.substring(0, ta1515desc.length()-1));
        
        travel.put("ta1520", form1.getTa1520());
        travel.put("ta1521", form1.getTa1521());
        travel.put("ta1522", form1.getTa1522());
        
        String t1547 = form1.getT1547();//要保人id
        String t1546 = form1.getT1546();//要保人        
        String[] t1807 = (String[]) form1.getT1807(); //被保險人姓名
        String[] t1808 = (String[]) form1.getT1808(); //被保險人ID        
        String[] returnCode = new String[3];
        
        String[] t1813 = (String[]) form1.getT1813(); //受益人姓名
        String[] t1814 = (String[]) form1.getT1814(); //受益人ID
        String[] t1837 = (String[]) form1.getT1837(); //受益人生日
        
        String[] birthYear = (String[]) travel.get("birthYear");
        String[] birthMonth = (String[]) travel.get("birthMonth");
        String[] birthDate = (String[]) travel.get("birthDate");

        //檢核是否為法務管制名單
        try {
        	//檢核要保人資料
        	if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
        		if(isid_switch.equals("Y")){//是否啟用新版
    	            if(!checkFas24prc_new(t1546, t1547, form1.getByear() + form1.getBmonth() + form1.getBdate(),travel.get("KD17").toString()))
    	            {
    	            	returnCode[1] = "風險等級較高，請洽專員處理！";
    	            	returnCode[2] = t1546 + t1547;
    	            }else{
    	            	returnCode[2] = "Y";
    	            }
        		}else{
    	            if(!checkFas24prc(t1547, t1546))
    	            {
    	            	returnCode[1] = "風險等級較高，請洽專員處理！";
    	            	returnCode[2] = t1546 + t1547;
    	            }else{
    	            	returnCode[2] = "Y";
    	            }
        		}
        	}else{
        		returnCode[2] = "Y";
        	}
        	            
        	//檢核被保險人、受益人資料，如要保人已經有錯誤回傳則不再查詢
            if(returnCode[1] == null){
                for (int j = 0; j < t1808.length; j++) {

                	if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
                		if(isid_switch.equals("Y")){//是否啟用新版
    	                    //檢核被保險人id、姓名是否為法務管制名單
    	                    if(!checkFas24prc_new(t1807[j], t1808[j], birthYear[j] + birthMonth[j] + birthDate[j] ,travel.get("KD17").toString()))
    	                    {
    	                    	returnCode[1] = "風險等級較高，請洽專員處理！";
    	                    	returnCode[2] = t1807[j] + t1808[j];                	
    	                    	break;
    	                    }else{
    	                    	returnCode[2] = "Y";
    	                    }           
    	                    
    	                    //檢核受益人id、姓名是否為法務管制名單
    	                    String t1837j = (t1837[j] != null && !t1837[j].equals("")) ? t1837[j] : "0";
    	                    if(!checkFas24prc_new(t1813[j], t1814[j], t1837j,travel.get("KD17").toString()))
    	                    {
    	                    	returnCode[1] = "風險等級較高，請洽專員處理！";
    	                    	returnCode[2] = t1813[j] + t1814[j];                	
    	                    	break;
    	                    }else{
    	                    	returnCode[2] = "Y";
    	                    }           
                		}else{
                    		//檢核被保險人id、姓名是否為法務管制名單
    	                    if(!checkFas24prc(t1808[j], t1807[j]))
    	                    {
    	                    	returnCode[1] = "風險等級較高，請洽專員處理！";
    	                    	returnCode[2] = t1807[j] + t1808[j];                	
    	                    	break;
    	                    }else{
    	                    	returnCode[2] = "Y";
    	                    }           
    	                    
    	                    //檢核受益人id、姓名是否為法務管制名單
    	                    if(!checkFas24prc(t1814[j], t1813[j]))
    	                    {
    	                    	returnCode[1] = "風險等級較高，請洽專員處理！";
    	                    	returnCode[2] = t1813[j] + t1814[j];                	
    	                    	break;
    	                    }else{
    	                    	returnCode[2] = "Y";
    	                    }  
                		}
	                    
                	}else{
                		returnCode[2] = "Y";
                	}
                    
        		}
              
            }
            
		} catch (Exception e) {
            returnCode[0] = "ERROR";
            e.printStackTrace();
		}
        
        travel.put("AS400Status", returnCode);

        return travel;
    }

    private int[] reAmount(HashMap<String, Integer> hm, String[] cols) {
        int len = cols.length;
        int[] charges = new int[len];

        for (int i = 0; i < len; i++) {
            Integer tmp = (Integer) hm.get(cols[i] + "0000");
            int temp = 0;
            if (tmp != null) {
                temp = tmp.intValue();
            }
            charges[i] = temp;
        }

        return charges;
    }
    
    private int[] reAmount(HashMap<String, Integer> hm, String[] cols ,String[] year,String[] month,String[] day , String strdate) {
        int len = cols.length;
        int[] charges = new int[len];

        for (int i = 0; i < len; i++) {
        	Integer tmp;
        	if(getAgeByStrdate(year[i], month[i], day[i] , strdate)>14)
        		tmp = (Integer) hm.get(cols[i] + "0000");
        	else
        		tmp = (Integer) hm.get("14="+cols[i] + "0000");
            int temp = 0;
            if (tmp != null) {
                temp = tmp.intValue();
            }
            charges[i] = temp;
        }

        return charges;
    }

    /**
     * 取得商品設定，業務來源、招攬人等資料
     * @param travel
     * @param KD19
     * @return
     * @throws AsiException
     */
    private HashMap getKYCkd(HashMap travel , String KD19) throws AsiException {
    	
    	String KD03 = "TA"; //險種
    	String KD20 = (String) travel.get("channel");

    	Kyckd kd = new Kyckd();
    	kd.setKD01("TA");
    	kd.setKD02("O");
    	kd.setKD03(KD03);
    	kd.setKD19(KD19); //來源網站
    	kd.setKD20(KD20);
    	DBO dbo = kd.executeSelect(tx_controller);

    	String KD13 = dbo.getRecordData("KD13"); //專案代碼
    	String KD14 = dbo.getRecordData("KD14"); //方案代碼
    	String KD15 = dbo.getRecordData("KD15"); //承保地區
    	String KD16 = dbo.getRecordData("KD16"); //業務來源
    	String KD17 = dbo.getRecordData("KD17"); //招覽人

    	dbo.destroy();

    	travel.put("KD13", KD13);
    	travel.put("KD14", KD14);
    	travel.put("KD15", KD15);
    	travel.put("KD16", KD16);
    	travel.put("KD17", KD17);

    	return travel;
    }
    
    /**
     * 使用 AS/400 Procedure 檢查保額上限副程式(EPSU41C)，並取得回傳值
     * 
     * @param form1
     * @return
     * @throws Exception
     */
    private HashMap<String, Object> checkAmountLimit(HttpServletRequest request , HashMap<String, Object> travel, String KD19) throws AsiException {

        String remoteAddr = request.getRemoteAddr();

        String KD03 = "TA";
        String KD13 = travel.get("KD13").toString(); //專案代碼
        String KD16 = travel.get("KD16").toString(); //業務來源

        String dateBegin = (String) travel.get("dateBegin");
        String dateEnd = (String) travel.get("dateEnd");

        String[] t1808 = (String[]) travel.get("t1808"); //被保險人ID
        String[] birthYear = (String[]) travel.get("birthYear"); //被保險人出生年
        String[] birthMonth = (String[]) travel.get("birthMonth"); //被保險人出生月
        String[] birthDate = (String[]) travel.get("birthDate"); //被保險人出生日
        String[] t1825 = (String[]) travel.get("t1825"); //死殘保額
        String[] t1826 = (String[]) travel.get("t1826"); //醫療保額

        String[] returnCode = new String[3];
       
        FirstInsWebService fiws = null;
        String querySN = "";
        List queryResult = null;
        String[] insCmpCount = null;
        String[] insDeathAmountCount = null;
        boolean isMedicalAmount = false;//判斷是否有醫療限額保額
        
        int deadAmountLimit = Integer.parseInt(SystemParam.getParam("TA_UW_DEATH"));//旅平險核保原則-身故保額上限
        int deadAmountLimit_online = Integer.parseInt(SystemParam.getParam("TA_UW_DEATH_5"));//旅平險核保原則-身故保額-網路
        int insCompanys = Integer.parseInt(SystemParam.getParam("TA_UW_COMPANIES"));//旅平險核保原則-投保家數
        
        AS400Procedure as400 = new AS400Procedure();
        Connection as400Conn = null;
        try {
        	
            //local時不通報查詢
            if(remoteAddr.indexOf("127.0.0.1") == -1){
            	fiws = new FirstInsWebService();
                querySN = Number.getWSQueryCheckNo(servlet, request);//取得查詢序號
                queryResult = fiws.getInsManAll(t1808, querySN);//查詢通報系統
                fiws.doInsertKXCKD(t1808, querySN, dateBegin, dateEnd);//解析查詢內容並寫入匯總檔
            }

            insCmpCount = new String[t1808.length];
            insDeathAmountCount = new String[t1808.length];
            
            as400Conn = AS400Connection.getConnection();
            
            for (int i = 0; i < t1808.length; i++) {
                String birthDay = birthYear[i] + birthMonth[i] + birthDate[i];
                returnCode = as400.callEPSU41C(as400Conn, KD13, KD16, KD03, dateBegin, dateEnd, birthDay, t1808[i], "", t1825[i] + "0000", t1826[i] + "0000", "0");
                if ("ERROR".equals(returnCode[1]) || "N".equalsIgnoreCase(returnCode[2])) {
                	returnCode[1] = "保險期間內，投保金額超過上限，如有問題請洽專員處理！";
                	returnCode[2] = t1808[i];
                    break;
                }
                
                //法務管制名單查詢
            	if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
            		if(isid_switch.equals("Y")){//是否啟用新版
                        if(!checkFas24prc_new("",t1808[i],"0",travel.get("KD17").toString()))
    	                {
    	                	returnCode[1] = "因承保範圍需經審核或其他條件因素，無法提供線上投保服務，如有問題請洽專員處理！";
    	                	returnCode[2] = t1808[i];                	
    	                	break;
    	                }else{
    	                	returnCode[2] = "Y";
    	                }
                    }else{
                		if(!checkFas24prc(t1808[i], ""))
    	                {
    	                	returnCode[1] = "因承保範圍需經審核或其他條件因素，無法提供線上投保服務，如有問題請洽專員處理！";
    	                	returnCode[2] = t1808[i];                	
    	                	break;
    	                }else{
    	                	returnCode[2] = "Y";
    	                }
            		}            		
                }
                
                //local時不通報查詢
                if(remoteAddr.indexOf("127.0.0.1") == -1){
                	
                    //通報查詢結果是否回傳值為0
                    boolean isRtcodeOK = isVpnReturn(tx_controller, querySN);
                    
                    if(isRtcodeOK){
                        //查詢通報系統投保家數
                        int count = getInsCompanyOverLimit(tx_controller, querySN, t1808[i]);
                        insCmpCount[i] = String.valueOf(count);
                        
                        if( count > insCompanys ){//若大於投保家數，則不可投保
                        	returnCode[1] = "保險期間內，投保家數超過上限，如有問題請洽專員處理！";
                        	returnCode[2] = t1808[i];
                            break;
                        }else{
                        	returnCode[2] = "Y";
                        }

                        //查詢通報系統死殘保額 - 全部的
                        int amount = getInsAmountOverLoad(tx_controller, querySN, t1808[i], t1825[i]+ "0000" , "1");
                        insDeathAmountCount[i] = String.valueOf(amount);
                        
                        if(amount > deadAmountLimit){//死殘保險金額+旅平投保金額 若大於投保上限，則不可投保
                        	returnCode[1] = "保險期間內，投保金額超過上限，如有問題請洽專員處理！";
                        	returnCode[2] = t1808[i];
                            break;
                        }else{
                        	returnCode[2] = "Y";
                        }
     
                        //查詢通報系統死殘保額 - 網路投保類別的
                        int amount_online = getInsAmountOverLoad(tx_controller, querySN, t1808[i], t1825[i]+ "0000" , "2");
                        insDeathAmountCount[i] = String.valueOf(amount_online);
                        
                        if(amount > deadAmountLimit_online){//死殘保險金額+旅平投保金額 若大於投保上限，則不可投保
                        	returnCode[1] = "保險期間內，投保金額超過上限！";
                        	returnCode[2] = t1808[i];
                            break;
                        }else{
                        	returnCode[2] = "Y";
                        }

                        //查詢通報系統網路投保類的醫療保額
                        isMedicalAmount = checkMedicalAmount(tx_controller, querySN, t1808[i]);
                        if(isMedicalAmount){
                        	returnCode[1] = "保險期間內，網投投保旅平險醫療限額僅限1張！";
                        	returnCode[2] = t1808[i];
                            break;
                        }else{
                        	returnCode[2] = "Y";
                        }
                              
                    }else{
                    	returnCode[1] = "通報系統查詢有誤，請洽專員處理！";
                    	returnCode[2] = "";                	
                    	break;
                    }

                }else{
                	insCmpCount[i] = "0";
                	insDeathAmountCount[i] =  t1825[i]+ "0000";
                }
                          
                //檢核ID於本公司網路交易件是否有保期重疊件
                boolean isDateOverlap = isDateDuplicate(tx_controller, t1808[i], dateBegin, dateEnd);
                
                if(isDateOverlap){
                	returnCode[1] = "保險期間與其他交易重疊，請再確認，如有問題請洽專員處理！";
                	returnCode[2] = t1808[i];
                    break;
                }else{
                	returnCode[2] = "Y";
                }
                               
            }
        } catch (Exception e) {
            returnCode[0] = "ERROR";
            e.printStackTrace();
        } finally {
            AS400Connection.closeConnection(as400Conn);
        }
        
        travel.put("AS400Status", returnCode);
        travel.put("ta1518", querySN);//查詢序號
        travel.put("inscmps", insCmpCount);
        travel.put("insamounts", insDeathAmountCount);

        return travel;
    }

    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * @param id
     * @param name
     * @param birthday
     * @param agentno
     * @return
     * @throws AsiException
     */
    private boolean checkFas24prc_new(String name, String id , String birthday, String agentno) throws AsiException {

        /*
         * S24I0	1	文字	執行BRIDGER(ISID)方式(1/2/3)
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
         * S24I1A	1	文字	傳入小險別（ /V/T/Z）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
		 * S24I9	7	數字	傳入人員生日(民國年)
		 * S24IA	10	文字	傳入打單人員(AS400使用者帳號)
         * */

    	FAS24Input in = new FAS24Input();
    	in.setS24i0("1");
    	in.setS24i1("O");
    	in.setS24i1a("T");
    	in.setS24i2("1");
    	in.setS24i3("");
    	in.setS24i4("0");
    	in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
    	in.setS24i6(name);
    	in.setS24i7("");
    	in.setS24i8(id);
    	in.setS24i9(birthday);
        in.setS24ia(agentno);
    	FAS24PRC prc = new FAS24PRC();
    	FAS24Return out = prc.execute(in);
    	
		if("E".equals(out.getS24o1().trim()))
			return false;
		else
			return true;
    }

    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * @param id
     * @param name
     * @return
     * @throws AsiException
     */
    private boolean checkFas24prc(String id , String name) throws AsiException {

        /*
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
 		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
 		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
 		 * S24I4	2	文字	傳入賠付次數
 		 * S24I5	7,0	數字	傳入判別基準日
 		 * S24I6    120	文字	傳入人員姓名
 		 * S24I7	3	文字	傳入國家代碼
 		 * S24I8	30	文字	傳入人員ID
         * */

    	FAS24Input in = new FAS24Input();
    	in.setS24i1("O");
    	in.setS24i2("1");
    	in.setS24i3("");
    	in.setS24i4("0");
    	in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
    	in.setS24i6(name);
    	in.setS24i7("");
    	in.setS24i8(id);
    	FAS24PRC prc = new FAS24PRC();
    	FAS24Return out = prc.execute(in);
    	
		if("E".equals(out.getS24o1().trim()))
			return false;
		else
			return true;
    }

    /**
     * 查詢通報匯總資料， 查詢是否有網投醫療限額保額
     * @param tx_controller
     * @param querysn 	查詢序號
     * @param t1808		id
     * @return
     * @throws AsiException
     */
    private boolean checkMedicalAmount(TransactionControl tx_controller , String querysn, String t1808 ) throws AsiException 
    {
    	boolean count = false;
		Map ret = null;
		
		String sql = "SELECT * FROM KYCKXD WHERE KXD001=? AND KXD002=? AND KXD004='13'";

		String[] args = new String[2];
		args[0] = querysn;
		args[1] = t1808;

		QueryRunner runner = new QueryRunner();
		tx_controller.begin(0);
		
		int kxd06 = 0;
		try
		{
			ret = (Map) runner.query(tx_controller.getConnection(), sql, args, new TrimedMapHandler());
			if(ret != null&& !ret.isEmpty()){
				kxd06 = Integer.parseInt(ret.get("KXD06") != null ? ret.get("KXD06").toString() : "0");//網路投保醫療限額保額累計
			}
			
			if(kxd06 > 0)
				count = true;
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
    	
    	return count;
    }

    /**
     * 查詢通報資料，查詢通報匯總死殘保額
     * @param tx_controller
     * @param querysn 	查詢序號
     * @param t1808		id
     * @param t1825		投保死殘保額
     * @param t1825		類別  1：全部的 2：網路投保類別的
     * @return
     * @throws AsiException
     */
    private int getInsAmountOverLoad(TransactionControl tx_controller , String querysn, String t1808 , String t1825 ,String type) throws AsiException 
    {
    	int countAmout = 0;
		Map ret = null;
		
		String sql = "SELECT * FROM KYCKXD WHERE KXD001='" + querysn + "' AND KXD002='" + t1808 + "' AND KXD004='13'";
		
		QueryRunner runner = new QueryRunner();
		tx_controller.begin(0);
		try
		{
			ret = (Map) runner.query(tx_controller.getConnection(), sql, new TrimedMapHandler());
			
			//本次投保死殘保額 + 通報查詢匯總死殘保額
			if(type.equals("1"))//全部的
				countAmout = Integer.parseInt(t1825) + Integer.parseInt(ret.get("KXD02") != null ? ret.get("KXD02").toString() : "0");
			else if(type.equals("2"))//網路投保類別的
				countAmout = Integer.parseInt(t1825) + Integer.parseInt(ret.get("KXD05") != null ? ret.get("KXD05").toString() : "0");

		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
    	
    	return countAmout;
    }

    /**
     * 查詢通報資料， 查詢投保家數
     * @param tx_controller
     * @param querysn 	查詢序號
     * @param t1808		id
     * @return
     * @throws AsiException
     */
    private int getInsCompanyOverLimit(TransactionControl tx_controller , String querysn, String t1808 ) throws AsiException 
    {
    	int count = 0;
		Map ret = null;
		
		String sql = "SELECT * FROM KYCKXD WHERE KXD001=? AND KXD002=? AND KXD004='13'";

		String[] args = new String[2];
		args[0] = querysn;
		args[1] = t1808;


		QueryRunner runner = new QueryRunner();
		tx_controller.begin(0);
		try
		{
			ret = (Map) runner.query(tx_controller.getConnection(), sql, args, new TrimedMapHandler());
			count = Integer.parseInt(ret.get("KXD01") != null ? ret.get("KXD01").toString() : "");
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
    	
    	return count;
    }
   
    /**
     * 檢查回傳代碼是否為0，不為0一律表示有問題
     * @param tx_controller
     * @param querysn
     * @return
     * @throws AsiException
     */
    private boolean isVpnReturn(TransactionControl tx_controller , String querysn) throws AsiException 
    {
    	boolean result = false;
		Map ret = null;
		
		String sql = "SELECT * FROM KYCKXC WHERE KXC001='" + querysn + "'";
		
		QueryRunner runner = new QueryRunner();
		tx_controller.begin(0);
		try
		{
			ret = (Map) runner.query(tx_controller.getConnection(), sql, new TrimedMapHandler());
			String rtcode = ret.get("KXC006").toString();
			
			if(rtcode.equals("0"))
				result = true;
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
    	
    	return result;
    }

    /**
     * @param string
     * @param request
     * @return
     */
    private String getZip(String zip, HttpServletRequest request) {
        if (zip == null || zip.equals("")) {
            HttpSession session = request.getSession(false);
            DBO dbo = (DBO) session.getAttribute(KycGlobal.Kyc_UserInfo);
            return dbo.getRecordData("CA106");
        } else
            return zip;
    }


    private DBO selectSECAJ(String userID) throws AsiException {
        DBO dbo = (DBO) tx_controller.getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", userID);
        dbo.executeSelect();
        return dbo;
    }

    /**
     * 寫入KYCKLA
     * @param travel
     * @param seqnumT
     * @throws AsiException
     */
    private void insertPT15PF(HashMap<String, Object> travel, String seqnumT,HttpServletRequest request) throws AsiException {

    	String otp = KYCEncryptor.genOTP();//取OTP號碼
    	travel.put("otp", otp);
    	
        String t1547 = (String) travel.get("t1547");
        String[] t1807 = (String[]) travel.get("t1807");
        String[] t1808 = (String[]) travel.get("t1808");
        String[] birthYear = (String[]) travel.get("birthYear");
        String[] birthMonth = (String[]) travel.get("birthMonth");
        String[] birthDate = (String[]) travel.get("birthDate");
        String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        String[] t1822 = (String[]) travel.get("t1822");
        
        //啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
        tx_controller.begin(0);
        
        //目前流程只需寫入到交易LOG檔
        DBO dbo = tx_controller.getDBO("kyc.KYCKLAi01", 0);//type=2 表寫入交易LOG檔
        
        dbo.addParameter("T1501", seqnumT);
        dbo.addParameter("T1502", "TA");
        dbo.addParameter("T1503", "O");

        String sex = "";
        String nation = "";
        
        //被保險人
        int countp = t1807.length;
        String Usex = String.valueOf( t1808[0].charAt(1));   
        
        if(t1808[0].length() == 8){
        	sex = "";//性別
        	nation = "G";//身分類別(國籍)
        }else{
	        if (Usex.equals("1")){
	        	sex = "M";//性別
	        	nation = "A";//身分類別(國籍)
	        } else if (Usex.equals("2")) {
	        	sex = "F";//性別
	        	nation = "A";//身分類別(國籍)
	        } else if (Usex.equals("C")) {
	        	sex = "M";//性別
	        	nation = "C";//身分類別(國籍)
	        } else {
	        	sex = "F";//性別
	        	nation = "C";//身分類別(國籍)
	        }
        }
        
        String tarea = (String) travel.get("tarea");
        String t1536sub = "A";
        if(tarea.equals("1"))
        	t1536sub = "A";
        else if(tarea.equals("2"))
        	t1536sub = "B";
        else if(tarea.equals("3"))
        	t1536sub = "C";
        else if(tarea.equals("4"))
        	t1536sub = "D";
        
        
        dbo.addParameter("T1504", ""); //保單號碼
        dbo.addParameter("T1505", ""); //承保地區
        dbo.addParameter("T1506", t1807[0] + (countp > 1 ? "等"+String.valueOf(countp)+"人" : ""));
        dbo.addParameter("T1507", t1808[0]);
        dbo.addParameter("T1508", birthYear[0] + birthMonth[0] + birthDate[0]);
        dbo.addParameter("T1509", sex);        
        dbo.addParameter("T1511", (String) travel.get("t1511"));
        dbo.addParameter("T1512", (String) travel.get("t1512"));
        dbo.addParameter("T1513", (String) travel.get("t1513"));
        dbo.addParameter("T1514", (String) travel.get("t1514"));
        dbo.addParameter("T1515", (String) travel.get("t1515"));
        dbo.addParameter("T1516", (String) travel.get("t1516"));
        dbo.addParameter("T1517", (String) travel.get("dateBegin"));
        dbo.addParameter("T1518", (String) travel.get("dateEnd"));
        dbo.addParameter("T1519", (String) travel.get("KD16"));
        dbo.addParameter("T1520", (String) travel.get("KD17"));
        dbo.addParameter("T1523", sysDate);
        dbo.addParameter("T1530", "9");
        dbo.addParameter("T1531", ""); //信用卡別
        dbo.addParameter("T1532", ""); //信用卡號
        dbo.addParameter("T1533", ""); //信用卡有效年月
        dbo.addParameter("T1536", (String) travel.get("KD16") + t1536sub);
        dbo.addParameter("T1537", tarea);
        dbo.addParameter("T1538", "B2C");
        dbo.addParameter("T1539", (String) travel.get("t1539"));
        dbo.addParameter("T1541", (String) travel.get("t1539"));
        dbo.addParameter("T1544", nation);
        dbo.addParameter("T1546", (String) travel.get("t1546"));
        dbo.addParameter("T1547", t1547);
        dbo.addParameter("T1548", t1822[0]);
        dbo.addParameter("T1549", sysDate);
        dbo.addParameter("T1550", (String) travel.get("travelArea") + "(" + (String) travel.get("t15501")+ ")");
        dbo.addParameter("T1552", (String) travel.get("t1546"));//要保人
        dbo.addParameter("T1553", t1547);//要保人ID
        dbo.addParameter("T1554", (String) travel.get("birthDay"));//要保人出生年月日
        dbo.addParameter("T1555", (String) travel.get("t1548"));
        dbo.addParameter("T1556", (String) travel.get("hourFrom"));
        dbo.addParameter("T1557", (String) travel.get("hourFrom"));
        dbo.addParameter("T1560", (String) travel.get("t1560"));
        dbo.addParameter("T1561", (String) travel.get("t1561"));
        dbo.addParameter("T1572", (String) travel.get("sysHHMMSS"));
        dbo.addParameter("T1573", (String) travel.get("t1512"));
        dbo.addParameter("T1574", "Y"); //確認碼
        dbo.addParameter("T1577", "N"); //取消請款碼
 
        dbo.addParameter("T1580", "1"); //交易狀態碼 1-進入金流
        dbo.addParameter("T1596", sysDate);
        dbo.addParameter("T1597", t1547);
        dbo.addParameter("T1598", sysDate);
        dbo.addParameter("T1599", t1547);
        
        String expireTime = SystemParam.getParam("OTPEXTIME");
        String otpexpireday = getExpireDate();
        String INSARGNO = SystemParam.getParam("ARGDOC_INS_NO"); // 聲明事項文件編號
        boolean isnewclient = isClient_P(t1547);

        dbo.addParameter("T15B0", isnewclient ? "1" : "2");
        dbo.addParameter("T15B1", otp);
        dbo.addParameter("T15B2", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T15B3", DateUtil.getSysTime(false));
        dbo.addParameter("T15B4", otpexpireday);
        dbo.addParameter("T15B5", expireTime);
        dbo.addParameter("T15B6", "0");
        dbo.addParameter("T15B7", "0");
        dbo.addParameter("T15B8", "0");
        dbo.addParameter("T15B9", travel.get("entry").toString().equals("1") ? "NCCC" : "Hitrust");

        dbo.addParameter("T15C0", (String) travel.get("ismobile"));
        dbo.addParameter("T15C1", (String) travel.get("os"));
        dbo.addParameter("T15C2", (String) travel.get("browser"));
        dbo.addParameter("T15C3", (String) travel.get("bro_version"));
        dbo.addParameter("T15C9", INSARGNO);
        //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
        String remoteAddr =request.getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = request.getRemoteAddr();
        }        
        dbo.addParameter("T15C10", remoteAddr);
        dbo.addParameter("T15E0",remoteAddr);

        dbo.addParameter("T1594", DateUtil.getSysTime());
        dbo.addParameter("T1595", DateUtil.getSysTime());
        dbo.addParameter("TA1507", (String) travel.get("t1515"));//要保人聯絡電話
        dbo.addParameter("T15A7", (String) travel.get("birthDay"));//要保人生日
        int t15a8 = Integer.parseInt((String) travel.get("t15a8"));
        dbo.addParameter("T15A8", String.valueOf(t15a8 * 10000));//年收入        
        dbo.addParameter("TA1501", (String) travel.get("ta1501"));//旅遊目的
        dbo.addParameter("TA1502", (String) travel.get("ta1502"));//旅遊交通工具
        dbo.addParameter("TA1504", (String) travel.get("ta1504"));//服務單位
        dbo.addParameter("TA1505", (String) travel.get("ta1505"));//工作性質
        dbo.addParameter("TA1506", (String) travel.get("ta1506"));//收入來源
        dbo.addParameter("TA1506O", (String) travel.get("ta1506o"));//收入來源        
        int ta1508 = Integer.parseInt((String) travel.get("ta1508"));
        dbo.addParameter("TA1508", String.valueOf(ta1508 * 10000));//被保險人年收入
        dbo.addParameter("T15D9", String.valueOf(ta1508 * 10000));//被保險人年收入
        dbo.addParameter("TA1509", (String) travel.get("ta1509"));//被保險人收入來源
        dbo.addParameter("TA1509O", (String) travel.get("ta1509o"));//被保險人收入來源-其他
        dbo.addParameter("TA1510", (String) travel.get("ta1510"));//被保險人日常交通工具
        dbo.addParameter("TA1510O", (String) travel.get("ta1510o"));//被保險人日常交通工具-其他
        dbo.addParameter("TA1511", (String) travel.get("ta1511"));//要保人評估職業
        dbo.addParameter("TA1512", (String) travel.get("ta1512"));//被保險人評估職業
        dbo.addParameter("TA1513", (String) travel.get("ta1513"));//投保目的
        dbo.addParameter("TA1513O", (String) travel.get("ta1513o"));//投保目的-其他
        dbo.addParameter("TA1514", (String) travel.get("ta1514"));//是否投保其他商業險
        dbo.addParameter("TA1515", (String) travel.get("ta1515"));//主要經濟者為要保人之
        dbo.addParameter("TA1515O", (String) travel.get("ta1515o"));//主要經濟者為要保人之-其他
        
        dbo.addParameter("TA1520", (String) travel.get("ta1520"));//是否在其他保險公司投保旅平險
        dbo.addParameter("TA1521", (String) travel.get("ta1521") != null ? travel.get("ta1521").toString() : "0");//其他保險公司投保旅平險家數
        dbo.addParameter("TA1522", (String) travel.get("ta1522") != null ? travel.get("ta1522").toString() : "0");//其他保險公司投保旅平險保額
        
        dbo.addParameter("T1584", (String) travel.get("t1584"));//寫入促銷代碼
      
        //要保人
        Usex = String.valueOf( t1547.charAt(1));        
        
        if(t1547.length() == 8){
        	sex = "";//性別
        	nation = "G";//身分類別(國籍)
        }else{
            if (Usex.equals("1")){
            	sex = "M";//性別
            	nation = "A";//身分類別(國籍)
            } else if (Usex.equals("2")) {
            	sex = "F";//性別
            	nation = "A";//身分類別(國籍)
            } else if (Usex.equals("C")) {
            	sex = "M";//性別
            	nation = "C";//身分類別(國籍)
            } else {
            	sex = "F";//性別
            	nation = "C";//身分類別(國籍)
            }
        }
           
        dbo.addParameter("T15D0", nation);//要保人身份別
        dbo.addParameter("T15D1", sex);//要保人性別
        dbo.addParameter("T15D2", "B");//費率代號
        
        String t15d3 = (String) travel.get("t15d3");
        dbo.addParameter("T15D3", t15d3);//地區代號
        
        String t1546A = (String) travel.get("t1546A");
        String t1547A = (String) travel.get("t1547A");
        
        //要被保險人英文名字、護照號碼
        dbo.addParameter("T1506A", t1546A);
        dbo.addParameter("T1507A", t1547A);
        dbo.addParameter("T1546A", t1546A);
        dbo.addParameter("T1547A", t1547A);
        
        //電子保單選項
        String t1575 = (String) travel.get("t1575");    
        dbo.addParameter("T1575", t1575);
   		
        dbo.executeInsert();
        dbo.destroy();
    }

    /**
     * 寫入KYCKLB
     * @param travel
     * @param seqnumT
     * @throws AsiException
     */
    private void insertPT16PF(HashMap<String, Object> travel, String seqnumT) throws AsiException {

        //啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
        tx_controller.begin(0);
        
        //目前流程只需寫入到交易LOG檔
        DBO dbo = tx_controller.getDBO("kyc.KYCKLBt", 0); //寫入交易LOG檔

        String t1547 = (String) travel.get("t1547");
        String addValueA = (String) travel.get("addValueA");//個人責任保險費
        String addValueB = (String) travel.get("addValueB");//個人旅遊不便保險費
        String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        
        //人數
        String[] t1808 = (String[]) travel.get("t1808");
        int countt1808 = t1808.length;
        
        int amountA = Integer.parseInt(addValueA) * countt1808 ;
        int amountB = Integer.parseInt(addValueB) * countt1808 ;
        
        String tarea = (String) travel.get("tarea");
        
        //專案代號，依順為業務來源+ABCD，國內無專案代號
        String t1536sub = "A";
        if(tarea.equals("1"))
        	t1536sub = "";
        else if(tarea.equals("2"))
        	t1536sub = "B";
        else if(tarea.equals("3"))
        	t1536sub = "C";
        else if(tarea.equals("4"))
        	t1536sub = "D";

        //查詢EP27PF-意外險標的物預設值維護檔，並依其筆數逐一寫入PT16PF標的資料
        List ep27pf = getEp27pf(travel.get("KD16").toString() + t1536sub, "TA");                
        
        for (int i = 0; i < ep27pf.size(); i++) {			
        	
        	Map mp = (Map) ep27pf.get(i);
        	
        	String t1632 = "0";//保費
        	String t1635 = "0";//實收保費
        	
        	if(mp.get("P2711").toString().equals("TPL") && mp.get("P2706").toString().equals("1"))//標的01-個人旅遊責任保險，寫入保費
        	{
        		t1632 = String.valueOf(amountA);
        		t1635 = String.valueOf(amountA);
        	}else if(mp.get("P2711").toString().equals("TII") && mp.get("P2706").toString().equals("1"))//標的04-個人旅遊不便保險，寫入保費
        	{
        		t1632 = String.valueOf(amountB);
        		t1635 = String.valueOf(amountB);        		
        	}
        	
            doPT16PF(dbo, seqnumT, "TA", "O", mp.get("P2704").toString(), mp.get("P2710").toString(), mp.get("P2711").toString(), mp.get("P2705").toString(), mp.get("P2707").toString(), mp.get("P2708").toString(), t1632, t1635, sysDate, t1547, sysDate, t1547);
        	
		}
                              
        dbo.destroy();
    }

    private void doPT16PF(DBO dbo, String t1601, String t1602, String t1603, String t1604, String t1626, String t1627 , String t1628, String t1629, String t1630, String t1632, String t1635, String t1696,
            String t1697, String t1698, String t1699) throws AsiException {

        dbo.addParameter("T1601", t1601);
        dbo.addParameter("T1602", t1602);
        dbo.addParameter("T1603", t1603);
        dbo.addParameter("T1604", t1604);
        dbo.addParameter("T1626", t1626);
        dbo.addParameter("T1627", t1627);
        dbo.addParameter("T1628", t1628);
        dbo.addParameter("T1629", t1629);
        dbo.addParameter("T1630", t1630);
        dbo.addParameter("T1632", t1632);
        dbo.addParameter("T1635", t1635);
        dbo.addParameter("T1696", t1696);
        dbo.addParameter("T1697", t1697);
        dbo.addParameter("T1698", t1698);
        dbo.addParameter("T1699", t1699);
        dbo.executeInsert();
    }

    /**
     * 寫入KYCKLD
     * @param travel
     * @param seqnumT
     * @throws AsiException
     */
    private void insertPT18PF(HashMap<String, Object> travel, String seqnumT) throws AsiException {
        String t1547 = (String) travel.get("t1547");
        String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);

        String[] t1807 = (String[]) travel.get("t1807");
        String[] t1808 = (String[]) travel.get("t1808");
        String[] t1813 = (String[]) travel.get("t1813");
        String[] t1815 = (String[]) travel.get("t1815");
        String[] t1825 = (String[]) travel.get("t1825");
        String[] t1826 = (String[]) travel.get("t1826");
        String[] birthYear = (String[]) travel.get("birthYear");
        String[] birthMonth = (String[]) travel.get("birthMonth");
        String[] birthDate = (String[]) travel.get("birthDate");
        int amount = 0;
        int[] t1828 = (int[]) travel.get("t1828");
        int[] t1829 = (int[]) travel.get("t1829");
        String t1836 = (String) travel.get("t1836");
        String[] t1822 = (String[]) travel.get("t1822");
        String[] t1814 = (String[]) travel.get("t1814");
        String[] t1837 = (String[]) travel.get("t1837");
        String[] t1807A = (String[]) travel.get("t1807A");
        String[] t1808A = (String[]) travel.get("t1808A");
        
        //啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
        tx_controller.begin(0);
        
		//目前流程只需寫入到交易LOG檔
        DBO dbo = tx_controller.getDBO("kyc.KYCKLDt", 0); //寫入交易LOG檔

        int len = t1808.length;
        for (int i = 0; i < len; i++) {
        	
            String sex = "";
            String nation = "";
            //被保險人
            String Usex = String.valueOf( t1808[i].charAt(1));   
            
            if(t1808[i].length() == 8){
            	sex = "";//性別
            	nation = "G";//身分類別(國籍)
            }else{
    	        if (Usex.equals("1")){
    	        	sex = "M";//性別
    	        	nation = "A";//身分類別(國籍)
    	        } else if (Usex.equals("2")) {
    	        	sex = "F";//性別
    	        	nation = "A";//身分類別(國籍)
    	        } else if (Usex.equals("C")) {
    	        	sex = "M";//性別
    	        	nation = "C";//身分類別(國籍)
    	        } else {
    	        	sex = "F";//性別
    	        	nation = "C";//身分類別(國籍)
    	        }
            }

            dbo.addParameter("T1801", seqnumT);
            dbo.addParameter("T1802", "TA");
            dbo.addParameter("T1803", "O");
            dbo.addParameter("T1804", "TA");
            dbo.addParameter("T1805", "0");
            dbo.addParameter("T1806", String.valueOf(i + 1));
            dbo.addParameter("T1807", t1807[i]);
            dbo.addParameter("T1808", t1808[i]);
            dbo.addParameter("T1809", birthYear[i] + birthMonth[i] + birthDate[i]);
            dbo.addParameter("T1810", sex);//性別
            dbo.addParameter("T1811", (String) travel.get("dateBegin"));
            dbo.addParameter("T1812", (String) travel.get("dateEnd"));
            dbo.addParameter("T1813", t1813[i]);
            dbo.addParameter("T1815", t1815[i]);
            dbo.addParameter("T1822", t1822[i]);
            dbo.addParameter("T1824", "1");
            dbo.addParameter("T1825", t1825[i] + "0000");
            dbo.addParameter("T1826", t1826[i] + "0000");
            dbo.addParameter("T1828", String.valueOf(t1828[i])); //死殘
            dbo.addParameter("T1829", String.valueOf(t1829[i])); //醫療
            amount = t1828[i] + t1829[i]; //
            dbo.addParameter("T1831", String.valueOf(amount));
            dbo.addParameter("T1832", "000");
            dbo.addParameter("T1833", "0");
            dbo.addParameter("T1896", sysDate);
            dbo.addParameter("T1897", t1547);
            dbo.addParameter("T1898", sysDate);
            dbo.addParameter("T1899", t1547);
            dbo.addParameter("T1834", nation);//身份別
            dbo.addParameter("T1836", t1836);//投保他家MR註記，同KYCKLA.TA1514值
            dbo.addParameter("T1814", t1814[i]);//受益人ID
            dbo.addParameter("T1837", t1837[i]);//受益人生日
            dbo.addParameter("T1807A", t1807A != null ? t1807A[i] : "");//被保險人英文姓名
            dbo.addParameter("T1808A", t1808A != null ? t1808A[i] : "");//被保險人護照號碼
            
            dbo.executeInsert();
        }

        dbo.destroy();
    }
  
    private void insertPT19PF(HashMap<String, Object> travel, String seqnumT) throws AsiException {
      
        //啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
        tx_controller.begin(0);
        
		//目前流程只需寫入到交易LOG檔
        DBO dbo = tx_controller.getDBO("kyc.KYCKLEt", 0);
        
        String t1547 = (String) travel.get("t1547");//要保人id
        String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        
        String[] t1909 = (String[]) travel.get("t1909");//海突保額
        int[] t1910 = (int[]) travel.get("t1910");//海突保費
    	String[] t1808 = (String[]) travel.get("t1808");//被保險人id
    	int len = t1808.length;
    	String[] t1909pub = (String[]) travel.get("t1909pub");//公交保額
        int[] t1910pub = (int[]) travel.get("t1910pub");//公交保費

        boolean isAddOHS = "true".equals(String.valueOf(travel.get("isAddOHS")));
        
        //寫入海突
        if(isAddOHS){
	        for (int i = 0; i < len; i++) {
				
	            dbo.addParameter("T1901", seqnumT);
	            dbo.addParameter("T1902", "TA");
	            dbo.addParameter("T1903", "O");
	            dbo.addParameter("T1904", "TA");
	            dbo.addParameter("T1905", "0");
	            dbo.addParameter("T1906", String.valueOf(i + 1));
	            dbo.addParameter("T1907", "OHS");
	            dbo.addParameter("T1908", "A0");
	            dbo.addParameter("T1909", t1909[i]+ "0000");
	            dbo.addParameter("T1910", String.valueOf(t1910[i]));
	            dbo.addParameter("T1911", "");
	            dbo.addParameter("T1912", "0");
	            dbo.addParameter("T1913", "536301002211");
	            dbo.addParameter("T1914", "");
	            dbo.addParameter("T1915", "");
	            dbo.addParameter("T1916", "");
	            dbo.addParameter("T1917", "");
	            dbo.addParameter("T1996", sysDate);
	            dbo.addParameter("T1997", t1547);
	            dbo.addParameter("T1998", sysDate);
	            dbo.addParameter("T1999", t1547);
	            dbo.executeInsert();
	            
			}   
        }
        
    	//寫入公交，15歲以下不保，所以看每一人是否有保額才寫入
    	for (int i = 0; i < len; i++) {			
    		if(!t1909pub[i].equals("0")){
                dbo.addParameter("T1901", seqnumT);
                dbo.addParameter("T1902", "TA");
                dbo.addParameter("T1903", "O");
                dbo.addParameter("T1904", "TA");
                dbo.addParameter("T1905", "0");
                dbo.addParameter("T1906", String.valueOf(i + 1));
                dbo.addParameter("T1907", "PA67");
                dbo.addParameter("T1908", "C1");
                dbo.addParameter("T1909", t1909pub[i]+ "0000");
                dbo.addParameter("T1910", String.valueOf(t1910pub[i]));
                dbo.addParameter("T1911", "");
                dbo.addParameter("T1912", "0");
                dbo.addParameter("T1913", "");
                dbo.addParameter("T1914", "");
                dbo.addParameter("T1915", "");
                dbo.addParameter("T1916", "");
                dbo.addParameter("T1917", "");
                dbo.addParameter("T1996", sysDate);
                dbo.addParameter("T1997", t1547);
                dbo.addParameter("T1998", sysDate);
                dbo.addParameter("T1999", t1547);
                dbo.executeInsert();              
    		}
		}
    	
    	dbo.destroy();
    }   
    
    /**
     * 設定使用者資訊
     */
    private void setUserinfo() {
        if (tx_controller.getUserInfo() == null) {
            UserInfo ui = new UserInfo();
            ui.setInfo("USERID", "SYSTEM");
            ui.setDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setDateType(DateUtil.ChType);
            ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setFileDateType(DateUtil.ChType);
            tx_controller.setUserInfo(ui);
        }
    }

    /**
     * 重新將travel物件的資料放入form，供畫面的取用
     * @param travel
     * @param form1
     * @return
     * @throws AsiException
     */
    private WB1M040f reForm(HashMap<String, Object> travel, WB1M040f form1) throws AsiException {
        String userID = travel.get("t1547") != null ? (String) travel.get("t1547") : "";
        form1.setUID(userID);

        String pwd = travel.get("PWD") != null ? (String) travel.get("PWD") : "";
        if (pwd == null) {
            DBO dbo = selectSECAJ(userID);
            pwd = dbo.getRecordData("PASSWORD");
            dbo.destroy();

            form1.setPWD(pwd);
            travel.put("PWD", pwd);

        } else {
            form1.setPWD(pwd);
        }

        form1.setT1546((String) travel.get("t1546"));
        form1.setSeqnumT((String) travel.get("seqnumT"));
        form1.setHeadCount((String) travel.get("headCount"));
        form1.setT1539((String) travel.get("t1539"));
        form1.setC203("O");
        form1.setC204("OTA");
        if ("true".equals((String) travel.get("isNew"))) {
            form1.setNew(true);
        }
        
        form1.setEntry((String) travel.get("entry"));
        form1.setBirthYear((String[]) travel.get("birthYear"));
        form1.setBirthMonth((String[]) travel.get("birthMonth"));
        form1.setBirthDate((String[]) travel.get("birthDate"));
        form1.setT1825((String[]) travel.get("t1825"));
        form1.setT1826((String[]) travel.get("t1826"));
        form1.setAmount((int[]) travel.get("amount"));
        form1.setT1539((String) travel.get("t1539"));
        form1.setT1516((String) travel.get("t1516"));
        form1.setT1909((String[]) travel.get("t1909"));
        
        return form1;
    }

    /**
     * 組產生Report的路徑
     * @param servlet
     * @param request
     * @param url
     * @param tradeSeq
     * @param kindId
     * @param typeId
     * @return
     */
    public String getReportUrl(HttpServlet servlet, HttpServletRequest request, String url, String tradeSeq, String kindId, String typeId) 
    {
        String host = System.getProperty("jasper.report-host");
        String port = System.getProperty("jasper.report-port");
        String root = System.getProperty("jasper.report-root");
        String intra = System.getProperty("jasper.report-intra");

        if (host == null) {
            host = ConfigUtil.getConfig(servlet, "jasper.report-host");
        }
        if (port == null) {
            port = ConfigUtil.getConfig(servlet, "jasper.report-port");
        }
        if (port == null) {
            port = String.valueOf(request.getServerPort());
        }
        if (root == null) {
            root = ConfigUtil.getConfig(servlet, "jasper.report-root");
        }
        if (intra == null) {
            intra = ConfigUtil.getConfig(servlet, "jasper.report-intra");
        }
        
        StringBuffer buffer = new StringBuffer();
        //公司員工經由 kycap.firstins.com.tw 進入 KYC 時的report 路徑修改
        if ("kycapj.firstins.com.tw".equalsIgnoreCase(request.getServerName())) {
            buffer.append(intra);
        } else {
            buffer.append(host);
            buffer.append(":");
            buffer.append(port);
        }

        buffer.append(root);        
        buffer.append(url);
        buffer.append(".do");
        
        buffer.append("?tradeSeq=").append(tradeSeq);
        buffer.append("&kindId=").append(kindId);
        buffer.append("&typeId=").append(typeId);
        buffer.append("&nature=1");
        buffer.append("&dataId=").append(MD5Encode.encode(tradeSeq));

        return buffer.toString();
    }
    
    public String getInsContent(String headCount) {
        StringBuffer sb = new StringBuffer();
        sb.append("個人旅遊平安綜合保險 – 共 ").append(headCount).append(" 人投保 ");

        return sb.toString();
    }
    
    /**
     * 取得年齡
     * @param birthYear 出生年
     * @param birthMonth 出生月
     * @param birthDay 出生日
     * @return 
     */
    private int getAge(String birthYear,String birthMonth,String birthDay){
    	String sysdate = tx_controller.getSystemDate();
    	int sysYear = Integer.parseInt(sysdate.substring(0, sysdate.length()-4));
    	int sysMonth = Integer.parseInt(sysdate.substring(sysdate.length()-4, sysdate.length()-2));
    	int sysDay = Integer.parseInt(sysdate.substring(sysdate.length()-2, sysdate.length()));
    	
    	int age = sysYear - Integer.parseInt(birthYear);
    	if(sysMonth < Integer.parseInt(birthMonth) || (sysMonth==Integer.parseInt(birthMonth) && sysDay < Integer.parseInt(birthDay)))
    		age--;
    	return age;
    }

    /**
     * 以起保日計算取得年齡，先以實際年齡計算，大於15歲的以保險年齡計算
     * @param birthYear 出生年
     * @param birthMonth 出生月
     * @param birthDay 出生日
     * @param strdate 起保日
     * @return 
     */
    private int getAgeByStrdate(String birthYear,String birthMonth,String birthDay , String strdate){

    	int strYear = Integer.parseInt(strdate.substring(0, strdate.length()-4));
    	int strMonth = Integer.parseInt(strdate.substring(strdate.length()-4, strdate.length()-2));
    	int strDay = Integer.parseInt(strdate.substring(strdate.length()-2, strdate.length()));
    	
    	int age = strYear - Integer.parseInt(birthYear);
    	//先以實際年齡計算
    	if(strMonth < Integer.parseInt(birthMonth) || (strMonth==Integer.parseInt(birthMonth) && strDay < Integer.parseInt(birthDay)))
    		age--;
    	
    	//若大於15歲則以保險年齡重新計算
    	if(age >= 15){		
    		int dayscount = 0;
    		int currentmonth = strMonth;
    		
    		//先計算日期，不足從月借31日
        	if(strDay >= Integer.parseInt(birthDay)){
        		dayscount += strDay - Integer.parseInt(birthDay) ;
        	}
        	else{
        		dayscount += strDay + 31 - Integer.parseInt(birthDay) ;
        		currentmonth -- ;
        	}      
        	
        	//再計算月，不足從年借12月，同時年齡-1
    		if(currentmonth >= Integer.parseInt(birthMonth)){
    			dayscount += (currentmonth - Integer.parseInt(birthMonth)) * 31 ;
    		}else{
    			dayscount += (currentmonth + 12 - Integer.parseInt(birthMonth)) * 31 ;
    			age--;
    		}
    		//日數大於6個月180天則加1歲
        	if( dayscount > 180 )
        		age++;
    	}
    	
    	return age;
    }
    
 	/**
 	 * 寄發簡訊通知
 	 * @param name	姓名
 	 * @param otp	一次性密碼
 	 * @param cellphone手機
 	 */
 	public void sendMobileMsg(String name , String otp , String cellphone)
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		sb.append("第一產物交易OTP碼：").append(otp).append("\n");
 		sb.append("您正於第一產物進行網路投保作業");
 		sb.append("請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！若無線上作業請忽略此封簡訊，謝謝。");

 		String sendTel = cellphone;
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);
 			System.out.println("NWB1M0401-SendOTPError statuscode=" + statusCode + " " +getmethod.getResponseBodyAsString());

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

    
    /**
     * 寄送OTP EMAIL
     * @param request
     */
    public void sendOTPMail(HttpServletRequest request , String email , String name , String otp)
    {
    	int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
    	
 		//寄Email
 		KycMailUtil sender = new KycMailUtil();

 		//取範本
 		BufferedReader fr;
 		String path = getServlet().getServletContext().getRealPath("/mail/TransactionOTP_" + request.getLocale() + ".html");

 		StringBuffer linebf = new StringBuffer();
 		try {
 			fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
 			String line;
 			linebf = new StringBuffer();
 			line = fr.readLine();
 			while (line != null) {
 				linebf.append(line);
 				line = fr.readLine();
 			}
 		}
 		catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		catch (IOException e) {
 			e.printStackTrace();
 		}

	   	String msg = linebf.toString();
	   	msg = msg.replaceAll("\\{username\\}", name);
	   	msg = msg.replaceAll("\\{otp\\}", otp);
	   	msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));
	
	   	sender.setSubject("第一保 電子商務網 網路投保交易OTP");
	   	sender.setMessage(msg);
	   	sender.addTo(email);
	   	sender.sendMail();

   }
   
    
    /**
    * 查客戶id是否為傷害險有效保單客戶
    * @param id
    * @return
    */
   private boolean isClient_P(String id)
    {
   	boolean isNewclient = false;
   	
   		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
   		
 		String sql = "SELECT * FROM IC02PF WHERE C201=? AND C206 >= ? " + 
 		" AND C204 IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

		String[] args = new String[2];
		args[0] = id;
		args[1] = sysdate;

 		Connection con = AS400Connection.getConnection();
 		List<?> ret = null;
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List<?>) runner.query(con, sql, args, new TrimedMapListHandler());
 			
 			if(!ret.isEmpty() && ret.size()>0)
 				isNewclient = true;
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
 		
 		return isNewclient;
    }

   /**
    * 重新產生OTP,更新交易檔
    * @return
    * @throws AsiException
    */
   public boolean isUpdateOTP(HashMap<String, Object> travel) throws AsiException 
   {
	  boolean isok = false;
  	 
	  String getotp = KYCEncryptor.genOTP();
	  travel.put("otp", getotp);
	    	 
	  String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	  String systime = DateUtil.getSysTime();
	  String otpexpireday = getExpireDate();
  	 
	  String sql = "UPDATE KYCKLA SET T15B1=?,T15B2=?,T15B3=?,T15B4=?,T15B5=?,T1598=?,T1599=?,T15B8=0 WHERE T1501=?";
  	 
	  String args[] = new String[8];
	  args[0] = getotp;
	  args[1] = sysdate;
	  args[2] = systime;
	  args[3] = otpexpireday;
	  args[4] = SystemParam.getParam("OTPEXTIME");
	  args[5] = sysdate;
	  args[6] = travel.get("t1547").toString();
	  args[7] = travel.get("seqnumT").toString();

	  QueryRunner runner = new QueryRunner();
	  tx_controller.begin(0);

	  int ret = 0;
  	 
	  try 
	  {
		  Connection con = tx_controller.getConnection(0);
		  ret = runner.update(con, sql ,args);
		  if(ret > 0)
			  isok = true;
  		 
	  } catch (SQLException e) {
		  e.printStackTrace();
		  throw new AsiException(e.getLocalizedMessage());
	  } 

	  return isok;
	}

 	/**
 	 * 取得OTP過期日期
 	 * @return
 	 */
 	public String getExpireDate() {
		String expireday ="";
		KycDateUtil kycdate = new KycDateUtil();
		String sysdate = kycdate.getKycDate();
 	 
     try {
         
        kycdate.setKycDate(sysdate);
        kycdate.add(KycDateUtil.DATE, NumberUtils.toInt(SystemParam.getParam("OTPEXDAY")));//系統參數，系統日加天數
        expireday = kycdate.getKycDate();

     } 
     catch (ParseException e) {
        e.printStackTrace();
     }
     return expireday;
	}

 	/**
 	 * 確認otp是否正確
 	 * @return
 	 * @throws AsiException
 	 */
 	public boolean isRightOTP(HashMap<String, Object> travel , WB1M040f form1)throws AsiException
 	{
 		boolean isRight = false;
 		
 		String t1501=travel.get("seqnumT").toString();
 		
 		DBO dbo = tx_controller.getDBO("kyc.KYCKLAs03", 0);
 		dbo.addParameter("T1501", t1501);
 		dbo.executeSelect();

 		QueryRunner run = new QueryRunner();
		String sql;
		sql = "SELECT * FROM KYCKLA WHERE T1501 = ? AND ROWNUM = 1";		

		String[] args = new String[1];
		args[0] = t1501;
		
		Map<?, ?> ret = new HashMap<Object, Object>();
		try
		{
			tx_controller.begin(0);
			
			ret = (Map<?, ?>) run.query(tx_controller.getConnection(0),sql,args,new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}

 		String inputotp = form1.getInput_otp();
 		String orgotp = ret.get("T15B1").toString();
 		String expired = ret.get("T15B4").toString();
 		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
 		
 		if(Integer.parseInt(sysdate) <= Integer.parseInt(expired))
 				if(inputotp.equals(orgotp))
 					isRight = true;
 		
 		return isRight;
 	}


 	/**
 	 * 取得收件通報序號
 	 * @return
 	 */
 	private String getNotificationNo(){
		String result = "";//通報序號
		
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = AS400Connection.getConnection();
		AS400Procedure prc = new AS400Procedure();

		String s329i1 = "C";//資料來源
		String s329i2 = "99";//區域別
		String s329i3 = "99";//通路別

		try {
			result = prc.callEPSU329PRC(con, s329i1, s329i2, s329i3, sysdate);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			AS400Connection.closeConnection(con);
		}
		
		return result;
 	}


	/**
	 * 寫入承保通報記錄檔
	 * @param entry 要保/投保區別
	 * @param request
	 * @param t1504 保單號碼
	 * @param dbo1 主檔資料
	 * @param dbodetail 被保險人死殘/醫療明細
	 * @param dboOHS 被保險人海突明細
	 * @return
	 * @throws AsiException
	 */
	private boolean insertEPB500Files(String entry , HttpServletRequest request , String t1504 , DBO dbo1 , DBO dbodetail , DBO dboOHS) throws AsiException
	{
		boolean result = false;//寫檔結果
		Connection con = AS400Connection.getConnection();

		try {
	
			String pf03 = "";
			String pf04 = "";
			String pf05 = "";
			String pf06 = "";
			String pf07 = "";
			String pf11 = "";
			String pf12 = "";
			String pf16 = "";
			String pf27 = "";
			String pf28 = "";
			String pf29 = "";
			String pf32 = "";
			String pf33 = "";
			String pf34 = "";
			String pf35 = "";
			String pf36 = "";
			
			String isaddohs = dboOHS.getRecordCount() > 0 ? "Y" : "N";//由KYCKLE/PT19PF是否有資料，判斷是否附加海突
			int datasize = dbodetail.getRecordCount();//取得KYCKLD/PT18PF被保險人筆數，做為寫入筆數
			int totalinsertcount = isaddohs.equals("Y") ? datasize*2 : datasize;//如果有附加海突時，每人要加寫一筆，所以總筆數*2
			int insertCount = 0;
			
			for (int i = 1; i <= datasize; i++) // dbo recordcount 從1開始
			{
				pf03 = dbodetail.getRecordData(i, "T1807");//被保險人姓名
				pf04 = dbodetail.getRecordData(i, "T1808");//被保險人id
				pf05 = dbodetail.getRecordData(i, "T1809");//被保險人生日
				pf06 = getIdNationSex(pf04,true)[1];//被保險人性別
				pf07 = t1504;//保單號碼
				pf11 = dbodetail.getRecordData(i, "T1825");//死殘保額
				pf12 = dbodetail.getRecordData(i, "T1825");//死殘保額
				pf16 = dbodetail.getRecordData(i, "T1826");//傷害醫療限額
				
				pf27 = dbo1.getRecordData("T1517").toString();//保險起日
				pf28 = dbo1.getRecordData("T1518").toString();//保險迄日
				pf29 = dbodetail.getRecordData(i, "T1831");//明細保費，身故+醫療
				
				pf32 = WorkDay.getStrWorkDatebyDays("00", dbo1.getRecordData("T1523").toString(), true, String.valueOf(1)); ;//保單狀況生效日，用作帳日，用交易日的下一個工作日計算
				
				pf33 = dbo1.getRecordData("T1546").toString();//要保人
				pf34 = dbo1.getRecordData("T1547").toString();//要保人ID
				pf35 = dbo1.getRecordData("T1554").toString();//要保人生日

				String t1822 = dbodetail.getRecordData(i, "T1822");//與要保人關係
				pf36 = getConvertRelation(t1822);//與要被保人關係
											
				//每一被保險人，寫入檔案FGFLIB/EPB500PF							
				insertCount = insertCount + insertEPB500PF(entry, "N", "KYCB2C", request, con, pf03, pf04, pf05, pf06, pf07, pf11, pf12, pf16, pf27, pf28, pf29, pf32, pf33, pf34, pf35, pf36);
				
				//有海突時加寫一筆
				if(isaddohs.equals("Y")){
					pf11 = "0";
					pf12 = "0";
					pf16 = dboOHS.getRecordData(i, "T1909");//醫療限額，海突保額
					pf29 = dboOHS.getRecordData(i, "T1910");//明細保費，海突保費
					insertCount = insertCount + insertEPB500PF(entry, "Y", "KYCB2C", request, con, pf03, pf04, pf05, pf06, pf07, pf11, pf12, pf16, pf27, pf28, pf29, pf32, pf33, pf34, pf35, pf36);
				}
				
			}
			
			//新增筆數與查詢總筆數不同時，刪除承保通報資料
			if(insertCount != totalinsertcount )
			{
				//清除未新增完整資料筆數
				deleteEPB500PF(con, t1504);
			}else{
				result = true;
			}
					
		} catch (Exception e) {
			//錯誤時直接刪除400資料
			deleteEPB500PF(con, t1504);
			e.printStackTrace();
		} finally{
			AS400Connection.closeConnection(con);
		}

		return result;
	}

 	
	/**
	 * 寫入收件通報主檔/明細檔
	 * @param request
	 * @param insno 受理編號
	 * @param dbo1 主檔資料
	 * @param dbodetail明細檔資料
	 * @param pf01 通報序號
	 * @return 是否成功
	 * @throws AsiException
	 */
	private boolean insertEPB501Files(String entry , HttpServletRequest request , String insno , DBO dbo1 , DBO dbodetail , String pf01) throws AsiException
	{
		boolean result = false;//寫檔結果
		Connection con = AS400Connection.getConnection();

		try {
			
			String pf04 = getT4003(con, dbo1.getRecordData("T1519"));
			String pf05 = "";
			String pf06 = dbo1.getRecordData("T1523").toString();//要保日／收件日
			String pf07 = dbo1.getRecordData("T1518").toString();//到期日
			String pf08 = dbo1.getRecordData("T1546").toString();//要保人
			String pf09 = dbo1.getRecordData("T1547").toString();//要保人ID
			
			String pf10 = getIdNationSex(pf09,false)[0];//要保人身份
			String pf11 = getIdNationSex(pf09,false)[1];//要保人性別
			String pf12 = dbo1.getRecordData("T1554").toString();//要保人生日
		
			String pf19 = "3";//類別：1 個傷 2 團傷 3 旅平 4 健康 5 微型
			String pf20 = "01";//保單狀況：01: 有效 ,06: 契約撤銷 ,12: 鍵值欄位通報錯誤 ,15: 通報更正
			String pf23 = "C";//"A": 保經代自建系統 "B": 關貿 "C": 本公司 WEB  "D": AS/400 "E": KYC
			String pf24 = "";//保經代分類

			String pf13 = dbodetail.getRecordData(1, "T1807").toString();//被保險人姓名
			String pf14 = dbodetail.getRecordData(1, "T1808").toString();//被保險人身份證號
			String pf15 = getIdNationSex(pf14,false)[0];//被保險人身份
			String pf16 = dbodetail.getRecordData(1, "T1809").toString();//被保險人出生日期
			String pf17 = getIdNationSex(pf14,false)[1];//被保險人性別
			
			String t1548 = dbo1.getRecordData("T1548").toString();//要被保人關係
			String pf18 = getConvertRelation(t1548);//要被保人關係
						
			String pf21 = insno;//受理編號，用交易序號
			
			int insertCount = 0;
			//寫入檔案FGFLIB/EPB501PF(傷健險收件通報作業主檔)
			insertCount = insertCount + insertEPB501PF(entry, pf09, request, con, pf01, pf04, pf05, pf06, pf07, pf08, pf09, pf10, pf11, pf12, pf13, pf14, pf15, pf16, pf17, pf18, pf19, pf20, pf21, pf23, pf24);

			String pf205 = "";
			String pf206 = "";
			String pf207 = "";
			String pf208 = "";
			String pf209 = "";
			String pf210 = "0";//死殘保額
			String pf211 = "0";//傷害醫療限額
			String pf212 = "0";//傷害住院日額
			String pf213 = "0";//重大疾病保額
			String pf214 = "0";//住院醫療保額
			String pf215 = "0";//健康住院日額
			String pf216 = "0";//防癌保額
			String pf217 = "";//保單號碼
			
			int datasize = dbodetail.getRecordCount();
			for (int i = 1; i <= datasize; i++) // dbo recordcount 從1開始
			{
				pf205 = dbodetail.getRecordData(i, "T1807");//被保險人姓名
				pf206 = dbodetail.getRecordData(i, "T1808");//被保險人id
				pf207 = getIdNationSex(pf206,false)[0];//被保險人身份
				pf208 = dbodetail.getRecordData(i, "T1809");//被保險人生日
				pf209 = getIdNationSex(pf206,false)[1];//被保險人性別
				pf210 = dbodetail.getRecordData(i, "T1825");//死殘保額
				pf211 = dbodetail.getRecordData(i, "T1826");//傷害醫療限額
				
				//寫入檔案FGFLIB/EPB502PF(傷健險收件通報作業明細檔)
				insertCount = insertCount + insertEPB502PF(pf09, request, con, pf01, String.valueOf(i), pf205, pf206, pf207, pf208, pf209, pf210, pf211, pf212, pf213, pf214, pf215, pf216, pf217);
			}
			
			//新增筆數與查詢總筆數不同時，刪除收件通報資料，並傳出空白收件序號
			if(insertCount != (datasize + 1))
			{
				//清除未新增完整資料筆數
				deleteEPB501PF(con, pf01);
				deleteEPB502PF(con, pf01);
			}else{
				result = true;
			}
					
		} catch (Exception e) {
			//錯誤時直接刪除400資料
			deleteEPB501PF(con, pf01);
			deleteEPB502PF(con, pf01);
			e.printStackTrace();
		} finally{
			AS400Connection.closeConnection(con);
		}

		return result;
	}

	/**
	 * 傳入id取得本國外國籍代號、性別英文代號
	 * @param id
	 * @param isforTransfer 是否傳輸用，性別代號為1,2
	 * @return [0]：本國外國籍代號 [1]：性別英文代號
	 */
	public String[] getIdNationSex(String id , boolean isforTransfer){
		String[] result = new String[2];
		
		if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
			result[0] = "C";//外國人							
		else
			result[0] = "A";//本國人
			
		if("BD2".indexOf(id.substring(1, 2)) != -1)
			result[1] ="F";//女性
		else
			result[1] ="M";//男性

		//如果要傳外部用的，如寫入EPB500PF時
		if(isforTransfer){
			if("BD2".indexOf(id.substring(1, 2)) != -1)
				result[1] ="2";//女性
			else
				result[1] ="1";//男性			
		}
		
		return result;
	}

	
	/**
	 * 取得通路代碼
	 * @param con
	 * @param t4002
	 * @return
	 * @throws AsiException
	 */
	private String getT4003(Connection con , String t4002) throws AsiException
	{

		String t3905 = null;
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4001= 'E' AND T4002 = ? ";

		QueryRunner run = new QueryRunner();
		Map m = null;
		try
		{
			m = (Map) run.query(con , t4003sql, t4002, new MapHandler());
			t3905 = m.get("T4003").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		if(t3905==null)
			throw new AsiException("無法取得通路類別!");
		
		return t3905;	
	}
	
	/**
	 * 新增-傷健險收件通報作業主檔-EPB501PF
	 * @param entry 要保/投保區別
	 * @param crtuid 建立人員
	 * @param request
	 * @param con 連線
	 * @return
	 */
	public int insertEPB501PF(String entry,String crtuid,HttpServletRequest request,Connection con,String pf01,String pf04,String pf05,String pf06,String pf07,String pf08,String pf09,String pf10,String pf11
			,String pf12,String pf13,String pf14,String pf15,String pf16,String pf17,String pf18,String pf19,String pf20,String pf21,String pf23,String pf24)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = "INSERT INTO EPB501PF( "
			+"PF01,PF02,PF03,PF04,PF05,PF06,PF07,PF08,PF09,PF10 "
			+",PF11,PF12,PF13,PF14,PF15,PF16,PF17,PF18,PF19,PF20 "
			+",PF21,PF22,PF23,PF24,PF70,PF71,PF72,PF73,PF74,PF75"
			+",PF90,PF91,PF92,PF94,PF95,PF96,PF97,PF98,PF99)VALUES"
			+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String[] param = new String[39];
		param[0] = pf01;//收件通報序號
		param[1] = "01";//次數
		param[2] = "";//保經代公司代碼
		param[3] = pf04;//通路代號
		param[4] = pf05;//商品／專案代號
		param[5] = pf06;//要保日／收件日
		param[6] = pf07;
		param[7] = pf08;
		param[8] = pf09;
		param[9] = pf10;
		param[10] = pf11;
		param[11] = pf12;
		param[12] = pf13;
		param[13] = pf14;
		param[14] = pf15;//被保人身份別
		param[15] = pf16;//被保險人出生日期
		param[16] = pf17;//被保險人性別
		param[17] = pf18;//要／被保人關係
		param[18] = pf19;//類別 1 個傷 2 團傷 3 旅平 4 健康 5 微型
		param[19] = pf20;//保單狀況,01: 有效 ,06: 契約撤銷 ,12: 鍵值欄位通報錯誤 ,15: 通報更正
		param[20] = pf21;//受理編號
		param[21] = "NTD";//幣別
		param[22] = pf23;//來源,A: 保經代自建系統,B: 關貿,C: 本公司 WEB,D: AS/400,E: KYC
		param[23] = pf24;//保經代分類,97: 保險公司代通報,98: 保經代健康險 ( 補傷害醫療及健康險 ),99: 保經代壽險與傷害險 ( 自行通報件 )
		param[24] = entry.equals("1") ? sysdate : "0";//通報日期：網投時，直接寫入時期；網要時0
		param[25] = entry.equals("1") ? systime : "0";//通報時間：網投時，直接寫入時間；網要時0
		param[26] = "KYCB2C";//通報人員
		param[27] = "";//KYC 通報檔名
		param[28] = "NB";//類型
		param[29] = "";//保單號碼
		param[30] = entry.equals("1") ? sysdate : "0";//轉檔日期：網投時，直接寫入時期；網要時0
		param[31] = entry.equals("1") ? systime : "0";//轉檔時間：網投時，直接寫入時間；網要時0
		param[32] = "";//轉檔人員
		param[33] = systime;
		param[34] = systime;
		param[35] = sysdate;
		param[36] = crtuid;
		param[37] = sysdate;
		param[38] = crtuid;
		
		int ret =0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, param);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	/**
	 * 刪除-傷健險收件通報作業主檔資料檔-EPB501PF
	 * @param con
	 * @param pf01 收件通報序號
	 * @return
	 */
	public int deleteEPB501PF(Connection con,String pf01)
	{
		int ret = 0;
		String sql = "DELETE FROM EPB501PF WHERE PF01=?";
		
		QueryRunner runner = new QueryRunner();
		try
		{
			ret = runner.update(con, sql, pf01);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 新增-傷健險收件通報作業明細資料檔-EPB502PF
	 * @param crtuid 建立人員
	 * @param request
	 * @param con 連線
	 * @return 寫入筆數
	 */
	public int insertEPB502PF(String crtuid , HttpServletRequest request , Connection con,String pf201,String pf204,String pf205,String pf206,String pf207,String pf208,String pf209,String pf210
			,String pf211,String pf212,String pf213,String pf214,String pf215,String pf216,String pf217)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = "INSERT INTO EPB502PF( "
			+"PF201,PF202,PF203,PF204,PF205,PF206,PF207,PF208,PF209,PF210 "
			+",PF211,PF212,PF213,PF214,PF215,PF216,PF217 "
			+",PF294,PF295,PF296,PF297,PF298,PF299) "
			+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String[] param = new String[23];
		param[0] = pf201;//收件通報序號
		param[1] = "01";//次數
		param[2] = "0";//組別
		param[3] = pf204;//編號
		param[4] = pf205;//被保險人姓名
		param[5] = pf206;//被保險人身份證號
		param[6] = pf207;//被保險人身份
		param[7] = pf208;//被保險人出生日期
		param[8] = pf209;//被保險人性別
		param[9] = pf210;//死殘保額
		param[10] = pf211;//傷害醫療限額
		param[11] = pf212;//傷害住院日額
		param[12] = pf213;//重大疾病保額
		param[13] = pf214;//住院醫療保額
		param[14] = pf215;//健康住院日額
		param[15] = pf216;//防癌保額
		param[16] = pf217;//保單號碼
		param[17] = systime;
		param[18] = systime;
		param[19] = sysdate;
		param[20] = crtuid;
		param[21] = sysdate;
		param[22] = crtuid;
		
		int ret =0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, param);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	/**
	 * 刪除傷健險收件通報作業明細資料檔-EPB502PF
	 * @param con 連線
	 * @param pf201 收件通報序號
	 * @return
	 */
	public int deleteEPB502PF(Connection con,String pf201)
	{
		int ret = 0;
		String sql = "DELETE FROM EPB502PF WHERE PF201=?";
		
		QueryRunner runner = new QueryRunner();
		try
		{
			ret = runner.update(con, sql, pf201);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 新增-傷健險承保通報作業轉檔歷史檔-EPB500PF
	 * @param entry 要保/投保區別
	 * @param isaddohs 是否要寫海突
	 * @param crtuid 建立人員
	 * @param request
	 * @param con 連線
	 * @return 寫入筆數
	 */
	public int insertEPB500PF(String entry,String isaddohs,String crtuid,HttpServletRequest request,Connection con,
			String pf03,String pf04,String pf05,String pf06,String pf07,String pf11,String pf12,String pf16,String pf27,String pf28,
			String pf29,String pf32,String pf33,String pf34,String pf35,String pf36)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		
		String sql = "INSERT INTO EPB500PF ( "
				+ "PF01,PF02,PF03,PF04,PF05,PF06,PF07,PF08,PF09,PF10,"
				+ "PF11,PF12,PF13,PF14,PF15,PF16,PF17,PF18,PF19,PF20,"
				+ "PF21,PF22,PF23,PF24,PF25,PF26,PF27,PF28,PF29,PF30,"
				+ "PF31,PF32,PF33,PF34,PF35,PF36,PNOA,PNOB,PF98,PF99,PF96) VALUES"
				+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String[] param = new String[41];
		param[0] = "N";//N：產險業之承保通報資料。
		param[1] = "10";//公司代號
		param[2] = pf03;//被保險人姓名
		param[3] = pf04;//被保險人身份證號
		param[4] = pf05;//被保險人出生日期
		param[5] = pf06;//被保險人性別
		param[6] = pf07;//保單號碼
		param[7] = entry.equals("1") ? "5" : "1" ;//保單分類-要保1；投保5
		param[8] = isaddohs.equals("Y") ? "3" : "2";//險種分類-固定2，若有海突要+1筆，送3(健康保險)
		param[9] = "13";//險種-旅平險固定13
		param[10] = pf11;//身故
		param[11] = pf12;//全殘或最高級殘
		param[12] = "0";//殘廢扶助金
		param[13] = "0";//特定事故
		param[14] = "0";//初次罹患
		param[15] = pf16;//醫療限額
		param[16] = "0";//醫療限額自負額
		param[17] = "0";//日額
		param[18] = "0";//住院手術
		param[19] = "0";//門診手術
		param[20] = "0";//門診
		param[21] = "0";//重大疾病
		param[22] = "0";//重大燒燙傷
		param[23] = "0";//癌症療養
		param[24] = "0";//出院療養
		param[25] = "0";//失能
		param[26] = pf27;//契約生效日期
		param[27] = pf28;//契約滿期日期
		param[28] = pf29;//保費：一般意外事故保費(身故或殘廢保費+傷害醫療實支實付型保費) 不含旅遊不便(T1831)、海突(T1910)
		param[29] = "2";//保費繳別-1：躉繳 2：年繳
		param[30] = "01";//保單狀況：保單請填01有效
		param[31] = pf32;//保單狀況生效日：請填保單作帳日期
		param[32] = pf33;//要保人姓名
		param[33] = pf34;//要保人身分證號
		param[34] = pf35;//要保人出生日期
		param[35] = pf36;//要／被保人關係
		param[36] = pf07;//保單號碼
		param[37] = "";//批單號碼
		param[38] = sysdate;//轉檔日期
		param[39] = crtuid;//轉檔人員
		param[40] = "0";//賠案輸入日期
		
		int ret =0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, param);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	/**
	 * 刪除傷健險承保通報作業轉檔歷史檔
	 * @param con 連線
	 * @param pf07 保單號碼
	 * @return
	 */
	public int deleteEPB500PF(Connection con,String pf07)
	{
		int ret = 0;
		String sql = "DELETE FROM EPB500PF WHERE PF07=?";
		
		QueryRunner runner = new QueryRunner();
		try
		{
			ret = runner.update(con, sql, pf07);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 更新交易狀態
	 * @param request
	 * @param number
	 * @param orderstate 交易狀態KL80
	 * @throws AsiException
	 */
	private void updateKYCKLA_TA1516(HttpServletRequest request, String number, String TA1516, String TA1517, String TA1518, String TA1519) throws AsiException
	{
		DBO upd = tx_controller.getDBO("kyc.KYCKLAu08",0);
		upd.addParameter("TA1516",TA1516);
		upd.addParameter("TA1517",TA1517);
		upd.addParameter("TA1518",TA1518);
		upd.addParameter("TA1519",TA1519);
		upd.addParameter("T1501", number);
		upd.execute();

	}

	/**
	 * 查詢意外險標的物預設值維護檔，用以寫入KYCKLB/PT16PF標的資料用
	 * @param p2701
	 * @param p2702
	 * @return
	 */
	private List getEp27pf(String p2701 , String p2702){
		
		List ret = null;
		
 		String sql = "SELECT * FROM EP27PF WHERE P2701='" + p2701 + "' AND P2702='" + p2702 + "' ORDER BY P2703"; 
 		
 		Connection con = AS400Connection.getConnection();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List) runner.query(con, sql.toString(), new TrimedMapListHandler());
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

		return ret;
	}
	

	/**
	 * 更新交易狀態
	 * @param request
	 * @param number
	 * @param orderstate 交易狀態KL80
	 * @throws AsiException
	 */
	private void updatePT15PF_TA1516(HttpServletRequest request, String number, String TA1516, String TA1517, String TA1518, String TA1519) throws AsiException
	{
		DBO upd = tx_controller.getDBO("kyc.PT15PFu08",0);
		upd.addParameter("TA1516",TA1516);
		upd.addParameter("TA1517",TA1517);
		upd.addParameter("TA1518",TA1518);
		upd.addParameter("TA1519",TA1519);
		upd.addParameter("T1501", number);
		upd.execute();

	}

	
	
	/**
	 * @param request
	 * @param number 保單號碼
	 * @param kyckla 
	 * @throws AsiException
	 */
	private void updatePnumber(HttpServletRequest request, String number, DBO kyckla) throws AsiException
	{
        kyckla.addParameter("T1501", number);
        kyckla.executeSelect();
        
        String pNumber = null;
		if(kyckla.getRecordData("T1503").equals("F"))
		{
			//是否同意自動續保，保單號碼由 由60001開始編,ex.100003RCY60001,1000區域別、03年度、RCY類別、600001序號
			if("Y".equals(kyckla.getRecordData("T15A9")))
				pNumber = Number.getNumber_F_RE(servlet, request);
			else
				pNumber = Number.getNumber_F(getServlet(), request, "P");
			
			DBO updKLA = tx_controller.getDBO("kyc.KYCKLAu05", 0);
			updKLA.addParameter("T1501", number);
			updKLA.addParameter("T1504", pNumber);
			updKLA.execute();
            
            kyckla.addRecordData("T1504", pNumber);
		}
		else if(kyckla.getRecordData("T1503").equals("O"))
		{
			if(kyckla.getRecordData("T1502").equals("TA"))//旅平
				pNumber = Number.getNumber_O("TA",getServlet(), request, "P");
			else if(kyckla.getRecordData("T1502").equals("PA600"))//傷害
				pNumber = Number.getNumber_O("IP",getServlet(), request, "P");
			else if(kyckla.getRecordData("T1502").equals("PA1000"))//傷害
				pNumber = Number.getNumber_O("IP2",getServlet(), request, "P");
			
			DBO updKLA = tx_controller.getDBO("kyc.KYCKLAu05", 0);
			updKLA.addParameter("T1501", number);
			updKLA.addParameter("T1504", pNumber);
			updKLA.execute();
            
            kyckla.addRecordData("T1504", pNumber);

		}
	}

	
	/**
	 * 更新交易狀態
	 * @param request
	 * @param number
	 * @param orderstate 交易狀態KL80
	 * @throws AsiException
	 */
	private void update80(String uid, String number, String orderstate) throws AsiException
	{
		DBO upd = tx_controller.getDBO("kyc.KYCKLAu04",0);
		upd.addParameter("T1580", orderstate);
		upd.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false));
		upd.addParameter("T1599", uid);
		upd.addParameter("T1501", number);
		upd.execute();
	}

	/**
	 * 轉換關係代碼
	 * @param code
	 * @return
	 */
	private String getConvertRelation(String code)
	{	
		//代碼	說明                      			網投啟用	通報欄位PF18對應
		//0		本人                       			v			01 本人
		//1		法定繼承人                 		x			
		//2		配偶                       			v			02 配偶
		//3		父子 ( 女 ). 母子 ( 女 )  	v			03 父母
		//4		祖孫 ( 女 ). 外祖孫 ( 女 )	v			05 其他
		//5		兄弟姊妹                   			v			05 其他
		//6		僱傭                       			x			
		//7		債務                       			x			
		//8		管理財產或利益             		x			
		//9		其他                       			x			
		//A		子女                       			v			04 子女
		//B		父母                       			v			03 父母
		//C		翁婿(配偶父母)			v			05 其他
		//D		婆媳                     			v			05 其他

		String relation = "";
		
		if(code.equals("0"))
			relation = "01";//本人
		else if(code.equals("2"))
			relation = "02";//配偶
		else if(code.equals("3") || code.equals("B"))
			relation = "03";//父母
		else if(code.equals("A"))
			relation = "04";//子女
		else
			relation = "05";//其他

		return relation;
	}
	
	/**
	 * 判斷通報內容是否ok
	 * @param ret
	 * @return
	 */
	private boolean isResultOK(List ret){
		boolean result = false;
		String failcount = "0";
		
		try {
			if(ret != null){
				Map mp = (Map) ret.get(0);				
				failcount = mp.get("fail").toString();				
			}
			
			if(failcount.equals("0"))
				result = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
				
		return result;
	}
	
    /**
     * 檢核ID於本公司網路交易件是否有保期重疊件
     * @param tx_controller
     * @param id
     * @param strymd
     * @param endymd
     * @return
     * @throws AsiException
     */
    private boolean isDateDuplicate(TransactionControl tx_controller , String id , String strymd , String endymd) throws AsiException 
    {
    	boolean result = false;
		List ret = null;
				
		String sql = "SELECT * FROM KYCKLD "
				+ "LEFT JOIN KYCKLA ON KYCKLA.T1501 = KYCKLD.T1801 AND KYCKLA.T1502 = KYCKLD.T1802 " 
				+ "WHERE (KYCKLA.T1580='3' OR KYCKLA.T1580='4') "
				+ "AND T1808= ?"
				+ "AND (( ? >= KYCKLA.T1517 AND ? < KYCKLA.T1518) "
				+ "OR ( ? > KYCKLA.T1517 AND ? <= KYCKLA.T1518)) ";
		
		String[] args = new String[5];
		args[0] = id;
		args[1] = strymd;
		args[2] = strymd;
		args[3] = endymd;	
		args[4] = endymd;
		
		QueryRunner runner = new QueryRunner();
		tx_controller.begin(0);
		try
		{
			ret = (List) runner.query(tx_controller.getConnection(), sql, args, new TrimedMapListHandler());
			
			if(!ret.isEmpty() && ret.size() > 0)
				result = true;
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
    	
    	return result;
    }

    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }

}