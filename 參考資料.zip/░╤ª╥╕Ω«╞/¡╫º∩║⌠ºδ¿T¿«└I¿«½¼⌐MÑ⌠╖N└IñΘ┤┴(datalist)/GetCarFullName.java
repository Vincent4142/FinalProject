/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.FormatUtil;
import com.kyc.inc.dao.TrimedMapListHandler;

public class GetCarFullName extends AsiAction
{	

   public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       AsiActionForm form1 = (AsiActionForm) form;
       if (form1.getActionCode() == 0)
           form1.setActionCode(GlobalKey.ACTION_SELECT);
       return;
   }

   public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       return null;
   }

   protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
   {
   	
   }
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String carSerialNo = arg2.getParameter("carserialno") != null ? arg2.getParameter("carserialno").trim() : "";
		
		QueryRunner run = new QueryRunner();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT BO01,BN00,BN01,BN02,PC00,PC01,INT(PC02) PC02,PC03,PC04,PC05 FROM PFBN ");
		sb.append("LEFT JOIN PFPC ON SUBSTR(PC00,1,2)=BN00 ");
		sb.append("LEFT JOIN PFBO ON BO001=BN00 AND BO002=SUBSTR(PC00,3,2) ");
		sb.append("WHERE PC00=? ");
		
		List ret1 ;

		try
		{
			tx_controller.begin(1);
			
			ret1 = (List) run.query(tx_controller.getConnection(1),sb.toString(),carSerialNo,new TrimedMapListHandler());
			
			if(ret1 != null && ret1.size() != 0)
			{
				Map mp = (Map) ret1.get(0);
				mp.put("pc03f", FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("PC03").toString()), 0));
				String pc00end = mp.get("PC00").toString().substring(7, 8);
				String pc02desc = ""; 
				if(mp.get("PC02") != null)
				{
					if(pc00end.equals("1"))
						pc02desc = mp.get("PC02").toString() + "匹馬力";
					else
						pc02desc = mp.get("PC02").toString() + "C.C";
				}	
				mp.put("pc02desc", pc02desc);
			}								
			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(ret1).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		arg1.setNextPage(-1);
	}
}
