package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapListHandler;

public class GetInsCarUtil extends AsiAction
{

	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
	    AsiActionForm form1 = (AsiActionForm) form;
	    if (form1.getActionCode() == 0)
	        form1.setActionCode(GlobalKey.ACTION_SELECT);
	    return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
	    return null;
	}

	protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
	{
		
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException {
		String id = arg2.getParameter("clientid") != null && !arg2.getParameter("clientid").equals("") ? arg2.getParameter("clientid").trim() : "";//身份證號碼./統編
		String carnumber = arg2.getParameter("carnumber") != null && !arg2.getParameter("carnumber").equals("") ? arg2.getParameter("carnumber").trim() : "";//車牌
		String check_31s = arg2.getParameter("check_31s") != null && !arg2.getParameter("check_31s").equals("") ? arg2.getParameter("check_31s").trim() : "N";//是否有31類險種
		String check_0511s = arg2.getParameter("check_0511s") != null && !arg2.getParameter("check_0511s").equals("") ? arg2.getParameter("check_0511s").trim() : "N";//是否有05、11類險種	
		
		String[] strdate = null;
		Map param = null;
		
		try {
			
			//用id、車牌查保單資料
			if(!id.equals("") && !carnumber.equals("")){
				param = getOldInsDate(id, carnumber, check_31s, check_0511s);
				
				if(param.size() == 0){
					strdate = getInsStrDate();
					
					param = new HashMap();
					param.put("syear", strdate[0]);
					param.put("smonth", strdate[1]);
					param.put("sdate", strdate[2]);
					param.put("carSerialNo","novalue");
				}
			}else{
				strdate = getInsStrDate();
				
				param = new HashMap();
				param.put("syear", strdate[0]);
				param.put("smonth", strdate[1]);
				param.put("sdate", strdate[2]);

			}
			
			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
		
			arg3.getWriter().write(JSONArray.fromObject(param).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);
	}

	/**
	 * 由系統日及時間取得應起保日期
	 * 中午12點前為系統當日、中午12點後為系統次日
	 * @return
	 */
	public String[] getInsStrDate(){		
		String[] ret = null;
		
		try {
			
			int plusDay = 0;
		    Calendar now = Calendar.getInstance();
		    if(now.get(Calendar.HOUR_OF_DAY)>=12){
		    	plusDay=1;
		    }
		    now.add(Calendar.DATE, plusDay);
		    
		    int nYear = now.get(Calendar.YEAR) - 1911;//現在民國年
		    int nMonth = now.get(Calendar.MONTH) + 1;//現在月
		    int nowDate = now.get(Calendar.DATE);//現在日

		    String syear = String.valueOf(nYear);
		    String month = String.valueOf(StringUtils.leftPad(String.valueOf(nMonth), 2, "0"));
		    String date = String.valueOf(StringUtils.leftPad(String.valueOf(nowDate), 2, "0"));
		    
		    ret = new String[3];
		    ret[0] = syear;
		    ret[1] = month;
		    ret[2] = date;

		} catch (Exception e) {
			e.printStackTrace();
		}

	    return ret;
	}

    public Map getOldInsDate(String id , String carnumber , String check_31s , String check_0511s){
    	
    	Connection con = null;
    	List ret = null;
    	
		String sql = "SELECT * FROM PT21PF "
				+ "LEFT JOIN PT22PF ON T2201=T2101 AND T2202=T2102 "
				+ "WHERE T2105=? AND T2209=? AND T2102='C1' AND ? BETWEEN T2115 AND T2116 ";
        String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
    	
        Map retmap = null;
        String t2101_type = "";
        String t2116 = "0";
        
    	try
		{
    		con = AS400Connection.getConnection();
    		
            String[] args = new String[3];
            args[0] = id;
            args[1] = carnumber;
            args[2] = sysdate;
        	
        	QueryRunner runner = new QueryRunner();
            ret = (List) runner.query(con, sql, args , new TrimedMapListHandler());
	           
            if(ret != null && ret.size() > 0){
            	retmap = new HashMap();
            	
            	for (int i = 0; i < ret.size(); i++) {
					Map mp = (Map) ret.get(i);
					
					t2101_type = mp.get("T2101").toString().substring(4,5);
					t2116 = mp.get("T2116").toString();
					
					//L保單，任意險
            		if(check_31s != null ){
            			if(check_31s.equals("Y")){
            				if(t2101_type.equals("L")){           					
            					retmap.put("syear", t2116.substring(0, 3));
            					retmap.put("smonth", t2116.substring(3, 5));
            					retmap.put("sdate", t2116.substring(5, 7));
            					retmap.put("carSerialNo",mp.get("T2204").toString());
            					retmap.put("Displacement",mp.get("T2210").toString());
            				}
            			}            			
            		}
            		
            		//A保單，車體、竊盜，為優先
            		if(check_0511s != null){
            			if(check_0511s.equals("Y")){
            				if(t2101_type.equals("A")){
            					retmap.put("syear", t2116.substring(0, 3));
            					retmap.put("smonth", t2116.substring(3, 5));
            					retmap.put("sdate", t2116.substring(5, 7));
            					retmap.put("carSerialNo",mp.get("T2204").toString());
            					retmap.put("Displacement",mp.get("T2210").toString());
            					break;
            				}
            			}         			
            		}					
				}
            	
            }else{
            	String[] sysstr = getInsStrDate();
            	retmap = new HashMap();
				retmap.put("syear", sysstr[0]);
				retmap.put("smonth", sysstr[1]);
				retmap.put("sdate", sysstr[2]);
				retmap.put("carSerialNo","novalue");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
		finally{
			AS400Connection.closeConnection(con);
		}
    	
    	return retmap;
    }

}
