package com.kyc.schedule;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeUtility;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.EmailAttachment;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.KycWorkDayUtil;
import com.firstins.CooperativeBankExService;
import com.kyc.afl.utils.Employee;
import com.kyc.afl.utils.WorkDay;


/**
 * 合庫通路每日出單件明細通知
 * @author Vincent
 *
 */
public class SendChannelDataC021 extends AsiAction
{
	private String fileFolder = SystemParam.getParam("FILE_FOLDER") + "\\COOPERATIVEBANK";// 取得系統設定路徑
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		
		//判斷非工作日時不傳送，如為工作日時取前一工作日為資料日期基準
		String workdate = KycWorkDayUtil.getOffsetWorkDate("00", sysdate, 0);
		if(workdate.trim().length()==0)
			return;
		//取得前一工作日
		workdate = WorkDay.getStrWorkDatebyDays("00", sysdate, false, String.valueOf(1));
		
		CooperativeBankExService service = new CooperativeBankExService();

		Connection con = null;
		List dataV = null;
		List dataW = null;
		List dataK = null;
		List dataA = null;
		List dataC = null;
		List dataN = null;
		try
		{			
			tx_controller.begin(1);
			con=tx_controller.getConnection(1);
			//取得前一作帳日商住火保單資料-北市區
			dataV = service.getDataV(con, workdate);
			//取得前一作帳日商住火保單資料-新北市區
			dataW = service.getDataW(con, workdate);
			//取得前一作帳日商住火保單資料-高坪區
			dataK = service.getDataK(con, workdate);
			//取得前一作帳日商住火保單資料-桃竹區
			dataA = service.getDataA(con, workdate);
			//取得前一作帳日商住火保單資料-台中區
			dataC = service.getDataC(con, workdate);
			//取得前一作帳日商住火保單資料-雲嘉南
			dataN = service.getDataN(con, workdate);
									
			sendMail(servlet,request,workdate, dataV,dataW,dataK,dataA,dataC,dataN);
			
			//寄完刪除資料夾檔案
			//取得存放的路徑			
			File ffolder = new File(fileFolder+ "\\" +workdate);
			//呼叫刪除資料夾方法
			deleteDir(ffolder);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);
	}
	//送出郵件方法
	private void sendMail(HttpServlet servlet, HttpServletRequest request,String workdate,List dataV,List dataW,List dataK,List dataA,List dataC,List dataN)
	{
		if (dataV == null && dataW == null && dataK == null && dataA == null && dataC == null && dataN == null)
			return;

		try
		{
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
			ve.init();
			
			//北市區檔案路徑
			String pathV=generateCsvFile(dataV,"北市區-"+workdate);
			//新北市區檔案路徑
			String pathW=generateCsvFile(dataW,"新北市區-"+workdate);
			//高屏區檔案路徑
			String pathK=generateCsvFile(dataK,"高屏區-"+workdate);
			//桃竹區檔案路徑
			String pathA=generateCsvFile(dataA,"桃竹區-"+workdate);
			//台中區檔案路徑
			String pathC=generateCsvFile(dataC,"台中區-"+workdate);
			//雲嘉南檔案路徑
			String pathN=generateCsvFile(dataN,"雲嘉南-"+workdate);
			
			if((pathV==null || pathV.length()==0) && (pathW==null || pathW.length()==0) && (pathK==null || pathK.length()==0) && (pathA==null || pathA.length()==0) && (pathC==null || pathC.length()==0) && (pathN==null || pathN.length()==0))
				return;
			
			//有資料才加入附件檔,att用來暫存有資料的附件
			List<EmailAttachment> att=new ArrayList<EmailAttachment>();
			
			// 郵件附加檔-北市區
			if(pathV!=null && pathV!=""){
				EmailAttachment attachmentV = new EmailAttachment();
				attachmentV.setPath(pathV);
				attachmentV.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentV.setName(MimeUtility.encodeText("北市區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentV);
			}
			// 郵件附加檔-新北市區
			if(pathW!=null && pathW!=""){
				EmailAttachment attachmentW = new EmailAttachment();
				attachmentW.setPath(pathW);
				attachmentW.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentW.setName(MimeUtility.encodeText("新北市區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentW);
			}
			// 郵件附加檔-高屏區
			if(pathK!=null && pathK!=""){
				EmailAttachment attachmentK = new EmailAttachment();
				attachmentK.setPath(pathK);
				attachmentK.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentK.setName(MimeUtility.encodeText("高屏區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentK);
			}
			// 郵件附加檔-桃竹區
			if(pathA!=null && pathA!=""){
				EmailAttachment attachmentA = new EmailAttachment();
				attachmentA.setPath(pathA);
				attachmentA.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentA.setName(MimeUtility.encodeText("桃竹區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentA);
			}
			// 郵件附加檔-台中區
			if(pathC!=null && pathC!=""){
				EmailAttachment attachmentC = new EmailAttachment();
				attachmentC.setPath(pathC);
				attachmentC.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentC.setName(MimeUtility.encodeText("台中區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentC);
			}
			// 郵件附加檔-雲嘉南
			if(pathN!=null && pathN!=""){
				EmailAttachment attachmentN = new EmailAttachment();
				attachmentN.setPath(pathN);
				attachmentN.setDisposition(EmailAttachment.ATTACHMENT);
				attachmentN.setName(MimeUtility.encodeText("雲嘉南-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
				att.add(attachmentN);
			}
			//將list att資料塞入Object[]
			Object[] params=new Object[att.size()];
			for(int i=0;i<att.size();i++){
				params[i]=att.get(i);
			}
			
			KycMailUtil kmu = new KycMailUtil();
			kmu.addAttachment(params);
			
			//郵件內文
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setMessage(workdate+"合庫商住火保單資訊,請查收謝謝。");
			//郵件主旨
			kmu.setSubject("合庫商住火保單資訊-"+workdate + ".csv");
			
			//取得寄件正本人員
			List mailToList = new ArrayList();
			String[][] arrayTo = CodeUtil.getCodeArray(servlet, request, "C231AGENTS");
			for(int i=0;i<arrayTo.length;i++)
			{
				if(arrayTo[i][0]!=null && arrayTo[i][0].trim().length()>0)
					mailToList.add(Employee.getEmployee(arrayTo[i][0]).getEmail());
			}
			if(mailToList.size()>0)
				kmu.addTo(mailToList.toArray());
			
			kmu.sendMailWithAttachments();
						
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 組CSV資料，存到資料夾，並回傳路徑
	 * 
	 * @param response
	 * @throws UserException
	 */
	public String generateCsvFile(List data,
			String filename) throws UserException
	{
		//組CSV資料
		StringBuffer sb = new StringBuffer();

		sb.append("影像編號");
		sb.append(",");
		sb.append("要保人ID");
		sb.append(",");
		sb.append("被保險人ID");
		sb.append(",");
		sb.append("保單生效日期");
		sb.append(",");
		sb.append("被保險人姓名");
		sb.append(",");
		sb.append("保單號碼");
		sb.append(",");
		sb.append("業務來源");
		sb.append(",");
		sb.append("通路代號");
		sb.append(",");
		sb.append("\n");
		
		String rptPath = "";
		if(data!=null && data.size()!=0){
			
			for (int i = 0; i < data.size(); i++)
			{
				Map mp = (Map) data.get(i);

				//將保單生效日期轉為日期格式
				String date=mp.get("c205").toString().trim();
				String day=formatDate(date);
				
				sb.append(" ");
				sb.append(",");
				sb.append(mp.get("c248").toString().trim());
				sb.append(",");
				sb.append(mp.get("c201").toString().trim());
				sb.append(",");
				sb.append(day);
				sb.append(",");
				sb.append(mp.get("c230").toString().trim());
				sb.append(",");
				sb.append(mp.get("c202").toString().trim());
				sb.append(",");
				sb.append(mp.get("c210").toString().trim());
				sb.append(",");
				sb.append(mp.get("c233").toString().trim());
				sb.append(",");
				sb.append("\n");
			}
			//存到資料夾
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String workdate = WorkDay.getStrWorkDatebyDays("00", sysdate, false, String.valueOf(1)); 
			String sysFolder = fileFolder + "\\" +workdate;
					
			try
			{
				File ffolder = new File(sysFolder);
				if(!ffolder.exists())
					ffolder.mkdirs();
						   	
			   	rptPath = sysFolder + "\\" + filename + ".csv";
			   	
			    //解決CSV亂碼問題1
			   	BufferedWriter fos = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(rptPath), "UTF-8"));
			   	fos.write('\ufeff');
			   	fos.write(sb.toString());
			   	fos.close();
			    //解決CSV亂碼問題2
//			   	FileOutputStream fos = new FileOutputStream(new File(rptPath));
//			   	byte[] BOM_UTF8 = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
//			   	fos.write(BOM_UTF8);
//			   	fos.write(sb.toString().getBytes());
//				fos.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
				rptPath = null;
			}
		}
		return rptPath;				
	}
	
	//刪除資料夾方法
	public void deleteDir(File file) {
        if (file.isDirectory()) {
            for (File f : file.listFiles())
                deleteDir(f);
        }
        file.delete();
    }
	
	//轉西元年並轉成日期格式
	public String formatDate(String day){
		String year=(Integer.parseInt(day.substring(0,3))+1911)+"/";
		String mounth=day.substring(3,5)+"/";
		String date=day.substring(5,7);
		
		String day2=year+mounth+date;
		return day2;
	}
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}