package com.firstins;

import java.sql.Connection;
import java.util.List;
import org.apache.commons.dbutils.QueryRunner;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * 合庫通路業務每日排程需求資料抓取相關程式
 * 
 * @author Vincent
 * @Create Date：2020/8/5
 */

public class CooperativeBankExService {

	/**
	 * 取得前一作帳日商住火保單資料-北市區
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataV(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='V'"+ 
//測試用			 " AND C231>1090401";
		 		 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用	    data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
	/**
	 * 取得前一作帳日商住火保單資料-新北市區
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataW(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='W'"+ 
//測試用			 " AND C231>1090401";
		 		 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用		data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
	/**
	 * 取得前一作帳日商住火保單資料-高屏區
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataK(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='K'"+ 
//測試用			 " AND C231>1090401";
		 		 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用		data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
	/**
	 * 取得前一作帳日商住火保單資料-桃竹區
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataA(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='A'"+ 
//測試用			 " AND C231>1090401";
				 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用		data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());	
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
	/**
	 * 取得前一作帳日商住火保單資料-台中區
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataC(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='C'"+ 
//測試用			 " AND C231>1090401";
		 		 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用		data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
	/**
	 * 取得前一作帳日商住火保單資料-雲嘉南
	 * @param con
	 * @param date 前一工作日
	 * @return
	 */
	public List getDataN(Connection con,String date){
		List data=null;
		
		String sql = "SELECT"+                                                             
				 " C201,C230,C202,C203,C205,C206,C210,"+ 
				 "C213,C231,C233,C248,ZN04,"+
				 " CASE WHEN ZN04='V' THEN '北市區'"+                           
				 " WHEN ZN04='W' THEN '新北市區'"+                            
				 " WHEN ZN04='K' THEN '高屏區'"+                              
				 " WHEN ZN04='A' THEN '桃竹區'"+                              
				 " WHEN ZN04='C' THEN '台中區'"+                              
				 " WHEN ZN04='N' THEN '雲嘉南'"+                              
				 " ELSE '' END AS AREADESC"+ 
				 " FROM FIRSTF/IC02PF"+ 
				 " LEFT JOIN FGFLIB/FBZNPF ON ZN01=C203"+ 
				 " AND ZN02=SUBSTR(C202,1,4)"+ 
				 " WHERE C203 ='F' AND C233='C021' AND ZN04='N'"+ 
//測試用			 " AND C231>1090401";
		 		 " AND C231=?";
		try{
			QueryRunner qr=new QueryRunner();
			
			Object[] param={date};
			
//測試用		data = (List) qr.query(con, sql, new TrimedMapListHandler());
		    data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return data;
	}
}
