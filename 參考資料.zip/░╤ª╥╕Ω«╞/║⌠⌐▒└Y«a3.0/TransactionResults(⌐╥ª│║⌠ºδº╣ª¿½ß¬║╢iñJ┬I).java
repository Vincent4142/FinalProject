/*
 * $Header: D:/Repositories/KYC2/JavaSource/com/com/asi/kyc/common/actions/TransactionUpdate.java,v 1.5 2006/09/29 03:43:03 cvsuser Exp $
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. Taipei, Taiwan. All rights
 * reserved.
 * 
 * This software is the confidential and proprietary information of Asgard
 * System, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Asgard.
 * 
 */
package com.asi.kyc.common.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.Codec;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.wb1.actions.SendLineMessage;
import com.asi.kyc.wb1.forms.WB1M010f;
import com.asi.kyc.wb1.forms.WB1M020f;
import com.asi.kyc.wb1.forms.WB1M040f;
import com.asi.kyc.wb1.forms.WB1M050f;
import com.asi.kyc.wb1.forms.WB1M110f;
import com.nccc.evpos.HppApiClient;

/**
 * 提供聯信NCC回拋結果程式
 * 
 * @author vsg
 * @CreateDate 2015/6/30上午 11:46:21
 * @UpdateDate 2015/6/30上午 11:46:21
 * @FileName kyc/com.asi.kyc.common.actions/TransactionResults.java
 * @Purpose
 * 
 */
public class TransactionResults extends AsiAction
{

	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		form1.setActionCode(99);
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException,
			ServletException
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping,
			HttpServletRequest request, AsiActionForm form) throws AsiException
	{
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws AsiException {

		String MerchantID = SystemParam.getParam("NCCC_MERCHANTID"); // HCC聯信商店代號
		String TerminalID = SystemParam.getParam("NCCC_TERMINALID"); // HCC聯信端末機代號
		String NCCCURL = SystemParam.getParam("NCCC_URL"); // NCCC聯信取授權網址
		
		String key = request.getParameter("KEY");

     	// 產生API 物件
  		HppApiClient apiClient=new HppApiClient();
  		// 設定交易資料
  		try 
  		{
  			request.setCharacterEncoding("Big5");
  			apiClient.setKEY(key);
  			apiClient.setMERCHANTID(MerchantID);
  			apiClient.setTERMINALID(TerminalID);
  			apiClient.setURL(NCCCURL, "/merchant/HPPRequest");
  			apiClient.setProvider("sun.security.provider.Sun");
  			apiClient.postQuery();
  		} 
  		catch(Exception e){
  			e.printStackTrace();
  		}

  		String ordernumber = apiClient.getORDERID();				//訂單編號
  		String cardno = apiClient.getPAN();							//信用卡號
  		String pdata = apiClient.getPrivateData();					//自訂參數
  		String appcode = apiClient.getAPPROVECODE();				//授權碼
  		String responsecode = apiClient.getRESPONSECODE();			//授權回應碼
  		String msg = apiClient.getRESPONSEMSG();					//授權回應訊息
  		String state = "3";											//交易狀態
      
      if(!responsecode.equals("00") && !responsecode.equals("08") && !responsecode.equals("11"))
      	state = "2";

      //由Session取由WB1M010f
      WB1M010f mform = (WB1M010f) request.getSession().getAttribute("WB1M010f");     
      if(pdata.equals("NWB1M0101"))
      {
          mform.setRetcode(responsecode);
          request.getSession().setAttribute("WB1M010f", mform);
          request.setAttribute("WB1M010f", mform);
          request.setAttribute("action", pdata);
          request.setAttribute("MSG", msg); 

          try {
        	  request.setAttribute("decodedata", Codec.decode(mform.getInstypename()));
          } catch (IOException e) {
        	  e.printStackTrace();
          }
      }
      
      WB1M020f mform2 = (WB1M020f) request.getSession().getAttribute("WB1M020f");     
      if(pdata.equals("NWB1M0201"))
      {
    	  mform2.setRetcode(responsecode);
          request.getSession().setAttribute("WB1M020f", mform2);
          request.setAttribute("WB1M020f", mform2);
          request.setAttribute("action", pdata);
          request.setAttribute("MSG", msg); 
          
          try {
        	  request.setAttribute("decodedata", Codec.decode(mform2.getInstypename()));
          } catch (IOException e) {
        	  e.printStackTrace();
          }

      }

      WB1M040f mform4 = (WB1M040f) request.getSession().getAttribute("WB1M040f");  
      if(pdata.equals("NWB1M0401"))
      {
    	  mform4.setRetcode(responsecode);
          request.getSession().setAttribute("WB1M040f", mform4);
          request.getSession().setAttribute("errmsg", msg);
          request.setAttribute("WB1M040f", mform4);
          request.setAttribute("action", pdata);
          request.setAttribute("MSG", msg); 
      }
      
      
      WB1M050f mform5 = (WB1M050f) request.getSession().getAttribute("WB1M050f");     
      if(pdata.equals("NWB1M0501"))
      {
    	  mform5.setRetcode(responsecode);
          request.getSession().setAttribute("WB1M050f", mform5);
          request.setAttribute("WB1M050f", mform5);
          request.setAttribute("action", pdata);
          request.setAttribute("MSG", msg); 
      }

      WB1M110f mform11 = (WB1M110f) request.getSession().getAttribute("WB1M110f");  
      if(pdata.equals("NWB1M1101"))
      {
    	  mform11.setRetcode(responsecode);
          request.getSession().setAttribute("WB1M110f", mform11);
          request.getSession().setAttribute("errmsg", msg);
          request.setAttribute("WB1M110f", mform11);
          request.setAttribute("action", pdata);
          request.setAttribute("MSG", msg); 
      }

      UserInfo ui = new UserInfo();
      ui.setDateFormat(DateUtil.Format_YYYYMMDD);
      ui.setDateType(DateUtil.ChType);
      ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
      ui.setFileDateType(DateUtil.ChType);
      tx_controller.setUserInfo(ui);
      tx_controller.begin(0);

      DBO dbo = tx_controller.getDBO("kyc.KYCKLAu01", 0);
      dbo.addParameter("T1501", ordernumber);
      dbo.addParameter("T1578", responsecode);
      dbo.addParameter("T1579", appcode);
      dbo.addParameter("T1580", state);
      dbo.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD,false));
      dbo.addParameter("T1599", "NCCC");
      dbo.addParameter("T1532", cardno);
      dbo.executeUpdate();
      
      if (dbo.getRecordCount() == 0) {
    	  try {
    		  response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
    	  } catch (IOException e) {
    		  return;
    	  }
      }
      
      //交易成功寄發Email
      if(responsecode.equals("00") || responsecode.equals("08") || responsecode.equals("11"))
      {
    	  if(pdata.equals("NWB1M0501")){
    		  sendFireMail(ordernumber, request);    		  
    	  }
      }
      	
      if(pdata.equals("NWB1M0101")){
    	  //完成投保若有填寫推薦人代號則LINE推播通知
		  String referrerCode=(String) request.getSession().getAttribute("pjcode");
		  if(referrerCode != "" && referrerCode !=null){
			  if(!isProjectCode(referrerCode)){
			  SendLineMessage slm=new SendLineMessage();
			  String user_id=slm.getEmployeeCode(referrerCode);
			  slm.sendLine(user_id, "推薦人通知", "投保：您推薦會員已完成機車險投保，電銷部很愛你");
			  }
		  }
		  request.getSession().removeAttribute("pjcode");
    	  form.setNextPage(1);
      }    	      	  
      else if(pdata.equals("NWB1M0201")){   	  
    	  //完成投保若有填寫推薦人代號則LINE推播通知
		  String referrerCode=(String) request.getSession().getAttribute("pjcode");
		  if(referrerCode != "" && referrerCode !=null){
			  if(!isProjectCode(referrerCode)){
			  SendLineMessage slm=new SendLineMessage();
			  String user_id=slm.getEmployeeCode(referrerCode);
			  slm.sendLine(user_id, "推薦人通知", "投保：您推薦會員已完成汽車險投保，電銷部很愛你");
			  }
		  }
		  request.getSession().removeAttribute("pjcode");
    	  form.setNextPage(2);
      }   	 
      else if(pdata.equals("NWB1M0501")){    	  
		  //完成投保若有填寫推薦人代號則LINE推播通知
		  String referrerCode=(String) request.getSession().getAttribute("pjcode");
		  if(referrerCode != "" && referrerCode !=null){
			  if(!isProjectCode(referrerCode)){
			  SendLineMessage slm=new SendLineMessage();
			  String user_id=slm.getEmployeeCode(referrerCode);
			  slm.sendLine(user_id, "推薦人通知", "投保：您推薦會員已完成住火險投保，電銷部很愛你");
			  }
		  }
		  request.getSession().removeAttribute("pjcode");
		  form.setNextPage(3);
      }   	     	  
      else if(pdata.equals("NWB1M0401")){
    	  try {
    		  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M0401.do?actionCode=21&retcode=" + responsecode + "&ordernumber=" + ordernumber);
    	  } catch (MalformedURLException e) {
    		  e.printStackTrace();
    	  } catch (IOException e) {
    		  e.printStackTrace();
    	  }
    	  return;
      }else if(pdata.equals("NWB1M1101")){
    	  try {
    		  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M1101.do?actionCode=21&retcode=" + responsecode + "&ordernumber=" + ordernumber);
    	  } catch (MalformedURLException e) {
    		  e.printStackTrace();
    	  } catch (IOException e) {
    		  e.printStackTrace();
    	  }
    	  return;
      }

    	  
	}

	
	/**
	 * 住火確認投保通知
	 * @param number
	 * @param request
	 */
	private void sendFireMail(String number , HttpServletRequest request) {

        KycMailUtil sender = new KycMailUtil();
        sender.setSubject("第一產物保險-住宅火險投保確認通知");

        BufferedReader fr;
        String path = getServlet().getServletContext().getRealPath("/mail/fireInsurancesOrderOK.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        WB1M050f mform = (WB1M050f) request.getSession().getAttribute("WB1M050f");
        
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", mform.getKyc_T1506());
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{total\\}", FormatUtil.getDecimalFormat(Double.parseDouble(mform.getFb07()), 0));
        msg = msg.replaceAll("\\{insurancecontent\\}", "住宅火險及地震基本保險");

        msg = msg.replaceAll("\\{stry\\}", mform.getYear());
        msg = msg.replaceAll("\\{strm\\}", mform.getMonth());
        msg = msg.replaceAll("\\{strd\\}", mform.getDate());
        msg = msg.replaceAll("\\{endy\\}", mform.getYear2());
        msg = msg.replaceAll("\\{endm\\}", mform.getMonth2());
        msg = msg.replaceAll("\\{endd\\}", mform.getDate2());
        
        msg = msg.replaceAll("\\{time\\}", "十二");
        
        sender.setMessage(msg);
        sender.addTo(mform.getKyc_T1516());
        sender.sendMail();
   }
	
    /**
     * 判斷是否為專案代號或推薦人代號(true->專案代號 、false->推薦人代號)
     * @param pjcode
     */
    public boolean isProjectCode(String pjcode){
    	boolean ispjcode=true;
    	
    	String str= pjcode.substring(0,1);
    	String str2= pjcode.substring(1,4);
    	String regex = ".*[a-zA-z].*";
    	boolean isEng=str2.matches(regex);//true：含有英文
    	
    	if((str.equals("1") || str.equals("2")) && isEng){
    		ispjcode=false;
    	}
    	    	    	
    	return ispjcode;
    }

}
