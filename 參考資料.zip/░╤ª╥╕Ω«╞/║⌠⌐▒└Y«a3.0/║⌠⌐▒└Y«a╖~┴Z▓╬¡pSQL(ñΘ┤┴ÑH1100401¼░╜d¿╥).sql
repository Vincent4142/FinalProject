SELECT  X.M303 M303,X.M203 M203,X.M302 M302,X.M301 M301,X.T1582 T1582,                                  
SUM(X.CA1) CA1,SUM(X.CA2) CA2,SUM(X.CC1) CC1,SUM(X.CC2) CC2,                                            
SUM(X.MA1) MA1,SUM(X.MA2) MA2,SUM(X.MC1) MC1,SUM(X.MC2) MC2,                                            
SUM(X.FR1) FR1,SUM(X.FR2) FR2,                                                                          
SUM(X.TA1) TA1,SUM(X.TA2) TA2,                                                                          
SUM(X.SE1) SE1,SUM(X.SE2) SE2                                                                           
FROM (                                                                                                  
--汽強                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
COUNT(T1501) CA1,SUM(T1541) CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 LIKE '%C%' AND T1503='A'                                                                      
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--汽任                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,COUNT(T1501) CC1,SUM(T1541) CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 LIKE '%C%' AND T1503 LIKE '%C%'                                                               
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--機強                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,0 CC1,0 CC2,COUNT(T1501) MA1,SUM(T1541) MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 LIKE '%M%' AND T1503='A'                                                                      
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--機任                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,COUNT(T1501) MC1,SUM(T1541) MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 LIKE '%M%' AND T1503 LIKE '%C%'                                                               
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--住火                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,COUNT(T1501) FR1,SUM(T1541) FR2,0 TA1,0 TA2,0 SE1,0 SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 ='FR'                                                                                         
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--旅平                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,0,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,COUNT(T1501) TA1,SUM(T1541) TA2,0 SE1,0 SE2     
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 ='TA'                                                                                         
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
UNION                                                                                                   
--海域                                                                                                  
SELECT                                                                                                  
M303,M203,M302,M301,T1582,                                                                              
0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,COUNT(T1501) SE1,SUM(T1541) SE2 
FROM PT15PF                                                                                             
LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     
LEFT JOIN IC01PF ON C01A01 = C101                                                                       
LEFT JOIN PSM3PF ON M319=C101                                                                           
LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             
WHERE T1538='B2C' AND T1582 IS NOT NULL                                                                 
AND T1502 ='SE'                                                                                         
AND T1523 BETWEEN 1100401 AND 1100401                                                                               
GROUP BY M303,M203,M302,M301,T1582                                                                      
) X                                                                                                     
GROUP BY X.M303,X.M203,X.M302,X.M301,X.T1582;