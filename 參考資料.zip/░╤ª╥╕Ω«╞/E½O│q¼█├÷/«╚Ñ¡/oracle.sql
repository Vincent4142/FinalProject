-- 平台轉入失敗
SELECT ID,
       POLICY_NO, -- 保單號
       ENDST_NO -- 批單序號
FROM POS_POLICY
WHERE CLS_TYPE='GA' AND POLICY_OP_STATUS='WITHDRAW' and ENDST_NO>1
;

-- 保單原始名冊
SELECT ID, -- PK
       GROUP_NO, -- 群組
       SEQ_NO, -- 序號
       IDNO, -- ID
       LOCAL_NAME -- 姓名
FROM POS_POLICY_INSURED
WHERE POLICY_NO='100209GP000010' --
  AND ENDST_NO=1  --
;

-- 平台異動加保
SELECT ID, -- PK
       POLICY_ID, -- 保單 PK
       POLICY_NO, -- 保單號
       ENDST_NO, -- 批單序號
       GROUP_NO, -- 群組
       SEQ_NO, -- 序號
       IDNO, -- ID
       LOCAL_NAME, -- 姓名
        OP_STATUS -- 狀態
FROM POS_POLICY_INSURED_ENDST -- 異動名冊
WHERE POLICY_NO='100009GP000100'
AND OP_STATUS='ADD'
;
