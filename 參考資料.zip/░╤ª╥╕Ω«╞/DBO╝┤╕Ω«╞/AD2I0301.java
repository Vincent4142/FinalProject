/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc.
 * Taipei, Taiwan. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Asgard System, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Asgard.
 *
 */
package com.asi.adm.ad2.actions;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.adm.ad1.forms.AD1M050f;
import com.asi.common.ExcelGenerator;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.Record;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.KycDateUtil;

/**
 * 訂單資料查詢/匯出
 *
 * @author ：YiChuan
 * @version ：$Revision: 1.7 $ $Date: 2007/01/10 10:06:08 $<br>
 *          <p>
 * <pre>
 *    存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/adm/com/asi/adm/ad2/actions/AD2I0301.java,v 1.7 2007/01/10 10:06:08 cvsuser Exp $
 *    建立日期	：2005/4/1
 *    異動註記	：2005/09/16 Calvin 另新增資料匯出聯絡電話,郵遞區號,通訊地址
 * </pre>
 * </p>
 */
public class AD2I0301 extends AsiAction {
    public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(1);
        return;
    }

    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
        AD1M050f form1 = (AD1M050f) form;
        int nextPage = 1;
        
		UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
		String urid = ui.getUserId();
		
		

        if (form.getActionCode() == 1) {
            String date = this.tx_controller.getSystemDate();
            
   			// 日期預設值
   			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType,
   					DateUtil.Format_YYYYMMDD, false));
   			int sysMon = sysDate / 100;
   			int startDate = sysMon * 100;
   			startDate += 1; // 查詢日期區間的起日從當月1日起
            
            form1.setKYC_T1523s(String.valueOf(startDate));
            form1.setKYC_T1523e(date);
            form1.setKYC_T1598s(String.valueOf(startDate));
            form1.setKYC_T1598e(date);

        } else if (form.getActionCode() == 5) {
            nextPage = 2;
            SelectDBO dbo1 = selectDataFormPT15PF(request, form1);
            request.setAttribute("dbo1", dbo1);

    		//寫入KYCLLOG記錄檔處理
    		KycLogger klg = new KycLogger();
    		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "訂單資料查詢", "B", urid, "", "", "", "", "", "", "", "", "", "S", "", "資料查詢", dbo1.getAssembledSQL(), "", "", "", "");
            
            //匯出
        } else if (form.getActionCode() == 21) {
//            response.setContentType("application/octect-stream");
//            response.setHeader("Content-Disposition", "attachment;filename=ExportData" + this.tx_controller.getSystemDate() + ".xls");

            SelectDBO dbo1 = selectDataFormPT15PF(request, form1);
//         String[] key = {"T1501","T1503D","T1523","T1507","T1506","T1515"};
//            for(int i=0;i<dbo1.getRecordCount();i++){
//            	
//            	 for(int j=0;j<key.length;j++){
//            		System.out.println(dbo1.getRecordData(i+1, key[j]));
//            	 }
//            	
//            }
            KycDateUtil kycdate = new KycDateUtil();
			String sysdate = kycdate.getKycDate();
            HSSFWorkbook workbook = export(dbo1);
            try {
            	
            	response.setContentType("application/octect-stream");
                response.setHeader("Content-Disposition", "attachment;filename=ExportData" + this.tx_controller.getSystemDate() + ".xls");

				OutputStream os = response.getOutputStream();
				workbook.write(os);
				os.flush();
				os.close();
				response.flushBuffer();
            } catch (IOException e) {
                LogFactory.getLog(AD2I0301.class).error(e.getMessage());
            }
            nextPage = -1;
            
    		//寫入KYCLLOG記錄檔處理
    		KycLogger klg = new KycLogger();
//    		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "訂單資料查詢", "B", urid, "", "", "", "", "", "", "", "", "", "S", "", "匯出資料", dbo1.getAssembledSQL(), "", "", "", "");

        }
        form.setNextPage(nextPage);
    }
    
    private void createCell1(HSSFRow headerRow, short cellcnt, String cellString, HSSFCellStyle style)
	{
		HSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}
    
    

    private SelectDBO selectDataFormPT15PF(HttpServletRequest request, AD1M050f form1) throws AsiException {
        StringBuffer buffer = new StringBuffer();

        String t1610 = request.getParameter("T1610");

        if (form1.getKYC_T1501S() != null && form1.getKYC_T1501S().length() > 0)//交易序號
           buffer.append("A.T1501='" + form1.getKYC_T1501S() + "' ");
        else if(!t1610.equals(""))//車牌
      	  buffer.append("t1610 like '%").append(t1610).append("%' ");     	  
        else{
      	  //交易日期
           buffer.append("( A.T1523 BETWEEN ");
           buffer.append(form1.getKYC_T1523s() + " AND " + form1.getKYC_T1523e());
           
           //修改日期
           if(!form1.getKYC_T1598s().equals(""))
           {
         	  buffer.append(" OR A.T1598 BETWEEN ");
         	  buffer.append(form1.getKYC_T1598s() + " AND " + form1.getKYC_T1598e());
           }
           buffer.append(" ) ");
           
           //姓名
           if (form1.getKYC_T1506() != null && form1.getKYC_T1506().length() > 0)
         	  buffer.append(" AND A.T1506 LIKE '" + form1.getKYC_T1506() + "%'");
           //id
           if (form1.getKYC_T1507() != null && form1.getKYC_T1507().length() > 0)
         	  buffer.append(" AND A.T1507='" + form1.getKYC_T1507() + "'");
           
           buffer.append(" AND A.T1538='B2C' ");  	  
        }
        SelectDBO dbo1 = (SelectDBO) tx_controller.getDBO("kyc.PT15PFs03", 0);
        dbo1.setPageRowCount(20);
//        dbo1.setMaxRowCount(Integer.parseInt(SystemParam.getParam("MAXROWS")));
        dbo1.addParameter("WHERE", buffer.toString());
        dbo1.execute();

        DBO dbo2 = null;
        DBO dbo3 = null;

        int rows = dbo1.getRecordCount();
        if(rows > 0) {
            dbo2 = tx_controller.getDBO("kyc.KYCKDs13", 0);
            dbo2.executeSelect();
            dbo3 = tx_controller.getDBO("kyc.SECAZs02", 0);
            dbo3.addParameter("codetype", "GOODSID");
            dbo3.executeSelect();

            request.setAttribute("selected","true");//顯示匯出按鈕
        }

        for (int i = 1; i <= rows; i++) {
            String T1502 = dbo1.getRecordData(i, "T1502");
            String T1503 = dbo1.getRecordData(i, "T1503");
            String T1519 = dbo1.getRecordData(i, "T1519");
            String T1520 = dbo1.getRecordData(i, "T1520");
            String T1577 = dbo1.getRecordData(i, "T1577");
            //增加來源網站欄位
            String kd19 = getSource(dbo2, T1519, T1520);
            dbo1.addRecordData(i, "KD19", kd19);

            dbo1.addRecordData(i, "T1503D", CodeUtil.getCodeDesc(getServlet(), request, "KIND", T1503));

            dbo1.addRecordData(i, "T1577D", CodeUtil.getCodeDesc(getServlet(), request, "YN",T1577 ));
            //增加商品代碼中文
            dbo1.addRecordData(i, "T1502D", getPName(dbo3, T1502));

//          三隻電話選擇一隻,優先順序: 手機>>家裡>>公司
//          T1513 --TEL(H)
//          T1514 --TEL(O)
//          T1515 --TEL(M)
            String T1513 = dbo1.getRecordData(i, "T1513");
            String T1514 = dbo1.getRecordData(i, "T1514");
            String T1515 = dbo1.getRecordData(i, "T1515");
            if (!T1515.equals("")) {
                dbo1.addRecordData(i, "CURRPHONE", T1515);
            } else if (!T1513.equals("")) {
                dbo1.addRecordData(i, "CURRPHONE", T1513);
            } else if (!T1514.equals("")) {
                dbo1.addRecordData(i, "CURRPHONE", T1514);
            } else {
                dbo1.addRecordData(i, "CURRPHONE", null);
            }
            dbo1.addRecordData(i,"GOOD" ,dbo1.getRecordData(i,"T1502")+" "+CodeUtil.getCodeDesc(getServlet(), request, "GOODSID", dbo1.getRecordData(i,"T1502")));
        }

        return dbo1;
    }

    private String getSource(DBO dbo, String t1519, String t1520) {
        if (dbo == null) {
            return "";
        }

        int count = dbo.getRecordCount();
        for (int i = 1; i <= count; i++) {
            if (t1519.equals(dbo.getRecordData(i, "KD16")) && t1520.equals(dbo.getRecordData(i, "KD17"))) {
                return dbo.getRecordData(i, "KD19");
            }
        }

        return "";
    }

    private String getPName(DBO dbo, String t1502) {
        if (dbo == null) {
            return "";
        }

        int count = dbo.getRecordCount();
        for (int i = 1; i <= count; i++) {
            if (t1502.equals(dbo.getRecordData(i, "CODEID"))) {
                return dbo.getRecordData(i, "CODEDESC");
            }
        }

        return "";
    }

    public HSSFWorkbook export(SelectDBO data) throws AsiException
	{		
		
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet sheet = workBook.createSheet();
		
		sheet.createFreezePane(0, 1);//凍結視窗
		
		sheet.setDefaultRowHeightInPoints(20);//預設列高
		sheet.setDefaultColumnWidth((short)9);//預設欄寬
		sheet.setMargin(HSSFSheet.TopMargin, (double) .30);//設定上邊界
		sheet.setMargin(HSSFSheet.BottomMargin, (double) .30);//設定下邊界
		sheet.setMargin(HSSFSheet.LeftMargin, (double) .30);//設定左邊界
		sheet.setMargin(HSSFSheet.RightMargin, (double) .30);//設定右邊界
		
		HSSFCellStyle style = workBook.createCellStyle();//欄位&Data樣式
		style.setWrapText(false);//自動換行
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);//設定下框線樣式
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);//設定左框線樣式
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);//設定右框線樣式
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);//設定上框線樣式
		
		HSSFRow row = sheet.createRow(0);//欄位名稱
		createCell1(row, (short) 0, "交易序號", style);
		createCell1(row, (short) 1, "險種代號", style);
		createCell1(row, (short) 2, "交易日期", style);
		createCell1(row, (short) 3, "被保險人ID", style);
		createCell1(row, (short) 4, "被保險人姓名", style);
		createCell1(row, (short) 5, "被保險人手機", style);

		
		String[] key = {"T1501","T1503","T1523","T1507","T1506","T1515"};
        for(int i=0;i<data.getRecordCount();i++){
        	
        	 for(int j=0;j<key.length;j++){
        		//System.out.println(data.getRecordData(i+1, key[j]));
        		row = sheet.createRow(i + 1);
        		
     			createCell1(row, (short) 0, String.valueOf(data.getRecordData(i+1, "T1501")), style);
     			createCell1(row, (short) 1, String.valueOf(data.getRecordData(i+1, "T1503")), style);		
    			createCell1(row, (short) 2, String.valueOf(data.getRecordData(i+1, "T1523")), style);
     			createCell1(row, (short) 3, String.valueOf(data.getRecordData(i+1, "T1507")), style);
     			createCell1(row, (short) 4, String.valueOf(data.getRecordData(i+1, "T1506")), style);
     			createCell1(row, (short) 5, String.valueOf(data.getRecordData(i+1, "T1515")), style);
        	 }
        }	
		return workBook;
	}
	
	
}