/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.reg.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
/**
 * 登入OTP即時驗證API
 * @author vsg
 * @CreateDate 2020/5/5上午 10:25:25
 * @UpdateDate 2020/5/5上午 10:25:25
 * @FileName kyc/com.asi.kyc.reg.actions/LoginOTPcheck.java
 * @Purpose
 * 
 */
public class LoginOTPcheck extends AsiAction
{	

	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
	{
   	
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String uid = arg2.getParameter("UID").trim();
		String otpkey = arg2.getParameter("otpkey").trim();
		String input_otp = arg2.getParameter("otp").trim();
		
		KycLogger klg = new KycLogger();
		
		Map ret = null;
		Map out = new HashMap();
		int errtime ;
		
		tx_controller.begin(0);
		try
		{
			ret = klg.getLoginOTP(uid, otpkey);
			errtime = Integer.parseInt(ret.get("LL12").toString());
			
			if(ret != null && !ret.isEmpty() ){
				if(ret.get("LL20").toString().equals(input_otp)){
					out.put("errorCode", "");
					out.put("errorMsg", "OTP驗證成功！");	
				}else{					
					errtime +=1 ;
					klg.updateLoginOTPErrorCount(uid, otpkey, String.valueOf(errtime));
					if(errtime >= Integer.parseInt(SystemParam.getParam("LOGINOTPERRT"))){
						//停用帳號
						stopAccount(uid);

						out.put("errorCode", "6666");
						out.put("errorMsg", "OTP驗證超過錯誤次數！帳戶已被鎖定，請來電0800288068客服人員洽詢！");
												
					}else{
						out.put("errorCode", "9999");
						out.put("errorMsg", "OTP驗證失敗！次數：" + errtime);
					}
				}
			}else{
				out.put("errorCode", "4444");
				out.put("errorMsg", "查無資料！");									
			}
						
			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(out).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		arg1.setNextPage(-1);
	}
	
	/**
	 * 停用帳號
	 * @param uid
	 */
	private void stopAccount(String uid){
		
		String sql = "UPDATE SECAJ SET ERRCNT=0,STATE='Y',STOPCAUSE='1' WHERE USERID=? ";		
 		Connection con = null;
 		
 		try
 		{
 			con = AS400Connection.getOracleConnection();
 			QueryRunner runner = new QueryRunner();
 			runner.update(con, sql, uid);		
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
		
	}
	
}
