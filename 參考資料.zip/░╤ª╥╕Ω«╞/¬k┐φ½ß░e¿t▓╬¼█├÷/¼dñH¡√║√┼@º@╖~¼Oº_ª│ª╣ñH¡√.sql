select * from secak--另一個相關table是LEMP
where userid='19437' and system='LAW' and module='LA1' and function='LA1I080'; 
