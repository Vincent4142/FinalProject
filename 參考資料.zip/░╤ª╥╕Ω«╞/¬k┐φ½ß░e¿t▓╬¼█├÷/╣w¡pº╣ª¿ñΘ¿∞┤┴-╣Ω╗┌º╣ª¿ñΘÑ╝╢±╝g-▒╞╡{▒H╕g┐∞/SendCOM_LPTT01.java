/**
 * 
 */
package com.kyc.schedule;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.dao.PT15PFDao;
import com.asi.kyc.dao.PT16PFDao;
import com.asi.kyc.dao.PT17PFDao;
import com.firstins.CarInsCardService;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.la1.dao.COM_LEMPDao;

/**
 * 法遵後送平台-預計完成日到期後，實際完成日仍未填寫，寄信經辦單位、主管及法遵室追蹤。
 * @author jieyu
 * @Create Date 2019年04月02日
 */
public class SendCOM_LPTT01 extends AsiAction
{	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{	
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String beforeDate = DateUtil.getOffsetDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD,sysdate, -1, false);
		
		try
		{
			tx_controller.begin(0);
			Connection con = tx_controller.getConnection(0);

			//1.由COM_LPTT取得預定完成日已到期，但未填寫時寄完成日之資料
			String sql = "SELECT A.*,B.LDE02,C.CODEDESC AS LPT03Desc, D.CODEDESC AS LPT04Desc, E.LMA08 ";
			sql += "FROM COM_LPTT A ";
			sql += "JOIN COM_LDEP B ON LPT02 = LDE01 ";
			sql += "JOIN SECAZ C ON C.CODETYPE = 'COMPLIANCE' AND C.CODEID = LPT03 ";
			sql += "JOIN SECAZ D ON D.CODETYPE = LPT03 AND D.CODEID = LPT04 ";
			sql += "JOIN COM_LMAN E ON LPT01 = LMA01 ";
			sql += "WHERE LPT06<>0 AND LPT06<="+beforeDate+" AND LPT07=0 AND LPT06 >1100312 ";
			sql += "ORDER BY LPT01,LPT02,LPT03,LPT04 ";
			
			QueryRunner runner = new QueryRunner();
			List list = (List) runner.query(con, sql ,new TrimedMapListHandler());
			
			groupLPT01andLPT02(con, list);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);
	}
	
	private void groupLPT01andLPT02(Connection con, List result) throws SQLException
	{
		if (result == null)
			return;

		String oldx = "";
		List tox = null;
		for (int i = 0; i < result.size(); i++)
		{
			Map m = (Map) result.get(i);
			String newx = String.valueOf(m.get("lpt01"))+String.valueOf(m.get("lpt02"));//後送案號+後送部門
			if (!oldx.equals(newx))
			{
				sendMail(con, tox);
				tox = new LinkedList();
				oldx = newx;
			}
			tox.add(new HashMap(m));
		}
		sendMail(con, tox);
	}

	/**
	 * 發送mail
	 * @param data	 mail內文明細資料
	 */
	private void sendMail(Connection con, List data)
	{
		if (data == null || data.size() == 0)
			return;
		
		for (int i = 0; i < data.size(); i++)
		{
			Map t = (Map) data.get(i);
			t.put("a001", String.valueOf(t.get("lpt01")));// 後送案號
			t.put("a002", String.valueOf(t.get("lde02")));// 權責部門
			t.put("a003", String.valueOf(t.get("lpt03desc")));// 後送項目
			t.put("a004", String.valueOf(t.get("lpt04desc")));// 後送檢視項次
			t.put("a005", FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, String.valueOf(t.get("lpt06"))));// 預定完成日期
			t.put("a006", FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, String.valueOf(t.get("lpt07"))));// 實際完成日期
		}

		try
		{
			Map m = (Map) data.get(0);
			List<?> sendEmailList = null;
			Employee emp = null;
			COM_LEMPDao COM_LEMPDao = new COM_LEMPDao(con);
			
			sendEmailList = COM_LEMPDao.getEmailList(m.get("lpt02").toString(), m.get("lma08").toString());
			String recipient = null;
			
			for (int j = 0; j < sendEmailList.size(); j++)
			{
				Map<?, ?> map = (Map<?, ?>)sendEmailList.get(j);
				recipient = map.get("lem01").toString();		
				emp = Employee.getEmployee(recipient);
				String email = emp.getEmail();
				System.out.println(email);
				sendMail2(email, data);
			}
			
			if (emp != null){
				String email = emp.getDept().getBoss().getEmail();
				System.out.println(email);
				sendMail2(email, data);
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * 寄送Mail
	 * @param email
	 * @param data
	 */
	public void sendMail2(String email, List data)
	{
		try
		{
			Map m = (Map) data.get(0);
			
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
			ve.init();
			
			Template t = ve.getTemplate("mail/web/COM_LPTT01.html", "utf-8");
			VelocityContext context1 = new VelocityContext();
			context1.put("dtitle", "【部門檢視項次】預計完成日已到期，仍未填寫實際完成日");
			context1.put("detail", data);
			StringWriter sw = new StringWriter();
			t.merge(context1, sw);

			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setSubject("法令遵循室後送案件通知 - "+m.get("lpt03desc")+"(" + m.get("lpt01") + ")");
			kmu.setMessage(sw.getBuffer().toString());
			kmu.addTo(email);
			
			String[] cc = new String[1];
			cc[0] = "compliance@firstins.com.tw";
			kmu.addCc(cc);
			
			kmu.sendMail();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}
