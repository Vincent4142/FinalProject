SELECT lpd02, lde02, 
sum(case when floor(com_lman.crtdt / 10000) = 109 then 1 else 0 end) LAWCNT1, 
sum(case when floor(com_lman.crtdt / 10000) = 110 then 1 else 0 end) LAWCNT2, 
sum(case when floor(com_lman.crtdt / 10000) = 111 then 1 else 0 end) LAWCNT3, 
sum(case when floor(com_lman.crtdt / 10000) = 112 then 1 else 0 end) LAWCNT4, 
sum(case when floor(com_lman.crtdt / 10000) = 113 then 1 else 0 end) LAWCNT5 
FROM com_lman INNER JOIN com_lpde ON lma01 = lpd01 inner join com_ldep on lpd02 = lde01 
WHERE (case when (LPD08 is null or LPD08 = 0) then case when (LMA09 < 1100119 and LPD04 < 1100119) then 1 else 0 end else case when ((LPD04 < LPD05 AND LMA09 < LPD05) OR LPD05=0 OR LPD05 is null) then 1 else 0 end end = 1) 
and com_lman.crtdt between 1090601 and 1100119 
and lpd02 like '%' 
and lpd07 is null
Group By lpd02, lde02 Order By lpd02;




SELECT lma01,lma06, lma09, case when lpd07='Y' then '符合' else case when lpd07='N' then '退件' else ' ' end end as lpd07, lpd08, lpd09 
FROM com_lman 
INNER JOIN com_lpde ON lma01 = lpd01 
INNER JOIN com_ldep on lpd02 = lde01 
WHERE (case when (LPD08 is null or LPD08 = 0 or lpd07 = 'N') then case when (LMA09 < 1100119 and LPD04 < 1100119) then 1 else 0 end else case when ((LPD04 < LPD05 AND LMA09 < LPD05) OR LPD05=0 OR LPD05 is null) then 1 else 0 end end = 1) 
AND floor(com_lpde.crtdt / 10000) = 109 
AND com_lpde.crtdt between 1090601 and 1100119 
AND lpd02 like '10' 
AND lpd07 is null  
ORDER BY lma01;