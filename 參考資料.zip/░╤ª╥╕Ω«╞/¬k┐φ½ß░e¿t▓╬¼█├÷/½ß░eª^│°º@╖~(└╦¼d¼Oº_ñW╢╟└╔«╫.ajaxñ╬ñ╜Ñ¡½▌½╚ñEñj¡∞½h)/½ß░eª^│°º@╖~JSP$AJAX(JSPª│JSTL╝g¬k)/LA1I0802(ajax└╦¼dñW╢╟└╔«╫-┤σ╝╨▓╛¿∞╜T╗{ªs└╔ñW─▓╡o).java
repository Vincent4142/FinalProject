package com.kyc.la1.actions;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.sec.actions.WebAction;

/**
 * 即時判斷是否有上傳檔案
 * 
 */
public class LA1I0802 extends WebAction{
	public void doProcess(ActionMapping arg0, AsiActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		String lma01=request.getParameter("lma01");
		String lpd02=request.getParameter("lpd02");
		String lma07=request.getParameter("lma07");
		String lpt04=request.getParameter("lpt04");
		String[] s1=lma01.split(",");
		String[] s2=lpd02.split(",");
		String[] s3=lma07.split(",");
		String[] s4=lpt04.split(",");
		boolean flag=true;
		
		for(int i=0;i<s1.length;i++){
			Map m=searchFile(s1[i],s2[i],s3[i],s4[i]);
			if(m==null){
				flag=false;
				break;
			}
		}
		try{						
			PrintWriter out = response.getWriter();		
			if(flag){
				out.write("Y");
			}
			else{
				out.write("N");
			}
			out.flush();
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		

		form.setNextPage(-1);
	}
	
	public Map searchFile(String lma01,String lpd02,String lma07,String lpt04){ 
		Map m=null;
		try {
			String sql="select * from COM_LUPL where LUP01=? and LUP02=? and LUP03=? and LUP04=? ";
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			//設定?的參數
			Object[] params = {lma01,lpd02,lma07,lpt04};
			m=(Map) qr.query(tx_controller.getConnection(0), sql,params,new TrimedMapHandler());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return m;
	}

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
	{
		AsiActionForm form1 = (AsiActionForm) arg1;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(5);
		}
	}
}
