package com.kyc.schedule;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.poi.util.IOUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * 寄發EDM
 * 每次固定筆數發送，寄送後記錄Log，寄過不再發送
 * @author vsg
 *
 */
public class SendEDM extends AsiAction {
	
	private String sendMaxRows = SystemParam.getParam("EDMMAXROWS");//EDM發送最大筆數
	int logcount = 0;
	long strtime,endtime ;
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException {
		try {
			
			//取得促銷專案list
			List pjlist = getProjectList();
			List ret = null;
			
			if(pjlist != null && !pjlist.isEmpty())
			{
				for (int i = 0; i < pjlist.size(); i++) {
					Map mp = (Map) pjlist.get(i);
					
					String projectid = mp.get("EDM01").toString();//專案代碼
					String subject = mp.get("EDM02").toString();//專案主旨
					String template = mp.get("EDM06").toString();//電子報模板
					
					ret = getDetail(projectid , sendMaxRows);//讀取應發送的資料
					Map mpd = null;
					String eml02 = "";
					String eml03 = "";
					
					if(ret != null && !ret.isEmpty()){
						
						strtime = System.currentTimeMillis();
						for (int j = 0; j < ret.size(); j++) {
							mpd = (Map) ret.get(j);
							eml02 = mpd.get("C101").toString();
							eml03 = mpd.get("C113") != null ? mpd.get("C113").toString() : "";
							
							if(!eml03.equals("")){
								sendEDMEmail(request, eml03 , template ,subject);
								
								insertKYCEDMLOG(projectid, eml02, eml03);
								
								logcount++;

							}
						}
						endtime = System.currentTimeMillis();
						
						sendLogEmail(request, logcount, strtime, endtime);
					}
					
				}
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		arg1.setNextPage(-1);
	}

	/**
	 * 取出email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		List rs = null;
		String[] email = null;

		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}

    /**
     * 寄發LOG通知
     * @param request
     * @param counts 筆數
     * @param strtime 開始時間
     * @param endtime 結束時間
     */
    private void sendLogEmail(HttpServletRequest request , int counts , long strtime , long endtime){
    	
    	try {
    		
			String ec_maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
			String[] getecemail = getAuthManList(ec_maillist);//取得人員email
			
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String systime = DateUtil.getSysTime();
			
			KycMailUtil kmu = new KycMailUtil();
			kmu.setSubject("EDM發送處理Log： "+ sysdate + " " + systime );
			kmu.setMessage(sysdate + " " + systime + " EDM發送筆數：共 " + counts + " 筆<br>" + "執行時間，共計花費: " + (endtime - strtime)/1000 + " 秒");			
			kmu.addTo(getecemail);
			
			kmu.sendMail();

		} catch (Exception e) {
			e.printStackTrace();
		}
    }

	
	/**
	 * 以系統日抓取EDM發送設定檔中的檔次資料
	 * @return
	 * @throws SQLException
	 * @throws AsiException
	 */
	private List getProjectList() throws SQLException, AsiException 
	{
		String sysDate = DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false);
		
		String sql = "SELECT * FROM KYCEDM WHERE ? BETWEEN EDM03 AND EDM04 ";	
		
		Connection con = null;
		List rs = null;
		try {
			
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(con, sql,sysDate, new TrimedMapListHandler());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}

		return rs;
	}
	
	
	/**
	 * 查詢要寄發的客戶名單，並依專案串記錄檔確認是否發過信件
	 * @param projectid 促銷專案代號
	 * @param maxrows 最大筆數
	 * @return
	 * @throws SQLException
	 * @throws AsiException
	 */
	private List getDetail(String projectid ,String maxrows) throws SQLException, AsiException 
	{
		
		String sql = "SELECT * FROM KYCREG "
				   + "LEFT JOIN IC01PF ON C101 = RG01 "
				   + "LEFT JOIN IC01PFA ON C101 = C01A01 "
				   + "LEFT JOIN KYCEDMLOG ON EML01=? AND EML02 = RG01 "
				   + "WHERE RG14 <> 0 "
//				   + "AND RG05 IN ('hitomi2018@firstins.com.tw','tsai@firstins.com.tw','arron.yeh@firstins.com.tw') "//測試用
//				   + "AND RG01='P224019542' "//測試用
				   + "AND EML02 IS NULL "
				   + "AND (C01A16 IS NULL OR C01A16='Y') "//有訂閱電子報或沒有值的都可發
				   + "AND ROWNUM <= ? ";
		//測試機才要有此條件
		if (!SystemParam.getParam("ENV").equals("KYC")){
			sql+="AND RG01='A127834734' ";
		}
		
		String[] args = new String[2];
		args[0] = projectid;
		args[1] = maxrows;
		
		Connection con = null;
		List rs = null;
		
		try {
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(con, sql,args, new TrimedMapListHandler());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}

		return rs;
	}
	
	/**
	 * 寫入電子報發送log
	 * @param eml01
	 * @param eml02
	 * @param eml03
	 */
	private void insertKYCEDMLOG(String eml01 , String eml02 , String eml03){
		
		String sysDate = DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = "INSERT INTO KYCEDMLOG "
				+ "(EML01,EML02,EML03,EML04,EML05,EML06,EML07,EML08,EML09,EML10,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) "
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		
		String[] args = new String[16];
		args[0] = eml01;
		args[1] = eml02;
		args[2] = eml03;
		args[3] = "Y";
		args[4] = sysDate;
		args[5] = systime;
		args[6] = "0";
		args[7] = "";
		args[8] = "";
		args[9] = "";
		args[10] = sysDate;
		args[11] = systime;
		args[12] = "KYC";
		args[13] = "0";
		args[14] = "0";
		args[15] = "";
		
		Connection con = null;
		
		try {
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			runner.update(con, sql, args);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}

	}
	

    /**
     * 發送信件
     * @param request
     * @param email
     * @param template
     * @param subject
     * @return
     */
    private boolean sendEDMEmail(HttpServletRequest request , String email ,String template , String subject){
    	boolean isSentOK = false;
		try
		{
			String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 電商服務電話
			String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 電商傳真電話
			
			//傳入外部連結URL，改用以下讀取方式
            BufferedInputStream input = new BufferedInputStream(new URL(template).openStream());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            IOUtils.copy(input, baos);
            byte[] bytes = baos.toByteArray();
            Reader templateReader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(bytes), "utf-8"));

			VelocityContext context1 = new VelocityContext();
			context1.put("ecom_tel", ecom_tel);
			context1.put("ecom_fax", ecom_fax);
			
			StringWriter sw = new StringWriter();
			Velocity.evaluate(context1, sw, "log tag name", templateReader);		
			
			KycMailUtil kmu = new KycMailUtil();
			kmu.setSubject(subject);
			kmu.setMessage(sw.getBuffer().toString());		

			//正式機直接寄客戶
			if (SystemParam.getParam("ENV").equals("KYC")){
				kmu.addTo(email);
			}
			//測試機寄給我們自己
			else{
				String ec_maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
				String[] getecemail = getAuthManList(ec_maillist);//取得人員email
				kmu.addTo(getecemail);
			}
			
			kmu.sendMail();
			
			isSentOK = true;
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return isSentOK;
    }

	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1,
			AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws IOException, ServletException
	{
		return null;
	}

}
