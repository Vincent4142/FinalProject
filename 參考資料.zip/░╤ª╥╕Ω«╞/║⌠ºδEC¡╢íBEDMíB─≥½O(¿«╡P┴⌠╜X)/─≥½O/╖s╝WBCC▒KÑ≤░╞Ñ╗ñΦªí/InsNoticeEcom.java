package com.kyc.schedule;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * @author 	：vsg
 * 建立日期	：2019/07/30
 * 功能說明	：電商公代號10,30,45,660日續保/5,10日斷保通知   
 * actioncode:1: 10天前續保通知-車險
 *            2: 10天前續保通知-火險
 *            3: 30天前續保通知-車險
 *            4: 30天前續保通知-火險
 *            5: 45天前續保通知-車險
 *            6: 45天前續保通知-火險
 *            7: 60天前續保通知-車險
 *            8: 60天前續保通知-火險
 *            11: 5天斷保通知-車險
 *            12: 5天斷保通知-火險
 *            13: 10天斷保通知-車險
 *            14: 10天斷保通知-火險
 * 異動註記	：
 */
public class InsNoticeEcom extends AsiAction
{
	private String sendDay = "";   
	private String continueDate_10 = "";
	private String continueDate_30 = "";
	private String continueDate_45 = "";
	private String continueDate_60 = ""; 
	private String expireDate_5 = "";
	private String expireDate_10 = "";
	
	private String template_c = SystemParam.getParam("ECOM_NOTICE_C");//續保/斷保通知-車險樣板
	private String template_f = SystemParam.getParam("ECOM_NOTICE_F");//續保/斷保通知-火險樣板

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException
	{
		String tdate = request.getParameter("date") ;
		
		if(tdate == null)
			sendDay = DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false);
		
		//續保通知日期，系統日+10天
		continueDate_10 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, 10, false);
		//續保通知日期，系統日+30天
		continueDate_30 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, 30, false);
		//續保通知日期，系統日+45天
		continueDate_45 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, 45, false);
		//續保通知日期，系統日+60天
		continueDate_60 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, 60, false);
		//斷保通知日期，系統日-5天
		expireDate_5 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, -5, false);
		//斷保通知日期，系統日-10天
		expireDate_10 = DateUtil.getOffsetDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, sendDay, -10, false);

		int actioncode = arg1.getActionCode();
		
		Connection con = null;
		try
		{
			con = AS400Connection.getConnection();
			
			// 車險查詢
			String sql = "SELECT DISTINCT C113,C206,C245 "
					+ "FROM IC02PF "
					+ "LEFT JOIN IC01PF ON C101 = C201 "
					+ "LEFT JOIN PT22PF ON C202 = T2201 "
					+ "RIGHT JOIN PT40PF ON T4001='C' AND T4002=C210 AND T4003 IN ('6666','6688') "
					+ "LEFT JOIN PT15PF ON T1504=C202 "
					+ "WHERE C203 ='A' AND C213 ='96370' AND C221='N' AND TRIM(C223) <>'Y' AND C206 = ? ";//C221為續保狀態，若有新件以本單為續保單號，此處為Y，即為已續保，反之為N則為尚未續保件；C223為過戶註記，不含過戶件
			// 火險查詢
			if(actioncode == 2 || actioncode == 4  || actioncode == 6 || actioncode == 8 || actioncode == 12 || actioncode == 14){			
				sql = "SELECT DISTINCT T1516 "
					+	"FROM IC02PF "
					+	"LEFT JOIN IC01PF ON C101 = C201 "
					+	"LEFT JOIN PT22PF ON C202 = T2201 "
					+	"RIGHT JOIN PT40PF ON T4001='F' AND T4002=C210 AND T4003 IN ('6666','6688') "
					+	"LEFT JOIN PT15PF ON T1504=C202 "
					+	"WHERE C203 ='F' AND C213 ='96370' AND TRIM(C223) <>'Y' AND C206 = ? ";  //火險正式
//					+	"WHERE C203 ='F'";   //火險測試
			}
			String[] arg = new String[1];
			if(actioncode == 1 || actioncode == 2)//10天前續保通知
				arg[0] = continueDate_10;
			else if(actioncode == 3 || actioncode == 4)//30天前續保通知
				arg[0] = continueDate_30;
			else if(actioncode == 5 || actioncode == 6)//45天前續保通知
				arg[0] = continueDate_45;
			else if(actioncode == 7 || actioncode == 8)//60天前續保通知
				arg[0] = continueDate_60;
			else if(actioncode == 11 || actioncode == 12)//5天斷保通知
				arg[0] = expireDate_5;
			else if(actioncode == 13 || actioncode == 14)//10天斷保通知
				arg[0] = expireDate_10;
			
			QueryRunner runner = new QueryRunner();
			List<?> list = (List<?>) runner.query(con, sql,arg, new TrimedMapListHandler()); //正式用
//			List<?> list = (List<?>) runner.query(con, sql, new TrimedMapListHandler()); //火險測試用
			if(list != null && list.size() > 0)
				sendMail(request , list , actioncode);
			
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		arg1.setNextPage(-1);
	}


	/**
	 * 發送mail
	 * 
	 * @param data mail內文明細資料
	 */
	private void sendMail(HttpServletRequest request , List<?> data , int actioncode)
	{
		if (data == null || data.size() == 0)
			return;
		else{
			try
			{
				String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
				
				VelocityEngine ve = new VelocityEngine();
				ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
				ve.init();
				URL templateURL = null;
				
				if(actioncode == 1 || actioncode == 3 || actioncode == 5 || actioncode == 7 || actioncode == 11 || actioncode == 13)  //續保/斷保通知-車險
					templateURL = new URL(template_c);
				else if(actioncode == 2 || actioncode == 4 || actioncode == 6 || actioncode == 8 || actioncode == 12 || actioncode == 14)  //續保/斷保通知-火險
					templateURL = new URL(template_f);
				
				for (int i = 0; i < data.size(); i++) {
					VelocityContext context = new VelocityContext();
					StringWriter sw = new StringWriter();
					BufferedReader input = null;
					
					Map mp = (Map) data.get(i);
					String sendEmail = "";
					if(actioncode == 1 || actioncode == 3 || actioncode == 5 || actioncode == 7 || actioncode == 11 || actioncode == 13)  //續保/斷保通知-車險
					{
						String number = mp.get("C245").toString();
						String car_number =number.substring(0,1)+"*"+number.substring(2,number.length()-2)+"*"+number.substring(number.length()-1);
						String end_year =mp.get("C206").toString().substring(0, 3);
						String end_mounth =mp.get("C206").toString().substring(3, 5);
						String end_date =mp.get("C206").toString().substring(5, 7);
						context.put("car_number", car_number);//加入車牌
						context.put("end_year", end_year);//加入到期年
						context.put("end_mounth", end_mounth);//加入到期月
						context.put("end_date", end_date);//加入到期日
					}
								
					input = new BufferedReader(new InputStreamReader(templateURL.openStream()));
					context.put("ecom_fax", ecom_fax);
										
					ve.evaluate(context, sw, "car log", input);

					KycMailUtil kmu = new KycMailUtil();
					kmu.setFrom("admin@firstins.com.tw");
					kmu.setMessage(sw.getBuffer().toString());
					
					if(actioncode == 1 || actioncode == 3 || actioncode == 5 || actioncode == 7)			
						kmu.setSubject("您好：汽機車保險到期通知~網路投保第一省(汽車強制最高省360元)");//續保標題-車險
					else if(actioncode == 11 || actioncode == 13)
						kmu.setSubject("您好：汽機車保險斷保通知~網路投保第一省(汽車強制最高省360元)");//斷保標題-車險
					else if(actioncode == 2 || actioncode == 4 || actioncode == 6 || actioncode == 8)
						kmu.setSubject("您好：住宅火災及地震基本保險到期通知~線上投保享第一優惠");//續保標題-火險					
					else if(actioncode == 12 || actioncode == 14)
						kmu.setSubject("您好：住宅火災保險斷保通知~保費享75折優惠(不含地震險)");//斷保標題-火險
					
					String ec_mailcclist = CodeUtil.getCodeList(servlet, request, "ECOM-CC");//代碼檔設定之電商寄送副本人員
					String[] ccemail = getAuthManList(ec_mailcclist);//取得人員email
					if(!SystemParam.getParam("ENV").equals("KYC")){//測試環境				
						//取得電商窗口及主管
						String ec_maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
						String[] getecemail = getAuthManList(ec_maillist);//取得人員email
						
						kmu.addTo(getecemail);
//						kmu.addTo("w92532@firstins.com.tw");  //自己測試用
						kmu.addBcc(ccemail);
//						String[] test={"w92532@gmail.com"};   //自己測試用
//						kmu.addBcc(test);                     //自己測試用
						
						kmu.sendMail();
					}	
					else
					{
						//判斷客戶Email是否有值，先以交易資料檔PT15PF為主，若無再以客戶資料檔IC01PF，若都無則不寄發
						if(mp.get("T1516") != null && !mp.get("T1516").equals("")){
							sendEmail = mp.get("T1516").toString();
						}
						else{
							if(mp.get("C113") != null && !mp.get("C113").equals(""))
								sendEmail = mp.get("C113").toString();
						}
						//有Email時才寄發
						if(!sendEmail.equals("")){
							kmu.addTo(sendEmail);
							kmu.addBcc(ccemail);
							kmu.sendMail();
						}
					}						
					
				}
							
			} catch (Exception e){
				e.printStackTrace();
			}

		}
	}

	
	/**
	 * 取出人員帳號檔email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		List<?> rs = null;
		String[] email = null;
		Connection con = null;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List<?>) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}


	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1,
			AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws IOException, ServletException
	{
		return null;
	}
}
