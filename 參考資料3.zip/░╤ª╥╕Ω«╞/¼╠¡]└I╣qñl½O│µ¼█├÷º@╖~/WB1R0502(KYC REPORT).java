/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServlet;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.exception.AsiException;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MathUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.TrimedMapListHandler;


/**
 * 旅平險保單產生程式 - 組TableModel明細資料頁 - 被保險人明細
 * @author vsg
 * @CreateDate 2020/08/03 
 * @Purpose
 * 
 */
public class WB1R0502
{
	private TableModel tm = null;

	private String insNumber = "";

	private Connection conn = null;

	private Locale locale = null;

	private HttpServlet servlet = null;

	private Vector rows = null;

	private static Log logger = null;
	
	private String[] pa_spac_name;

	public WB1R0502(String insNumber, Connection conn, Locale locale, HttpServlet servlet)
	{
		this.insNumber = insNumber;
		this.conn = conn;
		this.locale = locale;
		this.servlet = servlet;
		rows = new Vector(); // 存放每一行的資料陣列
		logger = LogFactory.getLog(WB1R0502.class);
	}

	public TableModel getTableModel(String nature) throws AsiException
	{
		final Vector header = new Vector();// 明細欄位的key值
		for (int i = 1; i <= 25; i++)
		{
			for (int k = 1; k <= 10; k++)
			{
				header.add("D" + i + "_" + k);
			}
		}
		final int colcount = header.size(); // 明細欄位的數量
		
		if(nature.indexOf("VI") != -1){
			getVIDetailByInsured(colcount, nature);
		}
		else{
			getDetailByInsured(colcount, nature);
		}		
		tm = new DefaultTableModel(rows, header);
		return tm;
	}

	/**
	 * 以保單取得特定事故項目
	 * @param insno
	 * @return
	 */
	private List getTypeCodeList(String insno){
		
		String sql = "SELECT DISTINCT(T2506) T2506,T2507 FROM PT25PF WHERE T2501= ? AND T2506 NOT IN ('OHS') ";//排除海突項目查詢特定事故 

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, insno, new TrimedMapListHandler());			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}
	
	/**
	 * 取得VI被保險人明細
	 * 
	 * @param colcount
	 * @throws SQLException
	 */
	public void getVIDetailByInsured(int colcount, String nature) throws AsiException
	{
		int people_counts = getPT24PF(insNumber);//投保人數

		String sql = "SELECT T2101,T2136,T2137,T2104,T2105,T2106,T2109,T2110,"
					+"T2115,T2116,T2140,T2142,T2143,T2111,T2113,T2114,T2131,T2132,T2127,T2144,T2145,T2147,T2405,T2406,T2407,T2408,T2447,"
					+"C213,C231,ZN04,SUBSTR(FBZZPF.ZZ03,18,8) AS ZZ03 "
					+"FROM IC02PF "
					+"LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
					+"LEFT JOIN PT24PF ON T2101=T2401 "
					+"LEFT JOIN FBZNPF ON ZN01='E' AND ZN02=SUBSTR(C202,1,4) "
					+"LEFT JOIN FBZZPF ON ZZ01='BO' AND ZZ02=ZN04 "
					+"WHERE C202='"+nature+"'";
		
		Statement stmt = null;
		ResultSet rs = null;
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			int count = 0;
			Vector vec = new Vector();

			
			String[] key = new String[10];
			while (rs.next())
			{
				count++;
				
				//判斷何種方案才能抓對應的細項保費
				int type=Integer.parseInt(rs.getString("T2144"))/1000;//type的值就是方案編號
				String VHI1 = type == 1 ? "1,000" : type == 2 ? "2,000" : "3,000";
				String VHI2 = type == 1 ? "1,000" : type == 2 ? "2,000" : "3,000";
				String VHI3 = type == 1 ? "5,000" : type == 2 ? "10,000" : "15,000";
				String VHI4 = type == 1 ? "2,000" : type == 2 ? "2,000" : "3,000";
				
				//健康險保費 T2447為每一人保費
				int t2447 = Integer.parseInt(rs.getString("T2447"));
				
				//附加險保費T2147 除以PT24PF抓的筆數(人數)為每1人保費
				int insurance = Integer.parseInt(rs.getString("T2147"))/people_counts;
				
				key[0] = rs.getString("T2405");//SN
				key[1] = rs.getString("T2406").trim();//被保險人
				key[2] = rs.getString("T2408");//生日
				key[3] = rs.getString("T2407").substring(0, 3) + "****" + rs.getString("T2407").substring(7, rs.getString("T2407").length());//身份證號碼
				key[4] = FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString("T2145")),0);//殯葬費用保險金
				key[5] = VHI1;//一般住院日額保險金
				key[6] = VHI2;//加護病房或隔離病房住院日額保險金
				key[7] = VHI3;//住院關懷保險金
				key[8] = VHI4;//出院慰問保險金
				key[9] =FormatUtil.getDecimalFormat(t2447 + insurance , 0);//每人保險費，主險+附件保費
				
				getDetailByCategory(vec,  key);
				//每25筆加1頁
				if(count%25==0)
				{
					rows.add(vec);
					vec = new Vector();
				}				
			}

			//若筆數不滿一頁的25筆，最後補一筆空白
			if(count%25 != 0)
			{					
				vec.add("");
				vec.add("(以下空白)");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
			}

			if(count%10!=0)
			{
				rows.add(vec);
			}
		}
		catch (SQLException e)
		{
			logger.error("查詢資料時發生錯誤", e);
		}
		finally
		{
			closeResultSet(rs, stmt);
		}
	}
	
	/**
	 * 取得被保險人明細
	 * 
	 * @param colcount
	 * @throws SQLException
	 */
	public void getDetailByInsured(int colcount, String nature) throws AsiException
	{
		List typelist = getTypeCodeList(insNumber);//
		int people_counts = getPT24PF(insNumber);//投保人數
		
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT T2405,T2406,T2407,T2408,T2424,T2425,T2427,T2428,T2430, ");
		buf.append("A0.T2508 OHS_AMOUNT,A0.T2509 OHS_PREMIUM, ");
		
		if(typelist != null && !typelist.isEmpty()){
			pa_spac_name = new String[typelist.size()];
			
			for (int i = 1; i <= typelist.size(); i++) {			
				Map mp = (Map) typelist.get(i-1);
				pa_spac_name[i-1] = mp.get("T2506").toString() + mp.get("T2507").toString();
				
				buf.append("A").append(i).append(".T2508 AS ").append(mp.get("T2506").toString()).append(mp.get("T2507").toString()).append("_AMOUNT,")
				.append("A").append(i).append(".T2509 AS ").append(mp.get("T2506").toString()).append(mp.get("T2507").toString()).append("_PREMIUM ");
				if(i != typelist.size())
					buf.append(",");
			}
			
		}
		
		buf.append("FROM PT24PF ");
		buf.append("LEFT JOIN PT25PF A0 ON A0.T2501=T2401 AND A0.T2502=T2402 AND A0.T2504=T2404 AND A0.T2505=T2405 AND A0.T2506 = 'OHS' ");
		
		if(typelist != null && !typelist.isEmpty()){
			for (int i = 1; i <= typelist.size(); i++) {			
				Map mp = (Map) typelist.get(i-1);
				String type = mp.get("T2506").toString() + mp.get("T2507").toString();
				buf.append("LEFT JOIN PT25PF A").append(i).append(" ON ").append("A")
				.append(i).append(".T2501=T2401 AND A")
				.append(i).append(".T2502=T2402 AND A")
				.append(i).append(".T2504=T2404 AND A")
				.append(i).append(".T2505=T2405 AND A")
				.append(i).append(".T2506||A")
				.append(i).append(".T2507 = '").append(type).append("' ");			
			}
		}
		
		buf.append("WHERE T2401 = '").append(insNumber).append("' ");
		String sql = buf.toString();
		Statement stmt = null;
		ResultSet rs = null;
		try
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
	
			int count = 0;
			Vector vec = new Vector();

			int TPLTII_Per = getTravelIns(insNumber, people_counts);//取得個責保費、旅遊不便保費
			
			String[] key = new String[11];
			while (rs.next())
			{
				count++;
				
				key[0] = rs.getString("T2405");//SN
				key[1] = rs.getString("T2406");//被保險人
				key[2] = rs.getString("T2408");//生日
				key[3] = rs.getString("T2407").substring(0, 3) + "****" + rs.getString("T2407").substring(7, rs.getString("T2407").length());//身份證號碼
				key[4] = FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString("T2424")),0);//身故保額
				key[5] = FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString("T2425")),0);//醫療保額
				key[6] = rs.getString("OHS_AMOUNT") != null ? FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString("OHS_AMOUNT")),0) : "";//海突保額
				key[7] = pa_spac_name.length >= 1 ? FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString(pa_spac_name[0] + "_AMOUNT")),0) : "";//特定1保額
				key[8] = pa_spac_name.length >= 2 ? FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString(pa_spac_name[1] + "_AMOUNT")),0) : "";//特定2保額
				
				//每人保費加總：身故+醫療+海突+特定1+特定2+個責+旅遊不便
				double pa_spac_premium_1 = pa_spac_name.length >= 1 ? MathUtil.getDouble(rs.getString(pa_spac_name[0] + "_PREMIUM")) : 0 ;
				double pa_spac_premium_2 = pa_spac_name.length >= 2 ? MathUtil.getDouble(rs.getString(pa_spac_name[1] + "_PREMIUM")) : 0 ;
				
				double premium_totall = MathUtil.getDouble(rs.getString("T2430")) 
									+ MathUtil.getDouble(rs.getString("OHS_PREMIUM")) 
									+ pa_spac_premium_1
									+ pa_spac_premium_2
									+ MathUtil.getDouble(String.valueOf(TPLTII_Per));
				
				key[9] = FormatUtil.getDecimalFormat(premium_totall , 0);
				key[10] = pa_spac_name.length >= 3 ? FormatUtil.getDecimalFormat(MathUtil.getDouble(rs.getString(pa_spac_name[2] + "_AMOUNT")),0) : "";//特定3保額
				
				getDetailByCategory(vec,  key);
				//每25筆加1頁
				if(count%25==0)
				{
					rows.add(vec);
					vec = new Vector();
				}				
			}

			//若筆數不滿一頁的25筆，最後補一筆空白
			if(count%25 != 0)
			{					
				vec.add("");
				vec.add("(以下空白)");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
				vec.add("");
			}

			if(count%11!=0)
			{
				rows.add(vec);
			}
		}
		catch (SQLException e)
		{
			logger.error("查詢資料時發生錯誤", e);
		}
		finally
		{
			closeResultSet(rs, stmt);
		}
	}

	/**
	 * 查詢被保險人筆數
	 * @param insno
	 * @return
	 */
	private int getPT24PF(String insno){		
		String sql = "SELECT * FROM PT24PF WHERE T2401=? ";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, insno, new TrimedMapListHandler());			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret.size();
	}
	
	/**
	 * 取得個人責任及不便險保費每人保費
	 * 
	 * @return 
	 * @throws SQLException
	 */
	private int getTravelIns(String insno ,int people) throws SQLException
	{
		String sql = "SELECT T2231 FROM PT22PF WHERE T2201='" + insNumber + "' AND T2226 IN('TPL','TII') AND T2231<>0 ORDER BY T2203";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		
		int total = 0;

		while (rs.next())
		{	
			total += Integer.parseInt(String.valueOf(rs.getInt("T2231")));
		}
		
		return total / people;
	}

	
	/**
	 * 取得被保險人保險的種類明細
	 * @param vec
	 * @param travel
	 * @param key
	 * @throws AsiException
	 */
	private void getDetailByCategory(Vector vec, String[] key) throws AsiException
	{
		
		vec.add(key[0]);
		vec.add(key[1]);
		vec.add(key[2]);
		vec.add(key[3]);
		vec.add(key[4]);
		vec.add(key[5]);
		vec.add(key[6]);
		vec.add(key[7]);
		vec.add(key[8]);
		vec.add(key[9]);
		if(key.length > 10){
			vec.add(key[10]);
		}				
	}

	/**
	 * 關閉資料物件
	 * 
	 * @param stmt
	 * @param rs
	 */
	private static void closeResultSet(ResultSet rs, Statement stmt)
	{
		if (rs != null)
		{
			try
			{
				rs.close();
				stmt.close();
			}
			catch (SQLException sqle)
			{
				logger.error("關閉資料物件錯誤", sqle);
			}
		}
	}

	/**
	 * @return the pa_spac_name
	 */
	public String[] getPa_spac_name() {
		return pa_spac_name;
	}

	/**
	 * @param pa_spac_name the pa_spac_name to set
	 */
	public void setPa_spac_name(String[] pa_spac_name) {
		this.pa_spac_name = pa_spac_name;
	}
	
}
