select * from
(
select LL05,LL10,LL19,LL17,count(LL05) frequency
from KYCLLOG 
where LL19='ID試算保費' and LL17='PT' and LL10=1100310 
group by LL05,LL10,LL19,LL17
)
where frequency >=10;