package com.kyc.schedule;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * 網投ID試算保費一天達10次(含)以上通知
 * @author Vincent
 *
 */
public class SendPremiumTrialCalculation extends AsiAction
{
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		//系統今日
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);		
		//排程抓前一天的紀錄寄送
		sysdate = DateUtil.getOffsetDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, sysdate, -1, false);
		
		StringBuffer sql=new StringBuffer();
		sql.append("select * from ");
		sql.append("(select LL05,LL10,LL19,LL17,count(LL05) frequency ");
		sql.append("from KYCLLOG ");
		sql.append("where LL19='ID試算保費' and LL17='PT' and LL10=? ");
		sql.append("group by LL05,LL10,LL19,LL17) ");
		sql.append("where frequency >=10");
		String s=sql.toString();
		
		Connection con = null;
		List data=null;
		try
		{			
			tx_controller.begin(0);
			con=tx_controller.getConnection(0);	
			QueryRunner qr=new QueryRunner();

			String[] param={sysdate};
			data = (List) qr.query(con, sql.toString(),param, new TrimedMapListHandler());
			
			if(data != null && data.size() != 0){
				sendMail(servlet,request,data);
			}					
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);		
	}
	
	//送出郵件方法
	private void sendMail(HttpServlet servlet, HttpServletRequest request,List data)
	{
		try
		{
			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");//寄件者
			
			StringBuffer context=new StringBuffer();
			context.append("<html><head></head><body><table style='border:3px #cccccc solid;' cellpadding='10' border='1'>");
			context.append("<tr><td>ID</td><td>日期</td><td>動作說明</td><td>試算保費次數</td></tr>");
			for(int i=0;i<data.size();i++){
				Map m = (Map) data.get(i);
				context.append("<tr><td>");
				context.append(m.get("LL05")+"</td>");
				context.append("<td>");
				context.append(m.get("LL10")+"</td>");
				context.append("<td>");
				context.append(m.get("LL19")+"</td>");
				context.append("<td>");
				context.append(m.get("frequency")+"</td></tr>");
			}
			
			context.append("</table></body></html>");
			
			kmu.setMessage(context.toString());//內容
			kmu.setSubject("網投ID試算保費一天達10次(含)以上通知");//標題
			
			String maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口，記得到後台加代碼
			String[] getemail = getAuthManList(maillist);//取得人員email
//			kmu.addTo("w92532@firstins.com.tw");//測試用
			kmu.addTo(getemail);//正式用
			kmu.sendMail();
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * 取出人員帳號檔email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		List<?> rs = null;
		String[] email = null;
		Connection con = null;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List<?>) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}