/**
 * 
 */
package com.asi.adm.ad1.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.dbutils.QueryRunner;

import com.asi.common.util.DateUtil;
import com.asi.common.util.StringUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * 記錄至KYCLLOG程式
 * @author vsg
 *
 */
public class KycLogger
{
	
	/**
	 * @param request
	 * @param ll01 進入點程式
	 * @param ll02 頁面Source
	 * @param ll03 頁面說明
	 * @param ll04 前後台
	 * @param ll05 使用者代號
	 * @param ll06 車種
	 * @param ll07 車牌號碼
	 * @param ll08 網投/網要
	 * @param ll09 交易序號
	 * @param LL12 保險起日
	 * @param LL13 保險迄日
	 * @param LL14 郵遞區號/造價區域
	 * @param LL15 標的物地址
	 * @param LL16 投保險別
	 * @param LL17 動作&檢核項目
	 * @param LL18 檢核狀況
	 * @param LL19 動作說明&檢核錯誤訊息
	 * @param LL20 SQL查詢條件
	 * @param LL26 關貿強制查詢序號
	 * @param LL27 關貿任意查詢序號
	 * @param LL28 住火複保險查詢序號
	 * @param LL29 壽險通報系統查詢序號
	 */
	public void LoggerWriter(HttpServletRequest request , 
	String ll01,String ll02,String ll03,String ll04,String ll05,String ll06,String ll07,String ll08,String ll09,
	String ll12,String ll13,String ll14,String ll15,String ll16,String ll17,String ll18,String ll19,String ll20,
	String ll26,String ll27,String ll28,String ll29	)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
 		
		Map mp = getNavigatorInfo(request);
		
		String sql = "INSERT INTO KYCLLOG ( "
				+"LL01,LL02,LL03,LL04,LL05,LL06,LL07,LL08,LL09,LL10,LL11,LL12,LL13,LL14,LL15,LL16,LL17,LL18,LL19,LL20,LL21,LL22,LL23,LL24,LL25,LL26,LL27,LL28,LL29,LL97,LL98,LL99"
				+") VALUES "
				+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String 	ll20temp = "";
		Pattern CRLF = Pattern.compile("(\r\n|\r|\n|\n\r|\t)");
		Matcher m = CRLF.matcher(ll20);
		
		if (m.find()) {
			ll20temp = m.replaceAll("");
		}else
			ll20temp = ll20;
		
		String[] param = new String[32];
		param [0]  = ll01;
		param [1]  = ll02;
		param [2]  = ll03;
		param [3]  = ll04;
		param [4]  = ll05;
		param [5]  = ll06;
		param [6]  = ll07;
		param [7]  = ll08;
		param [8]  = ll09;
		param [9]  = sysdate;
		param [10] = systime;
		param [11] = ll12;
		param [12] = ll13;
		param [13] = ll14;
		param [14] = ll15;
		param [15] = ll16;
		param [16] = ll17;
		param [17] = ll18;
		param [18] = ll19;
		param [19] = ll20temp.length() > 900 ? StringUtil.subDoubleByteString(ll20temp, 900) : ll20temp;
		param [20] = mp.get("ip") != null ? mp.get("ip").toString() : "";
		param [21] = mp.get("ismobile") != null ? mp.get("ismobile").toString() : "";
		param [22] = mp.get("os") != null ? mp.get("os").toString() : "";
		param [23] = mp.get("type") != null ? mp.get("type").toString() : "";
		param [24] = mp.get("version") != null ? mp.get("version").toString() : "";
		param [25] = ll26;
		param [26] = ll27;
		param [27] = ll28;
		param [28] = ll29;
		param [29] = sysdate;
		param [30] = systime;
		param [31] = ll05;

 		
 		Connection con = AS400Connection.getOracleConnection();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			runner.update(con, sql.toString(), param);
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

		
	}
	
	/**
	 * 檢查登入時的OTP是否正確
	 * @param uid
	 * @param otpkey
	 * @param input_otp
	 * @return
	 */
	public boolean isLoginOTP(String uid , String otpkey , String input_otp){
		boolean result = false;
			
		String sql = "SELECT * FROM KYCLLOG WHERE LL04 = 'F' AND LL17 = 'LE' AND LL05 = ? AND LL09 = ? AND TRIM(LL20) = ?";
		String[] args = new String[3];
		args[0] = uid;
		args[1] = otpkey;
		args[2] = input_otp;
		
 		Connection con = AS400Connection.getOracleConnection();

 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			
 			Map mp = (Map) runner.query(con, sql, args, new TrimedMapHandler());
 			
 			if(mp != null && mp.size()>0)
 				result = true;
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
		
		return result;
	}

	/**
	 * 查詢登入OTP資料
	 * @param uid
	 * @param otpkey
	 * @param input_otp
	 * @return
	 */
	public Map getLoginOTP(String uid , String otpkey ){
		
		String sql = "SELECT * FROM KYCLLOG WHERE LL04 = 'F' AND LL17 = 'LE' AND LL05 = ? AND LL09 = ? ";
		String[] args = new String[2];
		args[0] = uid;
		args[1] = otpkey;
		
 		Connection con = AS400Connection.getOracleConnection();

 		Map mp = null;
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			mp = (Map) runner.query(con, sql, args, new TrimedMapHandler());
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
		
		return mp;
	}

	/**
	 * 更新登入OTP錯誤次數
	 * @param uid
	 * @param otpkey
	 * @param errors
	 */
	public void updateLoginOTPErrorCount(String uid , String otpkey ,String errors){
		
		String sql = "UPDATE KYCLLOG SET LL12 = ? WHERE LL04 = 'F' AND LL17 = 'LE' AND LL05 = ? AND LL09 = ? ";
		String[] args = new String[3];
		args[0] = errors;
		args[1] = uid;
		args[2] = otpkey;
		
 		Connection con = null;
 		
 		try
 		{
 			con = AS400Connection.getOracleConnection();
 			QueryRunner runner = new QueryRunner();
 			runner.update(con, sql, args);
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

	}
	
	
	/**
	 * 查詢user-agent取得瀏覽器資訊
	 * @param req
	 * @return Map < key , value >
	 * 	</br>type ：瀏覽器名稱
	 * 	</br>version	：瀏覽器版本
	 * 	</br>os	：作業系統
	 * 	</br>ismobile：是否為行動裝置 Y-是 ；N-不是
	 *  </br>ip ：查詢ip
	 */
	public Map getNavigatorInfo(HttpServletRequest req){
		
		Map Sys= new HashMap();  
        
		String ua = req.getHeader("User-Agent").toLowerCase();  
        String s;  
        
        String msieP = "msie ([\\d.]+)";//windows ie
        String trident = "trident\\/([\\d.]+)";//windows ie11
        String edge = "edge\\/([\\d.]+)";//windows edge
        String firefoxP = "firefox\\/([\\d.]+)";  
        String chromeP = "chrome\\/([\\d.]+)";  
        String safariP = "version\\/([\\d.]+).*safari";  
        
        //判斷瀏覽器
        Pattern pattern = Pattern.compile(msieP);  
        Matcher mat = pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  
            Sys.put("type", "ie");  
            Sys.put("version", s.split(" ")[1]);  
        }  
        pattern = Pattern.compile(trident);  
        mat=pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  

            Sys.put("type", "ie");  
            Sys.put("version", "11");   
        }  
        pattern = Pattern.compile(edge);  
        mat=pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  

            Sys.put("type", "edge");  
            Sys.put("version", s.split("/")[1]);   
        }  
        pattern = Pattern.compile(firefoxP);  
        mat=pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  
 
            Sys.put("type", "firefox");  
            Sys.put("version", s.split("/")[1]);   
        }  
        pattern = Pattern.compile(chromeP);  
        mat=pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  
            Sys.put("type", "chrome");  
            Sys.put("version", s.split("/")[1]);  
        }   
        pattern = Pattern.compile(safariP);  
        mat=pattern.matcher(ua);  
        if(mat.find()){  
            s=mat.group();  
            Sys.put("type", "safari");  
            Sys.put("version", s.split("/")[1].split(".")[0]);  
        }
        
        //判斷os
        String os = "";       
        if (ua.contains("windows")) {
        	if(ua.indexOf("windows nt 5.0") != -1)
        		os = "Windows 2000";
        	else if(ua.indexOf("windows nt 5.1") != -1)
        		os = "Windows XP";
        	else if(ua.indexOf("windows nt 5.2") != -1)
        		os = "Windows 2003";
        	else if(ua.indexOf("windows nt 6.0") != -1)
        		os = "Windows Vista";
        	else if(ua.indexOf("windows nt 6.1") != -1)
        		os = "Windows 7";
        	else if(ua.indexOf("windows nt 6.2") != -1)
        		os = "Windows 8";
        	else if(ua.indexOf("windows nt 6.3") != -1)
        		os = "Windows Server 2012";
        	else
        		os = "Windows";
        } else if (ua.contains("mac")) {
        	os = "Mac";
        } else if (ua.contains("x11")) {
        	os = "Unix";
        } else if (ua.contains("android")) {
        	os = "Android";
        } else if (ua.contains("iphone")) {
        	os = "IPhone";
        } else {
        	os = "UnKnown";
        }
        Sys.put("os", os);
        
        //判斷是否為行動裝置
        String isMobile = "N";
        if(os.equals("Android") || os.equals("IPhone"))
        	isMobile = "Y";
        Sys.put("ismobile", isMobile);
        
        //取得ip
        String ip = req.getRemoteAddr();
        Sys.put("ip", ip);
        
        return Sys; 
	}
	
    /**要保書影像管理補印要保書寫進KYCLLOG
	 * @param request
	 * @param ll01 進入點程式
	 * @param ll02 頁面Source
	 * @param ll03 頁面說明
	 * @param ll04 前後台
	 * @param ll05 使用者代號
	 * @param ll06 車種
	 * @param ll07 車牌號碼
	 * @param ll08 網投/網要
	 * @param ll09 交易序號
	 * @param LL12 保險起日
	 * @param LL13 保險迄日
	 * @param LL14 郵遞區號/造價區域
	 * @param LL15 標的物地址
	 * @param LL16 投保險別
	 * @param LL17 動作&檢核項目
	 * @param LL18 檢核狀況
	 * @param LL19 動作說明&檢核錯誤訊息
	 * @param LL20 SQL查詢條件
	 * @param LL26 關貿強制查詢序號
	 * @param LL27 關貿任意查詢序號
	 * @param LL28 住火複保險查詢序號
	 * @param LL29 壽險通報系統查詢序號
	 * @param LL101保單號碼
	 * @param LL102通路代號
	 */
	public void LoggerWriter2(HttpServletRequest request , 
	String ll01,String ll02,String ll03,String ll04,String ll05,String ll06,String ll07,String ll08,String ll09,
	String ll12,String ll13,String ll14,String ll15,String ll16,String ll17,String ll18,String ll19,String ll20,
	String ll26,String ll27,String ll28,String ll29	,String ll30,String ll31)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
 		
		Map mp = getNavigatorInfo(request);
		
		String sql = "INSERT INTO KYCLLOG ( "
				+"LL01,LL02,LL03,LL04,LL05,LL06,LL07,LL08,LL09,LL10,LL11,LL12,LL13,LL14,LL15,LL16,LL17,LL18,LL19,LL20,LL21,LL22,LL23,LL24,LL25,LL26,LL27,LL28,LL29,LL97,LL98,LL99,LL30,LL31"
				+") VALUES "
				+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String 	ll20temp = "";
		Pattern CRLF = Pattern.compile("(\r\n|\r|\n|\n\r|\t)");
		Matcher m = CRLF.matcher(ll20);
		
		if (m.find()) {
			ll20temp = m.replaceAll("");
		}else
			ll20temp = ll20;
		
		String[] param = new String[34];
		param [0]  = ll01;
		param [1]  = ll02;
		param [2]  = ll03;
		param [3]  = ll04;
		param [4]  = ll05;
		param [5]  = ll06;
		param [6]  = ll07;
		param [7]  = ll08;
		param [8]  = ll09;
		param [9]  = sysdate;
		param [10] = systime;
		param [11] = ll12;
		param [12] = ll13;
		param [13] = ll14;
		param [14] = ll15;
		param [15] = ll16;
		param [16] = ll17;
		param [17] = ll18;
		param [18] = ll19;
		param [19] = ll20temp.length() > 900 ? StringUtil.subDoubleByteString(ll20temp, 900) : ll20temp;
		param [20] = mp.get("ip") != null ? mp.get("ip").toString() : "";
		param [21] = mp.get("ismobile") != null ? mp.get("ismobile").toString() : "";
		param [22] = mp.get("os") != null ? mp.get("os").toString() : "";
		param [23] = mp.get("type") != null ? mp.get("type").toString() : "";
		param [24] = mp.get("version") != null ? mp.get("version").toString() : "";
		param [25] = ll26;
		param [26] = ll27;
		param [27] = ll28;
		param [28] = ll29;
		param [29] = sysdate;
		param [30] = systime;
		param [31] = ll05;
		param [32] = ll30;
		param [33] = ll31;

 		
 		Connection con = AS400Connection.getOracleConnection();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			runner.update(con, sql.toString(), param);
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

		
	}
	
	
	
}
