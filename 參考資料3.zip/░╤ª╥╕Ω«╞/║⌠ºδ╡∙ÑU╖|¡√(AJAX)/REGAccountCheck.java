/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.reg.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

public class REGAccountCheck extends AsiAction
{	

   public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       AsiActionForm form1 = (AsiActionForm) form;
       if (form1.getActionCode() == 0)
           form1.setActionCode(GlobalKey.ACTION_SELECT);
       return;
   }

   public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       return null;
   }

   protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
   {
   	
   }
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String id = arg2.getParameter("userid").trim();
		String cellphone = arg2.getParameter("cellphone").trim();
		String reffer = arg2.getParameter("reffer").trim();
		
		QueryRunner run = new QueryRunner();
		String sql1;
		sql1 = "SELECT * FROM SECAJ ";
		sql1 += "WHERE USERID = '" + id + "' ";		

		String sql2;
		sql2 = "SELECT * FROM KYCREG ";
		sql2 += "WHERE RG01 = '" + id + "' AND RG14<>0 ";		

		String sql3;
		sql3 = "SELECT * FROM IC01PF ";
		sql3 += "WHERE C101 = '" + id + "' AND C103<>0 ";		
		
		String sql4;//查手機是否註冊超過2個帳號
		sql4 = "SELECT * FROM KYCREG WHERE RG04='" + cellphone +"' AND RG14<>0";		

		String sql5;//查推薦人代號是否存在
		sql5 = "SELECT * FROM IC01PFA WHERE C01A17='" + reffer + "'";		

		Map ret1 = new HashMap();
		Map ret2 = new HashMap();
		Map ret3 = new HashMap();
		List ret4 = null;
		List ret5 = null;

		Map out = new HashMap();

		try
		{
			tx_controller.begin(0);
			
			ret1 = (Map) run.query(tx_controller.getConnection(0),sql1,new TrimedMapHandler());
			ret2 = (Map) run.query(tx_controller.getConnection(0),sql2,new TrimedMapHandler());
			ret3 = (Map) run.query(tx_controller.getConnection(0),sql3,new TrimedMapHandler());
			ret4 = (List) run.query(tx_controller.getConnection(0),sql4,new TrimedMapListHandler());
			ret5 = (List) run.query(tx_controller.getConnection(0),sql5,new TrimedMapListHandler());
			
			if(id.length() < 10)
			{
				out.put("errorCode", "0008");
				out.put("errorMsg", "網路會員註冊僅限自然人！");									
			}
			else
			{			
				
				if(ret1 != null && !ret1.isEmpty())//帳號已存在
				{
					if(ret2 != null && !ret2.isEmpty())//已有註冊資料
					{
						out.put("errorCode", "9999");
						out.put("errorMsg", "帳號：" + id + " 已完成註冊！");
						
					}
					else{
						
						if(ret3 != null && !ret3.isEmpty())//客戶資料檔已有生日
						{

							out.put("errorCode", "0004");
							out.put("errorMsg", "您已是本公司會員！但尚未註冊完成！為加速您的註冊流程，請輸入正確的生日帶出資料。");									
						}
						else{
							out.put("errorCode", "");
							out.put("errorMsg", "");
						}
					}
					
				}
				else{
					
					if(ret2 != null && !ret2.isEmpty())
					{
						if(ret2.get("RG14").toString().equals("0")){
							out.put("errorCode", "0002");
							out.put("errorMsg", "帳號：" + id + " 尚未尚未註冊完成！");									
						}
						else{
							out.put("errorCode", "0001");
							out.put("errorMsg", "帳號：" + id + " 已存在，請重新輸入！");					
						}
					}
					else {
						out.put("errorCode", "");
						out.put("errorMsg", "");									
					}
	
				}
					
				//查手機是否註冊超過2個帳號
				if(ret4 != null && ret4.size() >= 2)
				{
						out.put("errorCode", "E005");
						out.put("errorMsg", "同一手機號碼僅限註冊2組帳號！");	
				}

				//查推薦人代號是否存在
				if(reffer != null && !reffer.equals("")){
					if(ret5 == null || ret5.isEmpty())
					{
						out.put("errorCode", "E006");
						out.put("errorMsg", "邀請人代碼不存在！請查明後再輸入！");
					}
				}

			}

			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(out).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		}
		catch (SQLException e)
		{
			System.out.print("bb:" + e);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		arg1.setNextPage(-1);
	}
}
