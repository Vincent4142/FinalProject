/*
 * Created on 2005/3/23
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.asi.kyc.reg.actions;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.reg.forms.RG1M010f;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.kyc.sec.actions.kycAction;

/**
 * 網路投保 - 會員註冊
 * 
 * @author vsg
 * @CreateDate 2015/4/17上午 9:31:29
 * @UpdateDate 2015/4/17上午 9:31:29
 * @FileName kyc/com.asi.kyc.reg.actions/RG1M010.java
 * @Purpose
 * 
 */
public class RG1M010 extends kycAction
{

	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(5);
		}
		
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException
	{
		RG1M010f form1 = (RG1M010f) form;
		tx_controller.begin(0);
		RG1M010m model = new RG1M010m(tx_controller, request, form);
		String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
		request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
		model.init();
		
        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("RG", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("RG", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("RG", "description"));

		if(form1.getActionCode() == 6)//進入註冊頁
		{
			String uname = "";
			String addr="";
			String email ="";
			try {
				if(request.getParameter("username") != null)
					uname = new String(request.getParameter("username").getBytes("ISO-8859-1"),"UTF-8");;
				if(request.getParameter("address") != null)
					addr= new String(request.getParameter("address").getBytes("ISO-8859-1"),"UTF-8");//request.getParameter("address").getBytes("ISO-8859-1").toString();
				if(request.getParameter("email") != null)
					email= new String(request.getParameter("email").getBytes("ISO-8859-1"),"UTF-8");

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("sent_username", uname);
			request.setAttribute("sent_addr", addr);
			request.setAttribute("sent_email", email);
			
			request.getSession().setAttribute("counts","");//因繼承kycAction，非p1的source會被導回首頁
			saveToken(request);
			form.setNextPage(2);
		}
		else if(form1.getActionCode() == 51)//註冊完成動作
		{
			if(!model.isRegistered(request)){
				
				boolean isRegistertok = model.isRegisterOK(request);
				
				if(isRegistertok)
				{	
					model.dealwithIC01PF();//寫入客戶主檔IC01PF，Trigger自動寫入帳號檔SECAJ；更新客戶主檔
					model.sendRegCompleteMail(request);
					request.setAttribute("USNAME", model.getUsername());
					
					if(model.login())
						form.setNextPage(8);
					else
						form.setNextPage(5);
				}
				else{
					form.setNextPage(5);
				}
			}
			else{
				model.login();
				form.setNextPage(5);
			}
		}
		else if(form1.getActionCode() == 7)//OTP輸入正確
		{
			boolean isUpdatetok = model.isConfirmOTP();
			
			if(isUpdatetok)
			{
				model.sendRegConfirmMail(request);
				request.setAttribute("USNAME", model.getUsername());
				form.setNextPage(4);
			}
			else{
				request.setAttribute("MSG", "檔案寫入有問題！請再檢驗資料或電洽02-2371-1357專員服務！");
				form.setNextPage(3);
			}

		}
		else if(form1.getActionCode() == 2)//註冊
		{
			//處理重新整理畫面動作
			if (!isTokenValid(request))
			{
				doAction1(form1, request);
			}
			else{
				boolean isInsertok = model.isInsertSucess();//寫入註冊檔KYCREG
				request.setAttribute("RG1M010f", model.getMainForm());
				
				if(isInsertok){
//					model.dealwithIC01PF();//寫入客戶主檔IC01PF，Trigger自動寫入帳號檔SECAJ；更新客戶主檔
					
					if(otpswitch.equals("Y"))//系統代碼，是否發送簡訊註記
						model.sendMobileMsg();//發送OTP-簡訊
					else
						model.sendOTPMail(request);//發送OTP-Email
					
					request.setAttribute("uid", model.getInsertedid());
					request.setAttribute("token", model.getEncryptedkey());
					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
					
					resetToken(request);
					saveToken(request);
					form.setNextPage(3);
				}else{
					request.setAttribute("MSG", "檔案寫入有問題！請再檢驗資料或電洽02-2371-1357專員服務！");
					
					resetToken(request);
					saveToken(request);
					form1.setNextPage(2);	
				}	
			}
		}
		else if(form1.getActionCode() == 21){//重新寄發OTP
			
			boolean isUpdatetok = model.isUpdateOTP();
			if(isUpdatetok){
				if(otpswitch.equals("Y"))
					model.sendMobileMsg();//發送簡訊
				else
					model.sendOTPMail(request);
				
				request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");				
				request.setAttribute("uid", model.getInsertedid());
				request.setAttribute("token", model.getEncryptedkey());
				request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

			}else{
				request.setAttribute("uid", model.getInsertedid());
				request.setAttribute("token", model.getEncryptedkey());
				request.setAttribute("exmin", "0");
			}
			form.setNextPage(3);
		}
		else
		{
			doAction1(form, request);
		}
		
	}

    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }

	/**
	 * 初始設定
	 * @param form
	 * @param request
	 * @param model
	 * @throws AsiException
	 */
	private void doAction1(AsiActionForm form, HttpServletRequest request) throws AsiException
	{
		
		saveToken(request);
		
		form.setNextPage(1);
	}
}