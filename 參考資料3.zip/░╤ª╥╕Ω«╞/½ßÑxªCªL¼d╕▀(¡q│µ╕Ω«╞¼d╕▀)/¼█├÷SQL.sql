SELECT DISTINCT B.*,A.*,A.T1514 AS CURRPHONE,T1610 AS CARNUMBER,T1643 AS REINS,T1646 AS RECDATE,KYCKLB.*,B.T15C9 T15C9,A.T1524 AS "NEWT1524"
FROM PT15PF A
LEFT OUTER JOIN KYCKLA B ON A.T1501 = B.T1501 AND A.T1502=B.T1502 AND A.T1503=B.T1503
LEFT JOIN KYCKLB ON A.T1501=T1601 AND A.T1502=T1602 AND A.T1503=T1603 AND T1604='1' 
WHERE ( A.T1523 BETWEEN 1090901 AND 1090928 )  AND A.T1538='B2C'  ORDER BY A.T1523 DESC,A.T1501 DESC;
--下面為匯出EXCEL要新增的欄位
--<td><%=record.getData("NEWT1524") %></td>
--<td><span class="blue"><%=record.getData("T1584") %></span></td>
--<td><%if(record.getData("T1575").equals("Y")){ %><span class="red"><%=record.getData("T1575D") %></span> <%}else{ %> <%=record.getData("T1575D") %> <%} %></td>	
select * from PT15PF where T1523 BETWEEN 1090901 and 1090929; 