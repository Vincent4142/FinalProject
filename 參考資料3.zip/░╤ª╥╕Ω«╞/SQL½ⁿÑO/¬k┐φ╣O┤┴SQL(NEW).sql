--���ة���
SELECT distinct lpt01,lpt02, lma06, lpt05, lpt06, lpt07, lpt08, secaz.codedesc as sendItem, secaz1.codedesc AS viewItem 
FROM com_lptt 
INNER JOIN com_lman ON lpt01 = lma01 
INNER JOIN secaz secaz1 ON lpt03 = secaz1.codetype AND lpt04 = secaz1.codeid 
INNER JOIN secaz ON secaz1.codetype = secaz.codeid 
left join com_lpde on lpt01=com_lpde.lpd01 
WHERE lpt05 = 'Y' AND 
CASE WHEN lpt07 = 0 THEN CASE WHEN lpt06 < 1090922 THEN 1 ELSE 0 END 
ELSE CASE WHEN lpt06 < lpt07 THEN 1 ELSE 0 END END = 1 
AND floor(com_lptt.crtdt / 10000) = 109 
AND com_lptt.crtdt between 1090901 and 1090922 
AND lpt02 = 10 
AND secaz.codetype = 'COMPLIANCE' 
and com_lpde.lpd07 is null 
ORDER BY lpt01;

--���ة���(��l)
SELECT lpt01, lma06, lpt05, lpt06, lpt07, lpt08, secaz.codedesc as sendItem, secaz1.codedesc AS viewItem 
FROM com_lptt 
INNER JOIN com_lman ON lpt01 = lma01 
INNER JOIN secaz secaz1 ON lpt03 = secaz1.codetype AND lpt04 = secaz1.codeid 
INNER JOIN secaz ON secaz1.codetype = secaz.codeid 
WHERE lpt05 = 'Y' AND 
CASE WHEN lpt07 = 0 THEN CASE WHEN lpt06 < 1090922 THEN 1 ELSE 0 END 
ELSE CASE WHEN lpt06 < lpt07 THEN 1 ELSE 0 END END = 1 
AND floor(com_lptt.crtdt / 10000) = 109 
AND com_lptt.crtdt between 1090901 and 1090922 
AND lpt02 = 10 
AND secaz.codetype = 'COMPLIANCE'
ORDER BY lpt01, lpt03, lpt04 ;


--����
SELECT lpt02, lde02,lpd02,
sum(case when floor(com_lptt.crtdt / 10000) = 109 then 1 else 0 end) LAWCNT1, 
sum(case when floor(com_lptt.crtdt / 10000) = 110 then 1 else 0 end) LAWCNT2, 
sum(case when floor(com_lptt.crtdt / 10000) = 111 then 1 else 0 end) LAWCNT3, 
sum(case when floor(com_lptt.crtdt / 10000) = 112 then 1 else 0 end) LAWCNT4, 
sum(case when floor(com_lptt.crtdt / 10000) = 113 then 1 else 0 end) LAWCNT5 
FROM com_lptt 
inner join com_ldep on lpt02 = lde01 
inner join com_lpde on lpt01=lpd01 
WHERE LPT05 = 'Y' and 
(case when lpt07 = 0 then case when lpt06 < 1090922 then 1 else 0 end 
else case when lpt06 < lpt07 then 1 else 0 end end = 1) and 
com_lptt.crtdt between 1090901 and 1090922 
and lpt02 like '%'
and lpt02 = lpd02
and com_lpde.lpd07 is null
Group By lpt02,lde02,lpd02 Order By lpt02;

--���ح�l
SELECT lpt02, lde02,
sum(case when floor(com_lptt.crtdt / 10000) = 109 then 1 else 0 end) LAWCNT1,
sum(case when floor(com_lptt.crtdt / 10000) = 110 then 1 else 0 end) LAWCNT2, 
sum(case when floor(com_lptt.crtdt / 10000) = 111 then 1 else 0 end) LAWCNT3, 
sum(case when floor(com_lptt.crtdt / 10000) = 112 then 1 else 0 end) LAWCNT4, 
sum(case when floor(com_lptt.crtdt / 10000) = 113 then 1 else 0 end) LAWCNT5 
FROM com_lptt inner join com_ldep on lpt02 = lde01 
WHERE LPT05 = 'Y' and 
(case when lpt07 = 0 then case when lpt06 < 1090922 then 1 else 0 end 
else case when lpt06 < lpt07 then 1 else 0 end end = 1) and 
com_lptt.crtdt between 1090901 and 1090922 
and lpt02 like 10 
Group By lpt02, lde02 Order By lpt02;