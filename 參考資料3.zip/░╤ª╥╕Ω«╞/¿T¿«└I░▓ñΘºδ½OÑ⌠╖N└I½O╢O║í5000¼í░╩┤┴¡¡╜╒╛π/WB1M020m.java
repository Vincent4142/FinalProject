/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.asi.kyc.wb1.models;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;

import net.sf.json.JSONArray;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MathUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.Codec;
import com.asi.kyc.common.utils.InsuranceUtil;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.NumberUtil;
import com.asi.kyc.common.utils.TradeCounter;
import com.asi.kyc.common.utils.UpdateState;
import com.asi.kyc.wb1.actions.AS400Procedure;
import com.asi.kyc.wb1.forms.WB1M020f;
import com.firstins.dao.procedure.FAS24Input;
import com.firstins.dao.procedure.FAS24PRC;
import com.firstins.dao.procedure.FAS24Return;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc2.qt1.b2e.fun2.dao.Fc71pfDao;

/**
 * 網路投要保 - 汽車險
 * 
 * @author ：Sergio_Huang
 * @version：$Revision: 1.17 $ $Date: 2007/04/11 10:04:28 $<br>
 *          存放路徑 ：$Header:
 *          D:/CVSRepository/Financial/KYC/KYC/JavaSource/web/com/asi/kyc/wb1/models/WB1M020m.java,v
 *          1.13 2005/05/26 11:08:00 Sergio_Huang Exp $ 
 * 建立日期 ：	2005/5/5 
 * 異動註記 ：	2005/09/26  John  增加判斷使用者是由那個網站進入線上投保
 *			2005/10/18  John  增加判斷投保起日是否大於上次投保迄日-1個月
 *			2005/11/16  John  修正 call 400副程式cIILVLPRC 的 bug
 */
public class WB1M020m extends AsiModel 
{
    private static Log logger = LogFactory.getLog(WB1M020m.class);

    private WB1M020f mform;
    
    private String factor;//級數

    private StringBuffer buf = new StringBuffer();

    boolean showProcess = true;
    
    /**
     * @param tx_controller
     * @param request
     * @param form
     */
    public WB1M020m(TransactionControl tx_controller, HttpServletRequest request, AsiActionForm form) {
        super(tx_controller, request, form);
    }

    /**
     * @see com.asi.common.AsiModel#init()
     * 
     * @throws com.asi.common.exception.AsiException
     */
    public void init() throws AsiException {
        mform = new WB1M020f();
        //把form做拷貝
        try {
            BeanUtils.copyProperties(mform, getForm());
        } catch (InvocationTargetException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        } catch (IllegalAccessException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        }
        setUserinfo();
        setMainForm(mform);
    }

    public void destroy() {
    }

    public static void main(String[] args) {
    }
    
    public void processP1() {
    }

    public boolean processP3() {
        return false;
    }

    /**
     * @throws AsiException
     */
    public boolean processP4() throws AsiException {
        DBO dbo = getSECAJ(mform.getUID());

        if (dbo.getRecordCount() == 1) {
            getRequest().setAttribute(KycGlobal.InsureType, KycGlobal.MotorInsurance);
            return true;
        }
        mform.setPWD("");
        mform.setIdentityNumber(mform.getUID());
        return false;
    }

    public DBO getSECAJ(String userid) throws AsiException {
        DBO dbo = getTransaction().getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", userid);
        dbo.executeSelect();
        return dbo;
    }

    /**
     * 寄送OTP EMAIL
     * @param request
     */
    public void sendOTPMail(HttpServletRequest request)
    {
    	int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
    	
    	String email = mform.getKyc_T1516();
    	String name = mform.getKyc_T1506();
    	String otp = mform.getData_otp();
    	
 		//寄Email
 		KycMailUtil sender = new KycMailUtil();

 		//取範本
 		BufferedReader fr;
 		String path = getServlet().getServletContext().getRealPath("/mail/TransactionOTP_" + getLocale() + ".html");

 		StringBuffer linebf = new StringBuffer();
 		try {
 			fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
 			String line;
 			linebf = new StringBuffer();
 			line = fr.readLine();
 			while (line != null) {
 				linebf.append(line);
 				line = fr.readLine();
 			}

 		}
 		catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		catch (IOException e) {
 			e.printStackTrace();
 		}

 		//姓名隱碼
 		StringBuffer hiddenName  = new StringBuffer();
 		if(name.length() < 4){
 		   for(int i=0;i<name.length();i++){
 			   if(i==1){
 				   hiddenName.append("O");
 			   }
 			   else{
 				   hiddenName.append(name.substring(i,i+1));
 		   	   }
 		   }
 		}
 		else{
 		    for(int i=0;i<name.length();i++){
 			    if(i==1 || i==2){
 				    hiddenName.append("O");
 			    }
 			    else{
 				    hiddenName.append(name.substring(i,i+1));
 		   	    }
 		    }
 		}
 		
	   	String msg = linebf.toString();
	   	msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
	   	msg = msg.replaceAll("\\{otp\\}", otp);
	   	msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));
	
	   	sender.setSubject("第一保 電子商務網 網路投保交易OTP");
	   	sender.setMessage(msg);
	   	sender.addTo(email);
	   	sender.sendMail();

   }

 	/**
 	 * 寄發簡訊
 	 * 
 	 * @param data
 	 */
 	public void sendMobileMsg()
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		sb.append("第一產物交易OTP碼：").append(mform.getData_otp()).append("\n");
 		sb.append(" 您正於第一產物進行網路投保作業\n");
 		sb.append("請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！若無線上作業請忽略此封簡訊，謝謝。");

 		String sendTel = mform.getKyc_T1515();
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}
    
    /**
     * 資料檢核及處理
     * @throws AsiException
     * @throws UserException
     */
    public void processP5(String agentno) throws AsiException {
        if (mform.getAddr().equals("new")) {
            mform.setNewAddress(mform.getCity() + mform.getTown() + mform.getNewAddress());
        } else {
            mform.setNewAddress(mform.getOldAddress());
        }

//        //增加判斷投保起日是否大於上次投保迄日-1個月
//        DBO dbo2 = getTransaction().getDBO("kyc.PT15PFs08", 0);
//        dbo2.addParameter("T1507", mform.getIdentityNumber()); //pt15pf.t1507身份證
//        dbo2.addParameter("T1610", mform.getCarLicence()); //pt16pf.t1610車號
//        System.out.println(dbo2.getAssembledSQL());
//        dbo2.execute();
//        if (dbo2.getRecordCount() > 0) {
//            validDate(dbo2.getRecordData("T1518"), getStartDate());
//        }
//        dbo2.destroy();
        
        //        生日 => 檢核小於等於系統日
        if (DateUtil.getDateInterval(getUsrInfo(), DateUtil.getSysDate(getUsrInfo(), false), getBirthDay()) < 0)
            throw new UserException("WB1.ERROR02");

        //        原始發照民國 => 檢核小於等於系統年月
        if (DateUtil.getDateInterval(getUsrInfo(), DateUtil.getSysDate(getUsrInfo(), false), mform.getLicencey() + StringUtils.leftPad(mform.getLicencem(), 2, "0") + "01") < 0)
            throw new UserException("WB1.ERROR03");
        
        //查詢洗錢風險評估資料
		String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
        String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y

        if(!omitFAS24.equals("Y")){//是否略過查詢FAS24     
        	if(isid_switch.equals("Y")){//新版
            	//被保險人-查詢洗錢風險評估資料
            	if (checkFas24prc_new(mform.getKyc_T1507(),mform.getKyc_T1506(),getBirthDay(),agentno) == false){
            		throw new UserException("WB1.ERROR13");
            	}

    	        //要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc_new(mform.getKyc_T1547(),mform.getKyc_T1546(),getqmanBirthDay(),agentno) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
        	}else{
            	//被保險人-查詢洗錢風險評估資料
    	     	if (checkFas24prc(mform.getKyc_T1507(),mform.getKyc_T1506()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
    	
    	        //要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc(mform.getKyc_T1547(),mform.getKyc_T1546()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
        	}
        }	     	

        //地址處理
        String addr;
        if (mform.getAddr().equals("new"))
            addr = mform.getCity() + mform.getTown() + mform.getAddrnew();
        else
            addr = mform.getAddrold();
        mform.setKyc_T1512(addr);
        
        if(mform.getKyc_T1510().equals("")){
            mform.setKyc_T1510("3");
        }
        
        //C37PRC 車種、排氣量檢核
        String brandno = mform.getCarserialno();
        String c372i = brandno;
        String unit = "";
        String quantity = "";
        
        if (mform.getPassengerType().equals("people"))
        {
            unit = "P";
            quantity = mform.getPassengerCnt();
        }
        else if (mform.getPassengerType().equals("weight"))
        {
            unit = "T";
            quantity = mform.getTon();
        }

        String[] c37return = callC37PRC("0", c372i, mform.getCarType(), mform.getKyc_T1611(), quantity ,unit );
        if(c37return[0].equals("N"))
      	  throw new UserException(c37return[2]);
        
        try {
			String htmlcode = mform.getInstypename().replace("\n", "").replace("\r", "").replace("\t", "").replace("<tbody>", "").replace("</tbody>", "");
        	
			mform.setInstypename(Codec.encode(htmlcode));
		} catch (IOException e) {
			e.printStackTrace();
		}
    
    }

    /**
     * 保費試算處理
     * @throws AsiException
     */
    public void processP2() throws AsiException
	{
		try
		{
			getTransaction().begin(0);
			combineBirthday();
			
			//電動車判斷
			String pdtype = mform.getPrdtype();
			if(pdtype.equals("3"))
				mform.setIsEcar(true);
			
			//生日 => 檢核小於等於系統日
			if (DateUtil.getDateInterval(getUsrInfo(), DateUtil.getSysDate(getUsrInfo(), false), getBirthDay()) < 0)
				throw new UserException("WB1.ERROR02");
					
			String key = "";
			String pjcode = mform.getPjcode(); 
			if(!pjcode.equals("")) {
				if(isProjectCode(pjcode)){//判斷pjcode是專案代號(ture)或是推薦人代號(false)
					pjcode = CodeUtil.getCodeDesc(getServlet(), getRequest(), "PROJSOURCE", pjcode.toUpperCase());
			    	if (pjcode.equals("HOLIDAY"))
			    		pjcode = "KYC";
				}
				else{
					pjcode="BOSS3.0";
				}        	
			} else
				pjcode = "KYC";
			
	        String entry = mform.getEntry();
	        String check21 = mform.getCkb_ins_21() != null ? mform.getCkb_ins_21() : "N";
	        String check48 = mform.getCkb_ins_48() != null ? mform.getCkb_ins_48() : "N";
	        String check31 = mform.getCkb_ins_31() != null ? mform.getCkb_ins_31() : "N";
	        String check35 = mform.getCkb_ins_35() != null ? mform.getCkb_ins_35() : "N";
	        String check50 = mform.getCkb_ins_50() != null ? mform.getCkb_ins_50() : "N";
	        String check51 = mform.getCkb_ins_51() != null ? mform.getCkb_ins_51() : "N";
	        String check07 = mform.getCkb_ins_07() != null ? mform.getCkb_ins_07() : "N";
	        String check0DD = mform.getCkb_ins_0DD() != null ? mform.getCkb_ins_0DD() : "N";
	        String check0G = mform.getCkb_ins_0G() != null ? mform.getCkb_ins_0G() : "N";	       
	        String check3G = mform.getCkb_ins_3G() != null ? mform.getCkb_ins_3G() : "N";
	        String check37 = mform.getCkb_ins_37() != null ? mform.getCkb_ins_37() : "N";
	        String check77 = mform.getCkb_ins_77() != null ? mform.getCkb_ins_77() : "N";
	        String check05 = mform.getCkb_ins_05() != null ? mform.getCkb_ins_05() : "N";
	        String check11 = mform.getCkb_ins_11() != null ? mform.getCkb_ins_11() : "N";
	        String check1DD = mform.getCkb_ins_1DD() != null ? mform.getCkb_ins_1DD() : "N";
	        String check12 = mform.getCkb_ins_12() != null ? mform.getCkb_ins_12() : "N";	        
	        
	        String insamout_31 = mform.getInsamout_31();		//31自選保額
	        String insamout_32 = mform.getInsamout_32();		//32自選保額
	        String times_31 = mform.getTimes_31();				//31險種倍數
	        String insamout_35 = mform.getInsamout_35();		//35自選保額
	        String insamout_50 = mform.getInsamout_50();		//50自選保額
	        String insamout_51 = mform.getInsamout_51();		//51自選保額
	        String insamout_07 = mform.getInsamout_07();		//07保額
	        String insamout_3G = mform.getInsamout_3G();		//3G保額
	        String insamout_37 = mform.getInsamout_37();		//37保額
	        String insamout_37D = mform.getInsamout_37D();		//37身故保額	        
	        String insamout_77 = mform.getInsamout_77();		//77保額
	        String insamout_05 = mform.getInsamout_05();		//05保額
	        String insamout_11 = mform.getInsamout_11();		//05保額
	        	        
	        String insamout_31total = String.valueOf(Integer.parseInt(insamout_31) * Integer.parseInt(times_31));//保額*倍數
	        String insamout_51total = String.valueOf(Integer.parseInt(insamout_51) * (Integer.parseInt(mform.getPassengerCnt()) - 1));	//乘客險人數-1
	        String insamout_37total = String.valueOf(Integer.parseInt(insamout_37) * Integer.parseInt(times_31));//保額*倍數
	        String insamout_37Dtotal = String.valueOf(Integer.parseInt(insamout_37D) * Integer.parseInt(times_31));//保額*倍數
	        
	        String kd20 = "41";
	        if(entry.equals("2"))
	        	kd20 = "40";
	        
	        //如果05或11有勾選 查續保單號
	        if(check05.equals("Y") || check11.equals("Y")){
	        	getT1542();
	        }

	        //依畫面選取險種判斷方案	        
	        System.out.println("check21== " + check21 +" check48== " + check48 + " check31== " + check31 + " check50== " + check50 + " check51== " + check51 + " check07== " + check07 + " check0DD== " + check0DD + " check0G== " + check0G + " check35== " + check35 + " check3G== " + check3G + " check37== " + check37 + " check77== " + check77 + "check05== " + check05 + "check11== " + check11 + "check1DD== " + check1DD + "check12== " + check12);	       
	        
	        if(check21.equals("Y")){
		        if(!check48.equals("Y") && !check31.equals("Y") && !check50.equals("Y") && !check51.equals("Y") && !check07.equals("Y") && !check0DD.equals("Y") && !check0G.equals("Y") && !check35.equals("Y") && !check3G.equals("Y") && !check37.equals("Y") && !check77.equals("Y") && !check05.equals("Y") && !check11.equals("Y") && !check1DD.equals("Y") && !check12.equals("Y"))
		        	key = "C01";
		        else if(check48.equals("Y") && !check31.equals("Y") && !check50.equals("Y") && !check51.equals("Y") && !check07.equals("Y") && !check0DD.equals("Y") && !check0G.equals("Y") && !check35.equals("Y") && !check3G.equals("Y") && !check37.equals("Y") && !check77.equals("Y") && !check05.equals("Y") && !check11.equals("Y") && !check1DD.equals("Y") && !check12.equals("Y"))
		        	key = "C02";
		        else if(!check48.equals("Y") && check31.equals("Y") && !check50.equals("Y") && !check51.equals("Y") && !check07.equals("Y") && !check0DD.equals("Y") && !check0G.equals("Y") && check35.equals("Y") && !check3G.equals("Y") && !check37.equals("Y") && !check77.equals("Y") && !check05.equals("Y") && !check11.equals("Y") && !check1DD.equals("Y") && !check12.equals("Y"))
		        	key = "C03";
		        else if(check48.equals("Y") && check31.equals("Y") && !check50.equals("Y") && !check51.equals("Y") && !check07.equals("Y") && !check0DD.equals("Y") && !check0G.equals("Y") && check35.equals("Y") && !check3G.equals("Y") && !check37.equals("Y") && !check77.equals("Y") && !check05.equals("Y") && !check11.equals("Y") && !check1DD.equals("Y") && !check12.equals("Y"))
		        	key = "C03";
		        else if(check48.equals("Y") && check31.equals("Y") && !check50.equals("Y") && !check51.equals("Y") && !check07.equals("Y") && !check0DD.equals("Y") && !check0G.equals("Y") && !check35.equals("Y") && !check3G.equals("Y") && !check37.equals("Y") && !check77.equals("Y") && !check05.equals("Y") && !check11.equals("Y") && !check1DD.equals("Y") && !check12.equals("Y"))
		        	key = "C03";
		        else 
		        	key = "C04";
	        }else{
	        	key = "C05";
	        }
	        
	        mform.setType(key);
			
			Person p = new Person();
			p.setBirthday(mform.getBirthday());
			p.setSex(mform.getKyc_T1509());
			p.setIdNumber(mform.getKyc_T1507());
			
			String carbrand = (mform.getCarnumbertype() != null && mform.getCarnumbertype().equals("1")) ? mform.getKyc_T1610_old() : mform.getKyc_T1610();//車牌
			int carprice = Integer.parseInt(mform.getKyc_T1640() != null ? mform.getKyc_T1640() : "0");//重置價
			
			Car car = new Car();
			car.setLicence(carbrand);//車牌
			car.setPassengerType(mform.getPassengerType());//乖載
			car.setPassenger(mform.getPassengerCnt());//人數噸數
			car.setCarType(mform.getCarType());//車種
			car.setTon(mform.getTon());
			car.setLicencey(mform.getLicencey());//發照年
			car.setLicencem(StringUtils.leftPad(mform.getLicencem(), 2, "0"));//發照月
			car.setProducey(mform.getKyc_T1607());//製造年
			car.setBrandserialno(mform.getCarserialno());//廠代8碼
			car.setInsamout_07(mform.getInsamout_07());//寫入丙式車體險保額
			car.setInsamout_05(mform.getInsamout_05());//寫入乙式車體險保額
			car.setInsamout_11(mform.getInsamout_11());//寫入竊盜險保額

			
			car.setCheck21(check21.equals("Y") ? "Y":"N");
			car.setCheck48(check48.equals("Y") ? "Y":"N");
			car.setCheck31(check31.equals("Y") ? "Y":"N");
			car.setCheck35(check35.equals("Y") ? "Y":"N");
			car.setCheck50(check50.equals("Y") ? "Y":"N");
			car.setCheck51(check51.equals("Y") ? "Y":"N");
			car.setCheck07(check07.equals("Y") ? "Y":"N");
			car.setCheck0DD(check0DD.equals("Y") ? "Y":"N");
			car.setCheck0G(check0G.equals("Y") ? "Y":"N");
			car.setCheck3G(check3G.equals("Y") ? "Y":"N");
			car.setCheck37(check37.equals("Y") ? "Y":"N");
			car.setCheck77(check77.equals("Y") ? "Y":"N");
			car.setCheck05(check05.equals("Y") ? "Y":"N");
			car.setCheck1DD(check1DD.equals("Y") ? "Y":"N");
			car.setCheck11(check11.equals("Y") ? "Y":"N");
			car.setCheck12(check12.equals("Y") ? "Y":"N");
									
			
			//重置價暫時先用以下方式計算，若開賣車體險時，再參考報價系統計算含折舊率的方式
	        //該車牌是否存在FC71PF，若有存在抓取該檔案中的重置價格
	        if(isFc71pf(carbrand,""))
	        {
	        	Map m = getFc71pf(carbrand);
	        	String f7102 = ((BigDecimal)m.get("F7102")).toString();
	        	if(!f7102.equals("0"))
	        		carprice = Integer.parseInt(f7102);
	        }
	        car.setReproductvalue(String.valueOf(carprice));
				        
			OnlineCarCalculator car21 = new OnlineCarCalculator(car, p, getSession());
			car21.setConn(getTransaction().getConnection(0));
			car21.setStartDate(getStartDate());
			car21.setEndDate(getEndDate());
			car21.setVolstartDate(get_vol_InsureStart());
			car21.setVolendDate(get_vol_InsureEnd());
			car21.setEntry(pjcode.equals("FI94168") ? "KYC" : pjcode);
			car21.setChannelCode(kd20);
			car21.setAmount31(insamout_31);
			car21.setTotalamount31(insamout_31total);
			car21.setTimes_31(times_31);
			car21.setTotalamount32(insamout_32);
			car21.setTotalamount35(insamout_35);
			car21.setTotalamount50(insamout_50);
			car21.setTotalamount05(insamout_05);
			car21.setTotalamount07(insamout_07);
			car21.setAmount51(insamout_51);
			car21.setTotalamount51(insamout_51total);
			car21.setTotalamount3G(insamout_3G);
			car21.setTotalamount37(insamout_37);
			car21.setTotalamount77(insamout_77);
			car21.setTotalamount11(insamout_11);

			
			Total all = null;
			
			if(check31.equals("Y") || check50.equals("Y") || check51.equals("Y") || check07.equals("Y"))
	        	//判斷是否有部與承保註記
				if (GetPfwb(mform.getKyc_T1610().toString())){
					throw new UserException("WB1.ERROR13");
				}
				
			if (key.equals("C01") || key.equals("C02")){
				if (key.equals("C01"))
				{// 基本型A
					appendProcess("試算方案一…");
					appendProcess("試算險種:21…");
					
					all = car21.calculateC01();
					
					mform.setTotal21(car21.getTotal21().getTotal());
					mform.setDiscount21(car21.getTotal21().getDiscount());
				}
				else if (key.equals("C02"))
				{
					
					all = car21.calculateC02();
					
					mform.setTotal21(car21.getTotal21().getTotal());
					mform.setDiscount21(car21.getTotal21().getDiscount());
					
					mform.setTotal48(car21.getTotal48().getTotal());
					mform.setDiscount48(car21.getTotal48().getDiscount());
				}
			} else {
				//車體賠點過高判斷   有保車體險上限為2 沒有車體險則為4
				if(check07.equals("Y")){
					if (Integer.parseInt(car.getGradeCarbody().toString()) >= 2){
						throw new UserException("WB1.ERROR13");
					}
				} else {
					if (Integer.parseInt(car.getGradeCarbody().toString()) > 4){
						throw new UserException("WB1.ERROR13");
					}
				}
			
				//責任級數過高判斷
				if (Integer.parseInt(car.getGrade().toString()) > 5){
					throw new UserException("WB1.ERROR13");
				}
				if (key.equals("C03"))
				{	
					all = car21.calculateC03();
					
					mform.setTotal21(car21.getTotal21().getTotal());
					mform.setDiscount21(car21.getTotal21().getDiscount());
					
					mform.setTotal48(car21.getTotal48().getTotal());
					mform.setDiscount48(car21.getTotal48().getDiscount());

					mform.setTotal31(car21.getTotal31().getTotal());
					mform.setDiscount31(car21.getTotal31().getDiscount());
					
					mform.setTotal32(car21.getTotal32().getTotal());
					mform.setDiscount32(car21.getTotal32().getDiscount());

					mform.setTotal3132(String.valueOf(car21.getTotal31().getTotal()+car21.getTotal32().getTotal()));
					mform.setDiscount3132(String.valueOf(car21.getTotal31().getDiscount()+car21.getTotal32().getDiscount()));

					mform.setTotal35(car21.getTotal35().getTotal());
					mform.setDiscount35(car21.getTotal35().getDiscount());
				}
				else if (key.equals("C04"))
				{	//加值型B
					
					System.out.println("====C04====");
					
					all = car21.calculateC04();
					
					System.out.println("====C04 set total start ====");


					if(check21.equals("Y")){
						mform.setTotal21(car21.getTotal21().getTotal());
						mform.setDiscount21(car21.getTotal21().getDiscount());
					}
					
					if(check48.equals("Y")){
						mform.setTotal48(car21.getTotal48().getTotal());
						mform.setDiscount48(car21.getTotal48().getDiscount());
					}
					
					if(check31.equals("Y")){
						mform.setTotal31(car21.getTotal31().getTotal());
						mform.setDiscount31(car21.getTotal31().getDiscount());
				
						mform.setTotal32(car21.getTotal32().getTotal());
						mform.setDiscount32(car21.getTotal32().getDiscount());
					}
					
					if(check35.equals("Y")){
						mform.setTotal35(car21.getTotal35().getTotal());
						mform.setDiscount35(car21.getTotal35().getDiscount());
					}

					if(check31.equals("Y")){
						mform.setTotal3132(String.valueOf(car21.getTotal31().getTotal()+car21.getTotal32().getTotal()));
						mform.setDiscount3132(String.valueOf(car21.getTotal31().getDiscount()+car21.getTotal32().getDiscount()));
					}
					
					if(check51.equals("Y")){
						mform.setTotal55(car21.getTotal51().getTotal());
						mform.setDiscount55(car21.getTotal51().getDiscount());
					}
					
					if(check50.equals("Y")){
						mform.setTotal50(car21.getTotal50().getTotal());
						mform.setDiscount50(car21.getTotal50().getDiscount());
					}
					
					if(check05.equals("Y")){
						mform.setTotal05(car21.getTotal05().getTotal());
						mform.setDiscount05(car21.getTotal05().getDiscount());
					}
					
					if(check07.equals("Y")){
						mform.setTotal07(car21.getTotal07().getTotal());
						mform.setDiscount07(car21.getTotal07().getDiscount());
					}
					
					if(check0DD.equals("Y")){
						mform.setTotal0DD(car21.getTotal0DD().getTotal());
						mform.setDiscount0DD(car21.getTotal0DD().getDiscount());
					}
					
					if(check0G.equals("Y")){
						mform.setTotal0G(car21.getTotal0G().getTotal());
						mform.setDiscount0G(car21.getTotal0G().getDiscount());
					}
					
					if(check3G.equals("Y")){
						mform.setTotal3G(car21.getTotal3G().getTotal());
						mform.setDiscount3G(car21.getTotal3G().getDiscount());
					}
					
					if(check37.equals("Y")){
						mform.setTotal37(car21.getTotal37().getTotal());
						mform.setDiscount37(car21.getTotal37().getDiscount());
					}
					
					if(check11.equals("Y")){
						mform.setTotal11(car21.getTotal11().getTotal());
						mform.setDiscount11(car21.getTotal11().getDiscount());
					}
					
					if(check1DD.equals("Y")){
						mform.setTotal1DD(car21.getTotal1DD().getTotal());
						mform.setDiscount1DD(car21.getTotal1DD().getDiscount());
					}
					
					if(check12.equals("Y")){
						mform.setTotal12(car21.getTotal12().getTotal());
						mform.setDiscount12(car21.getTotal12().getDiscount());
					}
					
					if(check77.equals("Y")){
						mform.setTotal77(car21.getTotal77().getTotal());
						mform.setDiscount77(car21.getTotal77().getDiscount());
					}
					
					System.out.println("====C04 set total end ====");

				}
				else
				{	//完全保障型
					
					System.out.println("====C05====");

					all = car21.calculateC05();										
					
					System.out.println("====C05 set total START ====");

					if(check31.equals("Y")){
						mform.setTotal31(car21.getTotal31().getTotal());
						mform.setDiscount31(car21.getTotal31().getDiscount());											
						mform.setTotal32(car21.getTotal32().getTotal());
						mform.setDiscount32(car21.getTotal32().getDiscount());
					}
					
					if(check35.equals("Y")){
						mform.setTotal35(car21.getTotal35().getTotal());
						mform.setDiscount35(car21.getTotal35().getDiscount());
					}
					
					if(check31.equals("Y")){
						mform.setTotal3132(String.valueOf(car21.getTotal31().getTotal()+car21.getTotal32().getTotal()));
						mform.setDiscount3132(String.valueOf(car21.getTotal31().getDiscount()+car21.getTotal32().getDiscount()));
					}
					if(check51.equals("Y")){
						mform.setTotal55(car21.getTotal51().getTotal());
						mform.setDiscount55(car21.getTotal51().getDiscount());
					}
					if(check50.equals("Y")){
						mform.setTotal50(car21.getTotal50().getTotal());
						mform.setDiscount50(car21.getTotal50().getDiscount());
					}
					if(check05.equals("Y")){
						mform.setTotal05(car21.getTotal05().getTotal());
						mform.setDiscount05(car21.getTotal05().getDiscount());
					}
					if(check07.equals("Y")){
						mform.setTotal07(car21.getTotal07().getTotal());
						mform.setDiscount07(car21.getTotal07().getDiscount());
					}
					if(check0DD.equals("Y")){
						mform.setTotal0DD(car21.getTotal0DD().getTotal());
						mform.setDiscount0DD(car21.getTotal0DD().getDiscount());
					}
					if(check0G.equals("Y")){				
						mform.setTotal0G(car21.getTotal0G().getTotal());
						mform.setDiscount0G(car21.getTotal0G().getDiscount());
					}
					if(check3G.equals("Y")){
						mform.setTotal3G(car21.getTotal3G().getTotal());
						mform.setDiscount3G(car21.getTotal3G().getDiscount());
					}
					if(check37.equals("Y")){
						mform.setTotal37(car21.getTotal37().getTotal());
						mform.setDiscount37(car21.getTotal37().getDiscount());
					}
					if(check11.equals("Y")){
						mform.setTotal11(car21.getTotal11().getTotal());
						mform.setDiscount11(car21.getTotal11().getDiscount());
					}
					if(check1DD.equals("Y")){
						mform.setTotal1DD(car21.getTotal1DD().getTotal());
						mform.setDiscount1DD(car21.getTotal1DD().getDiscount());
					}
					if(check12.equals("Y")){
						mform.setTotal12(car21.getTotal12().getTotal());
						mform.setDiscount12(car21.getTotal12().getDiscount());
					}
					if(check77.equals("Y")){
						mform.setTotal77(car21.getTotal77().getTotal());
						mform.setDiscount77(car21.getTotal77().getDiscount());
					}

				}
			}
			
			System.out.println("====  over ==== ");
			
			int total = 0;
			int discount = 0;
			int total21 = 0;
			
			if(check21.equals("Y"))
			{
				total += mform.getTotal21();
				discount += mform.getDiscount21();
				total21 = mform.getDiscount21();

			}
			
			if(check48.equals("Y"))
			{
				total += mform.getTotal48();
				discount += mform.getDiscount48();

			}
			if(check31.equals("Y"))
			{
				total += (mform.getTotal31() + mform.getTotal32());
				discount += (mform.getDiscount31() + mform.getDiscount32());

			}	
			if(check35.equals("Y"))
			{
				total += mform.getTotal35();
				discount += mform.getDiscount35();

			}
			if(check50.equals("Y"))
			{
				total += mform.getTotal50();
				discount += mform.getDiscount50();

			}
			if(check51.equals("Y"))
			{
				total += mform.getTotal55();
				discount += mform.getDiscount55();

			}
			
			if(check05.equals("Y"))
			{
				total += mform.getTotal05();
				discount += mform.getDiscount05();

			}
			
			if(check07.equals("Y"))
			{
				total += mform.getTotal07();
				discount += mform.getDiscount07();

			}
			
			if(check0DD.equals("Y"))
			{
				total += mform.getTotal0DD();
				discount += mform.getDiscount0DD();

			}
			if(check0G.equals("Y"))
			{
				total += mform.getTotal0G();
				discount += mform.getDiscount0G();

			}
			if(check3G.equals("Y"))
			{
				total += mform.getTotal3G();
				discount += mform.getDiscount3G();

			}
			if(check37.equals("Y"))
			{
				total += mform.getTotal37();
				discount += mform.getDiscount37();

			}	
			if(check11.equals("Y"))
			{
				total += mform.getTotal11();
				discount += mform.getDiscount11();

			}
			if(check1DD.equals("Y"))
			{
				total += mform.getTotal1DD();
				discount += mform.getDiscount1DD();

			}
			if(check12.equals("Y"))
			{
				total += mform.getTotal12();
				discount += mform.getDiscount12();

			}
			if(check77.equals("Y"))
			{
				total += mform.getTotal77();
				discount += mform.getDiscount77();

			}
			
			mform.setInsamout_51total(insamout_51total);
			mform.setInsamout_31total(insamout_31total);
			mform.setInsamout_37total(insamout_37total);
			mform.setInsamout_37Dtotal(insamout_37Dtotal);
			mform.setTotal(total);
			mform.setDiscount(discount);
			mform.setTotalvol(total - total21);
			mform.setFactor21(car.getFactor21());
			mform.setFactor31(car.getGrade());
			mform.setFactor32(car.getGrade());
			mform.setFactor35(car.getGrade());
			mform.setFactor3G(car.getGrade());
			mform.setFactor37(car.getGrade());
			mform.setFactor77(car.getGrade());
			mform.setFactor11(car.getGrade());
			mform.setFactor12(car.getGrade());
			mform.setFactor05(car.getGradeCarbody());
			mform.setFactor07(car.getGradeCarbody());
			mform.setQueryNOPR(car.getQueryNOPR());//強制查詢序號
			mform.setQuserNOLV(car.getQuserNOLV());//任意查詢序號
			mform.setP09o(car.getP09o());//違規次數
			mform.setP10o(car.getP10o());//違規加費金額
			mform.setNonclaimYear(car.getBodyYear());//車體無賠款年度
			mform.setClaimTimes(car.getClaimCount());//賠款次數 
			getTransaction().begin(0);
			TradeCounter.count(getKG01(), (UserInfo) getSession().getAttribute(GlobalKey.USER_INFO), getTransaction());
		}
		finally
		{
			getRequest().setAttribute("processmsg", buf.toString());
		}
	}

    private void appendProcess(String msg) {
        if (showProcess)
            buf.append(msg).append("<br>");
    }

    private void combineBirthday() {
        mform.setBirthday(getBirthDay());
    }

    //被保險人生日
    private String getBirthDay() {
        if (mform.getByear() != null)
            return StringUtils.leftPad(mform.getByear(), 2, "0") + StringUtils.leftPad(mform.getBmonth(), 2, "0") + StringUtils.leftPad(mform.getBdate(), 2, "0");
        else
            return "0";
    }
    //要保人生日
    private String getqmanBirthDay() {
        if (mform.getByear() != null)
            return StringUtils.leftPad(mform.getKyc_T15A7_year(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_month(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_date(), 2, "0");
        else
            return "0";
    }

    private String getStartDate() {
        return StringUtils.leftPad(mform.getYear(), 2, "0") + StringUtils.leftPad(mform.getMonth(), 2, "0") + StringUtils.leftPad(mform.getDate(), 2, "0");
    }
    private String getEndDate() {
        return StringUtils.leftPad(mform.getYear2(), 2, "0") + StringUtils.leftPad(mform.getMonth2(), 2, "0") + StringUtils.leftPad(mform.getDate2(), 2, "0");
    }

    //任意起保日
    private String get_vol_InsureStart() {
        return mform.getVolyear() + StringUtils.leftPad(mform.getVolmonth(), 2, "0") + StringUtils.leftPad(mform.getVoldate(), 2, "0");
    }
    //任意到期日
    private String get_vol_InsureEnd() {
        return mform.getVolyear2() + StringUtils.leftPad(mform.getVolmonth2(), 2, "0") + StringUtils.leftPad(mform.getVoldate2(), 2, "0");
    }


    /**
     * 以kd01,kd02,kd03,kd04,kd19,kd20 抓取商品檔設定
     * 
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @return
     * @throws AsiException
     */
    private DBO getKyckd(String KD01, String KD02, String KD03, String KD04 , String KD19, String KD20) throws AsiException {
        //增加來源網站欄位的判斷
        if (KD19 == null) {
            KD19 = "KYC";
        }
        
        Kyckd kd = new Kyckd();
        kd.setKD01(KD01);
        kd.setKD02(KD02);
        kd.setKD03(KD03);
        kd.setKD04(KD04);
        kd.setKD19(KD19); //來源網站
        kd.setKD20(KD20); //通路別
        DBO dbo = kd.executeSelect(getTransaction());
        
        if (dbo.getRecordCount() == 0) {
            throw new UserException("WB1.ERROR06", KD01, KD02, KD03, mform.getCarType());
        }

        return dbo;
    }

    /**
     * 以kd01,kd02,kd03,kd04,kd06 抓取商品檔設定
     * 
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD06
     * @return
     * @throws AsiException
     */
    private DBO getKyckd(String KD01, String KD02, String KD03, String KD04, String KD06) throws AsiException {
        //增加來源網站欄位的判斷
        String KD19 = (String)getSession().getAttribute(KycGlobal.CaseFrom);
        if (KD19 == null) {
            KD19 = "KYC";
        }
        
        Kyckd kd = new Kyckd();
        kd.setKD01(KD01);
        kd.setKD02(KD02);
        kd.setKD03(KD03);
        kd.setKD04(KD04);
        kd.setKD05(mform.getCarType());
        kd.setKD06(NumberUtil.multiply(KD06, 10000));
        kd.setKD19(KD19); //來源網站
        DBO dbo = kd.executeSelect(getTransaction());
        
        if (dbo.getRecordCount() == 0) {
            throw new UserException("WB1.ERROR05", KD01, KD02, KD03, mform.getCarType(), KD06);
        }
        
        setDiscount(dbo);
        return dbo;
    }

    private void setUserinfo() {
        if (getTransaction().getUserInfo() == null) {
            UserInfo ui = new UserInfo();
            ui.setInfo("USERID", "SYSTEM");
            ui.setDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setDateType(DateUtil.ChType);
            ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setFileDateType(DateUtil.ChType);
            getTransaction().setUserInfo(ui);
        }
    }

    /**
     * 寫檔作業
     * @throws AsiException 
     */
    public String processP6() throws AsiException {
    	   
        String number = Number.getNumber_AC("AC", getServlet(), getRequest(), "T");
        mform.setNumber(number);
        mform.setKYC_T1501a(number);
        mform.setKYC_T1503a("C1");
      
        //測試寫檔完成用******************************************************************************************
//        mform.setRetcode("00");
//        try {
//        	getRequest().setAttribute("decodedata", Codec.decode(mform.getInstypename()));
//        } catch (IOException e) {
//      	  e.printStackTrace();
//        }        
        //****************************************************************************************************
        
        //強制起保日
        String startDate = mform.getYear()+mform.getMonth()+mform.getDate();
        //任意起保日
        String vol_startDate = mform.getVolyear() + mform.getVolmonth() + mform.getVoldate();

        //產otp
        String otp = KYCEncryptor.genOTP();
        String pjcode = mform.getPjcode();
        
        if(!pjcode.equals("")) {
        	if(isProjectCode(pjcode)){//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        		pjcode = CodeUtil.getCodeDesc(getServlet(), getRequest(), "PROJSOURCE", pjcode.toUpperCase());
            	if (pjcode.equals("HOLIDAY"))
            		pjcode = "KYC";
        	}
        	else{
        		pjcode="BOSS3.0";
        	}        	
        } else
        	pjcode = "KYC";
        	
        String channelCode = (mform.getEntry() != null && mform.getEntry().equals("2")) ? "40" : "41";
        String check21 = mform.getCkb_ins_21() != null ? mform.getCkb_ins_21() : "N";
        String check48 = mform.getCkb_ins_48() != null ? mform.getCkb_ins_48() : "N";
        String check31 = mform.getCkb_ins_31() != null ? mform.getCkb_ins_31() : "N";
        String check35 = mform.getCkb_ins_35() != null ? mform.getCkb_ins_35() : "N";
        String check50 = mform.getCkb_ins_50() != null ? mform.getCkb_ins_50() : "N";
        String check51 = mform.getCkb_ins_51() != null ? mform.getCkb_ins_51() : "N";
        String check07 = mform.getCkb_ins_07() != null ? mform.getCkb_ins_07() : "N";
        String check0DD = mform.getCkb_ins_0DD() != null ? mform.getCkb_ins_0DD() : "N";
        String check0G = mform.getCkb_ins_0G() != null ? mform.getCkb_ins_0G() : "N";
        String check3G = mform.getCkb_ins_3G() != null ? mform.getCkb_ins_3G() : "N";
        String check37 = mform.getCkb_ins_37() != null ? mform.getCkb_ins_37() : "N";
        String check77 = mform.getCkb_ins_77() != null ? mform.getCkb_ins_77() : "N";
		String check05 = mform.getCkb_ins_05() != null ? mform.getCkb_ins_05() : "N";
		String check1DD = mform.getCkb_ins_1DD() != null ? mform.getCkb_ins_1DD() : "N";
		String check11 = mform.getCkb_ins_11() != null ? mform.getCkb_ins_11() : "N";
		String check12 = mform.getCkb_ins_12() != null ? mform.getCkb_ins_12() : "N";
		
        System.out.println("processP6");
        System.out.println("check05: " + check05 + " check1DD: " + check1DD + " check11: " + check11 + " check12: " + check12);
        System.out.println("mform.getKyc_T15C11(): " + mform.getKyc_T15C11() + " mform.getKyc_T15C12(): " + mform.getKyc_T15C12() + " mform.getKyc_T15C13(): " + mform.getKyc_T15C13() + " mform.getKyc_T15C1(): " + mform.getKyc_T15C14());

        
        
		int total = 0;
		int discount = 0;
				
		if(check48.equals("Y"))
		{
			//強制保期與任意保期相同時，才把駕傷保費加到任意總保費
			if(startDate.equals(vol_startDate)){
				total += mform.getTotal48();
				discount += mform.getDiscount48();
			}
		}
		if(check31.equals("Y"))
		{
			total += (mform.getTotal31() + mform.getTotal32());
			discount += (mform.getDiscount31() + mform.getDiscount32());
		}	
		if(check35.equals("Y"))
		{
			total += mform.getTotal35();
			discount += mform.getDiscount35();
		}	
		if(check50.equals("Y"))
		{
			total += mform.getTotal50();
			discount += mform.getDiscount50();
		}
		if(check51.equals("Y"))
		{
			total += mform.getTotal55();
			discount += mform.getDiscount55();
		}
		if(check05.equals("Y"))
		{
			total += mform.getTotal05();
			discount += mform.getDiscount05();
		}
		if(check07.equals("Y"))
		{
			total += mform.getTotal07();
			discount += mform.getDiscount07();
		}
		if(check0DD.equals("Y"))
		{
			total += mform.getTotal0DD();
			discount += mform.getDiscount0DD();
		}
		if(check0G.equals("Y"))
		{
			total += mform.getTotal0G();
			discount += mform.getDiscount0G();
		}
		if(check3G.equals("Y"))
		{
			total += mform.getTotal3G();
			discount += mform.getDiscount3G();
		}
		if(check37.equals("Y"))
		{
			total += mform.getTotal37();
			discount += mform.getDiscount37();
		}
		if(check11.equals("Y"))
		{
			total += mform.getTotal11();
			discount += mform.getDiscount11();
		}
		if(check1DD.equals("Y"))
		{
			total += mform.getTotal1DD();
			discount += mform.getDiscount1DD();
		}		
		if(check12.equals("Y"))
		{
			total += mform.getTotal12();
			discount += mform.getDiscount12();
		}
		if(check77.equals("Y"))
		{
			total += mform.getTotal77();
			discount += mform.getDiscount77();
		}
        
        getTransaction().begin(0);

        if (mform.getType().equals("C01"))  // 基本型A
        {
        	//汽車強制險
            DBO dbo = getKyckd("C01", "A", "21", "1" , pjcode , channelCode );
            
            // 網路出單交易主檔
            writeToPT15PF(number, "C01", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getQueryNOPR() , otp);// 類別不傳，直接寫入交易LOG檔；改傳入查詢序號
            // 網路出單標的明細
            writeToPT16PF(number, "C01", "A", mform.getTotal21s(), mform.getDiscount21s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 類別傳入2-表寫入交易LOG檔
            // 網路出單交易明細
            writeToPT17PF(number, "C01", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getFactor21(), "2" , mform.getP09o() , mform.getP10o());// 類別傳入2-表寫入交易LOG檔
            
            mform.setKYC_T1503a("A");
        }
        else if (mform.getType().equals("C02")) // 基本型B 
        {
            //汽車強制險
            DBO dbo = getKyckd("C02", "A", "21", "1" , pjcode , channelCode);
            
            // 網路出單交易主檔
            writeToPT15PF(number, "C02", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getQueryNOPR() , otp);
            // 網路出單標的明細
            writeToPT16PF(number, "C02", "A", mform.getTotal21s(), mform.getDiscount21s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 類別傳入2-表寫入交易LOG檔
            // 網路出單交易明細
            writeToPT17PF(number, "C02", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getFactor21(), "2" , mform.getP09o() , mform.getP10o());// 類別傳入2-表寫入交易LOG檔
            
            // 強制附加單一事故駕駛人傷害險
            dbo = getKyckd("C02", "C", "48", "1" , pjcode , channelCode);
            // 網路出單交易主檔
            writeToPT15PF(number, "C02", "C1", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "" , otp);// 48險種不寫入查詢序號
            // 網路出單標的明細
            writeToPT16PF(number, "C02", "C1", mform.getDiscount48s(), mform.getDiscount48s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 類別傳入2-表寫入交易LOG檔
            // 網路出單交易明細
            writeToPT17PF(number, "C02", "C1", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        }
        else if (mform.getType().equals("C03"))// 加值型A
        { 
      	   // 汽車強制險-----------------------------------------------------------------------------------------------------------
            DBO dbo = getKyckd("C03", "A", "21", "1" , pjcode , channelCode);

            writeToPT15PF(number, "C03", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getQueryNOPR() , otp);
            writeToPT16PF(number, "C03", "A", mform.getTotal21s(), mform.getDiscount21s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔
            writeToPT17PF(number, "C03", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getFactor21(), "2" , mform.getP09o() , mform.getP10o());// 網路出單交易明細,類別傳入2-表寫入交易LOG檔
            
            if(!startDate.equals(vol_startDate)){
            	
            	if(check48.equals("Y")){
                	dbo = getKyckd("C03", "C", "48", "1" , pjcode , channelCode);
                	
                    // 網路出單交易主檔
                    writeToPT15PF(number, "C03", "C2", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "" , otp);// 48險種不寫入查詢序號
                    // 網路出單標的明細
                    writeToPT16PF(number, "C03", "C2", mform.getDiscount48s(), mform.getDiscount48s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 類別傳入2-表寫入交易LOG檔
                    // 網路出單交易明細
                    writeToPT17PF(number, "C03", "C2", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔            		
                    
                    mform.setKYC_T1503b("C2");
            	}
            	
            	
        		if(check31.equals("Y")){

                    dbo = getKyckd("C03", "C", "31", "1" , pjcode , channelCode);
                    
                    writeToPT15PF(number, "C03", "C1", String.valueOf(discount), String.valueOf(discount), dbo, mform.getQuserNOLV() , otp);// 傳入任意查詢序號
                    writeToPT16PF(number, "C03", "C1", String.valueOf(discount), String.valueOf(discount), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔

        			dbo = getKyckd("C03", "C", "31", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount31s(), mform.getDiscount31s(), dbo, NumberUtil.plus(mform.getFactor31(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKyckd("C03", "C", "32", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount32s(), mform.getDiscount32s(), dbo, NumberUtil.plus(mform.getFactor32(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		
        		if(check35.equals("Y")){
                    dbo = getKyckd("C03", "C", "35", "1", pjcode , channelCode);
                    //writeToPT17PF(number, "C03", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔
        		}           

            }else{
        		
                dbo = getKyckd("C03", "C", "31", "1" , pjcode , channelCode);
                
                writeToPT15PF(number, "C03", "C1", String.valueOf(discount), String.valueOf(discount), dbo, mform.getQuserNOLV() , otp);// 傳入任意查詢序號
                writeToPT16PF(number, "C03", "C1", String.valueOf(discount), String.valueOf(discount), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔

            	if(check48.equals("Y"))
        		{
        			dbo = getKyckd("C03", "C", "48", "1" , pjcode , channelCode);
                    // 網路出單交易明細
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        		}
                
        		if(check31.equals("Y")){
                    dbo = getKyckd("C03", "C", "31", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount31s(), mform.getDiscount31s(), dbo, NumberUtil.plus(mform.getFactor31(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKyckd("C03", "C", "32", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount32s(), mform.getDiscount32s(), dbo, NumberUtil.plus(mform.getFactor32(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		
        		if(check35.equals("Y")){
                    dbo = getKyckd("C03", "C", "35", "1", pjcode , channelCode);
                    //writeToPT17PF(number, "C03", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
                    writeToPT17PF(number, "C03", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔
        		}           
            }
            
        } 
        else if (mform.getType().equals("C04"))// 加值型B
        { 
        	DBO dbo = null;
        	
        	if(check21.equals("Y")){
            	// 汽車強制險-----------------------------------------------------------------------------------------------------------
                dbo = getKyckd("C04", "A", "21", "1" , pjcode , channelCode);

                writeToPT15PF(number, "C04", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getQueryNOPR() , otp);
                writeToPT16PF(number, "C04", "A", mform.getTotal21s(), mform.getDiscount21s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔
                writeToPT17PF(number, "C04", "A", mform.getTotal21s(), mform.getDiscount21s(), dbo, mform.getFactor21(), "2" , mform.getP09o() , mform.getP10o());// 網路出單交易明細,類別傳入2-表寫入交易LOG檔
        	}
            
            if(!startDate.equals(vol_startDate)){
            	
            	if(check48.equals("Y")){
                	dbo = getKyckd("C04", "C", "48", "1" , pjcode , channelCode);
                	
                    // 網路出單交易主檔
                    writeToPT15PF(number, "C04", "C2", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "" , otp);// 48險種不寫入查詢序號
                    // 網路出單標的明細
                    writeToPT16PF(number, "C04", "C2", mform.getDiscount48s(), mform.getDiscount48s(), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 類別傳入2-表寫入交易LOG檔
                    // 網路出單交易明細
                    writeToPT17PF(number, "C04", "C2", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔            	
                    
                    mform.setKYC_T1503b("C2");
            	}
            	
                dbo = getKyckd("C04", "C", "31", "1" , pjcode , channelCode);
                
                writeToPT15PF(number, "C04", "C1", String.valueOf(discount), String.valueOf(discount), dbo, mform.getQuserNOLV() , otp);// 傳入任意查詢序號
                writeToPT16PF(number, "C04", "C1", String.valueOf(discount), String.valueOf(discount), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔
            	
        		if(check31.equals("Y")){
                    dbo = getKyckd("C04", "C", "31", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount31s(), mform.getDiscount31s(), dbo, NumberUtil.plus(mform.getFactor31(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKyckd("C04", "C", "32", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount32s(), mform.getDiscount32s(), dbo, NumberUtil.plus(mform.getFactor32(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check3G.equals("Y")){
                    dbo = getKyckd("C04", "C", "3G", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount3Gs(), mform.getDiscount3Gs(), dbo, NumberUtil.plus(mform.getFactor3G(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check37.equals("Y")){
                    dbo = getKyckd("C04", "C", "37", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount37s(), mform.getDiscount37s(), dbo, NumberUtil.plus(mform.getFactor37(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check77.equals("Y")){
                    dbo = getKyckd("C04", "C", "77", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount77s(), mform.getDiscount77s(), dbo, NumberUtil.plus(mform.getFactor77(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check35.equals("Y")){
                    dbo = getKyckd("C04", "C", "35", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check51.equals("Y")){
                    dbo = getKyckd("C04", "C", "51", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount55s(), mform.getDiscount55s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
        		if(check50.equals("Y")){
                    dbo = getKyckd("C04", "C", "50", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount50s(), mform.getDiscount50s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
                    insertPT18PF(number, "C04", "C1", "50");
       			}
        		if(check05.equals("Y")){
                    dbo = getKyckd("C04", "C", "05", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount05s(), mform.getDiscount05s(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check0DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "0DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
            		if(check0G.equals("Y")){
                        dbo = getKyckd("C04", "C", "0G", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check07.equals("Y")){
                    dbo = getKyckd("C04", "C", "07", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount07s(), mform.getDiscount07s(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check0DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "0DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
            		if(check0G.equals("Y")){
                        dbo = getKyckd("C04", "C", "0G", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check11.equals("Y")){
                    dbo = getKyckd("C04", "C", "11", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount11s(), mform.getDiscount11s(), dbo, mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check1DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "1DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount1DDs(), mform.getDiscount1DDs(), dbo, mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check12.equals("Y")){
                    dbo = getKyckd("C04", "C", "12", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount12s(), mform.getDiscount12s(), dbo, mform.getFactor12(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}



            }else{
            	
                dbo = getKyckd("C04", "C", "31", "1" , pjcode , channelCode);
                
                writeToPT15PF(number, "C04", "C1", String.valueOf(discount), String.valueOf(discount), dbo, mform.getQuserNOLV() , otp);// 傳入任意查詢序號
                writeToPT16PF(number, "C04", "C1", String.valueOf(discount), String.valueOf(discount), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔

        		if(check48.equals("Y"))
        		{
        			dbo = getKyckd("C04", "C", "48", "1" , pjcode , channelCode);
                    // 網路出單交易明細
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount48s(), mform.getDiscount48s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        		}
                
        		if(check31.equals("Y")){
                    dbo = getKyckd("C04", "C", "31", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount31s(), mform.getDiscount31s(), dbo, NumberUtil.plus(mform.getFactor31(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKyckd("C04", "C", "32", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount32s(), mform.getDiscount32s(), dbo, NumberUtil.plus(mform.getFactor32(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check35.equals("Y")){
                    dbo = getKyckd("C04", "C", "35", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check3G.equals("Y")){
                    dbo = getKyckd("C04", "C", "3G", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount3Gs(), mform.getDiscount3Gs(), dbo, NumberUtil.plus(mform.getFactor3G(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check37.equals("Y")){
                    dbo = getKyckd("C04", "C", "37", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount37s(), mform.getDiscount37s(), dbo, NumberUtil.plus(mform.getFactor37(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check77.equals("Y")){
                    dbo = getKyckd("C04", "C", "77", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount77s(), mform.getDiscount77s(), dbo, NumberUtil.plus(mform.getFactor77(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
        		}
        		if(check51.equals("Y")){
                    dbo = getKyckd("C04", "C", "51", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount55s(), mform.getDiscount55s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
        		if(check50.equals("Y")){
                    dbo = getKyckd("C04", "C", "50", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount50s(), mform.getDiscount50s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
                    insertPT18PF(number, "C04", "C1", "50");
        		}
        		if(check05.equals("Y")){
                    dbo = getKyckd("C04", "C", "05", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount05s(), mform.getDiscount05s(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check0DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "0DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
            		if(check0G.equals("Y")){
                        dbo = getKyckd("C04", "C", "0G", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check07.equals("Y")){
                    dbo = getKyckd("C04", "C", "07", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount07s(), mform.getDiscount07s(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check0DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "0DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
            		if(check0G.equals("Y")){
                        dbo = getKyckd("C04", "C", "0G", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check11.equals("Y")){
                    dbo = getKyckd("C04", "C", "11", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount11s(), mform.getDiscount11s(), dbo,  mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
            		if(check1DD.equals("Y")){
                        dbo = getKyckd("C04", "C", "1DD", "1", pjcode , channelCode);
                        writeToPT17PF(number, "C04", "C1", mform.getDiscount1DDs(), mform.getDiscount1DDs(), dbo, mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
           			}
        		}
        		if(check12.equals("Y")){
                    dbo = getKyckd("C04", "C", "12", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C04", "C1", mform.getDiscount12s(), mform.getDiscount12s(), dbo,  mform.getFactor12(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
        		

            }
        	
        	
        }
        else if (mform.getType().equals("C05"))//單任意方案
        {
        	DBO dbo = null;
        	dbo = getKyckd("C05", "C", "31", "1" , pjcode , channelCode);
            
            writeToPT15PF(number, "C05", "C1", String.valueOf(discount), String.valueOf(discount), dbo, mform.getQuserNOLV() , otp);// 傳入任意查詢序號
            writeToPT16PF(number, "C05", "C1", String.valueOf(discount), String.valueOf(discount), "2",NumberUtil.plus(mform.getFactor31(), 4), mform.getFactor07());// 網路出單標的明細,類別傳入2-表寫入交易LOG檔
            
    		if(check31.equals("Y")){
                dbo = getKyckd("C05", "C", "31", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount31s(), mform.getDiscount31s(), dbo, NumberUtil.plus(mform.getFactor31(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKyckd("C05", "C", "32", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount32s(), mform.getDiscount32s(), dbo, NumberUtil.plus(mform.getFactor32(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
    		}
    		if(check35.equals("Y")){
                dbo = getKyckd("C05", "C", "35", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount35s(), mform.getDiscount35s(), dbo, NumberUtil.plus(mform.getFactor35(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
    		}
    		if(check3G.equals("Y")){
                dbo = getKyckd("C05", "C", "3G", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount3Gs(), mform.getDiscount3Gs(), dbo, NumberUtil.plus(mform.getFactor3G(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
    		}
    		if(check37.equals("Y")){
                dbo = getKyckd("C05", "C", "37", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount37s(), mform.getDiscount37s(), dbo, NumberUtil.plus(mform.getFactor37(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
    		}
    		if(check77.equals("Y")){
                dbo = getKyckd("C05", "C", "77", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount77s(), mform.getDiscount77s(), dbo, NumberUtil.plus(mform.getFactor77(), 4), "2" , "0" , "0");// 網路出單交易明細,類別傳入2-表寫入交易LOG檔    			
    		}
    		if(check51.equals("Y")){
                dbo = getKyckd("C05", "C", "51", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount55s(), mform.getDiscount55s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
   			}
    		if(check50.equals("Y")){
                dbo = getKyckd("C05", "C", "50", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount50s(), mform.getDiscount50s(), dbo, "4", "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
                insertPT18PF(number, "C04", "C1", "50");
    		}
    		
    		if(check05.equals("Y")){
                dbo = getKyckd("C05", "C", "05", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount05s(), mform.getDiscount05s(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        		if(check0DD.equals("Y")){
                    dbo = getKyckd("C05", "C", "0DD", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C05", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
        		if(check0G.equals("Y")){
                    dbo = getKyckd("C05", "C", "0G", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C05", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor05(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
    		}
    		if(check07.equals("Y")){
                dbo = getKyckd("C05", "C", "07", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount07s(), mform.getDiscount07s(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        		if(check0DD.equals("Y")){
                    dbo = getKyckd("C05", "C", "0DD", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C05", "C1", mform.getDiscount0DDs(), mform.getDiscount0DDs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
        		if(check0G.equals("Y")){
                    dbo = getKyckd("C05", "C", "0G", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C05", "C1", mform.getDiscount0Gs(), mform.getDiscount0Gs(), dbo, mform.getFactor07(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
    		}
    		
    		if(check11.equals("Y")){
                dbo = getKyckd("C05", "C", "11", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount11s(), mform.getDiscount11s(), dbo,  mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
        		if(check1DD.equals("Y")){
                    dbo = getKyckd("C05", "C", "1DD", "1", pjcode , channelCode);
                    writeToPT17PF(number, "C05", "C1", mform.getDiscount1DDs(), mform.getDiscount1DDs(), dbo, mform.getFactor11(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
       			}
    		}
    		if(check12.equals("Y")){
                dbo = getKyckd("C05", "C", "12", "1", pjcode , channelCode);
                writeToPT17PF(number, "C05", "C1", mform.getDiscount12s(), mform.getDiscount12s(), dbo,  mform.getFactor12(), "2" , "0" , "0");// 類別傳入2-表寫入交易LOG檔
   			}

        }
        String HitrustlID = mform.getNumber();	
		return HitrustlID;
    }

	/**
	 * 取得報表路徑
	 * 
	 * @param url
	 * @return
	 * @throws JspException
	 */
	public String getPath(String url) throws JspException
	{
		String host = System.getProperty("jasper.report-url");
		if (host == null)
		{
			host = ConfigUtil.getConfig(getServlet(), "jasper.report-intra");
		}
		StringBuffer action = new StringBuffer();
		action.append(host).append(url).append(".do");
		logger.info("report action path : " + action.toString());
		return action.toString();
	}

	/**
	 * 汽車確認投保通知
	 * @param number
	 * @param request
	 */
	public void sendCarMail(String number , HttpServletRequest request) {

        KycMailUtil sender = new KycMailUtil();
        sender.setSubject("第一產物保險-汽車險投保申請通知");
        
        WB1M020f mform = (WB1M020f) request.getSession().getAttribute("WB1M020f");
        String entry = mform.getEntry();
        
        BufferedReader fr;
        String path = "";
        if(entry.equals("2"))
        	if (mform.getType().equals("C01")){
        		path = getServlet().getServletContext().getRealPath("/mail/motorInsurances_2_40_OrderOK.html");
        	} else {
        		path = getServlet().getServletContext().getRealPath("/mail/motorInsurances_2_OrderOK.html");
        		
            }
        else
        	path = getServlet().getServletContext().getRealPath("/mail/motorInsurancesOrderOK.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
       
        String decodedata = "";
        try {
        	decodedata = Codec.decode(mform.getInstypename()).toString();
        } catch (IOException e) {
      	  e.printStackTrace();
        }

        //組下載要保書連結
        StringBuffer url = new StringBuffer();      
        if(mform.getType().equals("M01"))
        	url.append("") ;
        else{        	
			try {
				
				url.append("<a href=\"");
				url.append(getPath("/AD2R0101") + "?select=1&sourcepg=B2C");
				url.append("&KYC_T1501a=" + number);
				url.append("&KYC_T1503a=" + mform.getKYC_T1503a());
				url.append("\" target=\"_blank\" > 【下載要保書】</a>");
				
			} catch (JspException e) {
				e.printStackTrace();
			}
        }
			
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", mform.getKyc_T1506());
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{total\\}", FormatUtil.getDecimalFormat(Double.parseDouble(String.valueOf(mform.getTotal())), 0));
        msg = msg.replaceAll("\\{discount\\}", FormatUtil.getDecimalFormat(Double.parseDouble(String.valueOf(mform.getDiscount())), 0));
        if (mform.getTotal()== mform.getDiscount()) {
            msg = msg.replaceAll("\\{showdiscount\\}", "none");
        }
        msg = msg.replaceAll("\\{type\\}", mform.getType());
        msg = msg.replaceAll("\\{carKind\\}", mform.getCarbrandname());
        msg = msg.replaceAll("\\{insurancecontent\\}", decodedata);
        msg = msg.replaceAll("\\{printdoc\\}", url.toString());

        msg = msg.replaceAll("\\{stry\\}", mform.getYear());
        msg = msg.replaceAll("\\{strm\\}", mform.getMonth());
        msg = msg.replaceAll("\\{strd\\}", mform.getDate());
        msg = msg.replaceAll("\\{endy\\}", mform.getYear2());
        msg = msg.replaceAll("\\{endm\\}", mform.getMonth2());
        msg = msg.replaceAll("\\{endd\\}", mform.getDate2());
        
        msg = msg.replaceAll("\\{time\\}", "十二");
        
        sender.setMessage(msg);
        sender.addTo(mform.getKyc_T1516());
        sender.sendMail();
	}


    private void writeToPT15PF(String number, String T1502, String T1503, String T1539, String T1541, DBO kyckd, String querySeries ,String otp) throws AsiException {   	 
    	DBO dbo = null;
    	dbo = getTransaction().getDBO("kyc.KYCKLAt", 0);//type=2 表寫入交易LOG檔

    	System.out.println("mform.getKyc_T15C11() = " + mform.getKyc_T15C11());
    	System.out.println("mform.getKyc_T15C12() = " + mform.getKyc_T15C12());
    	System.out.println("mform.getKyc_T15C13() = " + mform.getKyc_T15C13());
    	System.out.println("mform.getKyc_T15C14() = " + mform.getKyc_T15C14());
    	
        dbo.addParameter("T1501", number);
        dbo.addParameter("T1502", T1502);
        dbo.addParameter("T1503", T1503);
        dbo.addParameter("T1504", "");
        dbo.addParameter("T1505", Employee.getEmployee(kyckd.getRecordData("KD17")).getCarInsArea());
        dbo.addParameter("T1506", mform.getKyc_T1506());//被保險人
        dbo.addParameter("T1507", mform.getKyc_T1507());
        dbo.addParameter("T1508", getBirthDay());
        dbo.addParameter("T1509", mform.getKyc_T1509());
        dbo.addParameter("T1510", mform.getKyc_T1510());
        dbo.addParameter("T1511", getZip());
        dbo.addParameter("T1512", mform.getKyc_T1512());
        dbo.addParameter("T1513", mform.getKyc_T1513());
        dbo.addParameter("T1514", mform.getKyc_T1514());
        dbo.addParameter("T1515", mform.getKyc_T1515());
        dbo.addParameter("T1516", mform.getKyc_T1516());
        
        //起保日
        String strdate = "0";
        String enddate = "0";
        if(T1503.equals("A") || T1503.equals("C2")){
        	strdate = getStartDate();
        	enddate = getEndDate();
        }
        else if(T1503.equals("C1")){
        	if(mform.getCkb_ins_21().equals("Y")){
            	if(!mform.getCkb_ins_31().equals("Y") && !mform.getCkb_ins_35().equals("Y") && !mform.getCkb_ins_50().equals("Y") && !mform.getCkb_ins_51().equals("Y") && !mform.getCkb_ins_07().equals("Y")){
                	strdate = getStartDate();
                	enddate = getEndDate();      		
            	}else{    		
                	strdate = get_vol_InsureStart();
                	enddate = get_vol_InsureEnd();
            	}
        	}else{
            	strdate = get_vol_InsureStart();
            	enddate = get_vol_InsureEnd();
        	}
        }else {
        	strdate = "0";
        	enddate = "0";
        }

        dbo.addParameter("T1517", strdate);
        dbo.addParameter("T1518", enddate);
        
        int vol_tatal = Integer.parseInt(mform.getDiscounts()) - mform.getDiscount21();//計算任意險保費
        
        String businessSource = SystemParam.getParam("BUSINESS_SOURCE");
        if (checkZ42100(vol_tatal))//任意險保費超過5000檢核
        	dbo.addParameter("T1519", businessSource);
        else
        	dbo.addParameter("T1519", kyckd.getRecordData("KD16"));
        
        dbo.addParameter("T1520", kyckd.getRecordData("KD17"));
        dbo.addParameter("T1521", "");
        dbo.addParameter("T1522", "0");
        dbo.addParameter("T1523", DateUtil.getSysDate(getUsrInfo(), false));
        dbo.addParameter("T1524", "0");
        dbo.addParameter("T1525", "");
        dbo.addParameter("T1526", "");
        dbo.addParameter("T1527", "");
        dbo.addParameter("T1528", "");
        dbo.addParameter("T1529", "");
        dbo.addParameter("T1530", "9");
        dbo.addParameter("T1534", "");
        dbo.addParameter("T1535", "");
        dbo.addParameter("T1536", "");
        dbo.addParameter("T1537", "");
        dbo.addParameter("T1538", "B2C");
        dbo.addParameter("T1539", T1539);
        dbo.addParameter("T1540", NumberUtil.sub(T1539, T1541));
        dbo.addParameter("T1541", T1541);
        dbo.addParameter("T1543", "");
        dbo.addParameter("T1544", mform.getKyc_T1544());
        
        if(!T1503.equals("A")){
        	dbo.addParameter("T1545", mform.getKyc_T1545());
            dbo.addParameter("T1542", mform.getKYC_T1542a());

        }else{
        	dbo.addParameter("T1545", "");
        	dbo.addParameter("T1542", "");
        }
        	
        dbo.addParameter("T1546", mform.getKyc_T1546());
        dbo.addParameter("T1547", mform.getKyc_T1547());
        dbo.addParameter("T1548", mform.getKyc_T1548());
        dbo.addParameter("T1549", "0");
        dbo.addParameter("T1550", "");
        dbo.addParameter("T1551", mform.getKyc_T1551());
        dbo.addParameter("T1552", "");
        dbo.addParameter("T1553", "");
        dbo.addParameter("T1554", "0");
        dbo.addParameter("T1555", "");
        
        //寫入t1556車體無賠款年度 , t1557賠款次數
        if(!T1503.equals("A")){
            dbo.addParameter("T1556", mform.getNonclaimYear());
            dbo.addParameter("T1557", mform.getClaimTimes());
        }else{
            dbo.addParameter("T1556", "0");
            dbo.addParameter("T1557", "0");
        }

        dbo.addParameter("T1558", "0");
        dbo.addParameter("T1559", "0");
        dbo.addParameter("T1560", "0");
        dbo.addParameter("T1561", "0");
        dbo.addParameter("T1562", "");
        dbo.addParameter("T1563", "");
        dbo.addParameter("T1564", "");
        dbo.addParameter("T1565", "");
        dbo.addParameter("T1566", "");
        dbo.addParameter("T1567", "");
        dbo.addParameter("T1568", "");
        //任意險且為網投
        if(!mform.getType().equals("M01") && mform.getEntry().equals("1")){
        	dbo.addParameter("T1569", mform.getKyc_T1569());	//電訪註記
        }
        else{
        	dbo.addParameter("T1569", "");	//電訪註記
        }       
        dbo.addParameter("T1570", "");
        dbo.addParameter("T1571", getT1571(kyckd));
        dbo.addParameter("T1572", DateUtil.getSysTime(false));
        dbo.addParameter("T1573", mform.getKyc_T1573());
        dbo.addParameter("T1574", "N");
        
        String t1575 = mform.getKyc_T1575();//用以註記電子式保單
        if(T1503.equals("A"))//強制險一律為電子式
        	t1575 = "Y";
        
        dbo.addParameter("T1575", t1575);
        dbo.addParameter("T1576", mform.getKyc_T1576());
        dbo.addParameter("T1577", "N");
        dbo.addParameter("TA1501", "");
        dbo.addParameter("TA1502", "");
        dbo.addParameter("TA1503", "");
        dbo.addParameter("TA1504", "");
        dbo.addParameter("TA1505", "");
        dbo.addParameter("TA1506", "");
        dbo.addParameter("TA1507", mform.getKyc_TA1507());
        dbo.addParameter("T1594", DateUtil.getSysTime());
        dbo.addParameter("T1595", DateUtil.getSysTime());
        dbo.addParameter("T1596", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1597", mform.getKyc_T1507());
        dbo.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1599", mform.getKyc_T1507());
        dbo.addParameter("T1580", "1");
        //強制任意關貿查詢序號
        dbo.addParameter("T15A1", querySeries);
        dbo.addParameter("T15A7", getqmanBirthDay());//要保人生日

        mform.setData_otp(otp);
        
        //OTP
        String expireTime = SystemParam.getParam("OTPEXTIME");
        String otpexpireday = getExpireDate();
        String INSARGNO = SystemParam.getParam("ARGDOC_INS_NO"); // 聲明事項文件編號

        mform.setExpireTime(expireTime);
        mform.setExpireDate(otpexpireday);

        dbo.addParameter("T15B0", mform.isNewClient() ? "1" : "2");
        dbo.addParameter("T15B1", otp);
        dbo.addParameter("T15B2", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T15B3", DateUtil.getSysTime(false));
        dbo.addParameter("T15B4", otpexpireday);
        dbo.addParameter("T15B5", expireTime);
        dbo.addParameter("T15B6", "0");
        dbo.addParameter("T15B7", "0");
        dbo.addParameter("T15B8", "0");
        dbo.addParameter("T15B9", mform.getEntry().equals("1") ? "NCCC" : "Hitrust");
        
        dbo.addParameter("T15C0", mform.getIsmobile());
        dbo.addParameter("T15C1", mform.getOs());
        dbo.addParameter("T15C2", mform.getBrowser());
        dbo.addParameter("T15C3", mform.getBro_version());
        dbo.addParameter("T15C9", INSARGNO);
        //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
        String remoteAddr = getRequest().getHeader("X-FORWARDED-FOR");
        System.out.println("remoteAddr: " + remoteAddr);
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = getRequest().getRemoteAddr();
            System.out.println("remoteAddr: " + remoteAddr);
        }        
        dbo.addParameter("T15C10", remoteAddr);
        dbo.addParameter("T15E0", remoteAddr);

        if(!T1503.equals("A")){
        	if(mform.getCkb_ins_21() != null && !mform.getCkb_ins_21().equals("Y")){
	            dbo.addParameter("T1545A", mform.getKyc_T1545A());	//有效強制證保期起日
	            dbo.addParameter("T1545B", mform.getKyc_T1545B());	//有效強制證保期迄日
        	}
        }else{
            dbo.addParameter("T1545A", "");	//有效強制證保期起日
            dbo.addParameter("T1545B", "");	//有效強制證保期迄日
        }
        dbo.addParameter("T1544A", mform.getKyc_T1544A());	//被保險人國籍
        dbo.addParameter("TA1512", mform.getKyc_TA1512());	//被保險人評估職業
        dbo.addParameter("T15D0", mform.getKyc_T15D0());	//要保人國籍
        dbo.addParameter("TA1511", mform.getKyc_TA1511());	//要保人評估職業
        
        dbo.addParameter("TA1505", mform.getKyc_TA1505());	//車險客戶屬性
        dbo.addParameter("TA1506", mform.getKyc_TA1506());	//車險客戶繳交保費來源
        dbo.addParameter("TA1506O", mform.getKyc_TA1506o());	//車險客戶繳交保費來源-其他

        dbo.addParameter("T15C11", mform.getKyc_T15C11());	//勘車註記
        dbo.addParameter("T15C12", mform.getKyc_T15C12());	//勘車地點
        dbo.addParameter("T15C13", mform.getKyc_T15C13());	//勘車日期
        dbo.addParameter("T15C14", mform.getKyc_T15C14());	//勘車時間
        
        
        dbo.addParameter("T1584", mform.getKyc_T1584());	//促銷代碼
        
        dbo.addParameter("T1582", mform.getPjcode() == null ? "" : mform.getPjcode());	//推薦人代碼
        
        dbo.executeInsert();//
    }

    /**
     * 業源Z42100檢查
     * 110年6月前之假日, 任意險保費逹$5,000
     * @return
     * @throws AsiException
     */
    public boolean checkZ42100(Integer i)  {
    	boolean ret = false;
    	String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sysYM = sysDate.substring(0, sysDate.length() - 2);
		int campaignDate = Integer.parseInt(SystemParam.getParam("CAMPAIGN_DATE"));
		if (Integer.parseInt(sysYM) <= campaignDate && i >= 5000) {  //110年6月前任意險保費逹$5,000
			QueryRunner run = new QueryRunner();
			try
			{
				String sql = "SELECT * FROM AGAGPF WHERE AG04 = ?";  //檢核工作日檔
				String[] param = new String[1];
				param[0] = sysDate;
				getTransaction().begin(1);
				List<?> c = (List<?>) run.query(getTransaction().getConnection(1),sql,param,new TrimedMapListHandler());
				if(c.size() <= 0)
					ret= true;
			}
			catch (Exception e)
			{
				System.out.print("bb:" + e);
			}
		}
    	
    	return ret;
    }
    
    /**
     * @param kyckd
     * @return
     */
    private String getT1571(DBO kyckd) {
        String discount = kyckd.getRecordData("KD11");
        if (discount.equals("0"))
            discount = kyckd.getRecordData("KD12");
        return discount;
    }

    private void writeToPT16PF(String T1601, String T1602, String T1603, String T1632, String T1635, String type, String factor31, String factor07) throws AsiException {
    	DBO dbo = null;
    	dbo = getTransaction().getDBO("kyc.KYCKLBt", 0);//type=2 表寫入交易LOG檔	  
		  
        dbo.addParameter("T1601", T1601);
        dbo.addParameter("T1602", T1602);
        dbo.addParameter("T1603", T1603);
        dbo.addParameter("T1604", "1");
        dbo.addParameter("T1605", mform.getCarserialno());        
        dbo.addParameter("T1606", StringUtils.leftPad(mform.getLicencey(), 2, "0") + StringUtils.leftPad(mform.getLicencem(), 2, "0"));
        dbo.addParameter("T1607", mform.getKyc_T1607() + mform.getKyc_T1607_MM());
        dbo.addParameter("T1608", mform.getCarType());
        dbo.addParameter("T1609", mform.getKyc_T1609());
        dbo.addParameter("T1610", mform.getCarnumbertype().equals("1") ? mform.getKyc_T1610_old() : mform.getKyc_T1610());
        dbo.addParameter("T1611", mform.getKyc_T1611());
        dbo.addParameter("T1612", mform.getPassengerType().equals("people") ? mform.getPassengerCnt() : mform.getTon());
        dbo.addParameter("T1613", mform.getPassengerType().equals("people") ? "P" : "T");
        dbo.addParameter("T1614", "");
        dbo.addParameter("T1615", "");
        dbo.addParameter("T1616", "");
        dbo.addParameter("T1617", "");
        dbo.addParameter("T1618", "");
        dbo.addParameter("T1619", "");
        dbo.addParameter("T1620", "");
        dbo.addParameter("T1621", "");
        dbo.addParameter("T1622", "0");
        dbo.addParameter("T1623", "0");
        dbo.addParameter("T1624", "0");
        dbo.addParameter("T1625", "0");
        dbo.addParameter("T1626", "");
        dbo.addParameter("T1627", "");
        dbo.addParameter("T1628", "");
        dbo.addParameter("T1629", "");
        dbo.addParameter("T1630", "");
        dbo.addParameter("T1631", "");
        dbo.addParameter("T1632", T1632);
        dbo.addParameter("T1633", NumberUtil.sub(T1632, T1635));
        dbo.addParameter("T1634", "0");
        dbo.addParameter("T1635", T1635);
        dbo.addParameter("T1636", "");
        dbo.addParameter("T1637", "");
        dbo.addParameter("T1638", "");
        
        //加寫續保單號
        if(!T1603.equals("A")){
            dbo.addParameter("T1639", mform.getKYC_T1542a());
        }else{
            dbo.addParameter("T1639", "");
        }
        
        String input1 = Integer.toString(Integer.parseInt(mform.getLicencey().toString()) + 1911) + "-" + mform.getLicencem().toString() + "-01";
        String input2 = mform.getKyc_T1607() + "-" + mform.getKyc_T1607_MM() + "-01";
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date t1 = null;
        Date t2 = null;
        try{
        	t1 = formatter.parse(input1);
        	t2 = formatter.parse(input2);
        }catch(ParseException e){
        	e.printStackTrace();
        }
        
     
        dbo.addParameter("T1640", mform.getKyc_T1640());
        dbo.addParameter("T1642", "");
        dbo.addParameter("T1643", mform.getKYC_T1643());
        dbo.addParameter("T1644", "");
        dbo.addParameter("T1645", "0");
        dbo.addParameter("T1646", "0");
        dbo.addParameter("T1647", "0");
        //起保日
        String strdate = "0";
        String enddate = "0";
        if(T1603.equals("A") || T1603.equals("C2")){
        	strdate = getStartDate();
        	enddate = getEndDate();
        }
        else if(T1603.equals("C1")){
        	strdate = get_vol_InsureStart();
        	enddate = get_vol_InsureEnd();
        }      		

        Vector t = FCSU09PRC(mform.getCarserialno(), StringUtils.leftPad(mform.getLicencey(), 2, "0") + StringUtils.leftPad(mform.getLicencem(), 2, "0"), strdate , "07");

        dbo.addParameter("T16E0", t.elementAt(0).toString());
        dbo.addParameter("T16E1", t.elementAt(1).toString());
        dbo.addParameter("T16E2", t.elementAt(2).toString());
        dbo.addParameter("T16E3", t.elementAt(3).toString());
        dbo.addParameter("T16E4", factor31);
        dbo.addParameter("T16E5", factor07);
        
        dbo.addParameter("T1694", DateUtil.getSysTime());
        dbo.addParameter("T1695", DateUtil.getSysTime());
        dbo.addParameter("T1696", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1697", mform.getKyc_T1507());
        dbo.addParameter("T1698", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1699", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    private void writeToPT17PF(String number, String T1702, String T1703, String T1720, String T1723, DBO kyckd, String factor, String type , String t1755 , String t1756) throws AsiException {        
    	DBO dbo = null;
    	dbo = getTransaction().getDBO("kyc.KYCKLCt", 0);//type=2 表寫入交易LOG檔 
		
        //任意險總保額判斷********************************************************
        String t1705 = kyckd.getRecordData("KD03");
		String t1708 = "0";		//每一人體傷死亡保額
        String t1709 = "0";		//每一人體傷死亡保額
		String t1719 = "0";		//總保額
        String t1724 = null;    // kyckd.getRecordData("KD09"); //限額代號；倍數
        // 網路要投保汽機車３１險２倍型時，限額代號欄寫入空白，其他倍數型則依其倍數寫入。其他險種初值為null(轉入400則空白)(參考KYC報價的設定)  VI71001-K
        if(t1705.equals("31")){
        	t1708 = mform.getInsamout_31() != null ?  mform.getInsamout_31() : kyckd.getRecordData("KD07");
        	t1709 = mform.getInsamout_31() != null ?  mform.getInsamout_31() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_31total() != null ?  mform.getInsamout_31total() : kyckd.getRecordData("KD06");
        	t1724 = mform.getTimes_31() != null && "2".equals(mform.getTimes_31()) ? " " : mform.getTimes_31() != null && !"2".equals(mform.getTimes_31()) ? mform.getTimes_31() : kyckd.getRecordData("KD09");
        }
        else if (t1705.equals("32")){
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_32() != null ?  mform.getInsamout_32() : kyckd.getRecordData("KD06");
        }
        else if(t1705.equals("3G")){
        	t1719 = mform.getInsamout_3G() != null ?  mform.getInsamout_3G() : kyckd.getRecordData("KD06");
        }
        else if(t1705.equals("37")){
        	t1708 = mform.getInsamout_37();//每一人住院保額
        	t1709 = mform.getInsamout_37D();//每一人身故保額
        	t1719 = mform.getInsamout_37() != null ?  mform.getInsamout_37() : kyckd.getRecordData("KD06");
        	t1724 = mform.getTimes_31() != null && "2".equals(mform.getTimes_31()) ? " " : mform.getTimes_31() != null && !"2".equals(mform.getTimes_31()) ? mform.getTimes_31() : kyckd.getRecordData("KD09");	
        }
        else if (t1705.equals("35")){
        	t1719 = mform.getInsamout_35() != null ?  mform.getInsamout_35() : kyckd.getRecordData("KD06");
        }        
        else if (t1705.equals("51")) {
        	t1708 = "0";
        	t1709 = mform.getInsamout_51() != null ?  mform.getInsamout_51() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_51total() != null ?  mform.getInsamout_51total() : kyckd.getRecordData("KD06");
        	t1724 = String.valueOf(Integer.parseInt(mform.getPassengerCnt())-1);	//乘載-1
        }         
        else if (t1705.equals("50")) {
        	t1708 = "0";
        	t1709 = mform.getInsamout_50() != null ?  mform.getInsamout_50() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_50() != null ?  mform.getInsamout_50() : kyckd.getRecordData("KD06");
        }      
        else if (t1705.equals("05")) {
        	t1708 = "0";
        	t1709 = mform.getInsamout_05() != null ?  mform.getInsamout_05() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_05() != null ?  mform.getInsamout_05() : kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("07")) {
        	t1708 = "0";
        	t1709 = mform.getInsamout_07() != null ?  mform.getInsamout_07() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_07() != null ?  mform.getInsamout_07() : kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("0DD")) {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = kyckd.getRecordData("KD06");
        	t1724 = "B";
        }
    	else if (t1705.equals("0G")) {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("11")) {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_11() != null ?  mform.getInsamout_11() : kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("1DD")) {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = kyckd.getRecordData("KD06");
        	t1724 = "B";
        }
        else if (t1705.equals("12")) {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        }
    	else if(t1705.equals("77")){
        	t1719 = mform.getInsamout_77() != null ?  mform.getInsamout_77() : kyckd.getRecordData("KD06");
        }
        else {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = kyckd.getRecordData("KD06");
        }
       
        dbo.addParameter("T1701", number);
        dbo.addParameter("T1702", T1702);
        dbo.addParameter("T1703", T1703);
        dbo.addParameter("T1704", "1");
        dbo.addParameter("T1705", t1705);
        dbo.addParameter("T1706", "");
        dbo.addParameter("T1707", "");        
        dbo.addParameter("T1708", t1708);
        dbo.addParameter("T1709", t1709);
        if (t1705.equals("07")||t1705.equals("05")){
        	dbo.addParameter("T1710", "9");
        }else if(t1705.equals("11")){
        	dbo.addParameter("T1710", "10");
        }else {
        	dbo.addParameter("T1710", "");
        }
        dbo.addParameter("T1711", "");
        dbo.addParameter("T1712", "");
        dbo.addParameter("T1713", "");
        dbo.addParameter("T1714", "");
        dbo.addParameter("T1715", "");
        dbo.addParameter("T1716", "");
        dbo.addParameter("T1717", "");
        dbo.addParameter("T1718", "");
        dbo.addParameter("T1719", t1719);
        dbo.addParameter("T1720", T1720);
        dbo.addParameter("T1723", T1723);
        dbo.addParameter("T1724", t1724);
        dbo.addParameter("T1721", NumberUtil.sub(T1720, T1723));//20-23
        dbo.addParameter("T1722", "");
        
        dbo.addParameter("T1725", "0");
        if(kyckd.getRecordData("KD03").equals("21") || kyckd.getRecordData("KD03").equals("31") || kyckd.getRecordData("KD03").equals("32") ||  kyckd.getRecordData("KD03").equals("07") ||  kyckd.getRecordData("KD03").equals("05") ||  kyckd.getRecordData("KD03").equals("0DD") ||  kyckd.getRecordData("KD03").equals("0G") ||  kyckd.getRecordData("KD03").equals("3G") ||  kyckd.getRecordData("KD03").equals("37") ||  kyckd.getRecordData("KD03").equals("77"))
        {
        	dbo.addParameter("T1726", factor);
        }else{
        	dbo.addParameter("T1726", "0");
        }
        
        dbo.addParameter("T1727", "0");
        dbo.addParameter("T1728", "0");
        dbo.addParameter("T1729", "0");
        dbo.addParameter("T1730", "0");
        dbo.addParameter("T1731", "0");
        dbo.addParameter("T1732", "0");
        dbo.addParameter("T1733", "0");
        dbo.addParameter("T1734", "0");
        dbo.addParameter("T1735", "0");
        dbo.addParameter("T1736", "0");
        dbo.addParameter("T1737", "0");
        dbo.addParameter("T1738", "0");
        dbo.addParameter("T1739", "0");
        dbo.addParameter("T1740", "0");
        dbo.addParameter("T1741", "0");
        dbo.addParameter("T1742", "0");

        //加寫續保單號
        if(!T1703.equals("A")){
            dbo.addParameter("T1743", mform.getKYC_T1542a());
        }else{
            dbo.addParameter("T1743", "");
        }

        dbo.addParameter("T1755", t1755);
        dbo.addParameter("T1756", t1756);

        /**實支實付*/
        dbo.addParameter("T1794", DateUtil.getSysTime());
        dbo.addParameter("T1795", DateUtil.getSysTime());
        dbo.addParameter("T1796", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1797", mform.getKyc_T1507());
        dbo.addParameter("T1798", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1799", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    private void insertPT18PF(String number , String t1802  , String t1803 , String t1804 ) throws AsiException {

        String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);

        String[] t1807 = mform.getKyc_T1807();
        String[] t1808 = mform.getKyc_T1808();
        String[] t1813 = mform.getKyc_T1813();
        String[] t1815 = mform.getKyc_T1815();
        String[] birthYear = mform.getKyc_T1809_year();
        String[] birthMonth = mform.getKyc_T1809_month();
        String[] birthDate = mform.getKyc_T1809_date();
        String[] t1822 = mform.getKyc_T1822();
        String[] t18c01 = mform.getKyc_T18C01();
        String[] t18c02 = mform.getKyc_T18C02();
        
		//目前流程只需寫入到交易LOG檔
        DBO dbo = getTransaction().getDBO("kyc.KYCKLDt", 0); //寫入交易LOG檔

    	String strdate = getStartDate();
    	String enddate = getEndDate();
        
        int len = t1808.length;
        for (int i = 0; i < len; i++) {
        	
            String sex = "";

    		if("BD29".indexOf(t1808[i].substring(1, 2)) != -1)
    			sex ="2";//女性
    		else
    			sex ="1";//男性
          
            dbo.addParameter("T1801", number);
            dbo.addParameter("T1802", t1802);
            dbo.addParameter("T1803", t1803);
            dbo.addParameter("T1804", t1804);
            dbo.addParameter("T1805", "0");
            dbo.addParameter("T1806", String.valueOf(i + 1));
            dbo.addParameter("T1807", t1807[i]);
            dbo.addParameter("T1808", t1808[i]);
            dbo.addParameter("T1809", birthYear[i] + birthMonth[i] + birthDate[i]);
            dbo.addParameter("T1810", sex);//性別
            dbo.addParameter("T1811", strdate);
            dbo.addParameter("T1812", enddate);
            dbo.addParameter("T1813", t1813[i]);
            dbo.addParameter("T1815", t1815[i]);
            dbo.addParameter("T1822", t1822[i]);
            dbo.addParameter("T1896", sysDate);
            dbo.addParameter("T1897", mform.getKyc_T1507());
            dbo.addParameter("T1898", sysDate);
            dbo.addParameter("T1899", mform.getKyc_T1507());
            dbo.addParameter("T18C01", t18c01[i]);
            dbo.addParameter("T18C02", t18c02[i]);
            
            dbo.executeInsert();
        }

        dbo.destroy();
    }

    
    /**
     * @return 商品代碼
     */
    public String getKG01() {
        if (mform.getType().equals("1") || mform.getType().equals("C01"))
            return "C01";
        else if (mform.getType().equals("2") || mform.getType().equals("C02"))
            return "C02";
        else
            return "C03";
    }

    public void setExtraValue() throws AsiException {
        mform.setPWD(getPassword());
    }

    /**
     * @return
     * @throws AsiException
     */
    private String getPassword() throws AsiException {
        DBO dbo = getTransaction().getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", mform.getIdentityNumber());
        dbo.executeSelect();
        mform.setPWD(dbo.getRecordData("PASSWORD"));
        return mform.getPWD();
    }

    /**
     * 計算實收保費
     * 
     * @param dbo1
     * @throws AsiException
     */
    private void setDiscount(DBO dbo1) throws AsiException {
        double kd10 = MathUtil.getDouble(dbo1.getRecordData("KD10"));
        String discount = dbo1.getRecordData("KD11");
        double discount_d;//加上優惠後的保費
        if (discount == null || discount.equals("0")) {
            double t = MathUtil.getDouble(dbo1.getRecordData("KD12"));//優惠比率
            discount_d = kd10 * (1 - t / 100);
        } else {
            discount_d = MathUtil.getDouble(dbo1.getRecordData("KD10")) - MathUtil.getDouble(dbo1.getRecordData("KD11"));
        }
        discount_d = MathUtil.round(discount_d, 0, MathUtil.ROUND);
        dbo1.addRecordData("_discount", String.valueOf(discount_d).replaceAll("\\.0", ""));
    }

    /**
     * @throws AsiException
     *  
     */
    public void processP7() throws AsiException {
        //      重新由Session取由WB1M020f
        mform = (WB1M020f) getSession().getAttribute("WB1M020f");
        setMainForm(mform);
        System.out.println("取得號碼" + mform.getNumber() + " " + mform.getInstypename());
        
        mform.setRetcode(((WB1M020f) getForm()).getRetcode());//將傳入的回應碼放入mform
        mform.setAuthCode(((WB1M020f) getForm()).getAuthCode());//將傳入的授權碼放入mform
        System.out.println("取得號碼" + mform.getRetcode() + " " + mform.getAuthCode());
        
        String number = mform.getNumber();
        
        try {
        	getRequest().setAttribute("decodedata", Codec.decode(mform.getInstypename()));
        } catch (IOException e) {
      	  e.printStackTrace();
        }        
        System.out.println("交易序號" + number + " 授權碼" + ((WB1M020f) getForm()).getOrdernumber());
        if ("00".equals(((WB1M020f) getForm()).getRetcode())) {
            //更新金流狀態
        	System.out.println("開始更新");
            UpdateState.updateKL80_State(getTransaction(), number, "3");
            System.out.println("更新完成");

        }
        else
        {
        	UpdateState.updateKL80_State(getTransaction(), number, "2");
        }

        getSession().setAttribute("MotorTransactionNumber", number);
                
        mform.setNumber(number);
        System.out.println("完成更新動作");
    }

    /**
     * @return
     */
    public String getKD01() {
        return null;
    }

    /**
     * @return Returns the factor.
     */
    public String getFactor() {
        return factor;
    }

    /**
     * @param factor The factor to set.
     */
    public void setFactor(String factor) {
        this.factor = factor;
    }

    /**
     * @return
     */
    private String getZip() {
        if (mform.getZip().equals("")) {
            DBO dbo = (DBO) getSession().getAttribute(KycGlobal.Kyc_UserInfo);
            return dbo.getRecordData("CA106");
        } else
            return mform.getZip();
    }

    //判斷投保起日是否大於上次投保迄日-1個月
    private void validDate(String lastEndDate, String nowBeginDate) throws UserException {
        if(!InsuranceUtil.isStartGreaterThanLastEndDate(nowBeginDate, lastEndDate))
            throw new UserException("WB1.ERROR12");
    }
    
 	public String[] callC37PRC(String c371i, String c372i, String c373i,String c374i, String c375i, String c376i) 
 	{
		String[] returnStatus = new String[4];
		AS400Procedure prc = new AS400Procedure();
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			returnStatus = prc.callC37PRC(con, c371i, c372i, c373i, c374i, c375i, c376i);
			
			if(returnStatus[0].equals("N"))
			{
	         DBO dbo1 = null;
	         dbo1 = getTransaction().getDBO("kyc.QT1M03s05", 1);
	         dbo1.addParameter("mg00", returnStatus[1]);
	         dbo1.executeSelect();
	         
	         returnStatus[2] = dbo1.getRecordData(1, "mg01");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			returnStatus[0] = "ERROR";
			
		} finally {
			AS400Connection.closeConnection(con);
		}

		return returnStatus;
	}

	
    /**
     * 查詢客戶所有的汽車牌照號碼及保單狀態
     * @param uid
     * @return
     */
    public List getCustomerCarNos(String uid)
    {
    	//列出所有車牌號碼
    	StringBuffer sql1 = new StringBuffer();
    	sql1.append("SELECT DISTINCT(UC09) CARNO FROM PFUP ");
    	sql1.append("LEFT JOIN PFUC ON UC001=UP001 ");
    	sql1.append("RIGHT JOIN PFBN ON BN00=SUBSTR(UC04,1,2) AND BN03='' ");//BN03：空白-汽車 ；Y -機車
    	sql1.append("WHERE UP06='" + uid + "' AND TRIM(UC09)<>'' ");

 		Connection con = AS400Connection.getConnection();
 		List ret = new LinkedList();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List) runner.query(con, sql1.toString(), new TrimedMapListHandler());			 				
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
 		
 		return ret;
    }

    
 	/**
 	 * 確認otp是否正確
 	 * @return
 	 * @throws AsiException
 	 */
 	public boolean isRightOTP()throws AsiException
 	{
 		boolean isRight = false;
 		
 		String t1501=mform.getNumber();
 		
      DBO dbo = getTransaction().getDBO("kyc.KYCKLAs03", 0);
      dbo.addParameter("T1501", t1501);
      dbo.executeSelect();

      QueryRunner run = new QueryRunner();
		String sql;
		sql = "SELECT * FROM KYCKLA ";
		sql += "WHERE T1501 = '" + t1501 + "' AND ROWNUM = 1";		

		Map ret = new HashMap();
		try
		{
			getTransaction().begin(0);
			
			ret = (Map) run.query(getTransaction().getConnection(0),sql,new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			System.out.print("bb:" + e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}

 		String inputotp = mform.getInput_otp();
 		String orgotp = ret.get("T15B1").toString();
 		String expired = ret.get("T15B4").toString();		
 		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
 		
 		if(Integer.parseInt(sysdate) <= Integer.parseInt(expired))
 				if(inputotp.equals(orgotp))
 					isRight = true;
 		
 		return isRight;
 	}

   /**
    * 查客戶id是否為排除傷害險有效保單客戶
   * @param id
   * @return
   */
  private boolean isClient_P(String id)
   {
  	boolean isNewclient = true;
  	
  	String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sql = "SELECT * FROM IC02PF WHERE C201='" + id + "' AND C206 >= " + sysdate + 
		" AND C204 NOT IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

		Connection con = AS400Connection.getConnection();
		List ret = null;
		
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql.toString(), new TrimedMapListHandler());
			
			if(!ret.isEmpty() && ret.size()>0)
				isNewclient = false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally{
			AS400Connection.closeConnection(con);
		}
		
		return isNewclient;
   }
  
   /**
    * 重新產生OTP,更新交易檔
    * @return
    * @throws AsiException
    */
   public boolean isUpdateOTP() throws AsiException 
   {
	  boolean isok = false;
  	 
	  String getotp = KYCEncryptor.genOTP();
	  mform.setData_otp(getotp);	 
	  
	  String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	  String systime = DateUtil.getSysTime();
	  String otpexpireday = getExpireDate();
  	 
	  String sql = "UPDATE KYCKLA SET T15B1=?,T15B2=?,T15B3=?,T15B4=?,T15B5=?,T1598=?,T1599=?,T15B8=0 WHERE T1501=?";
  	 
	  String args[] = new String[8];
	  args[0] = getotp;
	  args[1] = sysdate;
	  args[2] = systime;
	  args[3] = otpexpireday;
	  args[4] = SystemParam.getParam("OTPEXTIME");
	  args[5] = sysdate;
	  args[6] = mform.getUID();
	  args[7] = mform.getNumber();

	  QueryRunner runner = new QueryRunner();
	  getTransaction().begin(0);

	  int ret = 0;
  	 
	  try 
	  {
		  Connection con = getTransaction().getConnection(0);
		  ret = runner.update(con, sql ,args);
		  if(ret > 0)
			  isok = true;
  		 
	  } catch (SQLException e) {
		  e.printStackTrace();
		  throw new AsiException(e.getLocalizedMessage());
	  } 

	  return isok;
	}

 	/**
 	 * 取得OTP過期日期
 	 * @return
 	 */
 	public String getExpireDate() {
		String expireday ="";
		KycDateUtil kycdate = new KycDateUtil();
		String sysdate = kycdate.getKycDate();
 	 
     try {
         
        kycdate.setKycDate(sysdate);
        kycdate.add(KycDateUtil.DATE, NumberUtils.toInt(SystemParam.getParam("OTPEXDAY")));//系統參數，系統日加天數
        expireday = kycdate.getKycDate();

     } 
     catch (ParseException e) {
        e.printStackTrace();
     }
     return expireday;
	}

    /**
     * 檢查該車牌是否有存在FC71PF中
     * @param f7101 車牌
     * @param f7104 保單生效日
     * @return isFc71pf
     * @throws AsiException
     */
    public boolean isFc71pf(String f7101, String f7104) throws AsiException
    {
    	boolean isFc71pf = false;
    	Connection con = null;
    	try
    	{
    		con = AS400Connection.getConnection();
    		Fc71pfDao fc71pfDao = new Fc71pfDao(con);
    		if(f7104.equals(""))
    			isFc71pf = fc71pfDao.isExists(f7101);
    		else
    			isFc71pf = fc71pfDao.isExists(f7101, f7104);
    	}
    	finally
        {
            AS400Connection.closeConnection(con);
        }
		return isFc71pf;
    }

    /**
     * 抓取車排現值記錄檔FC71PF
     * @param f7101
     * @return dbo
     * @throws AsiException
     */
    public Map getFc71pf(String f7101) throws AsiException
    {
    	Map ret = null;
    	Connection con = null;
    	try
    	{
    		con = AS400Connection.getConnection();
    		Fc71pfDao fc71pfDao = new Fc71pfDao(con);
    		ret = fc71pfDao.getFc71pf(f7101);
    	}
    	finally
        {
            AS400Connection.closeConnection(con);
        }
		return ret;
    }
    
    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * 
     * @param name 姓名
     * @param id 身分證字號
     * @param agentno 招攬人
     * @return
     * @throws AsiException
     */
    public boolean checkFas24prc_new(String id , String name ,String birthday , String agentno) throws AsiException {
        /*
         * S24I0	1	文字	執行BRIDGER(ISID)方式(1/2/3)
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
         * S24I1A	1	文字	傳入小險別（ /V/T/Z）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
		 * S24I9	7	數字	傳入人員生日(民國年)
		 * S24IA	10	文字	傳入打單人員(AS400使用者帳號)
         * */
    	
        FAS24Input in = new FAS24Input();
        in.setS24i0("1");
        in.setS24i1("C");
        in.setS24i1a("");
        in.setS24i2("1");
        in.setS24i3(id);
        in.setS24i4("");
        in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        in.setS24i6(name);
        in.setS24i7("");
        in.setS24i8(id);
        in.setS24i9(birthday);
        in.setS24ia(agentno);
        FAS24PRC prc = new FAS24PRC();
        FAS24Return out = prc.execute(in);
        
       if("E".equals(out.getS24o1().trim()))
           return false;
       else
           return true;
    }

    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * 
     * @param id
     * @param name
     * @return
     * @throws AsiException
     */
    public boolean checkFas24prc(String id , String name) throws AsiException {
        /*
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
         * */
    	
        FAS24Input in = new FAS24Input();
        in.setS24i1("C");
        in.setS24i2("1");
        in.setS24i3(id);
        in.setS24i4("");
        in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        in.setS24i6(name);
        in.setS24i7("");
        in.setS24i8(id);
        FAS24PRC prc = new FAS24PRC();
        FAS24Return out = prc.execute(in);
        
       if("E".equals(out.getS24o1().trim()))
           return false;
       else
           return true;
    }
    
    /**
     * 日期差計算
     * @param d1    较大的日期
     * @param d2    较小的日期
     * @return  如果d1>d2返回 月数差 否则返回0
     */
    public static int getMonthDiff(Date d1, Date d2) {
    	Calendar c1 = Calendar.getInstance();        
    	Calendar c2 = Calendar.getInstance();        
    	c1.setTime(d1);        
    	c2.setTime(d2);        
    	if(c1.getTimeInMillis() < c2.getTimeInMillis()) 
    		return 0;        
    	int year1 = c1.get(Calendar.YEAR);        
    	int year2 = c2.get(Calendar.YEAR);        
    	int month1 = c1.get(Calendar.MONTH);        
    	int month2 = c2.get(Calendar.MONTH);        
    	int day1 = c1.get(Calendar.DAY_OF_MONTH);        
    	int day2 = c2.get(Calendar.DAY_OF_MONTH);        
    	// 获取年的差值 假设 d1 = 2015-8-16  d2 = 2011-9-30        
    	int yearInterval = year1 - year2;       
    	// 如果 d1的 月-日 小于 d2的 月-日 那么 yearInterval-- 这样就得到了相差的年数        
    	if(month1 < month2 || month1 == month2 && day1 < day2) 
    		yearInterval--;        
    	// 获取月数差值        
    	int monthInterval =  (month1 + 12) - month2  ;        
    	if(day1 < day2) 
    		monthInterval--;        
    	monthInterval %= 12;        
    	return yearInterval * 12 + monthInterval;    
    }
    
    /**
     * 是否有拒絕標記 
     * @param con 資料庫
     * @param carno 車號
     * @return true 是有 false沒有
     */
    public boolean GetPfwb(String carno)
    {
    	Connection con = AS400Connection.getConnection();
    	try
		{
	        String sql = "SELECT * FROM pfwc LEFT JOIN pfwb ON wc001 = wb00 WHERE WC09='" + carno + "' AND WB28='Y'";
	        
	        Map ret = null;
	        try 
	        {
	            QueryRunner runner = new QueryRunner();
	            ret = (Map) runner.query(con, sql, new MapHandler());
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        if (ret != null){
	        	return true;
	        } else {
	        	return false;
	        }
		}
		finally{
			AS400Connection.closeConnection(con);
		}
    }
    
    /**
     * 抓取車體竊盜相關代號及係數
     * @param carserialno	廠牌車型
     * @param inscode		車損險險種代號
     * @param ymOrig		發照年月
     * @param sDate			保單生效起
     * @return
     * @throws AsiException
     * 
     * I/O參數	長度		說明
     * SU09I1	8  		廠牌車型      
     * SU09I2	50 		發照年月      
     * SU09I3	70 		保單生效起    
     * SU09I4	3  		車損險險種代號
     * SU09O1	2  		車體費率代號  
     * SU09O2	2  		竊盜費率代號  
     * SU09O3	64 		車體費率係數  
     * SU09O4	64 		竊盜費率係數  
     */
    public Vector FCSU09PRC(String carserialno, String ymOrig, String sDate , String inscode) throws AsiException
    {
        Connection con = null;
        Vector v = new Vector();
        try
        {
        	con = AS400Connection.getConnection();

            CallableStatement Cstmt = null;
            Cstmt = con.prepareCall("call FCSU09PRC(?,?,?,?,?,?,?,?)");
            Cstmt.setString(1, carserialno);
            Cstmt.setBigDecimal(2, BigDecimal.valueOf(Long.parseLong(ymOrig)));
            Cstmt.setBigDecimal(3, BigDecimal.valueOf(Long.parseLong(sDate)));
            Cstmt.setString(4, inscode);

            //       設定回傳的變數,資料型態
            Cstmt.registerOutParameter(5, java.sql.Types.VARCHAR);
            Cstmt.registerOutParameter(6, java.sql.Types.VARCHAR);
            Cstmt.registerOutParameter(7, java.sql.Types.DECIMAL);
            Cstmt.registerOutParameter(8, java.sql.Types.DECIMAL);

            Cstmt.execute();

            //       顯示回傳值
            v.add(0, Cstmt.getString(5));
            v.add(1, Cstmt.getString(6));
            v.add(2, Cstmt.getBigDecimal(7));
            v.add(3, Cstmt.getBigDecimal(8));

            Cstmt.close();
        }
        catch (SQLException e)
        {
            throw new UserException("errors.WB1.ERROR10");
        }
        finally
        {
        	AS400Connection.closeConnection(con);
        }

        return v;
    }
    
    /* 
     * 判断是否为整数  
     * @param str 传入的字符串  
     * @return 是整数返回true,否则返回false  
     */  
     public static boolean isInteger(String str) {    
       Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");    
       return pattern.matcher(str).matches();    
     }  
    
     
     /**
      * B2C專人報價寫檔作業
      * @throws AsiException 
      */
     public String processP8() throws AsiException {
     	   
         String number = Number.getNubmer_QuoteB2C(getServlet(), getRequest(), "C");
         mform.setNumber(number);
         mform.setKYC_T1501a(number);
         mform.setKYC_T1503a("C1");
                
         String check21 = mform.getCkb_ins_21() != null ? mform.getCkb_ins_21() : "N";
         String check48 = mform.getCkb_ins_48() != null ? mform.getCkb_ins_48() : "N";
         String check31 = mform.getCkb_ins_31() != null ? mform.getCkb_ins_31() : "N";
         String check35 = mform.getCkb_ins_35() != null ? mform.getCkb_ins_35() : "N";
         String check50 = mform.getCkb_ins_50() != null ? mform.getCkb_ins_50() : "N";
         String check51 = mform.getCkb_ins_51() != null ? mform.getCkb_ins_51() : "N";
         String check37 = mform.getCkb_ins_37() != null ? mform.getCkb_ins_37() : "N";
         String check3G = mform.getCkb_ins_3G() != null ? mform.getCkb_ins_3G() : "N";
         String check08 = mform.getCkb_ins_08() != null ? mform.getCkb_ins_08() : "N";
         String check0DD = mform.getCkb_ins_0DD() != null ? mform.getCkb_ins_0DD() : "N";
         String check0G = mform.getCkb_ins_0G() != null ? mform.getCkb_ins_0G() : "N";
         String check11 = mform.getCkb_ins_11() != null ? mform.getCkb_ins_11() : "N";
         String check16 = mform.getCkb_ins_16() != null ? mform.getCkb_ins_16() : "N";
         String check12 = mform.getCkb_ins_12() != null ? mform.getCkb_ins_12() : "N";
         String check1DD = mform.getCkb_ins_1DD() != null ? mform.getCkb_ins_1DD() : "N";
         String check77 = mform.getCkb_ins_77() != null ? mform.getCkb_ins_77() : "N";
         String insA0 = mform.getCkb_ins_A0() != null ? mform.getCkb_ins_A0() : "";
         String times_31 = mform.getTimes_31();//31險種倍數
         String t1719 = "0";
         String t1724 = "0";
         
         // 網路出單交易主檔
         writeToPT15PF_Q(number, "QT", "C1", "0", "0", "0" );// 類別不傳，直接寫入交易LOG檔；改傳入查詢序號
         // 網路出單標的明細
         writeToPT16PF_Q(number, "QT", "C1", "0", "0", "2","0", "0");// 類別傳入2-表寫入交易LOG檔
         // 網路出單交易明細
         
         if(check21.equals("Y")){
        	 writeToPT17PF_Q(number, "QT", "C1", "21", "200000", "2000000", "2000000" , t1724 );//強制
         }
         
         if(check48.equals("Y")){
        	 writeToPT17PF_Q(number, "QT", "C1", "48", "200000", "2000000", "2000000" , t1724 );//駕傷
         }

         if(check31.equals("Y")){
        	 
 	        String insamout_31 = mform.getInsamout_31();		//31自選保額
 	        String insamout_32 = mform.getInsamout_32();		//32自選保額
 	        	        
 	        String insamout_31total = String.valueOf(Integer.parseInt(insamout_31) * Integer.parseInt(times_31));//保額*倍數
        	 
 	        writeToPT17PF_Q(number, "QT", "C1", "31", mform.getInsamout_31(), mform.getInsamout_31(), insamout_31total , times_31 );//任意第三人傷害
 	        writeToPT17PF_Q(number, "QT", "C1", "32", "0", "0", insamout_32 , t1724 );//任意財損
         }

         if(check35.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "35", "0", "0", mform.getInsamout_35() , t1724 );//超額
         }

         if(check50.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "50", mform.getInsamout_50(), mform.getInsamout_50(), t1719 , t1724 );//任意附加駕駛人傷害險
         }

         if(check51.equals("Y")){
        	String insamout_51 = mform.getInsamout_51();//51自選保額
  	        String insamout_51total = String.valueOf(Integer.parseInt(insamout_51) * (Integer.parseInt(mform.getP51())));	//乘客險人數

        	writeToPT17PF_Q(number, "QT", "C1", "51", "0", insamout_51, insamout_51total , t1724 );
         }

         if(check37.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "37", "0", "0", "5000" , times_31 );
         }

         if(check3G.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "3G", "0", "0", t1719 , t1724 );
         }

         if(check0G.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "0G", "0", "0", t1719 , t1724 );
         }

         if(check0DD.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "0DD", "0", "0", t1719 , "85" );
         }

         if(check08.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "08", "0", "0", t1719 , t1724 );
         }

         if(check11.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "11", "0", "0", t1719 , t1724 );
         }

         if(check16.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "16", "0", "0", t1719 , t1724 );
         }

         if(check12.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "12", "0", "0", t1719 , t1724 );
         }

         if(check1DD.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "1DD", "0", "0", t1719 , "85" );
         }
         
         if(!insA0.equals("00")){
        	writeToPT17PF_Q(number, "QT", "C1", insA0, "0", "0", t1719 , t1724 );
         }

         if(check77.equals("Y")){
        	writeToPT17PF_Q(number, "QT", "C1", "77", "0", "0", t1719 , t1724 );
         }

         return number;
     }


     private void writeToPT15PF_Q(String number, String T1502, String T1503, String T1539, String T1541, String querySeries ) throws AsiException {   	 
    	 DBO dbo = null;
    	 dbo = getTransaction().getDBO("kyc.KYCKLAt", 0);//type=2 表寫入交易LOG檔

         dbo.addParameter("T1501", number);
         dbo.addParameter("T1502", T1502);
         dbo.addParameter("T1503", T1503);
         dbo.addParameter("T1504", "");
         dbo.addParameter("T1505", "01");
         dbo.addParameter("T1506", mform.getKyc_T1506());//被保險人
         dbo.addParameter("T1507", mform.getKyc_T1507());
         dbo.addParameter("T1508", getBirthDay());
         dbo.addParameter("T1509", mform.getKyc_T1509());
         dbo.addParameter("T1510", mform.getKyc_T1510());
         dbo.addParameter("T1511", "");
         dbo.addParameter("T1512", mform.getKyc_T1512());
         dbo.addParameter("T1513", mform.getKyc_T1513());
         dbo.addParameter("T1514", mform.getKyc_T1514());
         dbo.addParameter("T1515", mform.getKyc_T1515());
         dbo.addParameter("T1516", mform.getKyc_T1516());
         
         //起保日
         String strdate = "0";
         String enddate = "0";

         dbo.addParameter("T1517", strdate);
         dbo.addParameter("T1518", enddate);
         dbo.addParameter("T1519", "");
         dbo.addParameter("T1520", "96370");
         dbo.addParameter("T1521", "");
         dbo.addParameter("T1522", "0");
         dbo.addParameter("T1523", DateUtil.getSysDate(getUsrInfo(), false));
         dbo.addParameter("T1524", "0");
         dbo.addParameter("T1525", "");
         dbo.addParameter("T1526", "");
         dbo.addParameter("T1527", "");
         dbo.addParameter("T1528", "");
         dbo.addParameter("T1529", "");
         dbo.addParameter("T1530", "9");
         dbo.addParameter("T1534", "");
         dbo.addParameter("T1535", "");
         dbo.addParameter("T1536", "");
         dbo.addParameter("T1537", "");
         dbo.addParameter("T1538", "QUT");
         dbo.addParameter("T1539", "0");
         dbo.addParameter("T1540", "0");
         dbo.addParameter("T1541", "0");
         dbo.addParameter("T1542", "");
         dbo.addParameter("T1543", "");
         dbo.addParameter("T1544", mform.getKyc_T1544());
         
         dbo.addParameter("T1545", "");
         dbo.addParameter("T1546", mform.getKyc_T1546());
         dbo.addParameter("T1547", mform.getKyc_T1547());
         dbo.addParameter("T1548", mform.getKyc_T1548());
         dbo.addParameter("T1549", "0");
         dbo.addParameter("T1550", "");
         dbo.addParameter("T1551", mform.getKyc_T1551());
         dbo.addParameter("T1552", "");
         dbo.addParameter("T1553", "");
         dbo.addParameter("T1554", "0");
         dbo.addParameter("T1555", "");
         
         //寫入t1556車體無賠款年度 , t1557賠款次數

         dbo.addParameter("T1556", "0");
         dbo.addParameter("T1557", "0");

         dbo.addParameter("T1558", "0");
         dbo.addParameter("T1559", "0");
         dbo.addParameter("T1560", "0");
         dbo.addParameter("T1561", "0");
         dbo.addParameter("T1562", "");
         dbo.addParameter("T1563", "");
         dbo.addParameter("T1564", "");
         dbo.addParameter("T1565", "");
         dbo.addParameter("T1566", "");
         dbo.addParameter("T1567", "");
         dbo.addParameter("T1568", "");
         dbo.addParameter("T1569", "");
         dbo.addParameter("T1570", "");
         dbo.addParameter("T1571", "0");
         dbo.addParameter("T1572", DateUtil.getSysTime(false));
         dbo.addParameter("T1573", mform.getKyc_T1573());
         dbo.addParameter("T1574", "N");
         dbo.addParameter("T1575", "");
         dbo.addParameter("T1576", mform.getKyc_T1576());
         dbo.addParameter("T1577", "N");
         dbo.addParameter("T1580", "1");
         dbo.addParameter("TA1501", "");
         dbo.addParameter("TA1502", "");
         dbo.addParameter("TA1503", "");
         dbo.addParameter("TA1504", "");
         dbo.addParameter("TA1505", "");
         dbo.addParameter("TA1506", "");
         dbo.addParameter("TA1507", mform.getKyc_TA1507());
         dbo.addParameter("T1594", DateUtil.getSysTime());
         dbo.addParameter("T1595", DateUtil.getSysTime());
         dbo.addParameter("T1596", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1597", mform.getKyc_T1507());
         dbo.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1599", mform.getKyc_T1507());
         dbo.addParameter("T1580", "1");
         //強制任意關貿查詢序號
         dbo.addParameter("T15A1", querySeries);
         dbo.addParameter("T15A7", getqmanBirthDay());//要保人生日
         
         String INSARGNO = SystemParam.getParam("ARGDOC_INS_NO"); // 聲明事項文件編號

         dbo.addParameter("T15B0", mform.getKyc_T15B0());
         dbo.addParameter("T15B1", "");
         dbo.addParameter("T15B2", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T15B3", DateUtil.getSysTime(false));
         dbo.addParameter("T15B4", "0");
         dbo.addParameter("T15B5", "0");
         dbo.addParameter("T15B6", "0");
         dbo.addParameter("T15B7", "0");
         dbo.addParameter("T15B8", "0");
         dbo.addParameter("T15B9", mform.getEntry().equals("1") ? "NCCC" : "Hitrust");
         
         dbo.addParameter("T15C0", mform.getIsmobile());
         dbo.addParameter("T15C1", mform.getOs());
         dbo.addParameter("T15C2", mform.getBrowser());
         dbo.addParameter("T15C3", mform.getBro_version());
         dbo.addParameter("T15C9", INSARGNO);
         //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
         String remoteAddr = getRequest().getHeader("X-FORWARDED-FOR");
         if (remoteAddr == null || "".equals(remoteAddr)) {
             remoteAddr = getRequest().getRemoteAddr();
         }        
         dbo.addParameter("T15C10", remoteAddr);
         
         dbo.addParameter("T1545A", "");	//有效強制證保期起日
         dbo.addParameter("T1545B", "");	//有效強制證保期迄日

         dbo.addParameter("T1544A", mform.getKyc_T1544A());	//被保險人國籍
         dbo.addParameter("TA1512", mform.getKyc_TA1512());	//被保險人評估職業
         dbo.addParameter("T15D0", mform.getKyc_T15D0());	//要保人國籍
         dbo.addParameter("TA1511", mform.getKyc_TA1511());	//要保人評估職業

         dbo.executeInsert();//
     }

     private void writeToPT16PF_Q(String T1601, String T1602, String T1603, String T1632, String T1635, String type, String factor31, String factor07) throws AsiException {
    	 DBO dbo = null;
    	 dbo = getTransaction().getDBO("kyc.KYCKLBt", 0);//type=2 表寫入交易LOG檔	  
 		  
         dbo.addParameter("T1601", T1601);
         dbo.addParameter("T1602", T1602);
         dbo.addParameter("T1603", T1603);
         dbo.addParameter("T1604", "1");
         dbo.addParameter("T1605", mform.getCarserialno());        
         dbo.addParameter("T1606", StringUtils.leftPad(mform.getLicencey(), 2, "0") + StringUtils.leftPad(mform.getLicencem(), 2, "0"));
         dbo.addParameter("T1607", mform.getKyc_T1607() + mform.getKyc_T1607_MM());
         dbo.addParameter("T1608", mform.getCarType());
         dbo.addParameter("T1609", mform.getKyc_T1609());
         dbo.addParameter("T1610", mform.getKyc_T1610());
         dbo.addParameter("T1611", mform.getKyc_T1611());
         dbo.addParameter("T1612", mform.getPassengerType().equals("people") ? mform.getPassengerCnt() : mform.getTon());
         dbo.addParameter("T1613", mform.getPassengerType().equals("people") ? "P" : "T");
         dbo.addParameter("T1614", "");
         dbo.addParameter("T1615", "");
         dbo.addParameter("T1616", "");
         dbo.addParameter("T1617", "");
         dbo.addParameter("T1618", "");
         dbo.addParameter("T1619", "");
         dbo.addParameter("T1620", "");
         dbo.addParameter("T1621", "");
         dbo.addParameter("T1622", "0");
         dbo.addParameter("T1623", "0");
         dbo.addParameter("T1624", "0");
         dbo.addParameter("T1625", "0");
         dbo.addParameter("T1626", "");
         dbo.addParameter("T1627", "");
         dbo.addParameter("T1628", "");
         dbo.addParameter("T1629", "");
         dbo.addParameter("T1630", "");
         dbo.addParameter("T1631", "");
         dbo.addParameter("T1632", T1632);
         dbo.addParameter("T1633", NumberUtil.sub(T1632, T1635));
         dbo.addParameter("T1634", "0");
         dbo.addParameter("T1635", T1635);
         dbo.addParameter("T1636", "");
         dbo.addParameter("T1637", "");
         dbo.addParameter("T1638", "");
         
         String input1 = Integer.toString(Integer.parseInt(mform.getLicencey().toString()) + 1911) + "-" + mform.getLicencem().toString() + "-01";
         String input2 = mform.getKyc_T1607() + "-" + mform.getKyc_T1607_MM() + "-01";
         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
         Date t1 = null;
         Date t2 = null;
         try{
         	t1 = formatter.parse(input1);
         	t2 = formatter.parse(input2);
         }catch(ParseException e){
         	e.printStackTrace();
         }
         
      
         dbo.addParameter("T1640", mform.getKyc_T1640());
         dbo.addParameter("T1642", "");
         dbo.addParameter("T1643", mform.getKYC_T1643());
         dbo.addParameter("T1644", "");
         dbo.addParameter("T1645", "0");
         dbo.addParameter("T1646", "0");
         dbo.addParameter("T1647", "0");
         //起保日
         String strdate = "0";
         String enddate = "0";
         if(T1603.equals("A") || T1603.equals("C2")){
         	strdate = getStartDate();
         	enddate = getEndDate();
         }
         else if(T1603.equals("C1")){
         	strdate = get_vol_InsureStart();
         	enddate = get_vol_InsureEnd();
         }      		

//         Vector t = FCSU09PRC(mform.getCarserialno(), StringUtils.leftPad(mform.getLicencey(), 2, "0") + StringUtils.leftPad(mform.getLicencem(), 2, "0"), strdate , "07");
//
//         dbo.addParameter("T16E0", t.elementAt(0).toString());
//         dbo.addParameter("T16E1", t.elementAt(1).toString());
//         dbo.addParameter("T16E2", t.elementAt(2).toString());
//         dbo.addParameter("T16E3", t.elementAt(3).toString());
//         dbo.addParameter("T16E4", factor31);
//         dbo.addParameter("T16E5", factor07);
         
         dbo.addParameter("T1694", DateUtil.getSysTime());
         dbo.addParameter("T1695", DateUtil.getSysTime());
         dbo.addParameter("T1696", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1697", mform.getKyc_T1507());
         dbo.addParameter("T1698", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1699", mform.getKyc_T1507());
         dbo.executeInsert();
     }

     /**
     * @param number
     * @param T1702  商品代碼
     * @param T1703  險別
     * @param T1705  險種
     * @param T1708  每一個人體傷
     * @param T1709  每一個人死亡
     * @param T1719  保險金額
     * @param T1724  限額代號     
     * @throws AsiException
     */
    private void writeToPT17PF_Q(String number, String T1702, String T1703,String T1705,String T1708,String T1709,String T1719, String T1724) throws AsiException {        
     	DBO dbo = null;
     	dbo = getTransaction().getDBO("kyc.KYCKLCt", 0);//type=2 表寫入交易LOG檔 
 		        
         dbo.addParameter("T1701", number);
         dbo.addParameter("T1702", T1702);
         dbo.addParameter("T1703", T1703);
         dbo.addParameter("T1704", "1");
         dbo.addParameter("T1705", T1705);
         dbo.addParameter("T1706", "");
         dbo.addParameter("T1707", "");        
         dbo.addParameter("T1708", T1708);
         dbo.addParameter("T1709", T1709);
         if (T1705.equals("07") || T1705.equals("05")){
         	dbo.addParameter("T1710", "9");
         } else if(T1705.equals("11")){
        	dbo.addParameter("T1710", "10"); //竊盜預設給10%
         } else{
         	dbo.addParameter("T1710", "");
         }
         dbo.addParameter("T1711", "");
         dbo.addParameter("T1712", "");
         dbo.addParameter("T1713", "");
         dbo.addParameter("T1714", "");
         dbo.addParameter("T1715", "");
         dbo.addParameter("T1716", "");
         dbo.addParameter("T1717", "");
         dbo.addParameter("T1718", "");
         dbo.addParameter("T1719", T1719);
         dbo.addParameter("T1720", "");
         dbo.addParameter("T1723", "0");
         dbo.addParameter("T1724", T1724);
         dbo.addParameter("T1721", "0");//20-23
         dbo.addParameter("T1722", "0");
         
         dbo.addParameter("T1725", "0");
         dbo.addParameter("T1726", "0");       
         dbo.addParameter("T1727", "0");
         dbo.addParameter("T1728", "0");
         dbo.addParameter("T1729", "0");
         dbo.addParameter("T1730", "0");
         dbo.addParameter("T1731", "0");
         dbo.addParameter("T1732", "0");
         dbo.addParameter("T1733", "0");
         dbo.addParameter("T1734", "0");
         dbo.addParameter("T1735", "0");
         dbo.addParameter("T1736", "0");
         dbo.addParameter("T1737", "0");
         dbo.addParameter("T1738", "0");
         dbo.addParameter("T1739", "0");
         dbo.addParameter("T1740", "0");
         dbo.addParameter("T1741", "0");
         dbo.addParameter("T1742", "0");
         dbo.addParameter("T1755", "0");
         dbo.addParameter("T1756", "0");

         /**實支實付*/
         dbo.addParameter("T1794", DateUtil.getSysTime());
         dbo.addParameter("T1795", DateUtil.getSysTime());
         dbo.addParameter("T1796", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1797", mform.getKyc_T1507());
         dbo.addParameter("T1798", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
         dbo.addParameter("T1799", mform.getKyc_T1507());
         dbo.executeInsert();
     }

    /**
     * 寄送Quote EMAIL
     * @param request
     */
    public void sendQuoteMail(HttpServletRequest request)
    {
    	
    	String email = mform.getKyc_T1516();
    	String name = mform.getKyc_T1506();
    	String t1501 = mform.getNumber();
    	
    	String ecom_addr = SystemParam.getParam("ECOM_ADDR"); // 聯絡地址
        String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
        String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
        String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商接收Email

 		//寄Email
 		KycMailUtil sender = new KycMailUtil();

 		//取範本
 		BufferedReader fr;
 		String path = getServlet().getServletContext().getRealPath("/mail/B2C_QuoteSent_" + getLocale() + ".html");

 		StringBuffer linebf = new StringBuffer();
 		try {
 			fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
 			String line;
 			linebf = new StringBuffer();
 			line = fr.readLine();
 			while (line != null) {
 				linebf.append(line);
 				line = fr.readLine();
 			}

 		}
 		catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		catch (IOException e) {
 			e.printStackTrace();
 		}

	   	String msg = linebf.toString();
	   	msg = msg.replaceAll("\\{username\\}", name);
	   	msg = msg.replaceAll("\\{t1501\\}", t1501);
	   	msg = msg.replaceAll("\\{ecom_addr\\}", ecom_addr);
	   	msg = msg.replaceAll("\\{ecom_tel\\}", ecom_tel);
	   	msg = msg.replaceAll("\\{ecom_fax\\}", ecom_fax);
	   	msg = msg.replaceAll("\\{ecom_email\\}", ecom_email);
	
	   	//寄發客戶
	   	sender.setSubject("第一保 電子商務網 專人報價詢價通知");
	   	sender.setMessage(msg);
	   	sender.addTo(email);
	   	sender.sendMail();
	   	
	   	//寄發電商人員
	   	sender = new KycMailUtil();
	   	sender.setSubject("第一保 電子商務網 專人報價詢價通知");
	   	sender.setMessage(msg);
	   	
		String ec_maillist = CodeUtil.getCodeList(getServlet(), request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
		String[] getecemail = getAuthManList(ec_maillist);//取得人員email
	   	sender.addTo(getecemail);
	   	sender.sendMail();   	

   }

    
	/**
	 * 取出核保人員及主管email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

        Connection con = null;

		List rs = null;
		String[] email = null;

		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}

	
    /**
     * 是否有續保單號 
     * @param con 資料庫
     * @param carno ID
     * @return 
     */
    public void getT1542(){
    	
    	Connection con = AS400Connection.getConnection();
    	try
		{
	        String carnumbertype = mform.getCarnumbertype() != null ? mform.getCarnumbertype() : "0";	        

    		String carnumber = "" ;
    		if(carnumbertype.equals("1")){
    			carnumber = mform.getKyc_T1610_old();    			
    		}else{
    			carnumber = mform.getKyc_T1610();
    		}
	        String sql = "SELECT T2101 FROM PT21PF,PT22PF WHERE T2105='" + mform.getKyc_T1507() +"' AND T2209='" + carnumber + "' AND T2116='" + mform.getVolyear()+ mform.getVolmonth() + mform.getVoldate() + "' AND T2102='C1' ";

	        Map ret = null;
	        try 
	        {
	            QueryRunner runner = new QueryRunner();
	            ret = (Map) runner.query(con, sql, new MapHandler());
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        if (ret != null){
	        	//查詢A保單
	        	if(ret.get("T2101").toString().substring(4,5).equals("A")){
		        	mform.setKYC_T1542a(ret.get("T2101").toString());
		        	checkShowNotice();
	        	}
	        } else {	        	
        		mform.setShowNotice("Y");	        			
	        	mform.setKYC_T1542a("");
	        }
		}
		finally{
			AS400Connection.closeConnection(con);
		}
    }
    
    
    /**
     * 是否顯示勘車同事告示
     * @param con 資料庫
     * @param carno ID
     * @return 
     */
    public void checkShowNotice(){
    	
		String check05 = mform.getCkb_ins_05() != null ? mform.getCkb_ins_05() : "N";
		String check11 = mform.getCkb_ins_11() != null ? mform.getCkb_ins_11() : "N";
		String check12 = mform.getCkb_ins_12() != null ? mform.getCkb_ins_12() : "N";

		Boolean have05 = false;
		Boolean have11 = false;
		Boolean have12 = false;
		Boolean have0M2 = false;

    	Connection con = AS400Connection.getConnection();
    	try
		{    		

	        String sql = " SELECT * FROM PT23PF WHERE T2301='" + mform.getKYC_T1542a() + "'";
	        
	        List ret = null;
	        try 
	        {
	            QueryRunner runner = new QueryRunner();
	            ret = (List) runner.query(con, sql, new MapListHandler());
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        if (ret != null){
	        	
	        	if(check05.equals("Y") || check11.equals("Y")||check12.equals("Y")){
	        		for(int i=0 ; i<ret.size() ; i++){
	        			
	        			Map mp = (Map) ret.get(i);

	        			if (mp.get("T2304").toString().trim().equals("05")){
	        				have05 = true;
	        			}else if(mp.get("T2304").toString().trim().equals("11")){
	        				have11 = true;
	        			}else if(mp.get("T2304").toString().trim().equals("12")){
	        				have12 = true;
	        			}else if(mp.get("T2304").toString().trim().equals("0M2")){
	        				have0M2 = true;
	        			}
		        	}
	        	}
	        	
	        	//05打勾時
	        	if(check05.equals("Y")){
	        		if(have05 == false && have0M2 == false){
	        			mform.setShowNotice("Y");	
	        		}
	        	}
	        	
	        	//11打勾時
	        	if(check11.equals("Y")){
	        		if(have11 == false){
	        			mform.setShowNotice("Y");
	        		}
	        	}
	        	
	        	//12打勾時
	        	if(check12.equals("Y")){
	        		if(have12 == false){
	        			mform.setShowNotice("Y");
	        		}
	        	}
	        }
		}
		finally{
			AS400Connection.closeConnection(con);
		}
    }
    
    /**
     * 判斷是否為專案代號或推薦人代號(true->專案代號 、false->推薦人代號)
     * @param pjcode
     */
    public boolean isProjectCode(String pjcode){
    	boolean ispjcode=true;
    	
    	Connection con = AS400Connection.getOracleConnection();
    	String sql="SELECT * FROM IC01PFA WHERE C01A17 = ?";
    	List ret = new LinkedList();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List<?>) runner.query(con, sql, pjcode, new TrimedMapListHandler());	
 			if(ret != null && ret.size() > 0){
 				ispjcode=false;
 			}
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}    	    	
    	return ispjcode;
    }
    
    /**
     * 判斷是否為斷保件
     * @param pjcode
     */
    public List getCarDetail(String carnumber,String day){
    	List ret = null;
    	
    	String sql="SELECT DISTINCT C113,C206,C245,C202,C203,C201 "
				+"FROM IC02PF " 
				+"LEFT JOIN IC01PF ON C101 = C201 " 
				+"LEFT JOIN PT22PF ON C202 = T2201 "
				+"RIGHT JOIN PT40PF ON T4001='C' AND T4002=C210 "
				+"LEFT JOIN PT15PF ON T1504=C202 " 																																		  
				+"WHERE (C203 ='A' OR C203 ='C1') AND C221='N' AND (TRIM(C223) <>'Y' OR C223 IS NULL) AND C113 <> '' "
				+"AND C113 IS NOT NULL AND (C207 NOT IN('0','4') OR C207 IS NULL) AND C245=? AND C206 < ?";  	
    	String[] arg={carnumber,day};
    	
        try{
   	
        	Connection con = AS400Connection.getConnection();
        	QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql,arg ,new MapListHandler());
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
    		    	    	
    	return ret;
    }
   

}