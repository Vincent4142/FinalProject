/*
 * Created on 2005/3/23
 *
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.CharacterUtil;
import com.asi.kyc.common.utils.HitrustUtil;
import com.asi.kyc.common.utils.NCCCUtil;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.asi.kyc.wb1.dao.Strongholds;
import com.asi.kyc.wb1.forms.WB1M020f;
import com.asi.kyc.wb1.models.WB1M020m;
import com.kyc.afl.utils.WorkDay;
import com.kyc.sec.actions.kycAction;

public class NWB1M0201 extends kycAction {

	String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
	String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
	
    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException 
    {
    	WB1M020m model = new WB1M020m(tx_controller, request, form);
    	RG1M010m model2 = new RG1M010m(tx_controller, request, form);
        String omitcredit = SystemParam.getParam("INS_OMITCREDIT");// 是否略過聯合信用卡刷卡機制，平常-N 測試-Y
        String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
        String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
        String pjcode = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";
        
        if(!pjcode.equals("")) {  
        	//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        	if(model.isProjectCode(pjcode)){
        		pjcode = CodeUtil.getCodeDesc(getServlet(), request, "PROJSOURCE", pjcode.toUpperCase());//由專案代碼找對應的業務來源
            	if (pjcode.equals("HOLIDAY"))
            		pjcode = "KYC";
        	}
        	else{
        		request.getSession().setAttribute("referrerCode",pjcode);
        		
        		//將推薦人代號紀錄在cookie解決登入跳轉至住火、旅平、海域sesssion紀錄遺失問題
        		Cookie cookie = new Cookie("referrerCode",pjcode);
        		cookie.setMaxAge(600);//存活時間600秒=10分鐘 
        		response.addCookie(cookie);
        		
        		pjcode="BOSS3.0";
        	}        	
        }   
        
        request.setAttribute("pjcode", pjcode);

        WB1M020f form1 = (WB1M020f) model.getMainForm();		
        
        model.init();
        
        HttpSession session = request.getSession(false);
        //For 畫面顯示折扣金額用
        String discounty1 = get21Discount("C01", "A", "21", "1", pjcode, "41");   
        request.setAttribute("discount21y1", discounty1);
        String discounty3 = get21Discount("C03", "A", "21", "1", pjcode, "41");   
        request.setAttribute("discount21y3", discounty3);
        
        //專案名稱，若無傳入專案代號時，顯示直接投保
        String projectDesc = "直接投保";
        String pjc = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";
        if(!pjc.equals("")){
        	if(model.isProjectCode(pjc)){
        		projectDesc = CodeUtil.getCodeDesc(getServlet(), request, "CHANNELDES", pjc.toUpperCase());  
        	}        		
        }       
        request.setAttribute("pjdesc", projectDesc);

        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("C", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("C", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("C", "description"));
        request.setAttribute("meta_ogtitle", getKYCWHDbyKey("C", "ogtitle"));
        request.setAttribute("meta_ogdescription", getKYCWHDbyKey("C", "ogdescription"));
        request.setAttribute("meta_twittertitle", getKYCWHDbyKey("C", "twittertitle"));
        
        //取得招攬人代號，FAS24PRC用
        String agentno = getKYCKD_KD17("M01", "A", "21", "1", pjcode, "41");
        
        if(form.getActionCode() == 5){
        	
        	form.setNextPage(1);
        }        
        else if (form.getActionCode() == 21) 
        {
        	model.processP7();
            model.setExtraValue();
            request.setAttribute("WB1M020f", model.getMainForm());
            request.setAttribute("action", "NWB1M0201");
            
            String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商信箱
            String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
            String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
            request.setAttribute("ecom_email", ecom_email);
            request.setAttribute("telno", ecom_tel);
            request.setAttribute("faxno", ecom_fax);

			//完成投保若有填寫推薦人代號則LINE推播通知
			String referrerCode=(String) session.getAttribute("pjcode");
			if(referrerCode != "" && referrerCode !=null){
				if(!model.isProjectCode(referrerCode)){
					SendLineMessage slm=new SendLineMessage();
					String user_id=slm.getEmployeeCode(referrerCode);
					slm.sendLine(user_id, "推薦人通知", "投保：您推薦會員已完成汽車險投保，電銷部很愛你");
				}
			}
			session.removeAttribute("pjcode");
            
            form.setNextPage(8);
            return;
        }else{
  
            if (form.getSource().equals("WB1M020p1")) //第一頁
            {   
                UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);

                if (ui != null)
                	request.setAttribute("carNumbers", model.getCustomerCarNos(ui.getUserId()));
                
                form.setNextPage(2);
             }
            else if (form.getSource().equals("WB1M020p4")) //第二頁 登入頁
            {                  	
        		if(form.getActionCode()== 2)
        		{
        			
        			form.setNextPage(2);
        		}
        		else{
	            	if (model.processP4()) {
	                	request.setAttribute("carNumbers", model.getCustomerCarNos(request.getParameter("UID")));
	                    form.setNextPage(7);
	                } else {
	                    form.setNextPage(2);//已登入狀態，導輸入頁
	                    request.setAttribute("carNumbers", model.getCustomerCarNos(request.getParameter("UID")));
	                    request.setAttribute("WB1M020f", model.getMainForm());
	                }
        		}
            }
            else if (form.getSource().equals("WB1M020p2")) //試算條件輸入頁
            {    
            	session.setAttribute("WB1M020p2", form);
            	
            	//有輸入推薦人代號就紀錄
				if(request.getParameter("pjcode") !="" && request.getParameter("pjcode") != null){					
					session.setAttribute("pjcode", request.getParameter("pjcode"));
				}
            	
            	//先記住客戶是否同意行銷
            	String C01A18= request.getParameter("agreeChk4")== null ? "" : request.getParameter("agreeChk4");
            	session.setAttribute("C01A18",C01A18);
            	
            	//ID試算保費紀錄
				doKycllog(request,form.getSource(),request.getParameter("kyc_T1507"));
            	
            	//被保險人id，查詢洗錢風險評估資料
        		String t1507 = request.getParameter("kyc_T1507") !=null ? request.getParameter("kyc_T1507") : "" ;  
        		String t1508 = t1507.length() == 10 ? form1.getByear() + form1.getBmonth() + form1.getBdate() : "0" ;
        		
        		if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
        			if(isid_switch.equals("Y")){//是否啟用新版
    	             	if (model.checkFas24prc_new(t1507 , "" , t1508 , agentno) == false){
    	            		throw new UserException("WB1.ERROR13");
    	            	}
        			}else{
    	             	if (model.checkFas24prc(t1507,"") == false){
    	            		throw new UserException("WB1.ERROR13");
    	            	}
        			}      			   			
        		}
            	
        		//查詢官網據點資料
        		Strongholds strongholds = new Strongholds();
        		List<?> strongholdsList = strongholds.doProcess();
        		System.out.println("Strongholds===" + strongholdsList);

            	model.processP2();
                request.setAttribute("WB1M020f", model.getMainForm());
                request.setAttribute("strongholdsList", strongholdsList);//勘車據點用
                
                //勘車日期選單處理
                String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);//系統日
                String strdate = form1.getVolyear() + form1.getVolmonth() + form1.getVoldate();//任意險起保日
                
                //判斷起保日是否為工作日
                boolean strdateISworkday = WorkDay.isWorkDay(strdate);
                if(!strdateISworkday)//若不為工作日，勘車起日則以起保日取下1個工作日
                	strdate = WorkDay.getStrWorkDatebyDays("00", strdate, true, "1"); 
                
                List arlist = new ArrayList();
                
            	String min2day = WorkDay.getStrWorkDatebyDays("00", strdate, false, "2");//勘車起日前2個工作日
            	String min1day = WorkDay.getStrWorkDatebyDays("00", strdate, false, "1");//勘車起日前1個工作日
                String add1day = WorkDay.getStrWorkDatebyDays("00", strdate, true, "1"); //勘車起日後1個工作日
                String add2day = WorkDay.getStrWorkDatebyDays("00", strdate, true, "2"); //勘車起日後2個工作日
                
                int k = 0;
                //只有每個日期都大於系統日時才加入ArrayList中
                //前2
                if(Integer.parseInt(min2day) >= Integer.parseInt(sysdate)){
                	arlist.add(k, min2day);
                	k++;
                }
                //前1
                if(Integer.parseInt(min1day) >= Integer.parseInt(sysdate)){
                	arlist.add(k, min1day);
                	k++;
                }
                //勘車起日
                arlist.add(k, strdate);
            	k++;
                //後1
                if(Integer.parseInt(add1day) >= Integer.parseInt(sysdate)){
                	arlist.add(k, add1day);
                	k++;
                }
                //後2
                if(Integer.parseInt(add2day) >= Integer.parseInt(sysdate)){
                	arlist.add(k, add2day);
                	k++;
                }

                //ArrayList convert to Array
                String array[] = new String[arlist.size()];              
        		for(int j =0;j<arlist.size();j++){
        		  array[j] = (String) arlist.get(j);
        		}
                
                request.setAttribute("daylist", array);            
                form.setNextPage(3);
            }
            else if (form.getSource().equals("WB1M020p3")) //試算結果及輸入頁
            {    
            	session.setAttribute("WB1M020p3", form);
            	if(form.getActionCode()==31) {
            		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
            		if(ui != null )
            			request.setAttribute("carNumbers", model.getCustomerCarNos(ui.getUserId()));
             		form.setNextPage(2);
            	} else {
	            	model.processP5(agentno);//資料檢核
	
	                String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
	                request.setAttribute("telno", ecom_tel);
	
	                request.getSession(false).setAttribute("WB1M020f", model.getMainForm());
	                request.setAttribute("WB1M020f", model.getMainForm());
	                form.setNextPage(6);
            	}
            }
            else if (form.getSource().equals("WB1M020p6")) //計算結果頁
            {      	
            	if(form.getActionCode()==31) {
                	session.setAttribute("WB1M020p6", form);    

                  //查詢官網據點資料
            		Strongholds strongholds = new Strongholds();
            		List<?> strongholdsList = strongholds.doProcess();
            		System.out.println("Strongholds===" + strongholdsList);

                	model.processP2();
                    request.setAttribute("WB1M020f", model.getMainForm());
                    request.setAttribute("strongholdsList", strongholdsList);
                    
                    String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
                    String add1day = WorkDay.getStrWorkDatebyDays("00", sysdate, true, "1"); 
                    String add2day = WorkDay.getStrWorkDatebyDays("00", sysdate, true, "2"); 

                    request.setAttribute("add1day", add1day);
                    request.setAttribute("add2day", add2day);

                    System.out.println("add1day==" + add1day);
                    System.out.println("add2day==" + add2day);
                    
                    form.setNextPage(3);
            	} else {
            		session.removeAttribute("WB1M020p2");;
            		session.removeAttribute("WB1M020p3");
            		session.removeAttribute("WB1M020p6");
            		
            		//紀錄客戶是否同意行銷(IC01PFA)(IC01PF)
            		String C01A18= session.getAttribute("C01A18") != null ? session.getAttribute("C01A18").toString() : "";
            		boolean exist=model2.isExistIC01PFA(form1.getKyc_T1507());
            		model2.updateIC01PFA(form1.getKyc_T1507(), C01A18, exist);
            		model2.insertIC01PF_Insured(form1.getKyc_T1507());
            		session.removeAttribute("C01A18");
            		
            		if(form.getActionCode()==41)//網路投保
	            	{
	            		
	                	model.processP6();//寫檔
	                	//簡訊和MAIL都要寄送
	                	model.sendMobileMsg();//發送投保簡訊
	                	model.sendOTPMail(request);//發送投保email
	                	
	                	request.setAttribute("WB1M020f", model.getMainForm());
	                	request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
	                	form.setNextPage(9);
	            	}else{
	            		 		
	            		String orderId = model.processP6();//寫檔
	            		request.getSession(false).setAttribute("WB1M020f", model.getMainForm());
	      	  			request.setAttribute("WB1M020f", model.getMainForm());
	      	  			request.setAttribute("action", "NWB1M0201");
	             
	      	  			//測試用直接導完成頁
	//      	  			model.sendCarMail(form1.getNumber(), request);
	//      	  			form.setNextPage(8);
	                                       
	                    form.setNextPage(-1);
	
	      	  			HitrustUtil.callHitrust(orderId, form1.getDiscount(), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
	                            + CodeUtil.getCodeDesc(servlet,request,"GOODSID",form1.getType()) + form1.getKyc_T1507() + form1.getKyc_T1506(), 20), "/NWB1M0201.do", getServlet(), request, response);
	            	}

            	}
            	           		
            }
            else if (form.getSource().equals("WB1M020p9")) //OTP輸入頁
            {  
       		  if(form.getActionCode() == 28)
       		  { 			  
       				boolean isUpdatetok = model.isUpdateOTP();
       				if(isUpdatetok){
       					//簡訊和MAIL都要寄送
       					model.sendMobileMsg();//重新發送簡訊
       		        	model.sendOTPMail(request);//發送投保email
      					
       					request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");
       					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

       				}else{
       					request.setAttribute("exmin", "0");
       				}

       			  request.setAttribute("WB1M020f", model.getMainForm());
          		  form.setNextPage(9);

       		  }
       		  else{
             	  if(model.isRightOTP())
          		  {
                     
                      request.getSession(false).setAttribute("WB1M020f", model.getMainForm());
                      //略過網路投保刷卡動作，測試用
                      if(omitcredit.equals("Y"))
                      {
                          try {
                        	  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M0201.do?actionCode=21&retcode=00&ordernumber=" + form1.getNumber());
                        	  return;
                          } catch (MalformedURLException e) {

                        	  e.printStackTrace();
                          } catch (IOException e) {

                        	  e.printStackTrace();
                          }

                      }else{
                    	  
	                      form.setNextPage(-1);
	                      NCCCUtil.callNCCC(form1.getKyc_T1507() , form1.getNumber(), MathUtil.getDouble(String.valueOf(form1.getDiscount())), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
	                            + CodeUtil.getCodeDesc(servlet,request,"GOODSID",model.getKG01()) + form1.getKyc_T1507() + form1.getKyc_T1506(), 40), "NWB1M0201", getServlet(), request, response);
                      }
          		  }
          		  else{
          			  throw new UserException("errors.1000", "OTP輸入錯誤，請重新輸入！");
          		  }
       			  
       		  }
            }
            else if (form.getSource().equals("WB1M020p8")) {
                //重新取授權
                request.setAttribute("WB1M020f", request.getSession(false).getAttribute("WB1M020f"));
                form.setNextPage(6);
            }
            else if (form.getSource().equals("WB1M020p5")) 
            {	//要保資料輸入
            	
        		  model.processP5(agentno);
        		  //簡訊和MAIL都要寄送
        		  model.sendMobileMsg();//發送投保簡訊
        		  model.sendOTPMail(request);//發送投保email
        			  
        		  request.setAttribute("WB1M010f", model.getMainForm());
        		  request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
        		  form.setNextPage(8);    	
            }
            else if (form.getSource().equals("WB1M020p7")) 
            {	// 交易成功
                request.setAttribute("WB1M020f", request.getSession(false).getAttribute("WB1M020f"));
                form.setNextPage(6);
            }
        	        	
        }

    }
    
    /**
     * 取得強制費率下次實施日期
     * @return
     */
    public String getExecDate()
	{    	
    	tx_controller.begin(1);
    	Connection con = tx_controller.getConnection(1);
        String sql = "SELECT AH04 FROM PFAH WHERE AH01 ='21'";
        
        Map<?, ?> ret = null;
        try 
        {
            QueryRunner runner = new QueryRunner();
            ret = (Map<?, ?>) runner.query(con, sql, new MapHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return String.valueOf(ret.get("AH04"));	
	}

    /**
     * 查詢折扣金額
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD19
     * @param KD20
     * @return
     */
    public String get21Discount(String KD01,String KD02, String KD03, String KD04,String KD19,String KD20){
    	
    	String kd11 = "0" ; 
        if (KD19.equals("") || KD19 == null) {
            KD19 = "KYC";
        }
        tx_controller.begin(0);
        
        DBO dbo;
        try {
			
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);	//商品代碼
            kd.setKD02(KD02);	//險別
            kd.setKD03(KD03);	//險種
            kd.setKD04(KD04);	//年期
            kd.setKD19(KD19);	//來源網站
            kd.setKD20(KD20);	//通路別

        	dbo = kd.executeSelect(tx_controller.getConnection());
        	 
        	kd11 = dbo.getRecordData("KD11").toString();
		} catch (AsiException e) {
			e.printStackTrace();
		}

    	return kd11;
    }

    /**
     * 取得預設的招攬人代號
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD19
     * @param KD20
     * @return
     */
    public String getKYCKD_KD17(String KD01,String KD02, String KD03, String KD04,String KD19,String KD20){
    	
    	String kd17 = "0" ; 
        if (KD19.equals("") || KD19 == null) {
            KD19 = "KYC";
        }
        tx_controller.begin(0);
        
        DBO dbo;
        try {
			
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);	//商品代碼
            kd.setKD02(KD02);	//險別
            kd.setKD03(KD03);	//險種
            kd.setKD04(KD04);	//年期
            kd.setKD19(KD19);	//來源網站
            kd.setKD20(KD20);	//通路別

        	dbo = kd.executeSelect(tx_controller.getConnection(0));
        	 
        	kd17 = dbo.getRecordData("KD17").toString();
		} catch (AsiException e) {
			e.printStackTrace();
		}

    	return kd17;
    }

    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }
    
    /**
     * 寫入KYCLLOG記錄檔處理 - 用此檔案記錄ID試算保費次數
     * @param request
     * @param source
     * @param uid
     */
    public void doKycllog( HttpServletRequest request,String source,String uid){

    	String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
    	String systime = DateUtil.getSysTime();

    	String ll01 = this.getClass().getSimpleName();//進入點程式
    	String ll02 = source;//頁面source
    	String ll03 = "汽車險投保頁";//頁面說明
    	String ll04 = "F";
    	String ll05 = uid;//客戶身分證字號
    	String ll09 = sysdate + systime;//時間戳記
    	String ll17 = "PT";//動作/檢核項目
    	String ll19 = "ID試算保費";//動作說明/檢核錯誤訊息
    	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, "", "", "", "", "", ll17, "", ll19, "", "", "", "", "");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
    	WB1M020f form1 = (WB1M020f) arg1;
        if (form1.getActionCode() == 0 && form1.getRetcode() != null) {
            form1.setActionCode(21);
        }else if(form1.getActionCode() == 0)
        {
        	form1.setActionCode(5);
        }
    }

}