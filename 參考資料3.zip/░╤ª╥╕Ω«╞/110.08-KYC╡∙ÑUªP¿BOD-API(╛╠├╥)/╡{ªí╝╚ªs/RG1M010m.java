/*
 * Created on 2005/4/8
 */
package com.asi.kyc.reg.models;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.manager.IUserManager;
import com.asi.common.security.IUser;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.common.util.ManagerUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.Number3;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.reg.forms.RG1M010f;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.EncryptUtil;

import net.sf.json.JSONObject;
import sun.net.www.MessageHeader;
import sun.net.www.protocol.https.DelegateHttpsURLConnection;

/**
 * 會員註冊功能
 * @author vsg
 * @CreateDate 2015/5/18上午 9:24:30
 * @UpdateDate 2015/5/18上午 9:24:30
 * @FileName kyc/com.asi.kyc.reg.models/RG1M010m.java
 * @Purpose
 * 
 */
public class RG1M010m extends AsiModel {

    private static Log logger = LogFactory.getLog(RG1M010m.class);

    private RG1M010f mform;

    public String insertedOTP;
    public String encryptedkey;
    public String insertedid;
    public String username;


	/**
     * 建構值
     * 
     * @param tx_controller
     * @param request
     * @param form
     */
    public RG1M010m(TransactionControl tx_controller, HttpServletRequest request, AsiActionForm form) {
        super(tx_controller, request, form);
    }

    public void init() throws AsiException {

        mform = new RG1M010f();
        //把form做拷貝
        try {
            BeanUtils.copyProperties(mform, getForm());
        } catch (InvocationTargetException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        } catch (IllegalAccessException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        }
        setUserinfo();
        setMainForm(mform);

    }

    private void setUserinfo() {
        if (getTransaction().getUserInfo() == null) {
            UserInfo ui = new UserInfo();
            ui.setInfo("USERID", "SYSTEM");
            ui.setDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setDateType(DateUtil.ChType);
            ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setFileDateType(DateUtil.ChType);
            getTransaction().setUserInfo(ui);
        }
    }

    public void destroy() {
    }

    /**
     * 寄送註冊完成通知信
    * @param request
    */
	public void sendRegCompleteMail(HttpServletRequest request)
    {

   	 String token = mform.getKeytoken();
   	 String userid = getUidByToken(token);
   	 
   	 String username = "";
   	 String email = "";
   	 
   	 String sql = "SELECT * FROM KYCREG WHERE RG01='" + userid + "' AND RG16 = '" + token + "'";
   	 
   	 QueryRunner runner = new QueryRunner();
   	 getTransaction().begin(0);

   	 Map ret = new HashMap();
   	 
   	 try 
   	 {
   		 Connection con = getTransaction().getConnection(0);
   		 ret = (Map) runner.query(con, sql.toString(), new TrimedMapHandler());
   		 if(ret != null && ret.size() > 0)
   		 {
   			 username = ret.get("RG02").toString().trim();
   			 setUsername(username);
   			 email = ret.get("RG05").toString().trim();
   		 }	 
   		 
   	 } catch (SQLException e) {
   		 e.printStackTrace();
   	 } 
 
   	 //寄Email
   	 KycMailUtil sender = new KycMailUtil();
   	 
   	 //取範本
   	 BufferedReader fr;
   	 String path = getServlet().getServletContext().getRealPath("/mail/RegisterNoticeMail_" + getLocale() + ".html");

   	 StringBuffer linebf = new StringBuffer();
   	 try {
   		 fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
   		 String line;
   		 linebf = new StringBuffer();
   		 line = fr.readLine();
   		 while (line != null) {
   			 linebf.append(line);
   			 line = fr.readLine();
   		 }

   	 }
   	 catch (FileNotFoundException e) {
   		 e.printStackTrace();
   	 }
   	 catch (IOException e) {
   		 e.printStackTrace();
   	 }

	//被保險人姓名隱碼
	StringBuffer hiddenName = new StringBuffer();
	if(username.length() < 4){		
	    for(int a=0;a<username.length();a++){
		    if(a==1){
		    	
				hiddenName.append("O");
		    }
			else{
				hiddenName.append(username.substring(a,a+1));
		   	}
		}
	}
	else{
		for(int a=0;a<username.length();a++){
			if(a==1 || a==2){
				hiddenName.append("O");
			}
			else{
				hiddenName.append(username.substring(a,a+1));
		   	}
		}
	}
   	 
   	 String msg = linebf.toString();
   	 msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
 	 
   	 sender.setSubject("第一保 電子商務網 網路會員註冊成功通知");
   	 sender.setMessage(msg);
   	 sender.addTo(email);
   	 sender.sendMail();

    }


    /**
     * 寄送認證信
    * @param request
    */
   public void sendRegConfirmMail(HttpServletRequest request)
    {
   	 String token = mform.getKeytoken();
   	 
   	 String username = "";
   	 String email = "";
   	 
   	 String serverName = request.getServerName();
   	 String serverPort = String.valueOf(request.getServerPort());
   	 String contextPath = request.getContextPath();
   	 String protocal = request.getScheme() + "://";
   	 String url = protocal + serverName + ":" + serverPort + contextPath + "/RG1M010.do?actionCode=51&token=" + token;

   	 String sql = "SELECT * FROM KYCREG WHERE RG16 = '" + token + "'";
   	 
   	 QueryRunner runner = new QueryRunner();
   	 getTransaction().begin(0);

   	 Map ret = new HashMap();
   	 
   	 try 
   	 {
   		 Connection con = getTransaction().getConnection(0);
   		 ret = (Map) runner.query(con, sql.toString(), new TrimedMapHandler());
   		 if(ret != null && ret.size() > 0)
   		 {
   			 username = ret.get("RG02").toString().trim();
   			 setUsername(username);
   			 email = ret.get("RG05").toString().trim();
   		 }	 
   		 
   	 } catch (SQLException e) {
   		 e.printStackTrace();
   	 } 
 
   	 //寄Email
   	 KycMailUtil sender = new KycMailUtil();
   	 
   	 //取範本
   	 BufferedReader fr;
   	 String path = getServlet().getServletContext().getRealPath("/mail/RegisterConfirmMail_" + getLocale() + ".html");

   	 StringBuffer linebf = new StringBuffer();
   	 try {
   		 fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
   		 String line;
   		 linebf = new StringBuffer();
   		 line = fr.readLine();
   		 while (line != null) {
   			 linebf.append(line);
   			 line = fr.readLine();
   		 }

   	 }
   	 catch (FileNotFoundException e) {
   		 e.printStackTrace();
   	 }
   	 catch (IOException e) {
   		 e.printStackTrace();
   	 }

   	 String msg = linebf.toString();
   	 msg = msg.replaceAll("\\{username\\}", username);
   	 msg = msg.replaceAll("\\{regurl\\}", url);
   	 
   	 sender.setSubject("第一保 電子商務網 網路會員認證信");
   	 sender.setMessage(msg);
   	 sender.addTo(email);
   	 sender.sendMail();

    }

   /**
    * 寄送OTP EMAIL
    * @param request
    */
   public void sendOTPMail(HttpServletRequest request)
   {
	   int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;   	
	   String email = mform.getEmail();
	   String name = mform.getUsername();
   	
	   if(name == null)
	   {
		   String token = mform.getKeytoken();
		   String sql = "SELECT * FROM KYCREG WHERE RG16 = '" + token + "'";
   	 
		   QueryRunner runner = new QueryRunner();
		   getTransaction().begin(0);

		   Map ret = new HashMap();
   	 
		   try 
		   {
			   Connection con = getTransaction().getConnection(0);
			   ret = (Map) runner.query(con, sql.toString(), new TrimedMapHandler());
			   if(ret != null && ret.size() > 0)
			   {
				   name = ret.get("RG02").toString().trim();
				   setUsername(name);
				   email = ret.get("RG05").toString().trim();
			   } 		 
		   } catch (SQLException e) {
			   e.printStackTrace();
		   } 

	   }
 		
	   StringBuffer sb = new StringBuffer();
	   sb.append(" 您正於第一產物進行會員註冊\n");
	   sb.append("您的OTP認證碼為：").append(getInsertedOTP()).append("，請於 ").append(extime).append(" 分鐘內於網頁上輸入！");

	   //寄Email
	   KycMailUtil sender = new KycMailUtil();

	   //取範本
	   BufferedReader fr;
	   String path = getServlet().getServletContext().getRealPath("/mail/RegisterOTP_" + getLocale() + ".html");

	   StringBuffer linebf = new StringBuffer();
	   try {
		   fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
		   String line;
		   linebf = new StringBuffer();
		   line = fr.readLine();
		   while (line != null) {
			   linebf.append(line);
			   line = fr.readLine();
		   }

	   }catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }catch (IOException e) {
		   e.printStackTrace();
	   }
	   
	   //姓名隱碼
	   StringBuffer hiddenName  = new StringBuffer();
	   if(name.length() < 4){
	      for(int i=0;i<name.length();i++){
	   	   if(i==1){
	   		   hiddenName.append("O");
	   	   }
	   	   else{
	   		   hiddenName.append(name.substring(i,i+1));
	      	   }
	      }
	   }
	   else{
	       for(int i=0;i<name.length();i++){
	   	    if(i==1 || i==2){
	   		    hiddenName.append("O");
	   	    }
	   	    else{
	   		    hiddenName.append(name.substring(i,i+1));
	      	    }
	       }
	   }

	   String msg = linebf.toString();
	   msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
	   msg = msg.replaceAll("\\{otp\\}", getInsertedOTP());
	   msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));

	   sender.setSubject("第一保 電子商務網 網路會員註冊OTP");
	   sender.setMessage(msg);
	   sender.addTo(email);
	   sender.sendMail();

	}
   
   /**
    * 登入系統
    * @return
    * @throws AsiException
    */
   public boolean login() throws AsiException {
      //線上投保時，第一次登入時的訊息不同
      getRequest().setAttribute("loginmessage",getRequest().getParameter("loginmessage"));
      IUserManager usrMgr = (IUserManager) ManagerUtil.getManager(getServlet(), GlobalKey.USER_MANAGER);
      IUser user=null;
      
      DBO dbo = getTransaction().getDBO("sec.SECAJt",0);
      dbo.addParameter("USERID",mform.getUid());
      dbo.executeSelect();
      if(dbo.getRecordCount()>0&&mform.getPsw().equals("")){
          return false;
          
      } else {
          user = usrMgr.login(getServlet(), getRequest(), mform.getUid(), mform.getPsw());//登入時必要用法
          UserInfo ui = (UserInfo) getRequest().getSession(false).getAttribute(GlobalKey.USER_INFO);
          getTransaction().setUserInfo(ui);
          getTransaction().begin(0);
          DBO dbo1 = getTransaction().getDBO("sec.SECAJu03", 0);//更新登入次數
          dbo1.addParameter("USERID", ui.getUserId());
          dbo1.addParameter("LASTLOGIN", DateUtil.getSysDate(ui, false));
          dbo1.addParameter("UPDTM", DateUtil.getSysTime(false));
          dbo1.addParameter("UPDDT", DateUtil.getSysDate(ui, false));
          dbo1.execute();
          
          return true;
      }
	}

	/**
	 * 確認是否已有註冊完成資料
	 * @param request
	 * @return
	 */
	public boolean isRegistered(HttpServletRequest request)
	{
		boolean isok = false;

		String token = mform.getKeytoken();
		Map regData = getDataByToken(token);//使用token查註冊資料

		if(regData != null & !regData.isEmpty())
		{			
			String uid = regData.get("RG01").toString();
			String rg14 = regData.get("RG14").toString();
			
			if(!rg14.equals("0"))
				isok = true;
			
			mform.setUid(uid);
			mform.setUserid(uid);
			mform.setUsername(regData.get("RG02").toString());
			mform.setAllBirthday(regData.get("RG03").toString());
			mform.setZip(regData.get("RG20").toString());
			mform.setAllAddress(regData.get("RG21").toString());
			mform.setEmail(regData.get("RG05").toString());
			mform.setCellphone(regData.get("RG04").toString());
			//mform.setMarriage(regData.get("RG23").toString());
		}
		   	
		return isok;
	}
   
    /**
     * 確認註冊,更新註冊檔
    * @return
    * @throws AsiException
    */
	public boolean isRegisterOK(HttpServletRequest request) throws AsiException 
	{
		boolean isok = false;
   	 
		String token = mform.getKeytoken();
		String userid = getUidByToken(token);

		if(userid.equals(""))
			return isok;
   	 
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
   	 
		String sql = "UPDATE KYCREG SET RG14=?,RG15=?,UPDDT=?,UPDTM=?,UPDUR=? WHERE RG01=? AND RG16=?";
   	 
		String args[] = new String[7];

		args[0] = sysdate;
		args[1] = systime;
		args[2] = sysdate;
		args[3] = systime;
		args[4] = userid;
		args[5] = userid;
		args[6] = token;

		QueryRunner runner = new QueryRunner();
		getTransaction().begin(0);

		int ret = 0;
   	 
		try 
		{
			Connection con = getTransaction().getConnection(0);
			ret = runner.update(con, sql ,args);
			if(ret > 0)
			{
				isok = true;
			}   		 
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		} 

		return isok;
    }

   
   /**
    * 確認註冊,更新帳號檔
   * @return
   * @throws AsiException
   */
	public void UpdateSecaj() throws AsiException 
	{

		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();

		String sql = "UPDATE SECAJ SET FIRSTNAME=?,EMAIL=?,PASSWORD=?,LASTLOGIN=?,LOGINCOUNT=?,LOGINRESTRICT=?,UPDDT=?,UPDTM=?,UPDUR=? WHERE USERID=? ";

		String args[] = new String[10];

		args[0] = mform.getUsername();
		args[1] = mform.getEmail();
		args[2] = EncryptUtil.getDesEncryptString(mform.getAllBirthday());//生日當密碼，加密處理
		args[3] = sysdate;
		args[4] = "0";
		args[5] = "Y";
		args[6] = sysdate;
		args[7] = systime;
		args[8] = mform.getUserid();
		args[9] = mform.getUserid();

		QueryRunner runner = new QueryRunner();
		getTransaction().begin(0);

		int ret = 0;

		try 
		{
			 Connection con = getTransaction().getConnection(0);
			 ret = runner.update(con, sql ,args);
			 
			 if(ret == 0)
			 {
				 ret = insertSecaj() ;
				 
			 }else{
				 con.commit();
			 }
			 mform.setPsw(getPswByUid(mform.getUserid())); 
			 
		} catch (SQLException e) {
			 e.printStackTrace();
			 throw new AsiException(e.getLocalizedMessage());
		} 

   }

	
	/**
	 * 新增客戶帳號檔資料
	 * @return
	 * @throws AsiException
	 */
	public int insertSecaj() throws AsiException 
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = 
				 "INSERT INTO SECAJ (USERID,FIRSTNAME,LASTNAME,EMAIL,STATE,STOPCAUSE,LANGTYPE,ERRCNT,COMPANY,DEPARTMENT,DIVISION,PASSWORD,ENDATE,CHGPWD,"
				+"DISDATE_S,DISDATE_E,USERLEVEL,USERTYPE,LASTLOGIN,LOGINCOUNT,LOGINRESTRICT,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR,TELEXT) " 
  				+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		String args[] = new String[28];

		args[0] = mform.getUserid(); 
		args[1] = mform.getUsername();
		args[2] = "";
		args[3] = mform.getEmail();
		args[4] = "N";
		args[5] = "";
		args[6] = "ZH_TW";
		args[7] = "0";
		args[8] = "";
		args[9] = "";
		args[10] = "";
		args[11] = EncryptUtil.getDesEncryptString(mform.getAllBirthday());
		args[12] = "0";
		args[13] = "Y";
		args[14] = "0";
		args[15] = "0";
		args[16] = "5";
		args[17] = "1";
		args[18] = sysdate;
		args[19] = "1";
		args[20] = "Y";
		args[21] = sysdate;
		args[22] = systime;
		args[23] = mform.getUserid();
		args[24] = sysdate;
		args[25] = systime;
		args[26] = mform.getUserid();
		args[27] = "";				

		QueryRunner runner = new QueryRunner();
		getTransaction().begin(0);

		int ret = 0;
		try 
		{
			 Connection con = getTransaction().getConnection(0);
			 ret = runner.update(con, sql ,args);
			 
			 if(ret > 0)
				 con.commit();
	 	 
		} catch (SQLException e) {
			 e.printStackTrace();
			 throw new AsiException(e.getLocalizedMessage());
		} 

		return ret;
	}
	
  
  /**
   * 以token查註冊檔
   * @param token
   * @return
   */
  public Map getDataByToken(String token)
  {
 	 String sql = "SELECT * FROM KYCREG WHERE RG16='" + token +"'";
 	 
 	 QueryRunner runner = new QueryRunner();
 	 getTransaction().begin(0);

 	 Map ret = null;
 	 
 	 try 
 	 {
 		 Connection con = getTransaction().getConnection(0);
 		 ret = (Map) runner.query(con, sql, new TrimedMapHandler());			 		 
 	 } catch (SQLException e) {
 		 e.printStackTrace();
 	 } 

 	 return ret;
  }

   	
   /**
    * 以token查註冊檔
    * @param token
    * @return
    */
   public String getUidByToken(String token) 
   {
  	 String sql = "SELECT * FROM KYCREG WHERE RG16='" + token +"'";
  	 String uid = "";
  	 
  	 QueryRunner runner = new QueryRunner();
  	 getTransaction().begin(0);

  	 Map ret = null;
  	 
  	 try 
  	 {
  		 Connection con = getTransaction().getConnection(0);
  		 ret = (Map) runner.query(con, sql, new TrimedMapHandler());
			
  		 if(!ret.isEmpty() && ret.size()>0)
  			 uid = ret.get("RG01").toString();
  		 
  	 } catch (SQLException e) {
  		 e.printStackTrace();
  	 } 

  	 return uid;
   }

   /**
    * 查帳號密碼
    * @param uid
    * @return
    */
   public String getPswByUid(String uid) 
   {
  	 String sql = "SELECT * FROM SECAJ WHERE USERID='" + uid +"'";
  	 String psw = "";
  	 
  	 QueryRunner runner = new QueryRunner();
  	 getTransaction().begin(0);

  	 Map ret = null;
  	 
  	 try 
  	 {
  		 Connection con = getTransaction().getConnection(0);
  		 ret = (Map) runner.query(con, sql, new TrimedMapHandler());
			
  		 if(!ret.isEmpty() && ret.size()>0)
  			psw = ret.get("PASSWORD").toString();
  		 
  	 } catch (SQLException e) {
  		 e.printStackTrace();
  	 } 

  	 return psw;
   }

   
    /**
     * 確認OTP,更新註冊檔
    * @return
    * @throws AsiException
    */
   public boolean isConfirmOTP() throws AsiException 
    {
   	 boolean isok = false;
   	 
   	 String userid = mform.getKeyid();
   	 String token = mform.getKeytoken();
   	    	 
   	 String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
   	 String systime = DateUtil.getSysTime();
   	 
   	 String sql = "UPDATE KYCREG SET RG12=?,RG13=?,RG14=?,RG15=?,UPDDT=?,UPDTM=?,UPDUR=? " +
   	 "WHERE RG01=? AND RG16=?";
   	 
   	 String args[] = new String[9];

   	 args[0] = sysdate;
   	 args[1] = systime;
   	 args[2] = sysdate;
   	 args[3] = systime;
   	 args[4] = sysdate;
   	 args[5] = systime;
   	 args[6] = userid;
   	 args[7] = userid;
   	 args[8] = token;

   	 QueryRunner runner = new QueryRunner();
   	 getTransaction().begin(0);

   	 int ret = 0;
   	 
   	 try 
   	 {
   		 Connection con = getTransaction().getConnection(0);
   		 ret = runner.update(con, sql ,args);
   		 if(ret > 0)
   			 isok = true;
   		 
   	 } catch (SQLException e) {
   		 e.printStackTrace();
   		 throw new AsiException(e.getLocalizedMessage());
   	 } 

   	 return isok;
    }

    /**
     * 重新產生OTP,更新註冊檔
    * @return
    * @throws AsiException
    */
	public boolean isUpdateOTP() throws AsiException 
    {
	   boolean isok = false;

	   String getotp = KYCEncryptor.genOTP();
	   setInsertedOTP(getotp);
	   setInsertedid(mform.getKeyid());
	   setEncryptedkey(mform.getKeytoken());

	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String systime = DateUtil.getSysTime();
	   String otpexpireday = getExpireDate();

	   String sql = "UPDATE KYCREG SET RG06=?,RG07=?,RG08=?,RG09=?,RG10=?,RG11=?,UPDDT=?,UPDTM=?,UPDUR=? " +
	   "WHERE RG01=?";

	   String args[] = new String[10];
	   args[0] = getotp;
	   args[1] = "0";
	   args[2] = sysdate;
	   args[3] = systime;
	   args[4] = otpexpireday;
	   args[5] = SystemParam.getParam("OTPEXTIME");
	   args[6] = sysdate;
	   args[7] = systime;
	   args[8] = mform.getKeyid();
	   args[9] = mform.getKeyid();

	   QueryRunner runner = new QueryRunner();
	   getTransaction().begin(0);

	   int ret = 0;

	   try 
	   {
	   	 Connection con = getTransaction().getConnection(0);
	   	 ret = runner.update(con, sql ,args);
	   	 if(ret > 0)
	   		 isok = true;
	   	 
	   } catch (SQLException e) {
	   	 e.printStackTrace();
	   	 throw new AsiException(e.getLocalizedMessage());
	   } 

	   return isok;

	}

    
    /**
     * 寫入註冊檔
    * @return
    * @throws AsiException
    */
   	public boolean isInsertSucess() throws AsiException 
    {
   		boolean isok = false;

   		String gettoken = KYCEncryptor.genToken(mform.getUserid());//ID加密
   		setInsertedid(mform.getUserid());
   		setEncryptedkey(gettoken);
   		String getotp = KYCEncryptor.genOTP();
   		setInsertedOTP(getotp);

   		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
   		String systime = DateUtil.getSysTime();
   		String otpexpireday = getExpireDate();//OTP過期日期
   		String ARGNO = SystemParam.getParam("ARGDOC_REG_NO"); // 系統代碼，聲明事項文件編號
   		String zip = mform.getZip() != null ? mform.getZip() : "";
   		String city = mform.getCity() != null ? mform.getCity() : "";
   		String town = mform.getTown() != null ? mform.getTown() : "";

   		//判斷是否為產險客戶
   		boolean isProdClient = isClient_P(mform.getUserid());
   		//判斷是否為人身險客戶
   		boolean isLifeClient = isClient_O(mform.getUserid());

   		try 
   		{

	   		String sqlreg = "SELECT * FROM KYCREG WHERE RG01='" + mform.getUserid() + "'";
	
	   		QueryRunner runner = new QueryRunner();
	   		getTransaction().begin(0);
	
	   		int ret = 0;
	   		Connection con = getTransaction().getConnection(0);
	
	   		List regdata = null;
	   		regdata = (List) runner.query(con, sqlreg.toString(), new TrimedMapListHandler());
	
	   		if(!regdata.isEmpty() && regdata.size()>0)//註冊檔已有資料時
	   		{
	
		   		String sql = 
		   		"UPDATE KYCREG SET RG02=?,RG03=?,RG04=?,RG05=?,RG06=?,RG07=?,RG08=?,RG09=?,RG10=?,RG11=?,RG12=?,RG13=?,RG14=?,RG15=?,RG16=?,RG17=?,RG18=?,RG19=?,RG20=?,RG21=?," +
		   		"RG22=?,RG25=?,RG26=?,RG27=?,RG28=?,RG29=?,RG30=?,RG31=?,UPDDT=?,UPDTM=?,UPDUR=?" +
		   		"WHERE RG01=?";
		
		   		String args[] = new String[32];
		
		   		args[0] = mform.getUsername();
		   		args[1] = mform.getByear() + mform.getBmonth() + mform.getBdate();
		   		args[2] = mform.getCellphone();
		   		args[3] = mform.getEmail();
		   		args[4] = getotp;
		   		args[5] = "0";
		   		args[6] = sysdate;
		   		args[7] = systime;
		   		args[8] = otpexpireday;
		   		args[9] = SystemParam.getParam("OTPEXTIME");
		   		args[10] = "0";
		   		args[11] = "0";
		   		args[12] = "0";
		   		args[13] = "0";
		   		args[14] = gettoken;
		   		args[15] = isProdClient ? "2":"1";//1-新保戶 2-舊保戶
		   		args[16] = isLifeClient ? "2":"1";//1-新保戶 2-舊保戶
		   		args[17] = ARGNO;
		   		args[18] = zip;
		   		args[19] = city + town + mform.getAddress();
		   		
		   		args[20] = "1";
		   		//args[21] = mform.getMarriage();
		   		//args[22] = mform.getIscredit();
		   		args[21] = "";
		   		args[22] = "0";
		   		args[23] = mform.getIsmobile();
		   		args[24] = mform.getOs();
		   		args[25] = mform.getBrowser();
		   		args[26] = mform.getBro_version();
		   		
		   		args[27] = mform.getRg31();
		   		
		   		args[28] = sysdate;
		   		args[29] = systime;
		   		args[30] = mform.getUserid();
		   		args[31] = mform.getUserid();
		
		   		ret = runner.update(con, sql ,args);
		   		if(ret > 0)
		   		isok = true;
	
	   		}
	   		else{
	
		   		String sql = 
		   				"INSERT INTO KYCREG (RG01,RG02,RG03,RG04,RG05,RG06,RG07,RG08,RG09,RG10,RG11,RG12,RG13,RG14,RG15,RG16,RG17,RG18,RG19,RG20,RG21,"
		   				+"RG22,RG25,RG26,RG27,RG28,RG29,RG30,RG31,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) " 
		   				+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		   		String args[] = new String[35];
		   		args[0] = mform.getUserid();
		   		args[1] = mform.getUsername();
		   		args[2] = mform.getByear() + mform.getBmonth() + mform.getBdate();
		   		args[3] = mform.getCellphone();
		   		args[4] = mform.getEmail();
		   		args[5] = getotp;
		   		args[6] = "0";
		   		args[7] = sysdate;
		   		args[8] = systime;
		   		args[9] = otpexpireday;
		   		args[10] = SystemParam.getParam("OTPEXTIME");
		   		args[11] = "0";
		   		args[12] = "0";
		   		args[13] = "0";
		   		args[14] = "0";
		   		args[15] = gettoken;
		   		args[16] = isProdClient ? "2":"1";
		   		args[17] = isLifeClient ? "2":"1";
		   		args[18] = ARGNO;
		   		args[19] = zip;
		   		args[20] = city + town + mform.getAddress();
		   		//args[21] = mform.getMarriage();
		   		//args[22] = mform.getIscredit();
		   		args[21] = "1";
		   		
		   		args[22] = "";
		   		args[23] = "0";
		   		args[24] = mform.getIsmobile();
		   		args[25] = mform.getOs();
		   		args[26] = mform.getBrowser();
		   		args[27] = mform.getBro_version();

		   		args[28] = mform.getRg31();
		   		
		   		args[29] = sysdate;
		   		args[30] = systime;
		   		args[31] = mform.getUserid();
		   		args[32] = sysdate;
		   		args[33] = systime;
		   		args[34] = mform.getUserid();	   		
		
		   		ret = runner.update(con, sql ,args);
		   		if(ret > 0)
		   		isok = true;		 
	   		}

   		} catch (SQLException e) {
   			e.printStackTrace();
   			throw new AsiException(e.getLocalizedMessage());
   		} 

   		return isok;
    }
    
    
 	/**
 	 * 計算OTP過期日
 	 * @return
 	 */
 	public String getExpireDate() {
		String expireday ="";
		KycDateUtil kycdate = new KycDateUtil();
		String sysdate = kycdate.getKycDate();
  	 
      try {
          
         kycdate.setKycDate(sysdate);
         kycdate.add(KycDateUtil.DATE, NumberUtils.toInt(SystemParam.getParam("OTPEXDAY")));//系統參數，系統日加天數
         expireday = kycdate.getKycDate();

      } 
      catch (ParseException e) {
         e.printStackTrace();
      }
      return expireday;
	}

 	/**
 	 * 處理客戶資料檔新增/修改
 	 * @throws AsiException
 	 */
 	public void dealwithIC01PF()throws AsiException
 	{
 		DBO dboUser = getTransaction().getDBO("kyc.QT1M03s16", 0);
		dboUser.addParameter("c101", mform.getUserid());
		dboUser.executeSelect();

 		DBO dboUser400 = getTransaction().getDBO("kyc.QT1M03s16", 1);
 		dboUser400.addParameter("c101", mform.getUserid());
 		dboUser400.executeSelect();

		String id = mform.getUserid();
		String kind = "";
      
		if(id.length() == 8)
		{
			kind = "3";//法人
		}
		else{
			if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
				kind = "2";//外國人
			else
				kind = "1";//本國人
		}

		//oracle
		if (dboUser.getRecordCount() > 0)
		{
			updateIC01PF();//更新客戶檔
			UpdateSecaj();//更新帳號檔
		}
		// 新保戶
		else
		{
			if (!kind.equals("3") && !kind.equals(""))
			{
				insertIC01PF();//寫入oralce客戶檔自動新增帳號檔
			}
		}

		//AS400
		if (dboUser400.getRecordCount() > 0)
		{
			updateIC01PF_AS400();//更新400客戶檔
		}
		// 新保戶
		else
		{
			if (!kind.equals("3") && !kind.equals(""))
			{
				insertIC01PF_AS400();//寫入400客戶檔
			}
		}
		
		String token = mform.getKeytoken();
		String uid = getUidByToken(token);
		mform.setUid(uid);
		mform.setPsw(getPswByUid(uid));

 	}

   /**
    * 更新IC01PF-ORACLE
    * @throws AsiException
    */
   private void updateIC01PF() throws AsiException
   {

	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String sql = "UPDATE IC01PF SET C102=?,C103=?,C104=?,C106=?,CA106=?,C108=?,C113=?,CA101=?,C198=?,C199=? " + "WHERE C101=?";

	   String sex = "";
	   String id = mform.getUserid();
      
	   if(id.substring(1, 2).equals("1") ||  "ACE8".indexOf(id.substring(1, 2)) != -1){
		   sex = "1";
	   }
	   else if(id.substring(1, 2).equals("2") ||  "BDF9".indexOf(id.substring(1, 2)) != -1){
		   sex = "2";
	   }

	   String kind = "";
  
	   if(id.length() == 8)
	   {
		   kind = "3";
	   }
	   else{
		   if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
			   kind = "2";
		   else
			   kind = "1";
	   }
      
	   String args[] = new String[11];
	   args[0] = mform.getUsername();
	   args[1] = mform.getAllBirthday();
	   args[2] = sex;
	   
	   args[3] = kind;
	   args[4] = mform.getZip();
	   args[5] = mform.getAllAddress();
	   args[6] = mform.getEmail();
	   args[7] = mform.getCellphone();
	   args[8] = sysdate;
	   args[9] = id;
	   args[10] = id;

	   QueryRunner runner = new QueryRunner();
	   getTransaction().begin(0);

	   try 
	   {
		   Connection con = getTransaction().getConnection(0);
		   runner.update(con, sql ,args);
		   con.commit();
   		 
	   } catch (SQLException e) {
		   e.printStackTrace();
		   throw new AsiException(e.getLocalizedMessage());
	   } 

   }

   /**
    * 更新IC01PF-ORACLE
    * @throws AsiException
    */
   private void updateIC01PF_AS400() throws AsiException
   {

	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String sql = "UPDATE IC01PF SET C102=?,C103=?,C104=?,C106=?,C107=?,C108=?,C113=?,C198=?,C199=? WHERE C101=?";

	   String sex = "";
	   String id = mform.getUserid();
      
	   if(id.substring(1, 2).equals("1") ||  "ACE8".indexOf(id.substring(1, 2)) != -1){
		   sex = "1";
	   }
	   else if(id.substring(1, 2).equals("2") ||  "BDF9".indexOf(id.substring(1, 2)) != -1){
		   sex = "2";
	   }

	   String kind = "";
  
	   if(id.length() == 8)
	   {
		   kind = "3";
	   }
	   else{
		   if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
			   kind = "2";
		   else
			   kind = "1";
	   }
      
	   String args[] = new String[10];
	   args[0] = mform.getUsername();
	   args[1] = mform.getAllBirthday();
	   args[2] = sex;
	   //args[3] = mform.getMarriage();
	   args[3] = kind;
	   args[4] = mform.getCellphone();
	   args[5] = mform.getAllAddress();
	   args[6] = mform.getEmail();
	   args[7] = sysdate;
	   args[8] = id;
	   args[9] = id;
 
	   Connection con = null;
	   try 
	   {
		   con = AS400Connection.getConnection();
		   QueryRunner runner = new QueryRunner();
		   runner.update(con, sql ,args);
   		 
	   } catch (SQLException e) {
		   e.printStackTrace();
		   throw new AsiException(e.getLocalizedMessage());
	   } 
	   finally{
		   AS400Connection.closeConnection(con);
	   }

   }

   /**
    * 寫入IC01PF
    * @throws AsiException
    */
   private void insertIC01PF() throws AsiException
   {

	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String sql = "INSERT INTO IC01PF (C101,C102,C103,C104,C106,CA106,C108,C113,CA101,C196,C197,C198,C199) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";

	   String sex = "";
	   String id = mform.getUserid();
      
	   if(id.substring(1, 2).equals("1") ||  "ACE8".indexOf(id.substring(1, 2)) != -1){
		   sex = "1";
	   }
	   else if(id.substring(1, 2).equals("2") ||  "BDF9".indexOf(id.substring(1, 2)) != -1){
		   sex = "2";
	   }

	   String kind = "";
      
	   if(id.length() == 8)
	   {
		   kind = "3";
	   }
	   else{
		   if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
			   kind = "2";
		   else
			   kind = "1";
	   }
      
	   String args[] = new String[13];
	   args[0] = id;
	   args[1] = mform.getUsername();
	   args[2] = mform.getAllBirthday();
	   args[3] = sex;
	   //args[4] = mform.getMarriage();
	   args[4] = kind;
	   args[5] = mform.getZip();
	   args[6] = mform.getAllAddress();
	   args[7] = mform.getEmail();
	   args[8] = mform.getCellphone();
	   args[9] = sysdate;
	   args[10] = id;
	   args[11] = sysdate;
	   args[12] = id;	

   	QueryRunner runner = new QueryRunner();
   	getTransaction().begin(0);

   	try 
   	{
   		 Connection con = getTransaction().getConnection(0);
   		 runner.update(con, sql ,args);
   		 con.commit();
   		 
   	} catch (SQLException e) {
   		 e.printStackTrace();
   		 throw new AsiException(e.getLocalizedMessage());
   	} 

	}
   

   /**
    * 寫入IC01PF
    * @throws AsiException
    */
   private void insertIC01PF_AS400() throws AsiException
   {

	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String sql = "INSERT INTO IC01PF (C101,C102,C103,C104,C106,C107,C108,C113,C196,C197,C198,C199) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

	   String sex = "";
	   String id = mform.getUserid();
      
	   if(id.substring(1, 2).equals("1") ||  "ACE8".indexOf(id.substring(1, 2)) != -1){
		   sex = "1";
	   }
	   else if(id.substring(1, 2).equals("2") ||  "BDF9".indexOf(id.substring(1, 2)) != -1){
		   sex = "2";
	   }

	   String kind = "";
      
	   if(id.length() == 8)
	   {
		   kind = "3";
	   }
	   else{
		   if("ABCDEF89".indexOf(id.substring(1, 2)) != -1)
			   kind = "2";
		   else
			   kind = "1";
	   }
      
	   String args[] = new String[12];
	   args[0] = id;
	   args[1] = mform.getUsername();
	   args[2] = mform.getAllBirthday();
	   args[3] = sex;
	   //args[4] = mform.getMarriage();
	   args[4] = kind;
	   args[5] = mform.getCellphone();
	   args[6] = mform.getAllAddress();
	   args[7] = mform.getEmail();
	   args[8] = sysdate;
	   args[9] = id;
	   args[10] = sysdate;
	   args[11] = id;

	   Connection con = null;
	   try 
	   {
		   con = AS400Connection.getConnection();
		   QueryRunner runner = new QueryRunner();
		   runner.update(con, sql ,args);
   		 
	   } catch (SQLException e) {
		   e.printStackTrace();
		   throw new AsiException(e.getLocalizedMessage());
	   } 
	   finally{
		   AS400Connection.closeConnection(con);
	   }

   }

    /**
     * 查客戶id是否為傷害險有效保單客戶
    * @param id
    * @return
    */
	private boolean isClient_O(String id)
	{
		boolean isNewclient = true;
   	
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sql = "SELECT * FROM IC02PF WHERE C201 = ? AND C206 >= ? AND C204 IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

		String args[] = new String[2];
		args[0] = id;
		args[1] = sysdate;
		
		Connection con = null;
		List ret = null;
		
		try
		{
			con = AS400Connection.getConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql.toString(), args , new TrimedMapListHandler());
			
			if(!ret.isEmpty() && ret.size()>0)
				isNewclient = false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally{
			AS400Connection.closeConnection(con);
		}
		
		return isNewclient;
    }

   /**
    * 查客戶id是否為排除傷害險有效保單客戶
   * @param id
   * @return
   */
	private boolean isClient_P(String id)
	{
		boolean isNewclient = true;
  	
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sql = "SELECT * FROM IC02PF WHERE C201 = ? AND C206 >= ? AND C204 NOT IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

		String args[] = new String[2];
		args[0] = id;
		args[1] = sysdate;

		Connection con = null;
		List ret = null;
		
		try
		{
			con = AS400Connection.getConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql.toString(), args , new TrimedMapListHandler());
			
			if(ret != null && !ret.isEmpty())
				isNewclient = false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally{
			AS400Connection.closeConnection(con);
		}
		
		return isNewclient;
   }

    
 	/**
 	 * 寄發簡訊
 	 * 
 	 * @param data
 	 */
 	public void sendMobileMsg()
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		
 		sb.append("第一產物註冊OTP碼：").append(getInsertedOTP()).append("\n");
// 		sb.append("親愛的 ").append(mform.getUsername()).append(" 您好，您正於第一保進行會員註冊\n");
 		sb.append(" 您正於第一產物進行會員註冊");
 		sb.append("，請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！若無線上作業請忽略此封簡訊，謝謝。");

 		String sendTel = mform.getCellphone();
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);
 			System.out.println("statusCode" + statusCode + " " + getmethod.getResponseBodyAsString());
 			String responseText = getmethod.getResponseBodyAsString();

 			//判斷是否有回傳剩餘點數參數，剩餘200、100時發通知出納課
 			if (responseText.indexOf("LCount=") != -1)
 			{
 				String str = responseText.replaceAll("\n|\r", "");// 清除換行符號
 				if (Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 100
 						|| Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 200)
 				{
 					String content = responseText.replaceFirst("ErrorCode", "訊息代碼");
 					content = content.replaceFirst("LCount", "剩餘點數");
 					content = content.replaceFirst("MsgID000", "簡訊代號");

 					String email = SystemParam.getParam("EMAIL");// 客服信箱
 					sendSysMail(email, content);// 寄發剩餘點數通知
 				}
 			}

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

	private void sendSysMail(String email, String content)
	{
		KycMailUtil kmu = new KycMailUtil();
		kmu.setSubject("網路投保OTP-簡訊服務剩餘儲值點數");
		kmu.setFrom("admin@firstins.com.tw");
		kmu.setMessage(content);
		kmu.addTo(email);
		kmu.sendMail();
	}
	//查詢IC01PFA是否已經有該客戶資料
	public boolean isExistIC01PFA(String id)
	{
		String sql="select * from IC01PFA where C01A01=?";
		Connection con = getTransaction().getConnection(0);	
		QueryRunner qr=new QueryRunner();
		
		Object[] param={id};
		
		List data=null;
		try{
			data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		if(data==null || data.size()==0){
			return false;
		}else{
			return true;
		}		
	}
	//新增或更新IC01PFA客戶資料(是否同意行銷)
	public void updateIC01PFA(String id,String C01A18,boolean exist)
	{
		String sql="";
		if(!exist){
			sql="insert into IC01PFA(C01A18,C01A01) VALUES(?,?)";
		}
		else{
			sql = "UPDATE IC01PFA SET C01A18=? WHERE C01A01=?";
		}
				
		Connection con = getTransaction().getConnection(0);	
		QueryRunner qr=new QueryRunner();
			
		Object[] param={C01A18,id};
					
		try{
			qr.update(con, sql,param);
		}catch(Exception e){
			e.printStackTrace();
		}
			
	}
	//更新IC01PFA客戶資料(產生推薦人代碼)
	public void generateReferrerCode(String id,HttpServletRequest request,String birthday)
	{
		String sql="UPDATE IC01PFA SET C01A17=? WHERE C01A01= ?";
		
		String[] args = new String[2];
    	args[0] = Number3.getReferrerNumber(getServlet(), request, id, birthday);//取得推薦人代號
    	args[1] = id;
				
		Connection con = getTransaction().getConnection(0);	
		QueryRunner qr=new QueryRunner();
					
		try{
			qr.update(con, sql,args);
		}catch(Exception e){
			e.printStackTrace();
		}			
	}
	//網路投保完成後寫入IC01PF
	public void insertIC01PF_Insured(String id)
	{
		String sql="";
		try{
			DBO dboUser = getTransaction().getDBO("kyc.QT1M03s16", 0);
			dboUser.addParameter("c101", id);
			dboUser.executeSelect();
		
			//不存在則新增
			if (dboUser.getRecordCount() <= 0){
				sql="INSERT INTO IC01PF(C101) VALUES (?) ";
				Connection con = getTransaction().getConnection(0);	
				QueryRunner qr=new QueryRunner();				
				Object[] param={id};
				qr.update(con, sql,param);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
			
	}
	
	/**
	 * 判斷推薦人是否為員工
	 */
	public boolean isEmployee(String referrerCode){
		boolean result = false;
		
		String sql="select * from PSM3PF left join IC01PFA on M319=C01A01 where C01A17 = ?";
		try
		{
			QueryRunner qr = new QueryRunner(); 
			Connection con = getTransaction().getConnection(0);
			List<Map> m=(List<Map>)qr.query(con, sql,referrerCode,new TrimedMapListHandler());
			if(m.size()>0){
				result=true;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return result;
	}

 	
	/**
	 * @return the insertedOTP
	 */
	public String getInsertedOTP()
	{
		return insertedOTP;
	}

	/**
	 * @param insertedOTP the insertedOTP to set
	 */
	public void setInsertedOTP(String insertedOTP)
	{
		this.insertedOTP = insertedOTP;
	}

	/**
	 * @return the encryptedkey
	 */
	public String getEncryptedkey()
	{
		return encryptedkey;
	}

	/**
	 * @param encryptedkey the encryptedkey to set
	 */
	public void setEncryptedkey(String encryptedkey)
	{
		this.encryptedkey = encryptedkey;
	}

	/**
	 * @return the insertedid
	 */
	public String getInsertedid()
	{
		return insertedid;
	}

	/**
	 * @param insertedid the insertedid to set
	 */
	public void setInsertedid(String insertedid)
	{
		this.insertedid = insertedid;
	}

	/**
	 * @return the username
	 */
	public String getUsername()
	{
		return username;
	}

	/**
	 * @param username the username to set
	 */
	public void setUsername(String username)
	{
		this.username = username;
	}


	/**
	* For API 寫入註冊檔
    * @return
    * @throws AsiException
    */
   	public boolean isInsertFullSucess(Map input) throws AsiException 
    {
   		boolean isok = false;

   		String gettoken = KYCEncryptor.genToken(mform.getUserid());//ID加密
   		setInsertedid(mform.getUserid());
   		setEncryptedkey(gettoken);
   		
   		String getotp = "";
   		if(input != null && input.size() > 0)
   			getotp = input.get("regotp").toString();
   		else
   			getotp = KYCEncryptor.genOTP();
   		
   		setInsertedOTP(getotp);

   		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
   		String systime = DateUtil.getSysTime();
   		String otpexpireday = getExpireDate();//OTP過期日期
   		String ARGNO = SystemParam.getParam("ARGDOC_REG_NO"); // 系統代碼，聲明事項文件編號
   		String zip = mform.getZip() != null ? mform.getZip() : "";
   		String city = mform.getCity() != null ? mform.getCity() : "";
   		String town = mform.getTown() != null ? mform.getTown() : "";

   		//判斷是否為產險客戶
   		boolean isProdClient = isClient_P(mform.getUserid());
   		//判斷是否為人身險客戶
   		boolean isLifeClient = isClient_O(mform.getUserid());

        //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
        String remoteAddr = getRequest().getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = getRequest().getRemoteAddr();
        }        

   		try 
   		{

	   		String sqlreg = "SELECT * FROM KYCREG WHERE RG01='" + mform.getUserid() + "'";
	
	   		QueryRunner runner = new QueryRunner();
	   		getTransaction().begin(0);
	
	   		int ret = 0;
	   		Connection con = getTransaction().getConnection(0);
	
	   		List regdata = null;
	   		regdata = (List) runner.query(con, sqlreg.toString(), new TrimedMapListHandler());
	
	   		if(!regdata.isEmpty() && regdata.size()>0)//註冊檔已有資料時
	   		{
	
		   		String sql = 
		   		"UPDATE KYCREG SET RG02=?,RG03=?,RG04=?,RG05=?,RG06=?,RG07=?,RG08=?,RG09=?,RG10=?,RG11=?,RG12=?,RG13=?,RG14=?,RG15=?,RG16=?,RG17=?,RG18=?,RG19=?,RG20=?,RG21=?," +
		   		"RG22=?,RG23=?,RG24=?,RG25=?,RG26=?,RG27=?,RG28=?,RG29=?,RG30=?,RG31=?,UPDDT=?,UPDTM=?,UPDUR=?" +
		   		"WHERE RG01=?";
		
		   		String args[] = new String[34];
		
		   		args[0] = mform.getUsername();
		   		args[1] = mform.getByear() + mform.getBmonth() + mform.getBdate();
		   		args[2] = mform.getCellphone();
		   		args[3] = mform.getEmail();
		   		args[4] = getotp;
		   		args[5] = "0";
		   		args[6] = sysdate;
		   		args[7] = systime;
		   		args[8] = otpexpireday;
		   		args[9] = SystemParam.getParam("OTPEXTIME");
		   		args[10] = sysdate;
		   		args[11] = systime;
		   		args[12] = sysdate;
		   		args[13] = systime;
		   		args[14] = gettoken;
		   		args[15] = isProdClient ? "2":"1";//1-新保戶 2-舊保戶
		   		args[16] = isLifeClient ? "2":"1";//1-新保戶 2-舊保戶
		   		args[17] = ARGNO;
		   		args[18] = zip;
		   		args[19] = city + town + mform.getAddress();
		   		
		   		args[20] = "1";
		   		args[21] = "";
		   		args[22] = "0";
		   		args[23] = remoteAddr;
		   		
		   		args[24] = "0";
		   		args[25] = mform.getIsmobile();
		   		args[26] = mform.getOs();
		   		args[27] = mform.getBrowser();
		   		args[28] = mform.getBro_version();
		   		
		   		args[29] = mform.getRg31();
		   		
		   		args[30] = sysdate;
		   		args[31] = systime;
		   		args[32] = mform.getUserid();
		   		args[33] = mform.getUserid();
		
		   		ret = runner.update(con, sql ,args);
		   		if(ret > 0)
		   		isok = true;
	
	   		}
	   		else{
	
		   		String sql = 
		   				"INSERT INTO KYCREG (RG01,RG02,RG03,RG04,RG05,RG06,RG07,RG08,RG09,RG10,RG11,RG12,RG13,RG14,RG15,RG16,RG17,RG18,RG19,RG20,RG21,"
		   				+"RG22,RG23,RG24,RG25,RG26,RG27,RG28,RG29,RG30,RG31,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) " 
		   				+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		   		String args[] = new String[37];
		   		args[0] = mform.getUserid();
		   		args[1] = mform.getUsername();
		   		args[2] = mform.getByear() + mform.getBmonth() + mform.getBdate();
		   		args[3] = mform.getCellphone();
		   		args[4] = mform.getEmail();
		   		args[5] = getotp;
		   		args[6] = "0";
		   		args[7] = sysdate;
		   		args[8] = systime;
		   		args[9] = otpexpireday;
		   		args[10] = SystemParam.getParam("OTPEXTIME");
		   		args[11] = sysdate;
		   		args[12] = systime;
		   		args[13] = sysdate;
		   		args[14] = systime;
		   		args[15] = gettoken;
		   		args[16] = isProdClient ? "2":"1";
		   		args[17] = isLifeClient ? "2":"1";
		   		args[18] = ARGNO;
		   		args[19] = zip;
		   		args[20] = city + town + mform.getAddress();
		   		
		   		args[21] = "1";
		   		args[22] = "";
		   		args[23] = "0";
		   		args[24] = remoteAddr;
		   		args[25] = "0";
		   		args[26] = mform.getIsmobile();
		   		args[27] = mform.getOs();
		   		args[28] = mform.getBrowser();
		   		args[29] = mform.getBro_version();

		   		args[30] = mform.getRg31();
		   		
		   		args[31] = sysdate;
		   		args[32] = systime;
		   		args[33] = mform.getUserid();
		   		args[34] = sysdate;
		   		args[35] = systime;
		   		args[36] = mform.getUserid();	   		
		
		   		ret = runner.update(con, sql ,args);
		   		if(ret > 0)
		   		isok = true;		 
	   		}

   		} catch (SQLException e) {
   			e.printStackTrace();
   			throw new AsiException(e.getLocalizedMessage());
   		} 

   		return isok;
    }

    /**
     * 取得OD-API的TOKEN
     * @return
     */
    public String getODAPI_Token(HttpServletRequest request , HttpServletResponse resp){
    	String tkn = "";
    	JSONObject inputprarm = null;
    	
    	try {
			Map mp = new HashMap();
			mp.put("email_address", "FirstinsODAPI@firstins.com.tw");
			mp.put("password", "password");
    		
			inputprarm = JSONObject.fromObject(mp);


			
			//跳過SSL憑證檢核
//			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
//			Protocol.registerProtocol("https", easyhttps);

			String url = "https://ixt-test-api.firstins.com.tw/login";
			
			URL urlpost = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) urlpost.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
//			conn.setDoInput(true);		
			conn.setRequestProperty("CSRF-TOKEN","1");//固定一定要放
			conn.setRequestProperty("Content-Type","application/json;charset=utf-8");
			conn.setRequestProperty("Connection", "keep-alive");
			conn.setRequestProperty("Cookie", "CSRF-TOKEN=1; Path=/; Domain=firstins.com.tw;");
//			conn.setConnectTimeout(3000);
//			conn.setReadTimeout(3000);
			
			OutputStream os = conn.getOutputStream();
	        os.write(inputprarm.toString().getBytes());
	        os.flush();

//	        MessageHeader header = new MessageHeader (conn.);
//	        String v = header.findValue ("Set-Cookie");
	 
	        Map respmp = conn.getHeaderFields();
	        String[] cookie_content = (String[]) respmp.get("Set-Cookie").toString().split(";");
	        int countt = cookie_content[0].lastIndexOf("ACCESS-TOKEN=");
	        String token = cookie_content[0].replace("[ACCESS-TOKEN=", "");
	        
	        Map<String, List<String>> hf = conn.getHeaderFields();

            Iterator it = hf.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pairs = (Map.Entry)it.next();
                System.out.println(pairs.getKey() + " = " + pairs.getValue());
            }
	        
//	        if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
//	            throw new RuntimeException("Failed : HTTP error code : "
//	                + conn.getResponseCode());
//	        }
	        System.out.println(conn.getResponseMessage());
	        BufferedReader br = new BufferedReader(new InputStreamReader(
	                (conn.getInputStream())));
	 
	        String output;
	        System.out.println("Output from Server .... \n");
	        while ((output = br.readLine()) != null) {
	            System.out.println(output.getBytes("UTF-8"));
	        }
	 
	        conn.disconnect();
			
//			conn.connect();
//			System.out.println(conn.getResponseCode() + " " + conn.getResponseMessage());
//			conn.disconnect();
			
//			conn.connect();	
						
			PostMethod postmethod = new PostMethod(url);
		   	postmethod.setRequestHeader("CSRF-TOKEN","1");//固定一定要放
		   	postmethod.setRequestHeader("Content-Type","application/json;charset=utf-8");
		   	postmethod.setRequestHeader("Set-Cookie","CSRF-TOKEN=1; Path=/; Domain=firstins.com.tw;");
//		   	postmethod.addRequestHeader("Set-Cookie","CSRF-TOKEN=1; Path=/; Domain=firstins.com.tw;");
		   	postmethod.setRequestBody(inputprarm.toString());
			
			HttpClient client = new HttpClient();
//			client.getState().addCookies(cookie);
		   	client.setConnectionTimeout(1000);
		   	client.setTimeout(1000);
		   	client.executeMethod(postmethod);
		   	
//		   	org.apache.commons.httpclient.Cookie[] currentCookies = client.getState().getCookies();
//		   	
//		   	String getcookie = postmethod.getResponseHeader("Set-Cookie").getValue();
		   	
//		   	System.out.println(postmethod.getResponseHeader("ACCESS-TOKEN"));
		   	System.out.println(postmethod.getResponseHeader("Set-Cookie"));
		   	
//		   	SAXReader reader = new SAXReader();
//		    Document doc = reader.read(postmethod.getResponseBodyAsStream());
//		    Element out = doc.getRootElement();
    		
		    System.out.println(postmethod.getResponseBodyAsStream());
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return tkn;
    }

}