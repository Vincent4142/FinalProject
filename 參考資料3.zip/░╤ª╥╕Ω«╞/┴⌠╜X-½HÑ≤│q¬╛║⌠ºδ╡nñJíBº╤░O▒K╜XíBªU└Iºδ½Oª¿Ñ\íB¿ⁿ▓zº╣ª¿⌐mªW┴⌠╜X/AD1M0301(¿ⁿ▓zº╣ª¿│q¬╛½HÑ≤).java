/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.adm.ad1.actions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeUtility;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;

import net.sf.json.JSONObject;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.net.util.Base64;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.adm.ad1.forms.AD1M030f;
import com.asi.common.GlobalKey;
import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.Record;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.dao.WB22PFDao;
import com.firstins.CarInsCardService;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * 後台維護 - 保單號碼配號確認作業
 * 
 * @author  ：John
 * @version ：$Revision: 1.1 $ $Date: 2006/02/06 09:06:41 $<br>	
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/adm/com/asi/adm/ad1/actions/AD1M0301.java,v 1.1 2006/02/06 09:06:41 john Exp $  
 * 建立日期	：2005/4/18
 * 異動註記	： 2019/05/22 vsg 確認完成的同時，發送強制險電子式保險證憑證及收據
 * 異動註記	： 2020/08/20 vincent 新增篩選條件(NCCC及Hitrust)
 * </pre></p>
 */
public class AD1M0301 extends AsiAction {
	
	private String file_folder = SystemParam.getParam("FILE_FOLDER") + "\\CAR_TRADEVAN";// 檔案存放位置
	
    public void doProcess(ActionMapping mapping, AsiActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws AsiException {
        AD1M030f form1 = (AD1M030f) form;
        int pageIndex = 0;
        UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
        String loginId  = ui.getUserId();
               
        if (form.getSource().equals("AD1M030p1")) {
        	String nc=request.getParameter("nc");
        	String hi=request.getParameter("hi");
        	
            DBO dbo1 = tx_controller.getDBO("kyc.PT15PFs02", 0);
            
            StringBuffer sql = new StringBuffer();
            
            //畫面輸入交易日期
            String tradeDate = form1.getT1523();
            if (!"".equals(tradeDate)) {
                sql.append(" AND PT15PF.T1523=").append(tradeDate);
            }
            //加入篩選條件NCCC及Hitrust
			if(nc!=null && hi==null){
				 sql.append(" AND KYCKLA.T15B9=").append("'"+nc+"'");
			}
			else if(nc==null && hi!=null){
				sql.append(" AND KYCKLA.T15B9=").append("'"+hi+"'");
			}
			else if(nc!=null && hi!=null){
				sql.append(" AND (KYCKLA.T15B9=").append("'"+nc+"'").append(" OR KYCKLA.T15B9=").append("'"+hi+"')");
			}
            //加上轉檔錯誤的資料
            DBO t1547err = tx_controller.getDBO("kyc.PT15PFs11", 1);
			t1547err.execute();
			List dupins = new ArrayList();
			if(t1547err.getRecordCount()>0)
			{
				sql.append(" OR (");
				for(int i=1;i<=t1547err.getRecordCount();i++)
				{
					dupins.add(t1547err.getRecordData(i, "T1504"));
					sql.append(" PT15PF.T1504='").append(t1547err.getRecordData(i, "T1504")).append("'");
					if(i!=t1547err.getRecordCount())
						sql.append(" OR ");
				}
				sql.append(")");
			}
			
            dbo1.addParameter("WHERE", sql.toString());
            dbo1.execute();
            //System.out.print(dbo1.getAssembledSQL());
            for(int i=1;i<=dbo1.getRecordCount();i++)
			{
            	/*
            		已確認並已轉檔但轉檔有誤，需重新配號並重置確認碼為''
            		重新配號後即可重新確認
            	*/
				if(dupins.contains(dbo1.getRecordData("T1504"))&&dbo1.getRecordData(i, "T1574").equals("Y"))
					dbo1.addRecordData(i, "dup", "color:red;font-weight:bold");
			}
            
            dbo1 = reDbo(dbo1, request);

            form1.setRecordCount(dbo1.getRecordCount());

            request.setAttribute("dbo1", dbo1);

            pageIndex = 2;

        } else if (form.getSource().equals("AD1M030p2")) {
            //取出有勾選的checkbox，更新確認碼為'Y';
            String[] pickUp = form1.getPickUp();
            String[] T1501 = form1.getT1501();
            String[] T1502 = form1.getT1502();
            String[] T1503 = form1.getT1503();
            String[] T1504 = form1.getT1504();
            String[] T1542 = form1.getT1542();
            
            //收費出單實施註記 
            String insPayCode = SystemParam.getParam("INS_PAY_CODE");
            
            //啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
            tx_controller.begin(0);
            DBO updt1574 = null;
            if("Y".equals(insPayCode))
            	updt1574 = tx_controller.getDBO("kyc.PT15PFu07", 0);
            else
            	updt1574 = tx_controller.getDBO("kyc.PT15PFu01", 0);

            ArrayList  UserMailT1501 = new ArrayList();
            
            WB22PFDao dao = null;
            CarInsCardService service = null;
            Map insdata = null;
            Map wb22data = null;
            String retWs = null;
            boolean isInsATrandSentOK = false;
            Connection con = null;

            try {
            	con = AS400Connection.getConnection();
                int len = pickUp.length;
                for (int i = 0; i < len; i++) {
                	int row = Integer.parseInt(pickUp[i]) - 1;
                	
                	isInsATrandSentOK = false;
                	
                	//強制險進行電子式投保憑證上傳作業，強制險t1503='A'才寄發
                	if(T1503[row].equals("A")){
                			
                    	insdata = getTransactionData(T1501[row]);//投保明細
                    	wb22data = getWb22pfData(T1504[row]);//電子保證平台傳送紀錄檔 
                    	                   	
            			dao = new WB22PFDao(con);
            			service = new CarInsCardService();
            			
                    	//查詢WB22PF是否已傳送關貿認證平台
                    	if(wb22data != null && wb22data.size() >0){
                    		//WB22PF紀錄檔的傳送註記B2204='Y'
                    		if("Y".equals(wb22data.get("B2204").toString().trim()))
                    			throw new UserException("強制證號：" + T1504[row] + " 已上傳過資料，請查明後再處理！");
                    		else{
        						dao.setB2201(T1504[row]);
        						dao.setB2202("");
        						dao.deleteWb22pf();
                    		}	
                    	}

        				//傳送前新增資料至紀錄檔
                    	dao = insertCallRecord(dao, insdata);
        				//承保作業
        				retWs = service.callInsCardApplyWS(dao);
        				
        				if(retWs!=null)
        				{
        					JSONObject jsonObject = JSONObject.fromObject(retWs);
        					
        					//備份及回傳保險證(S0000或E800開頭-公路監理機關錯誤回覆即算上傳成功)
        					if("S0000".equals(jsonObject.getString("resultCode")) || jsonObject.getString("resultCode").startsWith("E800"))
        					{
        						String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
        						String systime = DateUtil.getSysTime();
        						//更新紀錄檔
        						dao.setB2204("Y");
        						dao.setB2223(jsonObject.getString("cardSelNo")!=null && !"null".equals(jsonObject.getString("cardSelNo"))?jsonObject.getString("cardSelNo"):"");
        						dao.setB2224(jsonObject.getString("cardSelDate")!=null && !"null".equals(jsonObject.getString("cardSelDate"))?jsonObject.getString("cardSelDate"):"0");
        						dao.setB2225(jsonObject.getString("resultCode"));
        						dao.setB2295(systime);
        						dao.setB2298(sysdate);
        						dao.setB2299("KYC");
        						dao.setB2201(dao.getB2201());
        						dao.setB2202(dao.getB2202());
        						dao.updateWb22pf();

        						Base64 base64 = new Base64();
        						byte[] sByte = base64.decode(String.valueOf(jsonObject.get("insuredCard")).getBytes());
        						
        						//備份取得PDF檔
        						File file = new File(file_folder + "\\" + sysdate);
        						if (!file.exists())
        							file.mkdirs();
        						File fileInBk = new File(file_folder + "\\" + sysdate + "\\" + T1504[row] + "_" + systime + ".pdf");

        						FileOutputStream fos;
        						try
        						{
        							fos = new FileOutputStream(fileInBk);
        							fos.write(sByte);
        							fos.close();
        						} catch (FileNotFoundException e)
        						{
        							e.printStackTrace();
        						} catch (IOException e)
        						{
        							e.printStackTrace();
        						}
        						
        						if(insdata.get("T1516")!=null && insdata.get("T1516").toString().length()>0)
        						{
        							try
        							{
        								String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 電商服務電話
        								String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 電商傳真電話
        								
        								VelocityEngine ve = new VelocityEngine();
        								ve.setProperty("file.resource.loader.path", request.getServletContext().getRealPath("/"));
        								ve.init();
        								Template t = ve.getTemplate("mail/ad/ad1m02.html","utf-8");
        								VelocityContext context1 = new VelocityContext();
        								//姓名隱碼
        								StringBuffer hiddenName = new StringBuffer();
        								String trueName=insdata.get("T1506").toString();
        								for(int a=0;a<trueName.length();a++){
        									if(a==1){
        										hiddenName.append("O");
        									}
        									else{
        									    hiddenName.append(trueName.substring(a,a+1));
        								   	}
        								}
        								context1.put("usernameA", hiddenName.toString());
        								context1.put("usernameB", insdata.get("T1506").toString());
        								context1.put("carid", insdata.get("T1610").toString());
        								context1.put("t1501", T1501[row]);
        								context1.put("newday", sysdate);
        								context1.put("display","");
        								context1.put("ecom_tel", ecom_tel);
        								context1.put("ecom_fax", ecom_fax);
        								
        								StringWriter sw = new StringWriter();
        								t.merge( context1, sw );
        								
        								EmailAttachment[] attachment = new EmailAttachment[2];
        								// 郵件附加檔-電子式保險證
        								attachment[0] = new EmailAttachment();
        								attachment[0].setPath(fileInBk.getPath());
        								attachment[0].setDisposition(EmailAttachment.ATTACHMENT);
        								// 處理附件檔名編碼
        								attachment[0].setName(MimeUtility.encodeText(insdata.get("T1610").toString() + "-電子式保險證.pdf", "UTF-8", "B"));
        								
        								String rcpPath = getReportFilePathProv(file_folder+ "\\" + sysdate, "WB2R0811", insdata.get("T1504").toString(), insdata.get("T1507").toString());
        								// 郵件附加檔-保險費收據
        								attachment[1] = new EmailAttachment();
        								attachment[1].setPath(rcpPath);
        								attachment[1].setDisposition(EmailAttachment.ATTACHMENT);
        								// 處理附件檔名編碼
        								attachment[1].setName(MimeUtility.encodeText(insdata.get("T1610").toString() + "-保險費收據.pdf", "UTF-8", "B"));

        								KycMailUtil kmu = new KycMailUtil();
        								kmu.addAttachment(attachment);
        								kmu.setSubject("第一產物保險股份有限公司-網路投保受理完成通知");
        								kmu.setMessage(sw.getBuffer().toString());
        								kmu.addTo(insdata.get("T1516").toString());
        								kmu.sendMailWithAttachments();
        								
        								isInsATrandSentOK = true;
        							} catch (Exception e)
        							{
        								e.printStackTrace();
        							}
        						}
        					}
        					else
        					{		
        						System.out.println("網路投保後台-交易資料確認作業 :insuredCardNo="+insdata.get("T1504").toString() + ":resultError=" +retWs);
        					}
        					
        				}    				
                	}
                	
                    //更新保單交易檔的確認碼為Y
                    updt1574.addParameter("T1501", T1501[row]);
                    updt1574.addParameter("T1502", T1502[row]);
                    updt1574.addParameter("T1503", T1503[row]); 
                    if (T1542[row].equals(""))
                        updt1574.addParameter("WHERE"," rtrim(T1542) IS NULL");
                    else 
                        updt1574.addParameter("WHERE"," T1542 = '"+T1542[row]+"'");
                    updt1574.execute();
                    
            		//寫入KYCLLOG記錄檔處理
            		KycLogger klg = new KycLogger();
            		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保單號碼確認作業", "B", loginId, "", "", "", T1501[row], "", "", "", "", "", "U", "", "更新確認註記", updt1574.getAssembledSQL(), "", "", "", "");
                    
                    //若交易序號含強制險(A)已寄過不再寄；若無A保單就需另外寄
            		if(!isInsATrandSentOK)
            			UserMailT1501.add(T1501[row]);

                }
            	
			} catch (Exception e) {
				e.printStackTrace();
			} 
            finally
			{
				AS400Connection.closeConnection(con);
			}

            //使用構造HashSet
            HashSet<String> set = new HashSet<String>(UserMailT1501);
            //排除重複資料
            ArrayList<String> UserMailT1501Organize = new ArrayList<String>(set);
            
            for (int a = 0; a < UserMailT1501Organize.size(); a++){     	
            	getMail(UserMailT1501Organize.get(a),loginId);
            }
            
            pageIndex = 1;
        }

        form.setNextPage(pageIndex);
    }

	/**
	 * 取得產生強制保險憑證檔案連結
	 * @param fileFolder 暫存資料夾
	 * @param sendRptAction 報表action
	 * @param insnumber 保單號碼
	 * @param idNumber 被保人id(檔案加密)
	 * @return
	 */
	private String getReportFilePathProv(String fileFolder,String sendRptAction,String insnumber,String idNumber)
	{
		String rptPath = fileFolder + "\\PROV\\" + insnumber + "_prov.pdf";
		
		try
		{
			File ffolder = new File(fileFolder +"\\PROV");
			if(!ffolder.exists())
				ffolder.mkdirs();
			else
			{
				File file = new File(rptPath);
				if(file.exists())
					file.delete();
			}
			
			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);
			
			String url = getPath("/"+sendRptAction);

			PostMethod postmethod = new PostMethod(url);
		   	postmethod.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
		   	postmethod.addParameter("ckb", insnumber);
		   	postmethod.addParameter("reqType", "online");
		   	
		   	HttpClient client = new HttpClient();
		   	client.setConnectionTimeout(20000);
		   	client.setTimeout(20000);
		   	client.executeMethod(postmethod);
		   	
		   	FileOutputStream fos = new FileOutputStream(new File(rptPath));
			fos.write(postmethod.getResponseBody());
			fos.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return rptPath;
	}

	/**
	 * 取得報表路徑
	 * 
	 * @param url
	 * @return
	 * @throws JspException
	 */
	public String getPath(String url) throws JspException
	{
		String host = System.getProperty("jasper.report-url");
		if (host == null)
		{
			host = ConfigUtil.getConfig(getServlet(), "jasper.report-intra");
		}
		StringBuffer action = new StringBuffer();
		action.append(host).append(url).append(".do");
		System.out.println("report action path : " + action.toString());
		return action.toString();
	}

	/**
	 * 新增傳送資料至紀錄檔
	 * @param dao
	 * @param srcType 來源,1-保單原始檔,2-保單最新檔,3-未確認批單
	 * @param sendType 傳送類型,1-承保,2-批單,3-退保
	 * @param data
	 * @throws AsiException
	 */
	private WB22PFDao insertCallRecord(WB22PFDao dao , Map data) throws AsiException
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		dao.setB2201(data.get("T1504").toString());
		dao.setB2202("");
		dao.setB2203("");
		dao.setB2204("");
		dao.setB2205("1");

		dao.setB2206(data.get("T1507").toString());
		dao.setB2207(data.get("T1506").toString());
		dao.setB2208(data.get("T1517").toString());
		dao.setB2209(data.get("T1518").toString());
		dao.setB2210(data.get("T1502").toString().substring(0, 1).equals("C") ? "C" : "M");
		dao.setB2211(data.get("T1608").toString());
		dao.setB2212(data.get("T1606").toString()+"01");//原始發照日期,固定為原始發照年月+'01'
		dao.setB2213(data.get("T1605").toString());
		dao.setB2214(data.get("T1611").toString());
		dao.setB2215(data.get("T1609").toString());
		dao.setB2216(data.get("T1610").toString());
		dao.setB2217(data.get("T1726").toString());
		dao.setB2218("10");
		dao.setB2219(sysdate);//資料傳送當時之系統日
		dao.setB2220(data.get("T1541").toString());				
		dao.setB2221("1");//是否須同步至公路監理機構,未確認保單=1；反之放2
		dao.setB2222("0");
		dao.setB2223("");
		dao.setB2224("0");
		dao.setB2225("");
		dao.setB2226(data.get("channel").toString());
		dao.setB2227(data.get("B2227").toString());
		dao.setB2228(data.get("B2228").toString());
		dao.setB2229(data.get("agentCode").toString());
		dao.setB2294(systime);
		dao.setB2295(systime);
		dao.setB2296(sysdate);
		dao.setB2297(data.get("T1507").toString());
		dao.setB2298(sysdate);
		dao.setB2299(data.get("T1507").toString());
				
		dao.insertWb22pf();
		
		return dao;
	}

	/**
	 * 取得通路代碼
	 * @param con
	 * @param t4002 傳入業務來源
	 * @return
	 * @throws AsiException
	 */
	private String getT3905(String t4002)
	{

		String t3905 = null;
		String t4003sql = "SELECT * FROM PT40PF LEFT JOIN PT39PF ON T3901 = T4003 WHERE T4001= 'C' AND T4002 = ? ";

		QueryRunner run = new QueryRunner();
		Map m = null;
		tx_controller.begin(1);
		try
		{
			m = (Map) run.query(tx_controller.getConnection(1) , t4003sql, t4002, new MapHandler());
			t3905 = m.get("T3905").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
				
		return t3905;	
	}

    /**
     * 取得交易資料-強制險投保明細資料
     * @param conn
     * @param t1501
     * @return
     */
    private Map getTransactionData(String t1501)
    { 	
		Map data = null;
	
    	StringBuffer sql = new StringBuffer();
    	sql.append("SELECT * FROM PT15PF ");
    	sql.append("LEFT JOIN PT16PF ON T1601=T1501 AND T1602=T1502 AND T1603=T1503 ");
    	sql.append("LEFT JOIN PT17PF ON T1701=T1501 AND T1702=T1502 AND T1703=T1503 AND T1705='21' ");
    	sql.append("WHERE T1501=? AND T1503='A' ");

    	String args[] = new String[1];
    	args[0] = t1501;
		
 		tx_controller.begin(0);
		try
		{
 			QueryRunner runner = new QueryRunner();
 			data = (Map) runner.query(tx_controller.getConnection(0), sql.toString(), args , new TrimedMapHandler());
 			
 			if(data != null && data.size() > 0){
 				String channel = getT3905(data.get("T1519").toString());
 				
 				Employee emp = Employee.getEmployee(data.get("T1520").toString());
 				String agentCode = emp.getLicenceNo();
 				
 				//寫入WB22PF需要欄位
 				data.put("channel", channel);
 				data.put("agentCode", agentCode);
 	 			data.put("B2201", data.get("T1504"));
 	 			data.put("B2216", data.get("T1610"));
 	 			data.put("B2227", "03359109");
 	 			data.put("B2228", "第一產物保險股份有限公司");

 			}
 			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return data;
    }
    
    /**
     * 取得電子保證平台傳送紀錄檔 
     * @param b2201
     * @return
     */
    private Map getWb22pfData(String b2201)
    {
		Map data = null;
		
    	StringBuffer sql = new StringBuffer();
    	sql.append("SELECT * FROM WB22PF ");
    	sql.append("WHERE B2201=? ");

    	String args[] = new String[1];
    	args[0] = b2201;
		
 		tx_controller.begin(1);
		try
		{
 			QueryRunner runner = new QueryRunner();
 			data = (Map) runner.query(tx_controller.getConnection(1) , sql.toString(), args,  new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return data;  	
    }
       
    /**
     * 重組畫面上顯示的資料，並放入 DBO 中
     * @param dbo1
     * @param request
     * @return DBO
     */
    private DBO reDbo(DBO dbo1, HttpServletRequest request) {
        Record record;
        int index = 0;
        String tempstr = "";
        String compstr = "";
        int count = dbo1.getRecordCount();
        for (int i = 1; i <= count; i++) {
            record = dbo1.getRecord(i);

            // 險別
            if ("A".equals(record.getData("T1503"))) {
                if ("C".equals(record.getData("CT04"))) {
                    tempstr = MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD2M020.TXT04");

                } else {
                    tempstr = MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD2M020.TXT05");
                }

            } else if ("C1".equals(record.getData("T1503"))
                    || "C2".equals(record.getData("T1503"))) {
                if (record.getData("T1542") != null
                        && record.getData("T1542").length() > 5
                        && "A".equals(record.getData("T1542").substring(4, 5))) {
                    tempstr = MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD2M020.TXT07");
                    record.setData("CT04", "A");

                } else {
                    tempstr = MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD2M020.TXT06");
                    record.setData("CT04", "L");
                }
            }
            record.setData("uT1503", tempstr);

            // 編號
            tempstr = record.getData("T1501");

            if (compstr.equals(tempstr)) {
                index++;

            } else {
                compstr = tempstr;
                index = 1;
            }
            record.setData("SEQNUM", String.valueOf(index));

            // 列印狀態
            tempstr = record.getData("T1575");
            if ("A".equals(record.getData("T1503"))) {
                if ("Y".equals(tempstr)) {
                    tempstr = MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD1M030.TXT02");

                } else {
                    tempstr = "<font color='red'>"
                            + MessageUtil.getMessage(this.getServlet(),
                                                     request, "AD1M030.TXT03")
                            + "</font>";
                }

            } else {
                tempstr = "&nbsp;";
            }
            record.setData("uT1575", tempstr);
        }
        return dbo1;
    }
    
    /*
     * T1501 交易序號
     * carId 車號
     * loginId 確認人帳號
     */
    private void getMail(String T1501, String loginId) {
    	
    	// 郵件主體
		HtmlEmail email = new HtmlEmail();
		ResultSet userData ;
		
		String T1546 = "";//要保人
		String T1506 = "";//被保險人
		String T1610 = "";//車號
		String T1516 = "";//信箱
		
		try {
			tx_controller.begin(0);
			
			userData = getUserT1504(tx_controller.getConnection(0), T1501);
			while (userData.next())
			{
				T1546 = userData.getString("T1546");
				T1506 = userData.getString("T1506");
				T1610 = userData.getString("T1610");
				T1516 = userData.getString("T1516");
			}
			
			if (!T1516.equals("")){
				email.setMailSessionFromJNDI("java:comp/env/mail/MailSession");
				// 主旨註明是否為測試信
				if (SystemParam.getParam("ENV").equals("KYC"))
					email.addTo(T1516);// 收件人
				else
					email.addTo(getUserMail(tx_controller.getConnection(0), loginId));// 測試用收件人
							
				email.addBcc(getUserMail(tx_controller.getConnection(0), loginId));// 密件副本-登入人員
				email.addBcc("admin@firstins.com.tw");

				// 主旨註明是否為測試信
				if (SystemParam.getParam("ENV").equals("KYC"))
					email.setSubject("第一產物保險股份有限公司-網路投保受理完成通知");
				else
					email.setSubject("【測試】第一產物保險股份有限公司-網路投保受理完成通知");

				email.setFrom("admin@firstins.com.tw");// 寄件人
				email.setCharset("utf-8");
			
				email.setHtmlMsg(getMessage(T1501,T1546,T1506,T1610));//郵件內文
				email.send();
								
				SimpleDateFormat format = new SimpleDateFormat("yyyy年-M月-d日 kk時:m分:ss秒 E ");
				String s = format.format(new java.util.Date());
				System.out.println("時間：" + s + " 寄件者：" + loginId + " Email：" + T1516 + " 寄發成功！");
			}
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (EmailException e) {
			e.printStackTrace();
		} catch (AsiException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
	/**
	 * 取得傳入ID設定Email
	 * @param conn
	 * @param userid
	 * @return
	 * @throws AsiException
	 */
	public String getUserMail(Connection conn, String userid) throws AsiException
	{
		String mail = "";
		PreparedStatement st = null;
		ResultSet rs = null;
		try
		{
			st = conn.prepareStatement("SELECT EMAIL FROM SECAJ WHERE USERID=?");
			st.setString(1, userid);
			rs = st.executeQuery();
			while (rs.next())
			{
				mail = rs.getString("EMAIL");
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return mail;
	}
	/**
	 * 取得傳入保單號碼設定Email
	 * @param conn
	 * @param userid
	 * @return
	 * @throws AsiException
	 */
	public ResultSet getUserT1504(Connection conn, String T1501) throws AsiException
	{
		PreparedStatement st = null;
		ResultSet rs = null;
		try
		{
			st = conn.prepareStatement("SELECT * FROM PT15PF LEFT JOIN PT16PF ON T1601 = T1501 WHERE T1501 = ?");
			st.setString(1, T1501);
			rs = st.executeQuery();
	
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return rs;
	}
	
	/**
	 * 取得郵件內文
	 * 
	 * @param email
	 * @return
	 * @throws Exception
	 */
	private String getMessage(String t1501 , String usernameA, String usernameB, String carid) throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy年-M月-d日 ");
		String s = format.format(new java.util.Date());
		
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
		ve.init();
		
		// 郵件內文樣本
		Template t = ve.getTemplate("mail/ad/ad1m02.html", "utf-8");
		// 內文使用變數
		VelocityContext context1 = new VelocityContext();
		//姓名隱碼
		StringBuffer hiddenName = new StringBuffer();
		String trueName=usernameA;
		for(int i=0;i<trueName.length();i++){
			if(i==1){
				hiddenName.append("O");
			}
			else{
			    hiddenName.append(trueName.substring(i,i+1));
		   	}
		}
		context1.put("usernameA", hiddenName.toString());
		context1.put("usernameB", usernameB);
		context1.put("newday", s);
		context1.put("carid", carid);
		context1.put("t1501", t1501);
		context1.put("display","display: none;");//強制證說明不顯示

		StringWriter sw = new StringWriter();
		t.merge(context1, sw);

		return sw.getBuffer().toString();
	}

}