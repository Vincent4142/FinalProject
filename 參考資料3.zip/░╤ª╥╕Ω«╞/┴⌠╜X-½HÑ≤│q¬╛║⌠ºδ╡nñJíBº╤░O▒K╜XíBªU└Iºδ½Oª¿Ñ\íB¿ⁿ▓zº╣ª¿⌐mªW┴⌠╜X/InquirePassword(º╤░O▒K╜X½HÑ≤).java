/*
 * Created on 2005/3/25
 */
package com.kyc.sec.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.MailSender;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.ConfigUtil;
import com.asi.kyc.common.SystemParam;
import com.kyc.sec.forms.InquirePasswordForm;

/**
 * @author Sergio_Huang
 */
public class InquirePassword extends kycAction {

    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {

    	String[] googleCaptchaVerify = GoogleRecaptchaAPI.reCaptchaVerify(request);
    	
        InquirePasswordForm form1 = (InquirePasswordForm) form;
        DBO dbo2 = tx_controller.getDBO("sec.SECAJt", 0);
        dbo2.addParameter("USERID", form1.getId());
        dbo2.executeSelect();
        if (dbo2.getRecordCount() == 0) {
            throw new UserException("SEC.PASSERR4",form1.getId());
        }

        String userType = dbo2.getRecordData("USERTYPE");
        String mail = form1.getEmail() ;
        
        //判斷來源別為客戶或員工
        //如果為員工，檢查員工生日
        if (userType.equals("2")) {
            DBO dbo1 = tx_controller.getDBO("kyc.PSM3PFt", 0);
            dbo1.addParameter("M301", form1.getId());
            dbo1.executeSelect();
            
            	
                if (dbo1.getRecordCount() == 0) {
                    throw new UserException("SEC.PASSERR1", form1.getId());
                } else {
                    
                    //google 非機器人驗證，驗證通過再進行資料查詢及檢核
                    if(googleCaptchaVerify[0].equals("true")){

	                	if (dbo1.getRecordData("M318").equals("0") || dbo1.getRecordData("M318").equals(form1.getBirth()))
	                    {
	                        if(mail == null || mail.equals(""))
	                        	mail = dbo2.getRecordData("EMAIL");
	                        
	                        send(request, form1.getId(), mail);
	                    }
	                    else
	                        throw new UserException("SEC.PASSERR2", form1.getBirth());
                	
                    }else{
                    	String errmsg = googleCaptchaVerify[3].indexOf("timeout") != -1 ? "Google驗證碼超時，請重新輸入！" : googleCaptchaVerify[3] ;
                    	
                    	throw new AsiException(errmsg);
                    }

                }

        } else {
            //從客戶檔判斷來客戶為法人或自然人
            DBO dbo1 = tx_controller.getDBO("kyc.IC01PFs03", 0);
            dbo1.addParameter("C101", form1.getId());
            dbo1.execute();
            if (dbo1.getRecordCount() == 0)
                throw new UserException("SEC.PASSERR3", form1.getId());
            else {
                String tp = dbo1.getRecordData("C106");
                //如果為自然人，寄密碼
                if (tp.equals("1")) {
                    //                  如果為自然人，判斷生日正不正確
                    if (dbo1.getRecordData("C103").equals("0") || dbo1.getRecordData("C103").equals(form1.getBirth()))
                        send(request, form1.getId(), mail);
                    else
                        throw new UserException("SEC.PASSERR2", form1.getBirth());
                } else {//如果為法人，直接寄信
                    send(request, form1.getId(), dbo1.getRecordData("C113"));
                }
            }
        }
        form1.setNextPage(2);
    }

    private void send(HttpServletRequest request, String id, String email) throws AsiException {
        try {
            DBO dbo2 = tx_controller.getDBO("sec.SECAJt", 0);
            dbo2.addParameter("USERID", id);
            dbo2.executeSelect();
            String pass = EncryptUtil.getDesDecryptString(dbo2.getRecordData("PASSWORD"));

            String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
            String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
            
            if (email != null&&!email.equals("")) {
                MailSender sender = new MailSender();
                //主旨註明是否為測試信
				if (SystemParam.getParam("ENV").equals("KYC"))
					sender.setSubject("第一產物保險-密碼查詢回覆");
				else
					sender.setSubject("[測試]第一產物保險-密碼查詢回覆");

                String path = getServlet().getServletContext().getRealPath("/mail/pass_" + request.getLocale() + ".html");
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path),"UTF-8"));
                String line;
                StringBuffer linebf = new StringBuffer();
                line = br.readLine();
                while (line != null) {
                    linebf.append(line);
                    line = br.readLine();
                }

                String msg = linebf.toString();
                //姓名隱碼
                String name=dbo2.getRecordData("FIRSTNAME");
                StringBuffer hiddenName  = new StringBuffer();
                for(int i=0;i<name.length();i++){
                	if(i==1){
                		hiddenName.append("O");
                	}
                	else{
                		hiddenName.append(name.substring(i,i+1));
                	}
                }
                
                msg = msg.replaceAll("\\{0\\}", hiddenName.toString());
                msg = msg.replaceAll("\\{1\\}", pass);
                msg = msg.replaceAll("\\{2\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
                msg = msg.replaceAll("\\{link1\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
                msg = msg.replaceAll("\\{link2\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
                msg = msg.replaceAll("\\{ecom_tel\\}", ecom_tel);
                msg = msg.replaceAll("\\{ecom_fax\\}", ecom_fax);
                
                sender.setMessage(msg);
                String[] to = new String[1];
                to[0] = email;
                sender.addTo(to);
                sender.addBCC(SystemParam.getParam("BCCMAIL"));
                try {
                    sender.sendMail();
                } catch (AsiException e) {
                    LogFactory.getLog(InquirePassword.class).info("寄信發生錯誤 email:" + email);
                }
            } else {
                throw new UserException("SEC.mailError02");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     *  
     */

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        super.redefineActionCode(arg0, arg1, arg2, arg3);
    }
}