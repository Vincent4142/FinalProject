package com.kyc.diary.actions;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.utils.Codec;
import com.kyc.diary.forms.TP1M070f;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * @author Vincent
 * 作業：工作日誌維護-查詢是否有重複的聯繫單編號(AJAX)
 */

public class TP1M0702 extends AsiAction{

	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
	{
   	
	}
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws AsiException {
		
		AsiActionForm form1 = (AsiActionForm) form;
	      
			response.setContentType("text/html;charset=UTF-8");
			//flag代表是新增頁傳過來或是修改刪除頁傳過來
			int flag = Integer.parseInt(request.getParameter("flag").trim());
			
			//新增頁傳來
			if(flag==1){
				String cNumber=request.getParameter("cNumber").trim();
				String sql="SELECT * FROM TEST_DIARY where CNUMBER=?";
				try{
					
					PrintWriter out = response.getWriter();
					tx_controller.begin(0);
					QueryRunner qr = new QueryRunner(); 
					//設定?的參數
					Object[] params = {cNumber}; 
					Map m=(Map) qr.query(tx_controller.getConnection(0), sql,params,new TrimedMapHandler());
					if(cNumber.equals("")){
						out.write("不能為空");
					}
					else if(m==null){
						out.write("可以使用");
					}
					else{
						out.write("編號已重複");
					}
					out.flush();
					out.close();
				}catch(Exception e){
					e.printStackTrace();
				}
				form1.setNextPage(-1);
			}
			
			//修改刪除頁傳來
			if(flag==2){
				String cNumber=request.getParameter("cNumber").trim();
				
				String sql="SELECT * FROM TEST_DIARY where CNUMBER=?";
				try{
					
					PrintWriter out = response.getWriter();
					tx_controller.begin(0);
					QueryRunner qr = new QueryRunner(); 
					//設定?的參數
					Object[] params = {cNumber}; 
					Map m=(Map) qr.query(tx_controller.getConnection(0), sql,params,new TrimedMapHandler());
					if(m==null){
						out.write("查無此編號");
					}
					else{
						out.write("編號存在");
					}
					out.flush();
					out.close();
				}catch(Exception e){
					e.printStackTrace();
				}
				form1.setNextPage(-1);
			}
			
			
        
		
		
        	
	}

}
