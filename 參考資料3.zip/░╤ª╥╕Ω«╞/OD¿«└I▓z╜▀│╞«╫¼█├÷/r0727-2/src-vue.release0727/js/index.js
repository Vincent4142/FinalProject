/*
 * login_form:
 * Handle kyc data & api 
 */
const login_form = {
  data() {
    return {
      errors: {
        // status of each input data (validation)
        // default: false (no error)
        // if true: display error message for each data field
        clientid: false,
        carno: false,
        //accdate: false
        checkbox: false
      },
      data: {
        // form data for the api
        clientid: null,
        carno: null,
        date: new Date().toISOString().slice(0,10),
        accdate: null, 
        checkbox: false
      },
      // display notification element for end user: false/true
      show_note: false
    }
  },
  mounted () {

  },
  /*
  components: {
  	Datepicker
  },*/
  methods:{
    checkForm: function (e) {
      // check if data present, otherwise display error message
      this.errors.clientid = ( Boolean( this.data.clientid ) ) ? false : true
      this.errors.carno = ( Boolean( this.data.carno ) ) ? false : true
      
      // Check length of the clientid
      if ( Boolean( this.data.clientid ) ) {
        this.errors.clientid = ( this.data.clientid.length == 10) ? false : true
      }
      
      // Calculate ROC date
      this.rocdate()
      
      // Display debug info in console:
      console.log("Data:")
      console.log(this.data)
      console.log("Error:")
      console.log(this.errors)
      
      //e.preventDefault()
    },
    rocdate: function() {
      [Y, M, D] = this.data.date.split("-")
      this.data.accdate = (parseInt(Y)-1911).toString()+M+D
    }
  }
}
const login_form_instance = Vue.createApp( login_form ).mount('#login_form')

