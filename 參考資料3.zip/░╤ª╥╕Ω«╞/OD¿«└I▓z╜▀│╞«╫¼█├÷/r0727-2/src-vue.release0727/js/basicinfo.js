/*
 * baisc_information_form:
 * Handle baisc information form data & api 
 */
const baisc_information_form = {
  data() {
    return {
      errors: {
        // status of each input data (validation)
        // default: false (no error)
        // if true: display error message for each data field
        apply_name: false,
        apply_mobile: false,
        email: false,
        //date: false,
        accident_city: false,
        accident_reason: false,
        //accident_loss: false,
        hope_location: false
      },
      //token: null,
      //car_owner_id: null,
      //car_number: null,
      data: {
        // form data for the api
        apply_name: null,
        apply_mobile: null,
        email: null,
        date: new Date().toISOString().slice(0,10), /* Not shown in ui */
        accident_city: null,
        accident_reason: null,
        accident_loss: [],
        hope_location: null,
      },
      // loading data
      accident_city_list: [],
      hope_location_list: []
    }
  },
  mounted () {
    this.loadJsonData();
  },
  methods:{
    checkForm: function (e) {
      // check if data present, otherwise display error message
      this.errors.apply_name = ( Boolean( this.data.apply_name ) ) ? false : true
      this.errors.apply_mobile = ( Boolean( this.data.apply_mobile ) ) ? false : true
      this.errors.email = ( Boolean( this.data.email ) ) ? false : true
      this.errors.accident_city = ( Boolean( this.data.accident_city ) ) ? false : true
      this.errors.accident_reason = ( Boolean( this.data.accident_reason ) ) ? false : true
      this.errors.hope_location = ( Boolean( this.data.hope_location ) ) ? false : true

      // check if apply_name valid (chinese only)
      if ( Boolean( this.data.apply_name ) ) {
        this.errors.apply_name = ( /^[\u4E00-\u9FA5]+$/.test( String(this.data.apply_name) ) ) ? false : true
      }
      
      // check if email valid
      if ( Boolean( this.data.email ) ) {
        this.errors.email = ( /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( String(this.data.email) ) ) ? false : true
      }
      
      /*
      e.preventDefault()
      */
      // Display debug info in console:
      console.log("Data:")
      console.log(this.data)
      console.log("Error:")
      console.log(this.errors)
      
      //e.preventDefault()
    },
    loadJsonData: function () {
      this.accident_city_list = ["基隆市", "臺北市", "新北市", "宜蘭縣", "新竹市", "新竹縣", "桃園市", "苗栗縣", "臺中市", "彰化縣", "南投縣", "嘉義市", "嘉義縣", "雲林縣", "臺南市", "高雄市", "屏東縣", "臺東縣", "花蓮縣", "金門縣", "連江縣", "澎湖縣"]

      this.hope_location_list = [
        "總公司 台北市中正區忠孝東路一段54號",
        "內湖服務中心 台北市內湖區民權東路六段160號4樓之1",
        "基隆服務中心 基隆市仁愛區愛九路11號4樓",
        "新北分公司 新北市板橋區三民路二段37號16樓",
        "三重服務中心 新北市三重區中正北路46號",
        "新店服務中心 新北市新店區民權路103號11樓",
        "蘭陽服務中心 宜蘭縣羅東鎮公正路338之6號6樓",
        "花蓮服務中心 花蓮縣花蓮市中正路215號",
        "台東服務中心 台東縣台東市新生路503號",
        "桃竹分公司 桃園市中壢區環北路398號21樓之2",
        "桃園服務中心 桃園市桃園區經國路9號5樓之2",
        "新竹服務中心 新竹市北區中華路3段9號10樓之5",
        "苗栗服務中心 苗栗縣苗栗市福麗里至公路428之1號",
        "台中分公司 台中市西區臺灣大道一段726號9樓",
        "豐原服務中心 台中市豐原區豐東路 52號",
        "中港服務中心 台中市梧棲區中棲路一段 181號",
        "彰化服務中心 彰化縣彰化市中山路二段 2號8樓",
        "員林服務中心 彰化縣員林市南平街 170號",
        "草屯服務中心 南投縣草屯鎮太平路一段 285巷7號",
        "台南分公司 台南市中西區成功路515號6樓",
        "雲林服務中心 雲林縣斗南鎮南昌西路78號",
        "嘉義服務中心 嘉義市東區垂楊路316號11樓之1",
        "新營服務中心 台南市新營區大同路27號之3",
        "佳里服務中心 台南市佳里區安北路67號",
        "永康服務中心 台南市永康區中華路1-42號9樓",
        "高雄分公司 高雄市苓雅區四維三路263號3樓4樓",
        "路竹服務中心 高雄市路竹區中山路1187號6樓",
        "楠梓服務中心 高雄市楠梓區軍校路800號13樓之2",
        "鳳山服務中心 高雄市鳳山區青年路一段360號6樓",
        "屏東服務中心 屏東縣屏東市忠孝路229之35號"
        ]
    }
  }
}


const basic_info_form = Vue.createApp(baisc_information_form).mount('#info_form')
