const axios = require('axios');
const https = require('https');

// Please specify the test server/proxy server if needed
const KYC_SERVER_URL="https://kyctest.firstins.com.tw/kyc/";
// KYC APIs:
const KYC_TOKEN_API="GetTokenByOD.do?source=claim"
const INSCAR_API="QueryInsCarAPI.do?source=claim"

// Please specify the test server/proxy server if needed
const APP_SERVER_URL="https://1startupt.firstins.com.tw/app_web/";
// APP_WEB APIs:
const TOKEN_API="Handler_Car_Accident_Token.ashx";
const INFO_API="Handler_Car_Accident.ashx";
const FILE_API="Handler_Car_Accident_File.ashx";


async function kyc_api_test(){
	let token = null;
	// Ignore: 'UNABLE_TO_VERIFY_LEAF_SIGNATURE'
	process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
	const agent = new https.Agent({ 
		//requestCert: false, 
		rejectUnauthorized: false
	});

	console.log ("******************************")
	console.log ("*** KYC API TEST           ***")
	console.log ("******************************")

	// Step 1: kyc token request
	console.log ("1. Fetch kyc token: ");
	let axiosConfig = {
		headers: {
		'Accept': 'application/json; charset=utf-8',
		'Content-Type': 'application/json;charset=UTF-8'
		}
	};
	try {
		var response = await axios.post( KYC_SERVER_URL+KYC_TOKEN_API, {httpsAgent : agent}, {}, axiosConfig );
		console.log ( JSON.stringify (response["data"]) );
		token = response["data"].result.token
	} catch (err) {
		// Handle Error Here
		console.error(err);
	};

	// Step 2: Query INS CAR
	console.log ("2. Query INS CAR API:");
	let data = {
		"carno":"ABC-123",
		"clientid" : "E221426065",
		"accdate" : "1100501"
	};
	axiosConfig = {
		headers: {
			'Content-Type': 'application/json;charset=UTF-8',
			'Authorization': token
		}
	};
	    
        try {
                var response = await axios.post( KYC_SERVER_URL+INSCAR_API, {httpsAgent : agent}, data, axiosConfig );
                console.log ( JSON.stringify (response["data"]) );
        } catch (err) {
                // Handle Error Here
                console.error(err);
        };

};


async function app_web_api_test(){
	let token = null;
	let accident_id = null;

	console.log ("******************************")
	console.log ("*** APP WEB API TEST       ***")
	console.log ("******************************")

	// Step 1: token request
	console.log ("1. Fetch token API: ");
	let axiosConfig = {
		headers: {
		'Accept': 'application/json; charset=utf-8',
		'Content-Type': 'application/json;charset=UTF-8'
		}
	};
	try {
		var response = await axios.post(APP_SERVER_URL+TOKEN_API, {}, axiosConfig );
		console.log ( JSON.stringify (response["data"][0]) );
		token = response ["data"][0]["data"]["token"]
	} catch (err) {
		// Handle Error Here
		console.error(err);
	};

	// Step 2: send form data
	console.log ("2. Send form data & get accident id:");
	let data= {
		"token": token,
		"car_owner_id": "A123456789",
		"car_number": "AB-1234",
		"apply_name": "王第一",
		"apply_mobile": "0912345678",
		"apply_date": new Date().toISOString().slice(0,10),
		"email": "service@firstins.com.tw",
		"accident_city": "台北市",
		"accident_reason": "功能測試，事由限100字",
		"accident_loss": "乘客,竊盜,第三人,車損,駕傷,體傷",
		"hope_location": "台北分公司"
		};
	let params = new URLSearchParams();
	for (key in data)
		params.append (key, data[key]);
        axiosConfig = {
                headers: {
                'Accept': 'application/json; charset=utf-8',
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
                }
        };
        try {
                var response = await axios.post(APP_SERVER_URL+INFO_API, params, axiosConfig );
                console.log ( JSON.stringify (response["data"][0]) );
                accident_id = response ["data"][0]["data"]["accident_id"]
        } catch (err) {
                // Handle Error Here
                console.error(err);
        };

	// Display token & accident_id(from step 1, step 2)
	console.log ("token: "+ token + ", accident_id: "+ accident_id);

	// Step 3: upload file
	console.log ("3. Upload files: ");

	var FormData = require('form-data');
	var fs = require('fs');

	let formData = new FormData();
	formData.append('Files', fs.createReadStream('./images/1.png'));
	formData.append('Files', fs.createReadStream('./images/2.png'));
	formData.append('Files', fs.createReadStream('./images/3.png'));
	formData.append("token", token);
	formData.append("accident_id", accident_id);
	
        axiosConfig = {
                headers: {
                //'Accept': 'application/json; charset=utf-8',
                'Content-Type': `multipart/form-data; boundary=${formData._boundary}`
                }
        };
        try {
                var response = await axios.post(APP_SERVER_URL+FILE_API, formData, axiosConfig );
                console.log ( JSON.stringify ( response["data"] ) );
                //console.log ( response );
        } catch (err) {
                // Handle Error Here
                console.error(err);
        };	
};

// run test
async function run_test(){
	await kyc_api_test();
	await app_web_api_test();
}

run_test();
