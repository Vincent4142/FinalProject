/*
 * Created on 2005/4/21
 */
package com.asi.kyc.common.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * @author Sergio_Huang
 */
public class PasswordModifyDispatcher extends WebAction {

    /**
     *
     */
    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
        UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
        if (!ui.getUserId().startsWith("USER")) {
            String userType = ui.getInfo("USERTYPE");
            if(userType.equals("1")){//客戶{//bce
                form.setNextPage(2);
            }else if(userType.equals("2")){//員工
            	List<Map> m = null;
            	String sql="SELECT * FROM SECAL WHERE USERID=? ";
    			try
    			{
    				tx_controller.begin(0);
    				QueryRunner qr = new QueryRunner(); 
    				
    				m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,ui.getUserId(),new TrimedMapListHandler());  				
    				request.setAttribute("list", m);
    			}
    			catch (Exception e)
    			{
    				e.printStackTrace();
    			}
    			
                form.setNextPage(3);
            }else if(userType.equals("3")){//其它
                form.setNextPage(1); 
            }else
                form.setNextPage(4);
        } else {
            form.setNextPage(5);
        }
    }

    /**
     *
     */

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        AsiActionForm form = (AsiActionForm)arg1;
        form.setActionCode(1);
    }
}
