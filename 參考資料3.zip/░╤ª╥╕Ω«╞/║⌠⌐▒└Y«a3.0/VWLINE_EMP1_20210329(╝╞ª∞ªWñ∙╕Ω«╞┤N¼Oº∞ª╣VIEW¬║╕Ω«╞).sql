  CREATE OR REPLACE FORCE EDITIONABLE VIEW "FIRSTCRM"."VWLINE_EMP1" ("USERID", "NAME", "DEPTNO", "BIRTHDAY", "ID", "LEAVE_DATE", "EMAIL", "COMPANYTEL", "TELEXT", "CELLPHONE", "FAX", "LIC1", "LIC2", "LIC3", "LIC1_DATE", "CANCEL", "STOP", "RECOMID") AS 
  SELECT
    TO_CHAR(M301),
    TRIM(M302),
    m303 deptNo,
    m318,
    m319,
    m315,
    email,
    COMPANYTEL,
    PSM3PFA.telext,
    CELLPHONE,
    FAX,
    Lic1,
    Lic2,
    Lic3,
    NVL(lic1date,0), 
    CASE WHEN RTRIM(nvl(Z208,' '))='C'  THEN 'Y' ELSE 'N' END ,
    CASE WHEN RTRIM(nvl(MI04,' '))='70' THEN 'Y' ELSE 'N' END ,
	c01a17
 FROM
    psm3pf
    left join PSM3PFA on PSM3PFA.userid = to_CHAR(psm3pf.m301)
    left join secaj on secaj.userid=to_CHAR(psm3pf.m301)
	left join ic01pfa on c01a01 = m319 
    left join (SELECT
    z101@as400,
    z102@as400,
    MAX(TRIM(z106@as400) ) lic1,
    MAX(TRIM(z108@as400) ) lic2,
    MAX(TRIM(z110@as400) ) lic3,
    MAX(NVL(Z107,0)) lic1date 
    FROM  pyflib.psz1pf@as400
    WHERE z102@as400 <= ( TO_CHAR(SYSDATE,'YYYYMMDD') - 19110000 )
      AND z103@as400 >= ( TO_CHAR(SYSDATE,'YYYYMMDD') - 19110000 )
    GROUP BY z101,z102) on m301 = z101
   left join (SELECT
    z201@as400,
    z202@as400,
    MAX(Z208) Z208 
    FROM  pyflib.psz2pf@as400
    WHERE z203@as400 <= ( TO_CHAR(SYSDATE,'YYYYMMDD') - 19110000 )
      and z208@as400 ='C'
    GROUP BY z201,z202) on m301 = z201  and z202=z102
    left join (SELECT
    mi01@as400,
    MAX(mi04) Mi04 
    FROM  pyflib.psMipf@as400
    WHERE mi07@as400 <= ( TO_CHAR(SYSDATE,'YYYYMMDD') - 19110000 )
      AND mi08@as400 >= ( TO_CHAR(SYSDATE,'YYYYMMDD') - 19110000 )
      AND mi04@as400='70'
    GROUP BY mi01) on m301 = mi01;
