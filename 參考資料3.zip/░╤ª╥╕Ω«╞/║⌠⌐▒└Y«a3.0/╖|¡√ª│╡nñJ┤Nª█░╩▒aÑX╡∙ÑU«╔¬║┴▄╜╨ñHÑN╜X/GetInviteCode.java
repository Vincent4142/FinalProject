/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.utils.KycDateUtil;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * 網投會員如有登入，自動帶入註冊時輸入的邀請人代碼
 * @author Vincent
 * @Create Date 2021年08月16日
 */
public class GetInviteCode extends AsiAction
{	

   public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       AsiActionForm form1 = (AsiActionForm) form;
       if (form1.getActionCode() == 0)
           form1.setActionCode(GlobalKey.ACTION_SELECT);
       return;
   }

   public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       return null;
   }

   protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
   {
   	
   }
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String id = arg2.getParameter("uid") != null && !arg2.getParameter("uid").equals("") ? arg2.getParameter("uid").trim() : "";
		
		QueryRunner run = new QueryRunner();
		
		String sql="select RG01,RG02,RG31 from KYCREG where RG01=?";
		
		Map ret = null;

		try
		{
			tx_controller.begin(0);
			ret = (Map) run.query(tx_controller.getConnection(0),sql,id,new TrimedMapHandler());
												
			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(ret).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		arg1.setNextPage(-1);
	}
}
