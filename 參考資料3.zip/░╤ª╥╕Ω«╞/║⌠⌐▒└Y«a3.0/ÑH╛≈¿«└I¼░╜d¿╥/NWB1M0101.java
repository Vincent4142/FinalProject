package com.asi.kyc.wb1.actions;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.CharacterUtil;
import com.asi.kyc.common.utils.HitrustUtil;
import com.asi.kyc.common.utils.NCCCUtil;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.asi.kyc.wb1.forms.WB1M010f;
import com.asi.kyc.wb1.models.WB1M010m;
import com.kyc.sec.actions.kycAction;
import com.asi.common.util.DateUtil;

/**
 * 網路投保 - 機車險
 * 複製自 WB1M0101
 * @CreateDate 2015/3/31上午 9:26:25
 * @UpdateDate 2015/3/31上午 9:26:25   2018/6/27 don
 * @FileName kyc/com.asi.kyc.wb1.actions/NWB1M0101.java
 * @Purpose
 * 
 */
public class NWB1M0101 extends kycAction {

	String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
	String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
	
    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {

        WB1M010m model = new WB1M010m(tx_controller, request, form);
        RG1M010m model2 = new RG1M010m(tx_controller, request, form);
        String omitcredit = SystemParam.getParam("INS_OMITCREDIT");// 是否略過聯合信用卡刷卡機制，平常-N 測試-Y
        String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
        String pjcode = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";
        if(!pjcode.equals("")) {  
        	//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        	if(model.isProjectCode(pjcode)){
        		pjcode = CodeUtil.getCodeDesc(getServlet(), request, "PROJSOURCE", pjcode.toUpperCase());//由專案代碼找對應的業務來源
            	if (pjcode.equals("HOLIDAY"))
            		pjcode = "KYC";
        	}
        	else{
        		pjcode="BOSS3.0";
        	}        	
        }
        
        request.setAttribute("pjcode", pjcode);
        
        WB1M010f f = (WB1M010f) model.getMainForm();
        
        model.init();
        
        HttpSession session = request.getSession(false);
        UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);

        String userid = "";

        //For 畫面顯示折扣金額用
        String discounty1 = get21Discount("M01", "A", "21", "1", pjcode, "41");
        String discounty2 = get21Discount("M01", "A", "21", "2", pjcode, "41");       
        String discounty1a = get21Discount("M03", "A", "21", "1", pjcode, "41");
        String discounty2a = get21Discount("M03", "A", "21", "2", pjcode, "41");       
        request.setAttribute("discount21y1", discounty1);
        request.setAttribute("discount21y2", discounty2);
        request.setAttribute("discount21y1a", discounty1a);
        request.setAttribute("discount21y2a", discounty2a);
        
        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("M", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("M", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("M", "description"));
        request.setAttribute("meta_ogtitle", getKYCWHDbyKey("M", "ogtitle"));
        request.setAttribute("meta_ogdescription", getKYCWHDbyKey("M", "ogdescription"));
        request.setAttribute("meta_twittertitle", getKYCWHDbyKey("M", "twittertitle"));
       
        //專案名稱，若無傳入專案代號時，顯示直接投保
        String projectDesc = "直接投保";
        String pjc = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";
        if(!pjc.equals("")){
        	if(model.isProjectCode(pjc)){
        		projectDesc = CodeUtil.getCodeDesc(getServlet(), request, "CHANNELDES", pjc.toUpperCase());  
        	}        		
        }       	     
        request.setAttribute("pjdesc", projectDesc);
        
        //取得招攬人代號，FAS24PRC用
        String agentno = getKYCKD_KD17("M01", "A", "21", "1", pjcode, "41");
        
        if(form.getActionCode() == 5){
        	
        	form.setNextPage(1);
        }
        else if (form.getActionCode() == 21) {
        	model.processP6();            
       	
            model.setExtraValue();            
            request.setAttribute("WB1M010f", model.getMainForm());
            request.setAttribute("action", "NWB1M0101");
            
            String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商信箱
            String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
            String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
            request.setAttribute("ecom_email", ecom_email);
            request.setAttribute("telno", ecom_tel);
            request.setAttribute("faxno", ecom_fax);
            
			//完成投保若有填寫推薦人代號則LINE推播通知
			String referrerCode=(String) session.getAttribute("pjcode");
			if(referrerCode != "" && referrerCode !=null){
				if(!model.isProjectCode(referrerCode)){
					SendLineMessage slm=new SendLineMessage();
					String user_id=slm.getEmployeeCode(referrerCode);
					slm.sendLine(user_id, "推薦人通知", "投保：您推薦會員已完成機車險投保，電銷部很愛你");
				}
			}
			session.removeAttribute("pjcode");
			
            form.setNextPage(8);
            return;
        }else{
        	
        	if(form.getSource().equals("WB1M010p1")){
            	String date = getExecDate();
            	request.setAttribute("NEXT_ADJDATE", date);

                if(ui != null )
                	userid = ui.getUserId();              	
                request.setAttribute("userid", userid);
        		request.setAttribute("WB1M010f", model.getMainForm());

        		if(!pjcode.equals("")){
                    if (ui != null)
                    	request.setAttribute("carNumbers", model.getCustomerCarNos(ui.getUserId()));
                    
                    form.setNextPage(2);
        		}else{
                    if (ui == null) {
                		form.setNextPage(2);
                    } else{
                    	request.setAttribute("carNumbers", model.getCustomerCarNos(ui.getUserId()));
                    	form.setNextPage(2);
                    }
        		}
        		
        	}
        	else if (form.getSource().equals("WB1M010p2")) {
				session.setAttribute("WB1M010p2", form);
				
				//有輸入推薦人代號就紀錄
				if(request.getParameter("pjcode") !="" && request.getParameter("pjcode") != null){					
					session.setAttribute("pjcode", request.getParameter("pjcode"));
				}
				
				//先記住客戶是否同意行銷
				String C01A18= request.getParameter("agreeChk5")== null ? "" : request.getParameter("agreeChk5");
				session.setAttribute("C01A18",C01A18);
				
				if(form.getActionCode()==2) {
					form.setNextPage(1);
				} else {
	        		//被保險人id，查詢洗錢風險評估資料            
	        		String t1507 = request.getParameter("kyc_T1507") !=null ? request.getParameter("kyc_T1507") : "" ;
	        		String t1508 = t1507.length() == 10 ? f.getByear() + f.getBmonth() + f.getBdate() : "0" ;
	        		        
	        		if(!omitFAS24.equals("Y")){//是否略過查詢FAS24        			
	        			if(isid_switch.equals("Y")){//是否啟用新版
	    	             	if (model.checkFas24prc_new(t1507 , "" , t1508 , agentno) == false){
	    	            		throw new UserException("WB1.ERROR13");
	    	            	}
	        			}else{
	    	             	if (model.checkFas24prc(t1507,"") == false){
	    	            		throw new UserException("WB1.ERROR13");
	    	            	}
	        			}       			
	        		}
	
	             	//保費試算
	        		model.processP1();
	
	                if(ui != null )
	                	userid = ui.getUserId();
	                	
	                request.setAttribute("userid", userid);
	                request.setAttribute("WB1M010f", model.getMainForm());
		
	                form.setNextPage(3);
				}
            } else if (form.getSource().equals("WB1M010p3")) {
            	session.setAttribute("WB1M010p3", form);
            	if(form.getActionCode()==31) {
            		String date = getExecDate();
                	request.setAttribute("NEXT_ADJDATE", date);
            		request.setAttribute("WB1M010f", model.getMainForm());
            		if(ui != null )
            			request.setAttribute("carNumbers", model.getCustomerCarNos(ui.getUserId()));
             		form.setNextPage(2);
            	} else {
	                model.processP4(agentno);  //未登入者進登入頁
	                
	                String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
	                request.setAttribute("telno", ecom_tel);
	
	                request.getSession(false).setAttribute("WB1M010f", model.getMainForm());
	                request.setAttribute("WB1M010f", model.getMainForm());
	                form.setNextPage(6);
            	}
            } else if (form.getSource().equals("WB1M010p4")) {
            	if(form.getActionCode()==9)
            	{
            		DBO dbo = new SelectDBO();
            		dbo.addRecordData("C101",request.getParameter("UID"));
            		request.getSession(false).setAttribute(KycGlobal.Kyc_UserInfo, dbo);
            		form.setNextPage(5);
            	}
            	else
            	{
                	String date = getExecDate();
                	request.setAttribute("NEXT_ADJDATE", date);

                    if(ui != null )
                    	userid = ui.getUserId();              	
                    request.setAttribute("userid", userid);
            		request.setAttribute("WB1M010f", model.getMainForm());

            		if(form.getActionCode()== 2)
            		{
            			 form.setNextPage(2);
            		}
            		else{
                		if (model.processP3()) {
                			request.setAttribute("carNumbers", model.getCustomerCarNos(request.getParameter("UID")));
                            form.setNextPage(7);
                		}else {
                        	request.setAttribute("carNumbers", model.getCustomerCarNos(request.getParameter("UID")));
                        	form.setNextPage(2);
                        	request.setAttribute("WB1M010f", model.getMainForm());
                		}                		
            		}

            	}
            } else if (form.getSource().equals("WB1M010p5")) {
                request.getSession(false).removeAttribute("WB1M010f");
                model.processP4(agentno);
                request.setAttribute("WB1M010f", model.getMainForm());	
                
                form.setNextPage(6);
            } else if (form.getSource().equals("WB1M010p6")) {
               
            	if(form.getActionCode()==31) {
                	session.setAttribute("WB1M010p6", form);    
           		//保費試算
            		model.processP1();

                    if(ui != null )
                    	userid = ui.getUserId();
                    	
                    request.setAttribute("userid", userid);
                    request.setAttribute("WB1M010f", model.getMainForm());
            		form.setNextPage(3);
            	} else {
            		session.removeAttribute("WB1M010p2");
            		session.removeAttribute("WB1M010p3");
            		session.removeAttribute("WB1M010p6");
            		
            		//紀錄客戶是否同意行銷(IC01PFA)(IC01PF)
            		String C01A18= session.getAttribute("C01A18").toString();
            		boolean exist=model2.isExistIC01PFA(f.getKyc_T1507());
            		model2.updateIC01PFA(f.getKyc_T1507(), C01A18, exist);
            		model2.insertIC01PF_Insured(f.getKyc_T1507());
            		session.removeAttribute("C01A18");
            		
            		if(form.getActionCode()==41)
	            	{
	            		model.processP5();
	            		if(otpswitch.equals("Y"))
	            			model.sendMobileMsg();//發送投保簡訊
	            		else
	            			model.sendOTPMail(request);//發送投保email
	          		  	
	            		request.getSession(false).setAttribute("WB1M010f", model.getMainForm());
	            		request.setAttribute("WB1M010f", model.getMainForm());
	            		request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
	            		form.setNextPage(9);
	          	  	}else{
	          	  			//檢查是否為線上金流停用時間
	          	  			if (ui==null){
		                        ui = new UserInfo();
		                        ui.setDateFormat(DateUtil.Format_YYYYMMDD);
		                        ui.setDateType(DateUtil.ChType);
		                        ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
		                        ui.setFileDateType(DateUtil.ChType);
	          	  			}
	          	  			
	          	  			model.processP5();
	          	  			request.getSession(false).setAttribute("WB1M010f", model.getMainForm());
	          	  			request.setAttribute("WB1M010f", model.getMainForm());
	          	  			request.setAttribute("action", "NWB1M0101");
	          	  			WB1M010f form1 = (WB1M010f) model.getMainForm();
	          	  			
	          	  			//導刷卡頁面
	          	  			form.setNextPage(-1);
	          	  			HitrustUtil.callHitrust(form1.getNumber(), MathUtil.getDouble(form1.getDiscount()), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
	                              + CodeUtil.getCodeDesc(servlet,request,"GOODSID",form1.getType()) + form1.getKyc_T1507() + form1.getKyc_T1506(), 20), "/NWB1M0101.do", getServlet(), request, response);
	          	  	}
            	}
          	  
            } else if (form.getSource().equals("WB1M010p8")) {
            	//重新取授權
            	request.setAttribute("WB1M010f", request.getSession(false).getAttribute("WB1M010f"));
                form.setNextPage(6);
            }
            else if (form.getSource().equals("WB1M010p9")) 
            {  
            	if(form.getActionCode() == 28)
            	{ 			  
            		boolean isUpdatetok = model.isUpdateOTP();
       				if(isUpdatetok){
       					if(otpswitch.equals("Y"))
       						model.sendMobileMsg();//重新發送簡訊
       		        	else
       		        		model.sendOTPMail(request);//發送投保email

       					request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");
       					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

       				}else{
       					request.setAttribute("exmin", "0");
       				}

       				request.setAttribute("WB1M010f", model.getMainForm());
       				form.setNextPage(9);
       		  }
       		  else{
       			  if(model.isRightOTP())
          		  {
       				  WB1M010f form1 = (WB1M010f) model.getMainForm();
                      request.getSession(false).setAttribute("WB1M010f", model.getMainForm());      
                      
                      //略過網路投保刷卡動作，測試用
                      if(omitcredit.equals("Y"))
                      {
                          try {
                        	  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M0101.do?actionCode=21&retcode=00&ordernumber=" + form1.getNumber());
                        	  return;
                          } catch (MalformedURLException e) {

                        	  e.printStackTrace();
                          } catch (IOException e) {

                        	  e.printStackTrace();
                          }

                      }else{
                   
	                      form.setNextPage(-1);
	                      NCCCUtil.callNCCC(form1.getKyc_T1507() , form1.getNumber(), MathUtil.getDouble(form1.getDiscount()), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
	                            + CodeUtil.getCodeDesc(servlet,request,"GOODSID",model.getKG01()) + form1.getKyc_T1507() + form1.getKyc_T1506(), 40), "NWB1M0101", getServlet(), request, response);
                      }
          		  }
          		  else{
          			  throw new UserException("errors.1000", "OTP輸入錯誤，請重新輸入！");
          		  }
       			  
       		  }
         	  
            }
        	
        }
    }
    
    /**
     * 取得強制費率下次實施日期
     * @return
     */
    public String getExecDate()
	{
    	Connection con = AS400Connection.getConnection();
        String sql = "SELECT AH04 FROM PFAH WHERE AH01 ='21'";
        
        Map<?, ?> ret = null;
        try 
        {
            QueryRunner runner = new QueryRunner();
            ret = (Map<?, ?>) runner.query(con, sql, new MapHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        }finally
        {
        	AS400Connection.closeConnection(con);
        }
        return String.valueOf(ret.get("AH04"));	
	}

    /**
     * 查詢折扣金額
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD19
     * @param KD20
     * @return
     */
    public String get21Discount(String KD01,String KD02, String KD03, String KD04,String KD19,String KD20){
    	
    	String kd11 = "0" ; 
        if (KD19.equals("") || KD19 == null) {
            KD19 = "KYC";
        }
        tx_controller.begin(0);
        
        DBO dbo;
        try {
			
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);	//商品代碼
            kd.setKD02(KD02);	//險別
            kd.setKD03(KD03);	//險種
            kd.setKD04(KD04);	//年期
            kd.setKD19(KD19);	//來源網站
            kd.setKD20(KD20);	//通路別

        	dbo = kd.executeSelect(tx_controller.getConnection());
        	 
        	kd11 = dbo.getRecordData("KD11").toString();
		} catch (AsiException e) {

			e.printStackTrace();
		}

    	return kd11;
    }
    
    /**
     * 取得預設的招攬人代號
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD19
     * @param KD20
     * @return
     */
    public String getKYCKD_KD17(String KD01,String KD02, String KD03, String KD04,String KD19,String KD20){
    	
    	String kd17 = "0" ; 
        if (KD19.equals("") || KD19 == null) {
            KD19 = "KYC";
        }
        tx_controller.begin(0);
        
        DBO dbo;
        try {
			
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);	//商品代碼
            kd.setKD02(KD02);	//險別
            kd.setKD03(KD03);	//險種
            kd.setKD04(KD04);	//年期
            kd.setKD19(KD19);	//來源網站
            kd.setKD20(KD20);	//通路別

        	dbo = kd.executeSelect(tx_controller.getConnection(0));
        	 
        	kd17 = dbo.getRecordData("KD17").toString();
		} catch (AsiException e) {
			e.printStackTrace();
		}

    	return kd17;
    } 
    
    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }
    
    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) 
    {
        WB1M010f form1 = (WB1M010f) arg1;
        if (form1.getActionCode() == 0 && form1.getRetcode() != null) {
            form1.setActionCode(21);
        }else if(form1.getActionCode() == 0)
        {
        	form1.setActionCode(5);
        }
    }
}