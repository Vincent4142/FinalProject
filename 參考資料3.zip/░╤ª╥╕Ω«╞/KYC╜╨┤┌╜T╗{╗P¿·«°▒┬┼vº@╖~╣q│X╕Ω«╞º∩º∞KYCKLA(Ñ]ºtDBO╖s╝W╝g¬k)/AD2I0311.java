/*
 * Copyright (c) 2000-2004 Asgard System, Inc. Taipei, Taiwan. All rights
 * reserved. This software is the confidential and proprietary information of
 * Asgard System, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Asgard.
 */
package com.asi.adm.ad2.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.adm.ad1.forms.AD1M050f;
import com.asi.adm.ad1.models.IConfirmMail;
import com.asi.adm.ad1.models.PaConfirmMail;
import com.asi.adm.ad1.models.TravelConfirmMail;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * 訂單詳細資料
 * 
 * @author ：YiChuan
 * @version ：$Revision: 1.14 $ $Date: 2007/01/22 11:07:12 $<br>
 *          <p>
 * 
 * <pre>
 *             存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/adm/com/asi/adm/ad2/actions/AD2I0311.java,v 1.14 2007/01/22 11:07:12 cvsuser Exp $  
 *             建立日期	：2005/4/4
 *             異動註記	： 
 * </pre>
 * 
 * </p>
 */
public class AD2I0311 extends AsiAction
{

	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		AD1M050f form1 = (AD1M050f) form;
		
		String t1503 = form1.getKYC_T1503();// 險別
		String kxd06 = form1.getKxd06();//通報查詢個人id
		
		//使用者id
		String userid = "";
        HttpSession session = request.getSession(false);
        UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
        if(ui != null )
        	userid = ui.getUserId(); 
        
        //核保人員代號設定檔
		String[][] authority = CodeUtil.getCodeArray(servlet, request, "TA-AUTHMAN");
		String auth = "N";
		
		for (int i = 0; i < authority.length; i++) {			
			if(authority[i][0].equals(userid)){
				auth = "Y";//若使用者帳號存在於核保人員設定檔中，則開放權限可以查詢通報索引結果明細
			}
		}
		request.setAttribute("auth", auth);

		//抓取主檔資料
		SelectDBO dbo1 = getPt15Data(request);
		request.setAttribute("dbo1", dbo1);

		// 修改頁動作
		if (form1.getSource().equals("AD2I031p2"))
		{
			// 修改資料
			if (form1.getActionCode() == 7)
			{
				updateData(request, form1, userid);
			}

			// 補寄Email ； T1580保單交易狀態 = 0 
			if (request.getParameter("isOrder").equals("0") && t1503.equals("O") && form1.getActionCode() == 8)
			{
				sendMail(request);
			}
			System.out.println("getActionCode == 7 end");
		}

		if(form.getActionCode() != 10 ){
			//抓取主檔資料
			dbo1 = getPt15Data(request);
			request.setAttribute("dbo1", dbo1);
			
			//檢查招攬人是否有產險證照，放到畫面作檢核
			if(Employee.getEmployee(dbo1.getRecordData("T1520"))
					.hasPropertyLicenceMutiDate(dbo1.getRecordData("T1523"), "0", "0", "0"))
				request.setAttribute("hasLicence", "Y");
			else
				request.setAttribute("hasLicence", "N");

			//抓取標的物相關資料
			DBO dbo2 = null;
			dbo2 = getInsObjectData(request, dbo1 , t1503);
			request.setAttribute("dbo2", dbo2);
		}

		Map maindata = null;
		List detail = null;
		List epb500 = null;
		
		if (form1.getSource().equals("AD2I031p1") || form1.getSource().equals("AD2I031p2") || form1.getSource().equals("AD2I031p5"))
		{
			if(form.getActionCode() == 9){
				updateCallout(request, form1, userid);
				
				System.out.println("=== 9 ===");

			}
			else if(form.getActionCode() == 10 || form.getActionCode() == 11 || form.getActionCode() == 12 || form.getActionCode() == 13)
			{
				String checkno = form1.getCheckno();
				String qtype = form1.getQuerytype();
				String t1504 = form1.getKYC_T1504();
				String t1501 = form1.getKYC_T1501();
				
				if(qtype.equals("2")){//收件通報序號
					maindata = getEPB501PF(request , checkno);
					detail = getKYCKXC(request , checkno , null);					
				}else if(qtype.equals("3")){//承保通報確認碼
					epb500 = getEPB500PF(request , t1504);
					detail = getKYCKXC(request , checkno , null);
				}else if(qtype.equals("4")){//收件通報確認碼
					maindata = getEPB501PFbyPF21(request, t1501);
					detail = getKYCKXC(request , checkno , null );
				}else {
					detail = getKYCKXC(request , checkno , kxd06);
				}
				
				request.setAttribute("checkno", checkno);
				request.setAttribute("qtype", qtype);
				request.setAttribute("DATA1", maindata != null ? maindata : epb500);
				request.setAttribute("DATA2", detail);
				
				form.setNextPage(4);
				
				System.out.println("=== 10-13 ===");

				return;	
			}else if(form.getActionCode() == 15 ){
				String checkno = form1.getCheckno();
				
				detail = getKYCKXD(request , checkno);
				
				request.setAttribute("checkno", checkno);
				request.setAttribute("DATA2", detail);
				
				form.setNextPage(5);
				
				System.out.println("=== 15 ===");

				return;	
			}
			else{
				
				System.out.println("=== else ===");

				form.setNextPage(2);
				return;	
			}		

		}
		//抓取主檔資料
		dbo1 = getPt15Data(request);
		request.setAttribute("dbo1", dbo1);

		System.out.println("== end ==");

		form.setNextPage(1);

	}
	/**
	 * 查詢 FIRSTCRM.KYCKXD 通報查詢匯總檔
	 * @param KXC001 checkno
	 * @return
	 */
	private List getKYCKXD(HttpServletRequest request, String KXC001){
		List ret = null;
				
		String sql = "SELECT * FROM KYCKXD "
				+ "LEFT JOIN KYCKLA ON TA1518=KXD001 "
				+ "LEFT JOIN KYCKLD ON T1501=T1801 AND T1502=T1802 AND T1808=KXD002 "
				+ "WHERE KXD001=? ";
		
		String[] args = new String[1];
		args[0] = KXC001;
		
		Connection conn = null;
		try
		{
			conn = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(conn, sql, args, new TrimedMapListHandler());
			
				if(ret != null && !ret.isEmpty()){				
					for (int i = 0; i < ret.size(); i++) {
						Map mp = (Map) ret.get(i);
						mp.put("rowid", i+1);

						String kxd02d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD02").toString()), 0);
						mp.put("KXD02D", kxd02d);

						String kxd03d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD03").toString()), 0);
						mp.put("KXD03D", kxd03d);

						String kxd04d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD04").toString()), 0);
						mp.put("KXD04D", kxd04d);

						String kxd05d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD05").toString()), 0);
						mp.put("KXD05D", kxd05d);

						String kxd06d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD06").toString()), 0);
						mp.put("KXD06D", kxd06d);

						String kxd07d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD07").toString()), 0);
						mp.put("KXD07D", kxd07d);

						String kxd08d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD08").toString()), 0);
						mp.put("KXD08D", kxd08d);

						String kxd09d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD09").toString()), 0);
						mp.put("KXD09D", kxd09d);

						String kxd10d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXD10").toString()), 0);
						mp.put("KXD10D", kxd10d);

						String t1825d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("T1825").toString()), 0);
						mp.put("T1825D", t1825d);

						String t1826d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("T1826").toString()), 0);
						mp.put("T1826D", t1826d);
						
					}
				}			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(conn);
		}
		
		return ret;	
	}

	/**
	 * 查詢 FIRSTCRM.KYCKXC 通報查詢記錄檔
	 * @param KXC001 checkno
	 * @return
	 */
	private List getKYCKXC(HttpServletRequest request, String KXC001 , String KXC06){
		List ret = null;
				
		String sql = "";
		
		String[] args ;
		if(KXC06 != null && !KXC06.equals("")){
			sql = "SELECT * FROM KYCKXC WHERE KXC001=? AND KXC06=? ORDER BY KXC001,KXC002,KXC003 ";
			args = new String[2];
			args[0] = KXC001;
			args[1] = KXC06;
		}
		else
		{
			sql = "SELECT * FROM KYCKXC WHERE KXC001=? ORDER BY KXC001,KXC002,KXC003 ";
			args = new String[1];
			args[0] = KXC001;
		}

		Connection conn = null;
		try
		{
			conn = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(conn, sql, args, new TrimedMapListHandler());
			
			//checkno不含R(承保),U(收件)的才是通報查詢的內容
			if(KXC001.indexOf("R") == -1 && KXC001.indexOf("U") == -1)
			{
				if(ret != null && !ret.isEmpty()){				
					for (int i = 0; i < ret.size(); i++) {
						Map mp = (Map) ret.get(i);
						mp.put("rowid", i+1);

						//開始時間
						String kxc008 = String.valueOf(Long.parseLong(mp.get("KXC008").toString()));
						String kxc008formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc008.substring(0, kxc008.length() - 6)) ;
						String kxc008formatT = FormatUtil.getTimeFormat(kxc008.substring(kxc008.length() - 6));
						mp.put("KXC008D", kxc008formatD);
						mp.put("KXC008T", kxc008formatT);

						//結束時間
						String kxc009 = String.valueOf(Long.parseLong(mp.get("KXC009").toString()));
						String kxc009formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc009.substring(0, kxc009.length() - 6)) ;
						String kxc009formatT = FormatUtil.getTimeFormat(kxc009.substring(kxc009.length() - 6));
						mp.put("KXC009D", kxc009formatD);
						mp.put("KXC009T", kxc009formatT);

						//訊息
						String kxc40 = mp.get("KXC40") != null ? mp.get("KXC40").toString():"";
						mp.remove("KXC40");
						mp.put("KXC40", kxc40);
						
						if(!kxc40.equals("查無資料")){
					
							//產壽業別
							String kxc03desc = CodeUtil.getCodeDesc(servlet, request, "LIA_CPTYPE", mp.get("KXC03").toString());
							mp.put("KXC03DESC", kxc03desc);
	
							//公司代號
							String kxc04desc = "";
							if(mp.get("KXC03").toString().equals("L") || mp.get("KXC03").toString().equals("R")){
								kxc04desc = CodeUtil.getCodeDesc(servlet, request, "LICOM", mp.get("KXC04").toString());
							}else{
								kxc04desc = CodeUtil.getCodeDesc(servlet, request, "NCOM", mp.get("KXC04").toString());
							}
							mp.put("KXC04DESC", kxc04desc);
							
							//保單分類
							String kxc10desc = CodeUtil.getCodeDesc(servlet, request, "LIA_CLTYPE", mp.get("KXC10") != null ? mp.get("KXC10").toString() : "");
							mp.put("KXC10DESC", kxc10desc);
	
							//保單狀況
							String kxc33desc = CodeUtil.getCodeDesc(servlet, request, "LIA_COTYPE", mp.get("KXC33") != null ? mp.get("KXC33").toString() : "");
							mp.put("KXC33DESC", kxc33desc);
	
							//險種分類
							String kxc11desc = CodeUtil.getCodeDesc(servlet, request, "LIA_INKIND", mp.get("KXC11") != null ? mp.get("KXC11").toString() : "");
							mp.put("KXC11DESC", kxc11desc);
	
							//險種
							String kxc12desc = CodeUtil.getCodeDesc(servlet, request, "LIA_INITEM", mp.get("KXC12") != null ? mp.get("KXC12").toString() : "");
							mp.put("KXC12DESC", kxc12desc);
							
							//保費繳別
							String kxc32desc = CodeUtil.getCodeDesc(servlet, request, "LIA_BTYPE", mp.get("KXC32") != null ? mp.get("KXC32").toString() : "");
							mp.put("KXC32DESC", kxc32desc);
														
							//出生年月日
							String kxc07 = String.valueOf(Long.parseLong(mp.get("KXC07") != null ? mp.get("KXC07").toString() : "0"));
							String kxc07formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc07) ;
							mp.put("KXC07D", kxc07formatD);
	
							//保單狀況生效日期
							String kxc34 = String.valueOf(Long.parseLong(mp.get("KXC34") != null ? mp.get("KXC34").toString() : "0"));
							String kxc34formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc34) ;
							mp.put("KXC34D", kxc34formatD);
	
							//契約生效日期
							String kxc29 = String.valueOf(Long.parseLong(mp.get("KXC29") != null ? mp.get("KXC29").toString() : "0"));
							String kxc29formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc29) ;
							mp.put("KXC29D", kxc29formatD);
	
							//契約滿期日期
							String kxc30 = String.valueOf(Long.parseLong(mp.get("KXC30") != null ? mp.get("KXC30").toString() : "0"));
							String kxc30formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc30) ;
							mp.put("KXC30D", kxc30formatD);
							
							//給付項目(身故)保額
							String kxc13d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXC13").toString()), 0);
							mp.put("KXC13D", kxc13d);
							
							//給付項目(全殘或最高級殘)保額
							String kxc14d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("KXC14").toString()), 0);
							mp.put("KXC14D", kxc14d);
						
						}
						
						System.out.println(i);
					}
				}

			}else{
				
				if(ret != null && !ret.isEmpty()){				
					for (int i = 0; i < ret.size(); i++) {
						Map mp = (Map) ret.get(i);
						mp.put("rowid", i+1);

						//開始時間
						String kxc008 = String.valueOf(Long.parseLong(mp.get("KXC008").toString()));
						String kxc008formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc008.substring(0, kxc008.length() - 6)) ;
						String kxc008formatT = FormatUtil.getTimeFormat(kxc008.substring(kxc008.length() - 6));
						mp.put("KXC008D", kxc008formatD);
						mp.put("KXC008T", kxc008formatT);

						//結束時間
						String kxc009 = String.valueOf(Long.parseLong(mp.get("KXC009").toString()));
						String kxc009formatD = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, kxc009.substring(0, kxc009.length() - 6)) ;
						String kxc009formatT = FormatUtil.getTimeFormat(kxc009.substring(kxc009.length() - 6));
						mp.put("KXC009D", kxc009formatD);
						mp.put("KXC009T", kxc009formatT);

					}
				}
			}
						
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(conn);
		}
		
		return ret;	
	}
	
	/**
	 * 查詢 FGFLIB/EPB501PF 傷健險收件通報作業主檔
	 * @param PF21 交易序號
	 * @return
	 */
	private Map getEPB501PFbyPF21(HttpServletRequest request , String PF21)
	{		
		HashMap ret = null;
				
		String sql = "SELECT * FROM EPB501PF WHERE PF21=? ";
		
		Connection conn = null;
		try
		{
			conn = AS400Connection.getConnection();
			QueryRunner runner = new QueryRunner();
			ret = (HashMap) runner.query(conn, sql, PF21, new TrimedMapHandler());
			
			if(ret != null && !ret.isEmpty()){									
				//要被保險人關係
				String pf18desc = CodeUtil.getCodeDesc(servlet, request, "LIA_RTYPE", ret.get("PF18").toString());
				ret.put("PF18DESC", pf18desc);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(conn);
		}
		
		return ret;
	}
	
	/**
	 * 查詢 FGFLIB/EPB501PF 傷健險收件通報作業主檔
	 * @param PF01 通報序號
	 * @return
	 */
	private Map getEPB501PF(HttpServletRequest request , String PF01)
	{		
		HashMap ret = null;

		String sql = "SELECT * FROM EPB501PF WHERE PF01=? ";
		
		Connection conn = null;
		try
		{
			conn = AS400Connection.getConnection();
			QueryRunner runner = new QueryRunner();
			ret = (HashMap) runner.query(conn, sql, PF01, new TrimedMapHandler());
			
			if(ret != null && !ret.isEmpty()){									
				//要被保險人關係
				String pf18desc = CodeUtil.getCodeDesc(servlet, request, "LIA_RTYPE", ret.get("PF18").toString());
				ret.put("PF18DESC", pf18desc);
			}

		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(conn);
		}
		
		return ret;
	}
	
	/**
	 * 查詢 FGFLIB/EPB500PF 傷健險承保通報作業主檔
	 * @param PF07 保單號碼
	 * @return
	 */
	private List getEPB500PF(HttpServletRequest request , String PF07)
	{		
		List ret = null;

		String sql = "SELECT * FROM EPB500PF WHERE PF07=? ";
		
		String[] args = new String[1];
		args[0] = PF07;

		Connection conn = null;
		try
		{
			conn = AS400Connection.getConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(conn, sql, args, new TrimedMapListHandler());		
			
			if(ret != null && !ret.isEmpty()){				
				for (int i = 0; i < ret.size(); i++) {
					Map mp = (Map) ret.get(i);
					mp.put("rowid", i+1);

					//產壽業別
					String pf01desc = CodeUtil.getCodeDesc(servlet, request, "LIA_CPTYPE", mp.get("PF01").toString());
					mp.put("PF01DESC", pf01desc);

					//公司代號
					String pf02desc = "";
					if(mp.get("PF02").toString().equals("L") || mp.get("PF02").toString().equals("R")){
						pf02desc = CodeUtil.getCodeDesc(servlet, request, "LICOM", mp.get("PF02").toString());
					}else{
						pf02desc = CodeUtil.getCodeDesc(servlet, request, "NCOM", mp.get("PF02").toString());
					}
					mp.put("PF02DESC", pf02desc);
					
					//保單分類
					String pf08desc = CodeUtil.getCodeDesc(servlet, request, "LIA_CLTYPE", mp.get("PF08").toString());
					mp.put("PF08DESC", pf08desc);

					//險種分類
					String pf09desc = CodeUtil.getCodeDesc(servlet, request, "LIA_INKIND", mp.get("PF09").toString());
					mp.put("PF09DESC", pf09desc);

					//險種
					String pf10desc = CodeUtil.getCodeDesc(servlet, request, "LIA_INITEM", mp.get("PF10").toString());
					mp.put("PF10DESC", pf10desc);
					
					//保單狀況
					String pf31desc = CodeUtil.getCodeDesc(servlet, request, "LIA_COTYPE", mp.get("PF31").toString());
					mp.put("PF31DESC", pf31desc);

					//保費繳別
					String pf30desc = CodeUtil.getCodeDesc(servlet, request, "LIA_BTYPE", mp.get("PF30").toString());
					mp.put("PF3ODESC", pf30desc);
					
					//要被保險人關係
					String pf36desc = CodeUtil.getCodeDesc(servlet, request, "LIA_RTYPE", mp.get("PF36").toString());
					mp.put("PF36DESC", pf36desc);

					//身故保額
					String pf11d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("PF11").toString()), 0);
					mp.put("PF11D", pf11d);
					
					//全殘或最高級殘保額
					String pf12d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("PF12").toString()), 0);
					mp.put("PF12D", pf12d);

					//醫療限額保額
					String pf16d = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("PF16").toString()), 0);
					mp.put("PF16D", pf16d);

				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(conn);
		}
		
		return ret;
	}	

	private void updateCallout(HttpServletRequest request , AD1M050f form1 , String urid) throws UserException
	{
		QueryRunner run = new QueryRunner();
		// 更改資料 機車
		String updatekyckla = "UPDATE KYCKLA SET T15C4=?,T15C5=?,T15C6=?,T15C7=?,T15C8=?"
				+ " WHERE T1501=?";
		String args[] = new String[6];
		args[0] = request.getParameter("T15C4");
		args[1] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		args[2] = DateUtil.getSysTime(false);
		args[3] = request.getParameter("T15C7");
		args[4] = request.getParameter("T15C8");
		args[5] = request.getParameter("KYC_T1501");
	
		tx_controller.begin(0);
		try
		{
			int c = run.update(tx_controller.getConnection(0), updatekyckla, args);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new UserException("error");
		}

		//寫入KYCLLOG記錄檔處理
		KycLogger klg = new KycLogger();
		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保險明細資料頁", "B", urid, "", "", "", request.getParameter("KYC_T1501"), "", "", "", "", "", "U", "", "電訪記錄修改", updatekyckla, "", "", "", "");
	}
	
	/**
	 * @return
	 * @throws AsiException
	 */
	private SelectDBO getPt15Data(HttpServletRequest request) throws AsiException
	{
		String t1501 = request.getParameter("KYC_T1501");
		String t1502 = request.getParameter("KYC_T1502");
		String t1503 = request.getParameter("KYC_T1503");
		String t1542 = request.getParameter("KYC_T1542");
		String isOrder = request.getParameter("isOrder");

        SelectDBO dbo1;
		if (isOrder.equals("0"))
		{
			dbo1 = (SelectDBO) tx_controller.getDBO("kyc.KYCKLAs02", 0);
		}
		else
		{
			dbo1 = (SelectDBO) tx_controller.getDBO("kyc.PT15PFs03", 0);
		}

		StringBuffer buffer = new StringBuffer();
		buffer.append("A.T1501='").append(t1501).append("'");
		buffer.append(" AND A.T1502='").append(t1502).append("'");
		buffer.append(" AND A.T1503='").append(t1503).append("'");
		if (t1542 == null || t1542.equals(""))
		{
			// T1542須加rtrim,因現trigger會updtae此欄位為空白
			buffer.append(" AND RTRIM(A.T1542) IS NULL");
		}
		else
		{
			buffer.append(" AND A.T1542='").append(t1542).append("'");
		}
		dbo1.addParameter("WHERE", buffer.toString());
		dbo1.execute();
		// System.out.println(dbo1.getAssembledSQL());

		//將電訪顯示的資料改為抓KYCKLA
		String sql="select T1501,T15C4,T15C5,T15C6,T15C7,T15C8 from KYCKLA where T1501=? AND T1502=? AND T1503=?";
		String[] param={t1501,t1502,t1503};
		List<Map> m= null;
		try{
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			
			m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,param,new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		dbo1.addRecordData("T15C4", m.get(0).get("T15C4") != null ? m.get(0).get("T15C4").toString() : "");
		dbo1.addRecordData("T15C5", m.get(0).get("T15C5") != null ? m.get(0).get("T15C5").toString() : "");
		dbo1.addRecordData("T15C6", m.get(0).get("T15C6") != null ? m.get(0).get("T15C6").toString() : "");
		dbo1.addRecordData("T15C7", m.get(0).get("T15C7") != null ? m.get(0).get("T15C7").toString() : "");
		dbo1.addRecordData("T15C8", m.get(0).get("T15C8") != null ? m.get(0).get("T15C8").toString() : "");
		
		int rows = 1;
		for (int i = 1; i <= rows; i++)
		{
			String T1502 = dbo1.getRecordData(i, "T1502");
			String T1503 = dbo1.getRecordData(i, "T1503");
			String T1508 = dbo1.getRecordData(i, "T1508");
			if (T1508.length() == 5)
				T1508 = "0" + T1508;
			String T1509 = dbo1.getRecordData(i, "T1509");
			String T1510 = dbo1.getRecordData(i, "T1510");
			String T1574 = dbo1.getRecordData(i, "T1574");
			String T1575 = dbo1.getRecordData(i, "T1575");
			String T1548 = dbo1.getRecordData(i, "T1548");
			String Ta1502 = dbo1.getRecordData(i, "TA1502");
			String T1537 = dbo1.getRecordData(i, "T1537");
			String T1537D = "";
			
			if(t1502.equals("TA")){
				if(T1537.equals("1"))
					T1537D = "國內基本型";
			    else if(T1537.equals("2"))
			    	T1537D = "海外基本型";
			    else if(T1537.equals("3"))
			    	T1537D = "海外加值型";
			    else if(T1537.equals("4"))
			    	T1537D = "海外申根型";
			}else if(t1502.equals("SE")){
				if(T1537.equals("1"))
					T1537D = "第 1 類";
			    else if(T1537.equals("2"))
			    	T1537D = "第 2 類";
			    else if(T1537.equals("3"))
			    	T1537D = "第 1 類+第 2 類";

			}
			
			
			dbo1.addRecordData(i, "T1537D", T1537D);

			//要保人收入來源
			String[] ta1506 = (String[]) (dbo1.getRecordData(i, "TA1506") != null ? dbo1.getRecordData(i, "TA1506").split(",") : "");
			String ta1506o = dbo1.getRecordData(i, "TA1506O") != null ? dbo1.getRecordData(i, "TA1506O") : "";
			String ta1506desc = "";
			for (int j = 0; j < ta1506.length; j++) {
				ta1506desc += CodeUtil.getCodeDesc(getServlet(), request, "TA_INCOME", ta1506[j]) + " ";
				if(ta1506desc.indexOf("其他") != -1)
					ta1506desc += ":" + ta1506o;
			}

			//購買保險目的
			String[] ta1513 = (String[]) (dbo1.getRecordData(i, "TA1513") != null ? dbo1.getRecordData(i, "TA1513").split(",") : "");
			String ta1513o = dbo1.getRecordData(i, "TA1513O") != null ? dbo1.getRecordData(i, "TA1513O") : "";
			String ta1513desc = "";
			for (int j = 0; j < ta1513.length; j++) {
				ta1513desc += CodeUtil.getCodeDesc(getServlet(), request, "TA_PURPOSE", ta1513[j]) + " ";
				if(ta1513desc.indexOf("其他") != -1)
					ta1513desc += ":" + ta1513o;
			}

			//家中主要經濟者為要保人關係
			String[] ta1515 = (String[]) (dbo1.getRecordData(i, "TA1515") != null ? dbo1.getRecordData(i, "TA1515").split(",") : "");
			String ta1515o = dbo1.getRecordData(i, "TA1515O") != null ? dbo1.getRecordData(i, "TA1515O") : "";
			String ta1515desc = "";
			for (int j = 0; j < ta1515.length; j++) {
				ta1515desc += CodeUtil.getCodeDesc(getServlet(), request, "TA_FUNDING", ta1515[j]) + " ";
				if(ta1515desc.indexOf("其他") != -1)
					ta1515desc += ":" + ta1515o;
			}

			//被保險人日常交通工具
			String[] ta1510 = (String[]) (dbo1.getRecordData(i, "TA1510") != null ? dbo1.getRecordData(i, "TA1510").split(",") : "");
			String ta1510o = dbo1.getRecordData(i, "TA1510O") != null ? dbo1.getRecordData(i, "TA1510O") : "";
			String ta1510desc = "";
			for (int j = 0; j < ta1510.length; j++) {
				ta1510desc += CodeUtil.getCodeDesc(getServlet(), request, "TA_TRAFFIC", ta1510[j]) + " ";
				if(ta1510desc.indexOf("其他") != -1)
					ta1510desc += ":" + ta1510o;
			}

			//被保險人收入來源
			String[] ta1509 = (String[]) (dbo1.getRecordData(i, "TA1509") != null ? dbo1.getRecordData(i, "TA1509").split(",") : "");
			String ta1509o = dbo1.getRecordData(i, "TA1509O") != null ? dbo1.getRecordData(i, "TA1509O") : "";
			String ta1509desc = "";
			for (int j = 0; j < ta1509.length; j++) {
				ta1509desc += CodeUtil.getCodeDesc(getServlet(), request, "TA_INCOME", ta1509[j]) + " ";
				if(ta1509desc.indexOf("其他") != -1)
					ta1509desc += ":" + ta1509o;
			}

            if (T1503.equals("F")) 
            {
			 //取建築等級說明
	           DBO dbo6 = tx_controller.getDBO("kyc.PT31PFs02",0);
	           dbo6.addParameter("T3101",dbo1.getRecordData(i, "T1616"));
	           dbo6.execute();
			   dbo1.addRecordData(i, "T1616D", dbo6.getRecordData("T3102"));
            }
            
	        dbo1.addRecordData(i, "T1502D", CodeUtil.getCodeDesc(getServlet(), request, "GOODSID", T1502));
			dbo1.addRecordData(i, "T1503D", CodeUtil.getCodeDesc(getServlet(), request, "KIND", T1503));
			dbo1.addRecordData(i, "T1508D", T1508);
			dbo1.addRecordData(i, "T1509D", CodeUtil.getCodeDesc(getServlet(), request, "SEX2", T1509));
			dbo1.addRecordData(i, "T1510D", CodeUtil.getCodeDesc(getServlet(), request, "MARRIAGE", T1510));
			dbo1.addRecordData(i, "T1574D", CodeUtil.getCodeDesc(getServlet(), request, "YN", T1574));
			//dbo1.addRecordData(i, "T1575D", CodeUtil.getCodeDesc(getServlet(), request, "YN", T1575));
			dbo1.addRecordData(i, "T1548D", CodeUtil.getCodeDesc(getServlet(), request, "RELATION", T1548));
			dbo1.addRecordData(i, "TA1502D", CodeUtil.getCodeDesc(getServlet(), request, "TRAVELTRAF", Ta1502));
			dbo1.addRecordData(i, "TA1506D", ta1506desc);
			dbo1.addRecordData(i, "TA1509D", ta1509desc);
			dbo1.addRecordData(i, "TA1510D", ta1510desc);
			dbo1.addRecordData(i, "TA1513D", ta1513desc);
			dbo1.addRecordData(i, "TA1515D", ta1515desc);
			
			//業務來源
			String t1519 = dbo1.getRecordData(i, "T1519");
			String channel = getT4003(t1519);//查通路代碼
			dbo1.addRecordData(i, "ENTRY", channel.equals("6666") ? "2":"1");
			
			//使用者IP顯示
			dbo1.addRecordData(i, "T15E0D", dbo1.getRecordData("T15E0") != null && !dbo1.getRecordData("T15E0").isEmpty() ? dbo1.getRecordData("T15E0").substring(0, 8) + "******" : "");
			
			//電子保單選項

			if(T1575.equals("Y"))
				dbo1.addRecordData(i, "T1575D", "電子");
			else
				dbo1.addRecordData(i, "T1575D", "紙本");

			
		}
		return dbo1;
	}

	/**
	 * 取得通路代碼
	 * @param con
	 * @param t4002
	 * @return
	 * @throws AsiException
	 */
	private String getT4003(String t4002) throws AsiException
	{
		
		String t3905 = null;
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4002 = ? ";

		QueryRunner run = new QueryRunner();
		Map m = null;
		Connection con = null;
		try
		{
			con = AS400Connection.getConnection();
			m = (Map) run.query(con , t4003sql, t4002, new MapHandler());
			t3905 = m.get("T4003").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		} finally{
			AS400Connection.closeConnection(con);
		}
		
		if(t3905==null)
			throw new AsiException("無法取得通路類別!");
		
		return t3905;	
	}

	/**
	 * 更新資料
	 * @param request
	 * @param t1501
	 * @param t1502
	 * @param isOrder
	 * @throws AsiException
	 */
	private void updateData(HttpServletRequest request , AD1M050f form1 , String urid) throws AsiException
	{
		String c101 = request.getParameter("T1507");
		String c102 = request.getParameter("T1506");
		if (request.getParameter("KYC_T1502").equals("TA"))// 旅平
		{
			c101 = request.getParameter("T1547");// 要保人ID
			c102 = request.getParameter("T1546");// 要保人姓名
		}

		updateIC01PF(c101, c102, request);
		updatePT15PF(request);
		updateSECAJ(c101, c102,request );

		request.setAttribute("isUpdate", "Yes");
		
		//寫入KYCLLOG記錄檔處理
		KycLogger klg = new KycLogger();
		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保險明細資料頁", "B", urid, "", "", "", request.getParameter("KYC_T1501"), "", "", "", "", "", "U", "", "交易資料修改", "修改交易資料相關檔案(含交易主通檔、明細檔、客戶資料檔、帳號檔)", "", "", "", "");

	}

	/**
	 * 寄發投保完成EMAIL
	 * @param request
	 * @param t1501
	 * @param t1502
	 * @throws AsiException
	 */
	private void sendMail(HttpServletRequest request) throws AsiException
	{
		String t1501 = request.getParameter("KYC_T1501");
		String t1502 = request.getParameter("KYC_T1502");

		IConfirmMail mail = null;
		String htmlpath = null;
		String subject = null;
		// 旅平險
		if (t1502.equals("TA"))
		{
			mail = new TravelConfirmMail();
			htmlpath = "/mail/travelInsurances_" + tx_controller.getUserLocale() + ".html";
			subject = MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT101");
		}
		// 傷害險
		else if (t1502.equals("PA600") || t1502.equals("PA1000"))
		{
			mail = new PaConfirmMail();
			htmlpath = "/mail/personInsurances_" + tx_controller.getUserLocale() + ".html";
			subject = MessageUtil.getMessage(this.getServlet(), request, "WB1M030.TXT76");
		}
		// 續保
		else if (t1502.equals("FIRSTB") || t1502.equals("FIRSTC"))
		{
			mail = new PaConfirmMail();
			htmlpath = "/mail/personalContinue_" + tx_controller.getUserLocale() + ".html";
			subject = MessageUtil.getMessage(this.getServlet(), request, "WB1M030.TXT76");
		}

		mail.setMailHtmlPath(htmlpath);
		mail.setSubject(subject);
		DBO dbo = tx_controller.getDBO("kyc.KYCKLAs03", 0);
		dbo.addParameter("T1501", t1501);
		dbo.executeSelect();
		mail.setKyckla(dbo);
		mail.sendConfirmMail(this.getServlet(), request, tx_controller);
		request.setAttribute("isSend", "Yes"); //寄發EMAIL畫面參數
	}

	/**
	 * 抓取車籍資料
	 * 
	 * @param t1503
	 * @param isOrder
	 * @param dbo1
	 * @return
	 * @throws AsiException
	 */
	private DBO getInsObjectData(HttpServletRequest request, SelectDBO dbo1 , String t1503) throws AsiException
	{

		String isOrder = request.getParameter("isOrder");
		DBO dbo2;
		if (isOrder.equals("0"))
		{
			dbo2 = tx_controller.getDBO("kyc.KYCKLBt", 0);
		}
		else
		{
			dbo2 = tx_controller.getDBO("kyc.PT16PFt", 0);
		}
		dbo2.addParameter("T1601", dbo1.getRecordData("T1501"));
		dbo2.addParameter("T1602", dbo1.getRecordData("T1502"));
		dbo2.addParameter("T1603", t1503);
		dbo2.addParameter("T1604", "1");
		dbo2.executeSelect();
		
		if (t1503.equals("A") || t1503.equals("C1") || t1503.equals("C2"))
		{
			if (dbo2.getRecordCount() > 0)
			{
				String brand = dbo2.getRecordData("T1605").substring(0, 2);
				String kind = dbo2.getRecordData("T1605").substring(2, 4);
				dbo2.addRecordData("CT01", getCarType(dbo2.getRecordData("T1608")));
				dbo2.addRecordData("BN01", getCarBrand(brand));
				dbo2.addRecordData("PC01", getCarKind(brand, kind) + " | " + dbo2.getRecordData("T1605"));
			}
		}
		
		Map pt17 = isIns_A(dbo1.getRecordData("T1501"), isOrder);
		
		if(pt17 != null && pt17.size()>0)
			dbo2.addRecordData("T1709", pt17.get("T1709").toString());
		else
			dbo2.addRecordData("T1709", "0");
				
		return dbo2;
	}

	/**
	 * 查詢交易資料是否有含車體險種
	 * @param t1701
	 * @param isorder
	 * @return
	 */
	private Map isIns_A(String t1701 , String isorder)
	   {
	  	
	  	StringBuffer sb = new StringBuffer();
	  	sb.append("SELECT * FROM ");
	  	if(isorder.equals("0"))
	  		sb.append("KYCKLC ");
	  	else
	  		sb.append("PT17PF ");
	  	sb.append("RIGHT JOIN KYCCA ON CA01=T1705 AND CA13='A0' ");//串KYCCA, 找險種類別為A0→車體險
	  	sb.append("WHERE T1701=? ");

		String[] args = new String[1];
		args[0] = t1701;

	  	Map ret = null;
	  	tx_controller.begin(0);
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = (Map) runner.query(tx_controller.getConnection(0), sb.toString(), args, new TrimedMapHandler());
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	
	private String getCarType(String ct00) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFCTs04", 0);
		dbo.addParameter("WHERE", " where ct00='" + ct00 + "'");
		dbo.executeSelect();
		return dbo.getRecordData("CT01").trim();
	}

	private String getCarBrand(String bn00) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFBNs03", 0);
		dbo.addParameter("BN00", bn00);
		dbo.executeSelect();
		return dbo.getRecordData("BN01").trim();
	}

	private String getCarKind(String brand, String kind) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFBOs01", 0);
		dbo.addParameter("BO001", brand);
		dbo.addParameter("BO002", kind);
		dbo.executeSelect();
		if (dbo.getRecordData("BO02") == null){ return ""; }
		return dbo.getRecordData("BO02").trim();
	}

	/**
	 * 更新 客戶名稱 最新通訊地址 E-MAIL 行動電話 住家聯絡電話 公司聯絡電話 所在區域 通訊郵遞區號
	 * @throws AsiException
	 */
	private void updateIC01PF(String c101, String c102, HttpServletRequest request) throws AsiException
	{
		String c108 = request.getParameter("T1512");
		String c113 = request.getParameter("T1516");
		String ca101 = request.getParameter("T1515");
		String ca102 = request.getParameter("T1513");
		String ca103 = request.getParameter("T1514");
		String ca105 = request.getParameter("t3004");
		String ca106 = request.getParameter("T1511");
		String isOrder = request.getParameter("isOrder");
		String c104 = request.getParameter("T1509");
		
		if (isOrder.equals("0")){ return; }

		String uid = tx_controller.getUserId();
		String sysDate = tx_controller.getSystemDate();

		tx_controller.begin(0);
		DBO dbo = tx_controller.getDBO("kyc.IC01PFu13", 0);
		dbo.addParameter("C101", c101);
		dbo.addParameter("C102", c102);
		dbo.addParameter("C104", c104);
		dbo.addParameter("C108", c108);
		dbo.addParameter("C113", c113);
		dbo.addParameter("CA101", ca101);
		dbo.addParameter("CA102", ca102);
		dbo.addParameter("CA103", ca103);
		dbo.addParameter("CA105", ca105);
		dbo.addParameter("CA106", ca106);
		dbo.addParameter("C198", sysDate);
		dbo.addParameter("C199", uid);
		// System.out.println(dbo.getAssembledSQL());
		dbo.executeUpdate();
		dbo.destroy();
	}

	/**
	 * 更新被保險人姓名，郵遞區號 通訊地址 聯絡電話H 聯絡電話O 行動電話 E-MAIL
	 * @throws AsiException
	 */
	private void updatePT15PF(HttpServletRequest request) throws AsiException
	{

		String t1501 = request.getParameter("KYC_T1501");
		String t1506 = request.getParameter("T1506");
		String t1511 = request.getParameter("T1511");
		String t1512 = request.getParameter("T1512");
		String t1513 = request.getParameter("T1513");
		String t1514 = request.getParameter("T1514");
		String t1515 = request.getParameter("T1515");
		String t1516 = request.getParameter("T1516");
		String t1546 = request.getParameter("T1546");
		String t1548 = request.getParameter("T1548");
		String t1550 = request.getParameter("T1550");
		String t1581 = request.getParameter("T1581");
		String isOrder = request.getParameter("isOrder");

		String t1507 = request.getParameter("T1507");
		String t1508 = request.getParameter("T1508");
		String t1509 = request.getParameter("T1509");
		String t1520 = request.getParameter("T1520");
		
		String t1562 = request.getParameter("T1562");
		String t1563 = request.getParameter("T1563");
		String t1564 = request.getParameter("T1564");
		
		String uid = tx_controller.getUserId();
		String sysDate = tx_controller.getSystemDate();

		tx_controller.begin(0);
		DBO dbo = null;
		if (isOrder.equals("0"))
		{
			dbo = (DBO) tx_controller.getDBO("kyc.KYCKLAu06", 0);
			dbo.addParameter("T1581", t1581);
		}
		else
		{
			dbo = (DBO) tx_controller.getDBO("kyc.PT15PFu06", 0);
		}
		dbo.addParameter("T1501", t1501);
		dbo.addParameter("T1506", t1506);

		dbo.addParameter("T1507", t1507);
		dbo.addParameter("t1508", t1508);
		dbo.addParameter("t1509", t1509);
		dbo.addParameter("t1520", t1520);

		dbo.addParameter("T1511", t1511);
		dbo.addParameter("T1512", t1512);
		dbo.addParameter("T1513", t1513);
		dbo.addParameter("T1514", t1514);
		dbo.addParameter("T1515", t1515);
		dbo.addParameter("T1516", t1516);
		dbo.addParameter("T1546", t1546);
		dbo.addParameter("T1548", t1548);
		dbo.addParameter("T1550", t1550);
		dbo.addParameter("T1562", t1562);//抵押權人總行
		dbo.addParameter("T1563", t1563);//抵押權人分行
		dbo.addParameter("T1564", t1564);//抵押權人名稱
		dbo.addParameter("T1598", sysDate);
		dbo.addParameter("T1599", uid);
//		System.out.println(dbo.getAssembledSQL());
		dbo.executeUpdate();
		dbo.destroy();
		
		if(request.getParameter("T1610")!=null)
		{
			if(request.getParameter("type").equals("M")||!t1509.equals("3"))
			{
				DBO dbo2;
				if (isOrder.equals("0"))
				{
					dbo2 = tx_controller.getDBO("kyc.KYCKLBu01", 0);
				}
				else
				{
					dbo2 = (DBO) tx_controller.getDBO("kyc.PT16PFu01", 0);
				}

				String bn00 = request.getParameter("BN00");
				String pc01 = request.getParameter("PC01");
				if (pc01.equals("無"))
					pc01 = "";
				dbo2.addParameter("T1605", StringUtils.rightPad(bn00 + pc01, 8, "0"));
				dbo2.addParameter("T1610", request.getParameter("T1610"));
				dbo2.addParameter("T1609", request.getParameter("T1609"));
				dbo2.addParameter("T1606", request.getParameter("T1606"));
				dbo2.addParameter("T1698", sysDate);
				dbo2.addParameter("T1699", uid);
				dbo2.addParameter("T1601", t1501);
				dbo2.executeUpdate();
				dbo2.destroy();
			}
		}
	}

	/**
	 * 更新姓名，email
	 * @throws AsiException
	 */
	private void updateSECAJ(String userid, String fistname, HttpServletRequest request ) throws AsiException
	{
		String email = request.getParameter("T1516");
		String isOrder = request.getParameter("isOrder");
		if (isOrder.equals("0")){ return; }
		DBO dbo = tx_controller.getDBO("kyc.SECAJu01", 0);
		dbo.addParameter("USERID", userid);
		dbo.addParameter("FIRSTNAME", fistname);
		dbo.addParameter("EMAIL", email);
		dbo.execute();
		dbo.destroy();
	}
}
