/*
 * $Header: D:/Repositories/KYC2/JavaSource/com/com/asi/kyc/common/utils/HitrustUtil.java,v 1.3 2006/11/02 08:25:10 cvsuser Exp $
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. Taipei, Taiwan. All rights
 * reserved.
 * 
 * This software is the confidential and proprietary information of Asgard
 * System, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Asgard.
 * 
 */
package com.asi.kyc.common.utils;

import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.struts.util.RequestUtils;

import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.kyc.common.SystemParam;
import com.nccc.evpos.HppApiClient;
import com.nccc.evpos.ApiClient;

public class NCCCUtil {

	private String html_3d;
	
	public static void callNCCC(String id , String orderNumber, double orderAccount,
			String orderDesc, String returnPath, HttpServlet servlet,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException {

		String MerchantID = SystemParam.getParam("NCCC_MERCHANTID"); // NCCC聯信商店代號
		String TerminalID = SystemParam.getParam("NCCC_TERMINALID"); // NCCC聯信端末機代號
		String NCCCURL = SystemParam.getParam("NCCC_URL"); // NCCC聯信取授權網址
		String root = null;

		// 取得目前使用者進入用的完整Http路徑
		try {
			root = RequestUtils.serverURL(request).toString();
			root += request.getContextPath();
			root = response.encodeURL(root);
		} catch (MalformedURLException e) {
			throw new UserException("errors.1000", e);
		}

		String updatePath = root + "/TransactionResults.do"; // 交易結果網址
	
		int rtnCode;
		String responseCode="";
		String responsemsg = "";
		String key ="";
		String url ="";
		
		// 產生API 物件
		HppApiClient apiClient=new HppApiClient();
		// 設定交易資料
		try 
		{
			request.setCharacterEncoding("Big5");
			apiClient.setMERCHANTID(MerchantID);
			apiClient.setTERMINALID(TerminalID);
			apiClient.setORDERID(orderNumber);
			apiClient.setIDNUMBER(id);
			apiClient.setTRANSMODE("0");
			apiClient.setINSTALLMENT("0");
			apiClient.setTRANSAMT(String.valueOf((int) (orderAccount)));
			apiClient.setNotifyURL(updatePath);
			apiClient.setURL(NCCCURL, "/merchant/HPPRequest");
			apiClient.setDebug(true);
			apiClient.setTemplate("BOTH");
			apiClient.setPrivateData(returnPath);//自訂參數用
			apiClient.setProvider("sun.security.provider.Sun");
//			apiClient.setCSS_URL("https://www.firstins.com.tw/kyc/_info/creditform.css");
			
			rtnCode = apiClient.postTransaction();
			responseCode = apiClient.getRESPONSECODE();
			responsemsg = apiClient.getRESPONSEMSG();

		} 
		catch(Exception ignore){}
		
		if ("00".equals(responseCode))
		{
			try {
				//取得交易金鑰apiClient.getKEY())再使用3.2 節方式呼叫hpp 程式
				key = URLEncoder.encode(apiClient.getKEY());
				url = "https://"+NCCCURL + "/merchant/HPPRequest?KEY=" + key;

				response.sendRedirect(url);
			} catch (Exception ex){}
		} else {
			//HppApi 執行錯誤
			throw new UserException("errors.1000", responseCode + responsemsg);
		}

	}
	
	/**
	 * 聯信 - 取消授權
	 * @param request
	 * @param orderNumber
	 * @return
	 */
	public static boolean cancelAuth(HttpServletRequest request , String orderNumber)
	{
		boolean isOk = false;
		
		String MerchantID = SystemParam.getParam("NCCC_MERCHANTID"); // NCCC聯信商店代號
		String TerminalID = SystemParam.getParam("NCCC_TERMINALID"); // NCCC聯信端末機代號
		String NCCCURL = SystemParam.getParam("NCCC_URL"); // NCCC聯信取授權網址

		int rtnCode ;
  		String transCode = "";
  		String responseCode = "";

     	// 產生API 物件
  		HppApiClient apiClient=new HppApiClient();
  		// 設定交易資料
  		try 
  		{
  			apiClient.setMERCHANTID(MerchantID);
  			apiClient.setTERMINALID(TerminalID);
  			apiClient.setORDERID(orderNumber);
  			apiClient.setURL(NCCCURL, "/merchant/HPPRequest");
  			apiClient.setProvider("sun.security.provider.Sun");
  			rtnCode = apiClient.postCancel();
  		} 
  		catch(Exception ignore){}

  		transCode = apiClient.getTRANSCODE();
  		responseCode = apiClient.getRESPONSECODE();
  		
  		if(transCode.equals("01") && responseCode.equals("00"))
  			isOk = true;
			
		return isOk;
	}
	
	public Map callNCCCAPI_AuthNon3D(HttpServlet servlet,HttpServletRequest request, HttpServletResponse response ,
			String id , String orderNumber, int orderPremium,String cardno,String extenno, String expiredate )
			throws AsiException {

		String MerchantID = SystemParam.getParam("NCCCAPI_STROEID"); // NCCC_API聯信商店代號
		String TerminalID = SystemParam.getParam("NCCCAPI_TERID"); // NCCC_API聯信端末機代號
		String NCCCURL = SystemParam.getParam("NCCC_URL"); // NCCC聯信取授權網址
		String root = null;

		// 取得目前使用者進入用的完整Http路徑
		try {
			root = RequestUtils.serverURL(request).toString();
			root += request.getContextPath();
			root = response.encodeURL(root);
		} catch (MalformedURLException e) {
			throw new UserException("errors.1000", e);
		}
				
		int rtnCode = 0;
		
		// 產生API 物件
		ApiClient apiClient=new ApiClient();
		
		Map ret = null;
				
		// 設定交易資料
		try 
		{
			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);
		
			//設定交易資料
			request.setCharacterEncoding("Big5");
			apiClient.setMERCHANTID(MerchantID);//特約商店代號
			apiClient.setTERMINALID(TerminalID);//端末機代號
			apiClient.setORDERID(orderNumber);//交易序號
			apiClient.setPAN(cardno);//信用卡號
			apiClient.setEXTENNO(extenno);//卡片背面3碼
			apiClient.setEXPIREDATE(expiredate);//卡片到期日YYMM
			apiClient.setIDNUMBER(id);//身分驗證碼
			apiClient.setTRANSCODE("00");//00-授權、90-卡號確認交易
			apiClient.setTRANSMODE("0");//0-一般、1-分期、2-紅利
			apiClient.setINSTALLMENT("0");
			apiClient.setTRANSAMT(String.valueOf(orderPremium));
			apiClient.setNotifyURL("");
			apiClient.setPrivateData("");//自訂參數用
			apiClient.setURL(NCCCURL, "/merchant/APIRequest");
			apiClient.setProvider("sun.security.provider.Sun");
			
			rtnCode = apiClient.postAuth();//送出取授權
  	  		String responsecode = apiClient.getRESPONSECODE();			//授權回應碼
  	  		String msg = apiClient.getRESPONSEMSG();					//授權回應訊息
			
			//進行查詢交易結果動作
			if(responsecode.equals("00") || responsecode.equals("08") || responsecode.equals("11")){
				
	  			request.setCharacterEncoding("Big5");
	  			apiClient.setMERCHANTID(MerchantID);
	  			apiClient.setTERMINALID(TerminalID);
	  			apiClient.setORDERID(orderNumber);
	  			apiClient.setURL(NCCCURL, "/merchant/HPPRequest");
	  			apiClient.setProvider("sun.security.provider.Sun");
	  			apiClient.postAuthQuery();

	  	  		String ordernumber = apiClient.getORDERID();				//訂單編號
	  	  		String retcardno = apiClient.getPAN();						//信用卡號
	  	  		String pdata = apiClient.getPrivateData();					//自訂參數
	  	  		String appcode = apiClient.getAPPROVECODE();				//授權碼

  	  			ret = new HashMap();
  	  			ret.put("rtncode", responsecode);
  	  			ret.put("msg", msg);
  	  			ret.put("orderno", ordernumber);
  	  			ret.put("panno", retcardno);
  	  			ret.put("appcode", appcode);	  	  			
	  	  		
	  	  		
			}else{
  	  			ret = new HashMap();
  	  			ret.put("rtncode", apiClient.getRESPONSECODE());
  	  			ret.put("msg", apiClient.getRESPONSEMSG());
			}

		} 
		catch (Exception e){
			e.printStackTrace();
		}	
		
		if (rtnCode == 1)//有3D驗證狀態，其他為2
		{
			try {
				//取得交易金鑰apiClient.getKEY())再使用3.2 節方式呼叫hpp 程式
				setHtml_3d(apiClient.getHTML());

			} catch (Exception ex){}
		} 

		return ret;
	}

	
	

	public String callNCCC_API(HttpServlet servlet,HttpServletRequest request, HttpServletResponse response ,
			String id , String orderNumber, double orderPremium,String cardno,String extenno, String expiredate , String returnPath , String formname )
			throws AsiException {

		String MerchantID = SystemParam.getParam("NCCCAPI_STROEID"); // NCCC_API聯信商店代號
		String TerminalID = SystemParam.getParam("NCCCAPI_TERID"); // NCCC_API聯信端末機代號
		String NCCCURL = SystemParam.getParam("NCCC_URL"); // NCCC聯信取授權網址
		String root = null;

		// 取得目前使用者進入用的完整Http路徑
		try {
			root = RequestUtils.serverURL(request).toString();
			root += request.getContextPath();
			root = response.encodeURL(root);
		} catch (MalformedURLException e) {
			throw new UserException("errors.1000", e);
		}

		String updatePath = root + "/TransactionResultsAPI.do"; // 交易結果網址
				
		int rtnCode = 0;
		String privateData = "action=" + returnPath + "&form=" + formname;
		
		// 產生API 物件
		ApiClient apiClient=new ApiClient();
				
		// 設定交易資料
		try 
		{
			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);
		
			//設定交易資料
			request.setCharacterEncoding("Big5");
			apiClient.setMERCHANTID(MerchantID);//特約商店代號
			apiClient.setTERMINALID(TerminalID);//端末機代號
			apiClient.setORDERID(orderNumber);//交易序號
			apiClient.setPAN(cardno);//信用卡號
			apiClient.setEXTENNO(extenno);//卡片背面3碼
			apiClient.setEXPIREDATE(expiredate);//卡片到期日YYMM
			apiClient.setIDNUMBER(id);//身分驗證碼
			apiClient.setTRANSCODE("00");//00-授權、90-卡號確認交易
			apiClient.setTRANSMODE("0");//0-一般、1-分期、2-紅利
			apiClient.setINSTALLMENT("0");
			apiClient.setTRANSAMT(String.valueOf((int) (orderPremium)));
			apiClient.setNotifyURL(updatePath);
			apiClient.setPrivateData(privateData);//自訂參數用
			apiClient.setURL(NCCCURL, "/merchant/APIRequest");
			apiClient.setProvider("sun.security.provider.Sun");
			
			rtnCode = apiClient.postAuth();

		} 
		catch (Exception e){
			e.printStackTrace();
		}	
		
		if (rtnCode == 1)//有3D驗證狀態，其他為2
		{
			try {
				//取得交易金鑰apiClient.getKEY())再使用3.2 節方式呼叫hpp 程式
				setHtml_3d(apiClient.getHTML());

			} catch (Exception ex){}
		} 

		return String.valueOf(rtnCode);
	}

	
	/**
	 * @return the html_3d
	 */
	public String getHtml_3d() {
		return html_3d;
	}

	/**
	 * @param html_3d the html_3d to set
	 */
	public void setHtml_3d(String html_3d) {
		this.html_3d = html_3d;
	}

}
