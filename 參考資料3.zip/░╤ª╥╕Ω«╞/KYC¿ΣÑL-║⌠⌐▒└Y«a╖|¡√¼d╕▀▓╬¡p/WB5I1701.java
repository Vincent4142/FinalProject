package com.asi.kyc.wb5.actions;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * @author Vincent
 * @version 2021/07/06
 * 網店頭家會員查詢統計
 * 
 */
public class WB5I1701 extends AsiAction {
	String buffersql = "";

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) arg1;
		if (form1.getActionCode() == 0) {
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			
			startDate += 1; // 查詢日期區間的起日從當月1日起
			request.setAttribute("strymd", String.valueOf(startDate));
			request.setAttribute("endymd", String.valueOf(sysDate));
			
			form1.setActionCode(5);
		}
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
		List ret = null;
		
        HttpSession session = request.getSession();
        UserInfo ui = (UserInfo)session.getAttribute(GlobalKey.USER_INFO);
        
        Employee emp = Employee.getEmployee(ui.getUserId());
        String id=emp.getId();//取得員工編號

		if (form.getActionCode() == 1)// 查詢
		{
			form.setNextPage(1);
			request.setAttribute("isempty", "N");//查詢是否有資料的判斷
		}
		else if (form.getActionCode() == 4) { // 匯出Excel
			try {
				KycDateUtil kycdate = new KycDateUtil();
				String sysdate = kycdate.getKycDate();

				ret = getDeatail1(request,id);
				
				//查無資料
				if(ret.size() < 1){
					request.setAttribute("isempty", "Y");//查詢是否有資料的判斷
					
					request.setAttribute("strymd", String.valueOf(request.getParameter("startYMD")));
					request.setAttribute("endymd", String.valueOf(request.getParameter("endYMD")));
					form.setNextPage(1);			
				}
				else{
					request.setAttribute("isempty", "N");//查詢是否有資料的判斷
					
					HSSFWorkbook workbook1 = null;
					workbook1=exportExcel(ret);				
					
					response.setContentType("application/octect-stream");
					response.setHeader("Content-Disposition","attachment;filename=BOSS3.0_" + sysdate + ".xls");
					OutputStream os = response.getOutputStream();
					workbook1.write(os);
					os.flush();
					os.close();
					response.flushBuffer();				
					form.setNextPage(-1);
				}			
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} else {
			request.setAttribute("isempty", "N");
			form.setNextPage(1);
		}
	}

	private void createCell(HSSFRow headerRow, short cellcnt,
			String cellString, HSSFCellStyle style) {
		HSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}

	/**
	 * 匯出excel處理
	 * @param data
	 * @return
	 * @throws AsiException
	 */
	public HSSFWorkbook exportExcel(List data)
			throws AsiException {
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet sheet = workBook.createSheet();
		
		sheet.createFreezePane(0, 1);//凍結視窗
		
		sheet.setDefaultRowHeightInPoints(20);//預設列高
		sheet.setDefaultColumnWidth((short)9);//預設欄寬
		sheet.setMargin(HSSFSheet.TopMargin, (double) .30);//設定上邊界
		sheet.setMargin(HSSFSheet.BottomMargin, (double) .30);//設定下邊界
		sheet.setMargin(HSSFSheet.LeftMargin, (double) .30);//設定左邊界
		sheet.setMargin(HSSFSheet.RightMargin, (double) .30);//設定右邊界
		
		HSSFCellStyle style = workBook.createCellStyle();//欄位&Data樣式
		style.setWrapText(false);//自動換行
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);//設定下框線樣式
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);//設定左框線樣式
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);//設定右框線樣式
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);//設定上框線樣式
		
		HSSFRow row = sheet.createRow(0);//欄位名稱
		createCell(row, (short) 0, "會員姓名", style);
		createCell(row, (short) 1, "推薦人代號", style);
		createCell(row, (short) 2, "註冊日期", style);
		createCell(row, (short) 3, "邀請人代碼", style);
		createCell(row, (short) 4, "邀請人姓名", style);
		
		for (int i = 0; i < data.size(); i++)//Data
		{
			Map currentRowData = (Map) data.get(i);
			row = sheet.createRow(i + 1);
			createCell(row, (short) 0, hiddenName(String.valueOf(currentRowData.get("RG02"))), style);
			createCell(row, (short) 1, String.valueOf(currentRowData.get("C01A17")), style);		
			createCell(row, (short) 2, String.valueOf(currentRowData.get("RG14")), style);
			createCell(row, (short) 3, String.valueOf(currentRowData.get("RG31")), style);
			createCell(row, (short) 4, String.valueOf(currentRowData.get("M301")), style);			
		}
		
		return workBook;
		
	}

	/**
	 * 找出推薦會員人數
	 * @param request
	 * @param id
	 * @return
	 */
	private List getDeatail1(HttpServletRequest request,String id) {
		List ret = null;

		String startYMD = request.getParameter("startYMD") != null ? request.getParameter("startYMD") : "";
		String endYMD = request.getParameter("endYMD") != null ? request.getParameter("endYMD") : "";

		String sql = "select distinct RG02,A.C01A17,RG14,RG31,M302,M301 "
					+"from KYCREG "
					+"left join IC01PFA A on RG01=A.C01A01 "
					+"left join IC01PFA B on RG31=B.C01A17 "
					+"left join PSM3PF on M319=B.C01A01 "
					+"where M301=? and RG14 between ? and ? and M315=0";
		String args[] = new String[3];
		args[0]  = id;
		args[1]  = startYMD;
		args[2]  = endYMD;
		
		
		Connection con = null;
		
		try {
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql.toString() , args ,new TrimedMapListHandler());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		
		return ret;
	}
	
	/**
	 * 處理姓名隱碼
	 * @param name
	 * @return
	 */
	public String hiddenName(String name){
		
		StringBuffer hiddenName = new StringBuffer();
		if(name.length() < 4){
		   for(int i=0;i<name.length();i++){
			   if(i==1){
				   hiddenName.append("O");
			   }
			   else{
				   hiddenName.append(name.substring(i,i+1));
		   	   }
		   }
		}
		else{
		    for(int i=0;i<name.length();i++){
			    if(i==1 || i==2){
				    hiddenName.append("O");
			    }
			    else{
				    hiddenName.append(name.substring(i,i+1));
		   	    }
		    }
		}
		
		return hiddenName.toString();	
	}
}