package com.kyc.ey1.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.kyc.sec.actions.WebAction;
import com.kyc.ey1.forms.EY1M010f;
import com.kyc.ey1.models.EY1M010m;
import com.kyc.la1.dao.SECAZDao;
import com.kyc.lm1.forms.LM1010f;

/**
 * 依「車險險種分類代碼」取得險種代號及名稱
 *	@author vsg
 * @CreateDate 2011/8/30下午 4:40:11
 * @UpdateDate 2011/8/30下午 4:40:11
 * @FileName kyc/com.kyc.lm1.actions/LM10102.java
 * @Purpose
 * 
 */
public class EY1M0102 extends WebAction
{
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		System.out.println("====EY1M0102====");
		
		EY1M010f form1 = (EY1M010f) arg1;		
		List ret = null;


		String PA01 = arg2.getParameter("PA01");
		String type = arg2.getParameter("type");
		String mainAction = arg2.getParameter("mainAction");

		System.out.println("PA01 = " + PA01);
		System.out.println("type = " + type);
		System.out.println("mainAction = " + mainAction);

		StringBuffer buf = new StringBuffer();
		buf.append("<select id='selectInsurance'>");

		if (PA01.equals("C"))
		{
			tx_controller.begin(1);
			Connection conn = tx_controller.getConnection(1);
			
	        EY1M010m model = new EY1M010m(tx_controller, arg2, arg1);
			
			SECAZDao secazDao = new SECAZDao(conn);			
			List<?> secazMenu = model.getInsuranceCategory();

			if(!type.equals("add")){
				buf.append("<option value='0'>--全部--</option>");
			}
			if (secazMenu != null)
			{
				int size = secazMenu.size();
				if(mainAction.equals("/EY1M0201")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("PT00").toString().trim()).append("'>");
						buf.append(map.get("PT00").toString().trim()).append(":").append(map.get("PT01").toString().trim()).append("</option>");
					}
				}else if(mainAction.equals("/EY1M0101")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("PT00").toString().trim()).append(":").append(map.get("PT01").toString().trim()).append("'>");
						buf.append(map.get("PT00").toString().trim()).append(":").append(map.get("PT01").toString().trim()).append("</option>");
					}
				}
				
			}
			

		}else if (PA01.equals("O"))
		{
			tx_controller.begin(0);
			Connection conn = tx_controller.getConnection(0);
			
			SECAZDao secazDao = new SECAZDao(conn);			
			List<?> secazMenu = secazDao.getcodetype("CLAUSE_O");

			if(!type.equals("add")){
				buf.append("<option value='0'>--全部--</option>");
			}
			
			if (secazMenu != null)
			{
				int size = secazMenu.size();
				if(mainAction.equals("/EY1M0201")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("CODEID").toString().trim()).append("'>");
						buf.append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("</option>");
					}
				}else if(mainAction.equals("/EY1M0101")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("'>");
						buf.append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("</option>");
					}
				}

			}
			

		}else if (PA01.equals("F"))
		{
			tx_controller.begin(0);
			Connection conn = tx_controller.getConnection(0);
			
			SECAZDao secazDao = new SECAZDao(conn);			
			List<?> secazMenu = secazDao.getcodetype("CLAUSE_F");

			if(!type.equals("add")){
				buf.append("<option value='0'>--全部--</option>");
			}
			if (secazMenu != null)
			{
				int size = secazMenu.size();
				if(mainAction.equals("/EY1M0201")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("CODEID").toString().trim()).append("'>");
						buf.append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("</option>");
					}
				}else if(mainAction.equals("/EY1M0101")){
					for (int i = 0; i < size; i++)
					{
						Map map = (Map) secazMenu.get(i);
						buf.append("<option value='").append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("'>");
						buf.append(map.get("CODEID").toString().trim()).append(":").append(map.get("CODEDESC").toString().trim()).append("</option>");
					}
				}

			}
			
		}	
		else
		{
			if(!type.equals("add")){
				buf.append("<option value='0'>--全部--</option>");
			}
		}
		buf.append("</select>");
		
		System.out.println("buf = " + buf.toString());

		arg3.setContentType("text/html;charset=UTF-8");
		arg3.setHeader("Cache-Control", "no-cache");
		try
		{
			arg3.getWriter().write(buf.toString());
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		form1.setNextPage(-1);
	}

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
	{
		AsiActionForm form1 = (AsiActionForm) arg1;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(5);
		}
	}
}
