package com.kyc.ey1.actions;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.firstins.dao.procedure.EPSU724Input;
import com.firstins.dao.procedure.EPSU724PRC;
import com.firstins.dao.procedure.EPSU724Return;
import com.kyc.ey1.forms.EY1M030f;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * 傷健險電子保單維護作業
 * 
 * @author vsg
 * @Create 2020/08/12
 * @Update 2021/06/28 增加VI 疫苗險查詢條件
 */
public class EY1M0301 extends WebAction
{
    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
		AsiActionForm form1 = (AsiActionForm) arg1;

		if (form1.getActionCode() == 0)
		{
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType,
					DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			startDate += 1; // 查詢日期區間的起日從當月1日起

			arg2.setAttribute("strymd", String.valueOf(startDate));
			arg2.setAttribute("endymd", String.valueOf(sysDate));
			
		}
    }
	
	public void doProcess(ActionMapping actionmapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		EY1M030f form1 = (EY1M030f) form;

		tx_controller.begin(1);
		if (form1.getActionCode() == 5)
		{
			HttpSession session = request.getSession();
	        UserInfo ui = (UserInfo)session.getAttribute(GlobalKey.USER_INFO);
	        
	        List ret =getQueryData(form1);

			request.setAttribute("queryData", ret);
			form1.setNextPage(2);
		} 
	}

	/**
	 * 查詢保單資料
	 * @param form1
	 * @return
	 */
	private List getQueryData(EY1M030f form1){
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT * FROM IC02PF ");
		sql.append("LEFT JOIN PT15PF ON T1504=C202 ");
		sql.append("LEFT JOIN WB35PF ON B3501=C202 AND B3503=C203 ");
		sql.append("WHERE ");
		
		//投保型態
		if(!form1.getC204().equals("0"))
			sql.append("C204 = '").append(form1.getC204()).append("' ");
		else
			sql.append("C204 IN ('OTA','OHS','OVI','FRC') ");//開放OTA旅平險、OHS新視界、OVI疫苗險、FRC住火險
		
		sql.append("AND (TRIM(C223) <>'Y' OR C223 IS NULL) AND (C207 NOT IN('0','4') OR C207 IS NULL)");
		
		//保單號碼
		if(!form1.getInsNo1().equals("") && !form1.getInsNo2().equals(""))
			sql.append("AND C202 BETWEEN '").append(form1.getInsNo1()).append("' AND '").append(form1.getInsNo2()).append("' ");
		else if(!form1.getInsNo1().equals("") && form1.getInsNo2().equals(""))
			sql.append("AND C202 = '").append(form1.getInsNo1()).append("' ");
		
		//業務來源
		if(!form1.getBusFrom().equals("") )
			sql.append("AND C210 LIKE '%").append(form1.getBusFrom()).append("%' ");
		
		//招攬人
		if(!form1.getSalesId().equals("") && !form1.getSalesId().equals("0") )
			sql.append("AND C213 = '").append(form1.getSalesId()).append("' ");
				
		//出單日期
		if(form1.getInsNo1().equals("") && form1.getInsNo2().equals("")){	
			if(form1.getStartDate() != null && form1.getEndDate() !=null)
				sql.append("AND C231 BETWEEN ").append(form1.getStartDate()).append(" AND ").append(form1.getEndDate()).append(" ");
		}
		
		//限制筆數
		sql.append(" ORDER BY C202,C231 FETCH FIRST " + form1.getLimit() + " ROWS ONLY");
		System.out.println(sql.toString());
		
		tx_controller.begin(1);
		List list = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			list = (List) runner.query(tx_controller.getConnection(1), sql.toString(), new TrimedMapListHandler());
			
			list = checkDetail(list, form1);//處理結果資料
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return list;
	}	
	
	/**
	 * 處理查詢結果資料
	 * @param data
	 * @param printStat
	 */
	private List checkDetail(List data , EY1M030f form1)
	{
		boolean isPrint = false;
		boolean isEpolicy = false;
		List retlist = new LinkedList();
		int addi = 0;
		
		for (int i = 0; i < data.size(); i++)
		{
			Map map = (Map) data.get(i);
			
			isPrint = checkPrintDetail(String.valueOf(map.get("C202")));
			if(isPrint)
				map.put("printStat", "已列印");
			else
				map.put("printStat", "未列印");
			
			//電子保單判斷方式：傷健險(OVI、OHS、OTA)會CALL400副程式判斷；火險直接判斷T1575(電子保單註記)
			if("F".equals(map.get("C203"))) {
				if("Y".equals(map.get("T1575"))) {
					isEpolicy=true;
				}
			}
			else {
				isEpolicy = isEpolicy(map.get("C202").toString());//查詢是否為電子保單
			}			
			
			if(isEpolicy)
				map.put("isepolicy", "Y");
			else
				map.put("isepolicy", "N");
			
			//保單類別處理
			if(form1.getPrintStat().equals("1")){//查詢電子保單
				if(isEpolicy){
					retlist.add(addi , data.get(i));
					addi++;
				}		
			}else if(form1.getPrintStat().equals("2")){//查詢紙本保單
				if(!isEpolicy){
					retlist.add(addi , data.get(i));
					addi++;
				}				
			}else{
				retlist.add(addi , data.get(i));
				addi++;
			}
						
		}
		
		return retlist;
	}
	
	/**
	 * 是否有保單列印紀錄
	 * @param insNo 保單編號
	 * @param insStat 保單狀態
	 * @return
	 */
	private boolean checkPrintDetail(String insNo)
	{
		tx_controller.begin(0);
		String sql = "SELECT KZ01 FROM KYCKZ WHERE KZ01=? ";
		String[] param = new String[1];
		param[0] = insNo;


		boolean ret = false;
		List list = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			list = (List) runner.query(tx_controller.getConnection(0), sql,param, new TrimedMapListHandler());
			if(list.size()>0) ret = true;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	/**
	 * 查詢EPSU724PRC 是否為電子保單
	 * @param insno
	 * @return
	 */
	private boolean isEpolicy(String insno){
		
		boolean ret = false;
		
		try {
			EPSU724Input su724 = new EPSU724Input();
			su724.setS741i1("O");
			su724.setS741i2(insno);
			su724.setS741i3("");
			su724.setS741i4("");
			su724.setS741i5("");
			su724.setS741i6("2");
			su724.setS741i7("");
			
			EPSU724PRC prc = new EPSU724PRC();
			EPSU724Return rt724 = prc.execute(su724);
			
			if(rt724.getS741o7().trim().equals("Y"))
				ret = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		
		return ret;
	}
	
}