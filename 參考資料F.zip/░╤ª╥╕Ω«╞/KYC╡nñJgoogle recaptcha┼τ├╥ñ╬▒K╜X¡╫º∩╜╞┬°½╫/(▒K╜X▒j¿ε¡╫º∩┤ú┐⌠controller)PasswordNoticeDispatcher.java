/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.common.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.KycGlobal;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * 密碼設定提醒
 * 
 * @author  ：John
 * @version ：$Revision: 1.2 $ $Date: 2006/06/01 02:40:36 $<br>	
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/com/com/asi/kyc/common/actions/PasswordNoticeDispatcher.java,v 1.2 2006/06/01 02:40:36 cvsuser Exp $  
 * 建立日期	：2005/11/15
 * 異動註記	： 
 * </pre></p>
 */
public class PasswordNoticeDispatcher extends WebAction {
    public void doProcess(ActionMapping mapping, AsiActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws AsiException {
        int nextPage = 4;
        int acode = form.getActionCode();

        UserInfo ui = (UserInfo) request.getSession(false)
                .getAttribute(GlobalKey.USER_INFO);
        String userType = ui.getInfo("USERTYPE");
        if (1 == acode) {
            //B2C
            if ("1".equals(userType)) {
                nextPage = 2;
                //B2E
            } else if ("2".equals(userType)) {
                nextPage = 3;
                //B2B
            } else if ("3".equals(userType)) {
                nextPage = 1;
            }

        } else if (5 == acode) {
            request.getSession(false).removeAttribute(KycGlobal.HideMenu);

            //B2C
            if ("1".equals(userType)) {
                nextPage = 6;
                //B2E
            } else if ("2".equals(userType)) {
                nextPage = 7;
                //B2B
            } else if ("3".equals(userType)) {
                nextPage = 5;
            }
        } else if (99 == acode) {
            request.getSession(false).removeAttribute(KycGlobal.HideMenu);

            //B2C
            if ("1".equals(userType)) {
                nextPage = 9;
                //B2E
            } else if ("2".equals(userType)) {
            	
            	List<Map> m = null;
            	String sql="SELECT * FROM SECAL WHERE USERID=? ";
    			try
    			{
    				tx_controller.begin(0);
    				QueryRunner qr = new QueryRunner(); 
    				
    				m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,ui.getUserId(),new TrimedMapListHandler());  				
    				request.setAttribute("list", m);
    			}
    			catch (Exception e)
    			{
    				e.printStackTrace();
    			}
            	
                nextPage = 10;
                //B2B
            } else if ("3".equals(userType)) {
                nextPage = 8;
            }
        }

        form.setNextPage(nextPage);
    }

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1,
            HttpServletRequest arg2, HttpServletResponse arg3) {
        AsiActionForm form = (AsiActionForm) arg1;
        if (form.getActionCode() == 0) {
            form.setActionCode(1);
        }
    }
}
