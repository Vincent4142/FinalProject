/*
 * Created on 2005/4/21
 */
package com.asi.kyc.common.models;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.GlobalKey;
import com.asi.common.MailSender;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.Record;
import com.asi.common.dbo.TableDBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.dbo.UpdateDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.ISecurityManager;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.ManagerUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.forms.KycPasswordModifyForm;
import com.kyc.sec.actions.EncryptUtil;
import com.kyc.sec.actions.GoogleRecaptchaAPI;

/**
 * @author Sergio_Huang
 * 異動註記 ：2005/11/15  John  增加刪除過多的密碼資料
 */
public class KycPasswordModifym extends AsiModel {

    private static Log logger = LogFactory.getLog(KycPasswordModifym.class);

    private KycPasswordModifyForm mform;

    /**
     * @param arg0
     * @param arg1
     * @param arg2
     */
    public KycPasswordModifym(TransactionControl arg0, HttpServletRequest arg1, AsiActionForm arg2) {
        super(arg0, arg1, arg2);

    }

    /**
     *  
     */

    public void init() throws AsiException {
        mform = new KycPasswordModifyForm();
        //把form做拷貝
        try {
            BeanUtils.copyProperties(mform, getForm());
        } catch (InvocationTargetException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        } catch (IllegalAccessException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        }
        setMainForm(mform);
    }

    public void processP1() throws AsiException {
        //        TableDBO pwdDBO = (TableDBO) getTransaction().getDBO("sec.SECALt",
        // 0); // 使用者密碼設定檔
        //        getTransaction().begin(0);
        //        pwdDBO.addParameter("USERID", getUsrInfo().getUserId());
        //        pwdDBO.addParameter("PASSWORD", mform.getNewPassword());
        //        pwdDBO.executeInsert();
        //
        //        UpdateDBO dbo1 = (UpdateDBO) getTransaction().getDBO("sec.SECAJu02",
        // 0);
        //        dbo1.addParameter("USERID", getUsrInfo().getUserId());
        //        dbo1.addParameter("PASSWORD", mform.getNewPassword());
        //        dbo1.executeUpdate();
        getTransaction().begin(0);

        UpdateDBO errcntDBO = (UpdateDBO) getTransaction().getDBO("sec.SECAJu01", 0); // ERRCNT
                                                                                      // + 1
        errcntDBO.addParameter("USERID", getUsrInfo().getUserId());
        errcntDBO.addParameter("STATE", getUsrInfo().getInfo("STATE"));
        //		errcntDBO.addParameter("CHGPWD", info.getInfo("CHGPWD"));
        errcntDBO.addParameter("ERRCNT", "0");
        errcntDBO.addParameter("STATE", "N");
        errcntDBO.addParameter("CHGPWD", "N");
        errcntDBO.executeUpdate();

        TableDBO pwdDBO = (TableDBO) getTransaction().getDBO("sec.SECALt", 0); // 使用者密碼設定檔
        pwdDBO.addParameter("USERID", getUsrInfo().getUserId());
        pwdDBO.executeSelect();
        Record pwdRecord = null;

        ISecurityManager secMgr = (ISecurityManager) ManagerUtil.getManager(getServlet(), GlobalKey.SECURITY_MANAGER);

		int limit = secMgr.getRepeatLimit();
		int count = pwdDBO.getRecordCount();
		
		/** B2C帳號-檢核新密碼不得為ID及生日 */
		if("1".equals(getUsrInfo().getInfo("USERTYPE")))
		{
        	//增加google驗證碼
        	String[] googleCaptchaVerify = GoogleRecaptchaAPI.reCaptchaVerify(getRequest());
        	
            //google 非機器人驗證，驗證通過再進行資料查詢及檢核
            if(!googleCaptchaVerify[0].equals("true")){         	
            	String errmsg = googleCaptchaVerify[3].indexOf("timeout") != -1 ? "Google驗證碼超時，請重新輸入！" : googleCaptchaVerify[3] ;           	
            	throw new AsiException(errmsg);
            }		
			
			if(mform.getNewPassword().equalsIgnoreCase(getUsrInfo().getUserId()))
            {
				throw new UserException("1032");
            }
			
			DBO dbo2 = getTransaction().getDBO("kyc.IC01PFt", 0);
            dbo2.addParameter("C101", getUsrInfo().getUserId());
            dbo2.executeSelect();
            
            if(mform.getNewPassword().equals(dbo2.getRecordData("C103")))
            {
            	throw new UserException("1032");
            }
		}
		
        /** 檢核新密碼在 repeatLimit 內是否有重複 */
        for (int i = 1; (i <= limit) && (i <= count); i++) {
            pwdRecord = pwdDBO.getRecord(i);
            if (mform.getNewPassword().equals(EncryptUtil.getDesDecryptString(pwdRecord.getData("PASSWORD")))) {
                throw new UserException("1007", MessageUtil.getMessage(getServlet(), getRequest(), "comm.passwordmodify.newpassword"), String.valueOf(limit));
            }
        }

        /** 檢核密碼存量是否已達上限 */
        if (count >= limit) {
            for (int i = limit; i <= count; i++) {
                if (i == 0) {
                    continue;
                }
                pwdRecord = pwdDBO.getRecord(i);
                pwdDBO.setParameters(pwdRecord);
                pwdDBO.executeDelete();
            }
        }

        /** 新增密碼資料 */
        pwdDBO.addParameter("USERID", getUsrInfo().getUserId());
        pwdDBO.addParameter("PASSWORD", EncryptUtil.getDesEncryptString(mform.getNewPassword()));
        pwdDBO.addParameter("CRTDT", DateUtil.getSysDate(getUsrInfo(), false));
        pwdDBO.addParameter("CRTTM", DateUtil.getSysTime());
        pwdDBO.addParameter("UPDDT", DateUtil.getSysDate(getUsrInfo(), false));
        pwdDBO.addParameter("UPDTM", DateUtil.getSysTime());
//        System.out.println(pwdDBO.getAssembledSQL(1));
        pwdDBO.executeInsert();

        UpdateDBO dbo1 = (UpdateDBO) getTransaction().getDBO("sec.SECAJu02", 0);
        dbo1.addParameter("USERID", getUsrInfo().getUserId());
        dbo1.addParameter("PASSWORD", EncryptUtil.getDesEncryptString(mform.getNewPassword()));
        dbo1.executeUpdate();
        getRequest().setAttribute("success", "Y");

        if (getUsrInfo().getUserId().length() != 5) {
            String path = getServlet().getServletContext().getRealPath("/mail/pass_" + getLocale() + ".html");
            StringBuffer linebf = new StringBuffer();
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
                String line;
                line = br.readLine();
                while (line != null) {
                    linebf.append(line);
                    line = br.readLine();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            String msg = linebf.toString();
            msg = msg.replaceAll("\\{0\\}", getUsrInfo().getName().replaceAll("\\$",""));
            msg = msg.replaceAll("\\{1\\}", mform.getNewPassword());
            msg = msg.replaceAll("\\{2\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
            msg = msg.replaceAll("\\{link1\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
            msg = msg.replaceAll("\\{link2\\}", ConfigUtil.getConfig(getServlet(), "mail.home"));
            
            DBO dbo2 = getTransaction().getDBO("kyc.IC01PFt", 0);
            dbo2.addParameter("C101", getUsrInfo().getUserId());
            dbo2.executeSelect();

            MailSender sender = new MailSender();
            
			if (SystemParam.getParam("ENV").equals("KYC"))
				sender.setSubject("第一產物保險公司-密碼修改通知");
			else
				sender.setSubject("[測試]第一產物保險公司-密碼修改通知");

            sender.addTo(dbo2.getRecordData("C113"));
            sender.setMessage(msg);
            try {
                sender.sendMail();
            } catch (AsiException e) {
                LogFactory.getLog(KycPasswordModifym.class).debug("寄信時發生錯誤 email : " + dbo2.getRecordData("C113"));
            }
        }
        getRequest().setAttribute("msg", "您的密碼已變更");
        getSession().removeAttribute(KycGlobal.HideMenu);
    }

    /**
     *  
     */

    public void destroy() {
    }

}