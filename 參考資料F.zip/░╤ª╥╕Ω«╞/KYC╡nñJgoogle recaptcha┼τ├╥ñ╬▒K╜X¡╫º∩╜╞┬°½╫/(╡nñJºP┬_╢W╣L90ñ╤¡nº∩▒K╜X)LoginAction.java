/*
 *
 * Copyright (c) 2000-2003 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.kyc.sec.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.ExceptionHandler;
import com.asi.common.exception.UserException;
import com.asi.common.forms.LoginForm;
import com.asi.common.manager.IUserManager;
import com.asi.common.security.ISecurityManager;
import com.asi.common.security.IUser;
import com.asi.common.security.UserInfo;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.LocaleUtil;
import com.asi.common.util.ManagerUtil;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.common.util.CodeUtil;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * 
 * 使用者登入
 * 
 * @author ：Richard_Lu
 * @version ：$Revision: 1.6 $ $Date: 2007/01/22 01:57:53 $ 
 * 存放路徑 ：$Header:
 *          D:/CVSRepository/Financial/KYC/KYC/JavaSource/sec/com/kyc/sec/actions/LoginAction.java,v
 *          1.11 2005/04/20 03:02:10 Sergio_Huang Exp $ 
 * 建立日期 ：2003/5/12 
 * 異動註記 ：2005/11/15  John  增加密碼過期後，登入時導入密碼設定提醒頁面
 *        2019/10/05  John Lai 增加LINE@快速登入暨跳至目標網頁功能
 *  
 */
public class LoginAction extends Action {

    /**
     * @param mapping ActionMapping 動作對映物件
     * @param form 畫面表單
     * @param request HttpReqeust 物件
     * @param response HttpResponse 物件
     * 
     * 執行使用者登入的主流程
     */
    @SuppressWarnings({ "rawtypes", "deprecation" })
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        HttpSession session  = request.getSession(false);
        try {
            session.setAttribute("InvalidateTest", "InvalidateTest");
        }
        catch (IllegalStateException re) {
            session = request.getSession(true);
        }

        if ("/secLogin".equals(mapping.getPath())) {
            session.setAttribute("B2ELogin", "true");
        }
        
		String token = request.getParameter("token") != null ? request.getParameter("token") : "";
		if (!token.equals("")) { // LINE@ 登入
			// 使用token至LINE@伺服器(區分正式/測試)索取使用者資料
			IUserManager usrMgr = (IUserManager) ManagerUtil.getManager(getServlet(), GlobalKey.USER_MANAGER);
			String url = "http://1startupt.firstins.com.tw/app_web/Handler_Token.ashx?token=" + token; // 測試環境
			if(SystemParam.getParam("ENV").equals("KYC")) // 正式環境
				url = "http://1startup.firstins.com.tw/app_web/Handler_Token.ashx?token=" + token;
			InputStream is = new URL(url).openStream();
			String userId = "";
			String userType = "";
			Date lastTime = null;
			String pageId = "";
			/**
			 * 解析LINE@伺服器回傳之JSONArray資料, 範例如下:
			 * 		[{
			 * 		"user_id": "46806", 
			 * 		"id_no": "A123456789", 
			 * 		"emp_id": "46806",
			 * 		"user_type": "B2E", 
			 * 		"page_id": "QT1M0301.do", 
			 * 		"last_time": "2020-01-04 17:26:02"
			 * 		}], 
			 */
			try {
				BufferedReader rd = new BufferedReader(new InputStreamReader(is, "utf-8")); // 避免中文亂碼問題
				StringBuilder sb = new StringBuilder();
				int cp;
				while ((cp = rd.read()) != -1) 
					sb.append((char) cp);
				
				JSONArray jsonArray = JSONArray.fromObject(sb.toString()); 
				userId = jsonArray.getJSONObject(0).get("user_id").toString();
				userType = jsonArray.getJSONObject(0).get("user_type").toString();
				String inputTime = jsonArray.getJSONObject(0).get("last_time").toString();
				if (! "".equals(inputTime)) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					lastTime = sdf.parse(jsonArray.getJSONObject(0).get("last_time").toString());
				}
				pageId = jsonArray.getJSONObject(0).get("page_id").toString();
			} finally {
				is.close();
			}
			
			if ("".equals(userId)) {  //查無token則跳至登入畫面
				return mapping.findForward("loginWin");
			}
			
			Calendar current = Calendar.getInstance(); //token僅5分鐘內有效
			current.add(Calendar.MINUTE,-5);
			if (lastTime.before(current.getTime()) ) {
				return mapping.findForward("loginWin");
			}
			
			Connection con = AS400Connection.getOracleConnection();  
			String sql_select = "SELECT * FROM SECAJ WHERE USERID=? "; // 使用回傳之user_id自動登入KYC
			String args[] = new String[1];
	        args[0] = userId;
			Map mp = new HashMap();
			try {
				QueryRunner runner = new QueryRunner();
				mp = (Map) runner.query(con, sql_select, args, new TrimedMapHandler());
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				AS400Connection.closeConnection(con);
			}
			String querypwd = mp.get("PASSWORD").toString();
			IUser user = null;
			try {
				user = usrMgr.login(getServlet(), request, userId, querypwd);
			} catch (Throwable e) {  //登入失敗時顯示錯誤訊息頁
				ActionErrors errors = new ActionErrors();
				errors.add("Login", ExceptionHandler.toActionError(e));
				saveErrors(request, errors);
				return mapping.findForward("fail");
	        }
			if (user.getInfo().isExpire()) { // 密碼到期時跳至密碼變更頁面
				session.setAttribute(KycGlobal.HideMenu, "true");
				return mapping.findForward("passwordModify");
			} else {

				UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
				TransactionControl txc = null;
				try {
					txc = new TransactionControl();
					txc.setUserInfo(ui);
					txc.setManagerFactory(ManagerUtil.getFactory(servlet));
					txc.setUserLocale(LocaleUtil.getUserLocale(request));
					txc.begin(0);

					// 將不受限的員工代號建在代碼檔：EXCEPTID ，若有已離職員工欲再登入時可使用
					String exceptid = CodeUtil.getCodeList(servlet, request, "EXCEPTID");
					// 檢查員工代號是否存在代碼檔中 不存在傳回-1
					if (exceptid.indexOf(userId) == -1) {
						DBO check999 = txc.getDBO("kyc.PSM3PFs01", 0);
						check999.addParameter("M301", ui.getUserId());
						check999.executeSelect();
						if (check999.getRecordCount() > 0)
							// 系統日大於離職日1天以上時，不可登入
							if (!"0".equals(check999.getRecordData("M315"))
									&& DateUtil.getDateInterval(
											DateUtil.ChType,
											DateUtil.Format_YYYYMMDD,
											DateUtil.getSysDate(ui, false),
											check999.getRecordData("M315")) >= 1) {
								usrMgr.logout(request);
								throw new AsiException("SEC.ERROR999", ui.getUserId());
							}
					}
					DBO dbo1 = txc.getDBO("sec.SECAJu03", 0);// 更新登入次數
					dbo1.addParameter("USERID", ui.getUserId());
					dbo1.addParameter("LASTLOGIN", DateUtil.getSysDate(ui, false));
					dbo1.addParameter("UPDTM", DateUtil.getSysTime(false));
					dbo1.addParameter("UPDDT", DateUtil.getSysDate(ui, false));
					dbo1.execute();
					txc.commit();
				} finally {
					txc.close();
				}
				String date = DateUtil.getSysDate(ui, true);
				String time = DateUtil.getSysTime(true);
				session.setAttribute("loginDT", date + " " + time);
				if ("B2E".equals(userType)) {  // 判斷使用者是B2E OR B2C
					if ("".equals(pageId)) {  // B2E跳至目標網頁
						request.setAttribute(GlobalKey.NEXT_PAGE, "/_layout/kyclayout/b2elayout/news.jsp");
						return mapping.findForward("successb2e");
					} else {
						response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/" + pageId);
						return null;
					}
				} else { // B2C跳至B2C首頁
					request.setAttribute(GlobalKey.NEXT_PAGE, "/_layout/kyclayout/neo_onlineins/news_index.jsp");
                    return mapping.findForward("successb2c");
				}
			}
		} else {
        
	        LoginForm loginForm = (LoginForm) form;
	        ISecurityManager secMgr = (ISecurityManager) ManagerUtil.getManager(getServlet(), GlobalKey.SECURITY_MANAGER);
	        IUserManager usrMgr = (IUserManager) ManagerUtil.getManager(getServlet(), GlobalKey.USER_MANAGER);
	        String rmt_usr = request.getRemoteUser();
	        if (rmt_usr != null) {
	            int index = -1;
	            if ((index = rmt_usr.indexOf("\\")) != -1) {
	                rmt_usr = rmt_usr.substring(index + 1, rmt_usr.length());
	            }
	            rmt_usr = rmt_usr.toUpperCase();
	        }
	        String userId = rmt_usr;
	        String pwd = null;
	        if (loginForm.getUID() == null) {
	            if (rmt_usr != null && !rmt_usr.equals("")) {
	                loginForm.setUID(rmt_usr);
	            }
	            return mapping.findForward("loginWin");
	        }
	        try {
	        	
	            if (secMgr.isSingleSignon()) {
	
	                if (session.getAttribute("try_single_signon") != null && session.getAttribute("try_single_signon").equals("false")) {
	                    userId = loginForm.getUID();
	                    pwd = loginForm.getPWD();
	                    
	                }
	                if (userId == null) {
	                    userId = "";
	                }
	                if (loginForm.getUID().equals("")) {
	                    loginForm.setUID(rmt_usr);
	                }
	                session.setAttribute("try_single_signon", "false");
	                usrMgr.login(getServlet(), request, userId, EncryptUtil.getDesEncryptString(pwd));
	                session.removeAttribute("try_single_signon");
	
	                return mapping.findForward("success2");
	            } else {
	            	
	            	userId = loginForm.getUID();
	                pwd = loginForm.getPWD();
	                IUser user = null;
	                
	                /** 2020/04/30 增加google驗證碼，並先判斷客戶是否為usertype=1 B2C**/
	                String userType = "";
	                int pwderr_count=0;
	                String db_pdw = "";
	                String[] googleCaptchaVerify = null;
	                String loginOTP = request.getParameter("input_otp");
		            
					UserInfo ui_first = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
					TransactionControl txc = null;
					try {
						txc = new TransactionControl();
						txc.setUserInfo(ui_first);
						txc.setManagerFactory(ManagerUtil.getFactory(servlet));
						txc.setUserLocale(LocaleUtil.getUserLocale(request));
						txc.begin(0);
						
		                DBO dbo2 = txc.getDBO("sec.SECAJt", 0);
		                dbo2.addParameter("USERID", userId);		           
		                dbo2.executeSelect();
		                if (dbo2.getRecordCount() == 0) {
		                    throw new UserException("SEC.PASSERR4",userId);
		                }

		                userType = dbo2.getRecordData("USERTYPE");
		                pwderr_count = Integer.parseInt(dbo2.getRecordData("ERRCNT"));
		                db_pdw = dbo2.getRecordData("PASSWORD");
					} finally {
						txc.close();
                    }

	                if(userType.equals("1")){
	                	
	                	//密碼錯誤3次、4次時，啟動otp驗證機制，客戶須輸入發至手機的otp碼代替密碼，輸入正確即帶入正確密碼進入登入，並強迫修改密碼
	                	if(pwderr_count >= 3){
	                		
	                		if(loginOTP != null){
	                			String otpkey = request.getParameter("otpkey");
	                			if(otpkey != null){
	                				KycLogger klg = new KycLogger();
	                				if(klg.isLoginOTP(userId, otpkey, loginOTP)){
	                					pwd = EncryptUtil.getDesDecryptString(db_pdw);
	                				}	                					
	                			}                			
	                		}                		
	                		
	                	}
//	                	else
//	                	{
//		                	googleCaptchaVerify = GoogleRecaptchaAPI.reCaptchaVerify(request);
//		                	
//		                    //google 非機器人驗證，驗證通過再進行資料查詢及檢核
//		                    if(!googleCaptchaVerify[0].equals("true")){
//		                    	String errmsg = googleCaptchaVerify[3].indexOf("timeout") != -1 ? "Google驗證碼超時，請重新輸入！" : googleCaptchaVerify[3] ;                   	
//		                    	throw new AsiException(errmsg);
//		                    }
//
//	                	}
	                	
	                }
	                user = usrMgr.login(getServlet(), request, userId, EncryptUtil.getDesEncryptString(pwd));
	                
	                if (user.getInfo().isExpire()) {
	                    //System.out.println("Password Expire in Action");
	                    session.setAttribute(KycGlobal.HideMenu, "true");
	                    return mapping.findForward("passwordModify");
	                } else {
	                    UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);

	                    try {
	                        txc = new TransactionControl();
	                        txc.setUserInfo(ui);
	                        txc.setManagerFactory(ManagerUtil.getFactory(servlet));
	                        txc.setUserLocale(LocaleUtil.getUserLocale(request));
	                        txc.begin(0);                     
	                        
	                        //將不受限的員工代號建在代碼檔：EXCEPTID ，若有已離職員工欲再登入時可使用
	                        String exceptid =CodeUtil.getCodeList(servlet, request, "EXCEPTID");
	                        //檢查員工代號是否存在代碼檔中	不存在傳回-1
	                        if(exceptid.indexOf(userId) == -1)
	                        {
	                            DBO check999 = txc.getDBO("kyc.PSM3PFs01", 0);
	                            check999.addParameter("M301", ui.getUserId());
	                            check999.executeSelect();
	                            if(check999.getRecordCount()>0)
	                            	//系統日大於離職日1天以上時，不可登入
	                                if(!"0".equals(check999.getRecordData("M315")) 
	                                		&& DateUtil.getDateInterval(DateUtil.ChType, DateUtil.Format_YYYYMMDD
	                                		, DateUtil.getSysDate(ui, false),check999.getRecordData("M315") )>=1)
	                                {
	                                    usrMgr.logout(request);
	                                    throw new AsiException("SEC.ERROR999",ui.getUserId());
	                                }
	                        }
	                        DBO dbo1 = txc.getDBO("sec.SECAJu03", 0);//更新登入次數
	                        dbo1.addParameter("USERID", ui.getUserId());
	                        dbo1.addParameter("LASTLOGIN", DateUtil.getSysDate(ui, false));
	                        dbo1.addParameter("UPDTM", DateUtil.getSysTime(false));
	                        dbo1.addParameter("UPDDT", DateUtil.getSysDate(ui, false));
	                        dbo1.execute();
	                        txc.commit();
	                    } finally {
	                        txc.close();
	                    }
	                    String date = DateUtil.getSysDate(ui, true);
						String time = DateUtil.getSysTime(true);
						session.setAttribute("loginDT", date + " " + time);
	                    String LASTCHGPASS = ui.getInfo("LASTCHGPASS");//SECAL.CRTDT
	                    
	                    
	                    // 以 USER 開頭的帳號，不進行修改密碼及進入密碼提醒頁面 (IT011002K改為除了B2C以外都要修改密碼，並在簽到退時間不予修改)
	                    int sysTime = NumberUtils.toInt(DateUtil.getSysTime().substring(0, 4));// 系統時分
	            		int SigninStartTime = NumberUtils.toInt(SystemParam.getParam("SIGNIN_START"));// 簽到起始時間
	            		int SigninEndTime = NumberUtils.toInt(SystemParam.getParam("SIGNIN_END"));// 簽到終止時間
	            		int SignoutStartTime = NumberUtils.toInt(SystemParam.getParam("SIGNOUT_START"));// 簽退起始時間
	            		int SignoutEndTime = NumberUtils.toInt(SystemParam.getParam("SIGNOUT_END"));// 簽退終止時間
	            		
	            		boolean isSigninTime =(sysTime >= SigninStartTime && sysTime <=SigninEndTime);
	            		boolean isSignoutTime =(sysTime >= SignoutStartTime && sysTime <=SignoutEndTime);
	            		
	            		//超過90天未修改密碼就強制進入密碼修改頁檢核  Y->開啟 N->關閉
	            		String pwdExpiredCheck=SystemParam.getParam("PWD_EXPIRED");    
	            		
	            		if("Y".equals(pwdExpiredCheck)) {	            			
	            			if(!isSigninTime && !isSignoutTime) {
		                    	if (userId.length() < 8) {
			                        //CHGPWD=Y，一定得修改密碼
			                        if (ui.getInfo("CHGPWD").equals("Y")) {
			                            session.setAttribute(KycGlobal.HideMenu, "true");
			                            return mapping.findForward("passwordModify");
			                        }
			                        //密碼過期後，登入時導入密碼設定提醒頁面
			                        double diff =Math.abs(DateUtil.getDateInterval(ui, DateUtil.getSysDate(ui, false), LASTCHGPASS));
			                        if (diff > Double.parseDouble(SystemParam.getParam("PWDEXPIREDATE"))) {
			                            session.setAttribute(KycGlobal.HideMenu, "true");
			                            return mapping.findForward("passwordNotice");
			                        }
			                    }
		                    }	            			
	            		}	            		                                                      
	
	                    //				    IManager cm = (ConfigManager)
	                    // ManagerUtil.getManager(getServlet(),GlobalKey.CONFIG_MANAGER);
	                    String adminId = ConfigUtil.getConfig(getServlet(), GlobalKey.ADMIN_KEY);
	                    if (ui.getUserId().equals(adminId)) {//SUPERVISOR
	                        return mapping.findForward("supervisor");
	                    } else {
	                        userType = ui.getInfo("USERTYPE");
	                        if (userType.equals("1")) {//客戶{
	                        	sendLoginMail(request, ui.getName(), ui.getEmail());
//	                            request.setAttribute(GlobalKey.NEXT_PAGE, "/_layout/kyclayout/neo_onlineins/news_index.jsp");
//	                            return mapping.findForward("successb2c");
	                        	
	                        	//金財通網頁URL判斷
//	                        	String OP_INNER_URL = SystemParam.getParam("OP_INNER_URL");
//	                        	String OP_OUTSIDE_URL = SystemParam.getParam("OP_OUTSIDE_URL");
//
//	                        	String addr = request.getHeader("X-FORWARDED-FOR");
//	                        	if (addr == null || "".equals(addr)) {
//	                        		   addr = request.getRemoteAddr();
//	                        	}
//	                        	
//	                        	String op_url = "";
//	                        	if(addr.indexOf("192.168") != -1 || addr.indexOf("127.0.0.1") != -1){
//	                        		op_url = OP_INNER_URL;//內部網址
//	                        	}else{
//	                        		op_url = OP_OUTSIDE_URL;//外部網址
//	                        	}
//
//	                        	response.sendRedirect(op_url);
	                        	
	                        	String memberDetailPage=request.getContextPath()+"/WB2M0201.do";

	                        	response.sendRedirect(memberDetailPage);
	                        	
	                        	return null;
	                        } else if (userType.equals("2")) {//員工
	                            request.setAttribute(GlobalKey.NEXT_PAGE, "/_layout/kyclayout/b2elayout/news.jsp");
	                            return mapping.findForward("successb2e");
	                        } else if (userType.equals("3")) {//其它
	                            request.setAttribute(GlobalKey.NEXT_PAGE, "/_layout/kyclayout/b2blayout/news.jsp");
	                            return mapping.findForward("successb2b");
	                        } else {
	                            return mapping.findForward("supervisor");
	                        }
	                    }
	                }
	            }
	
	        } catch (Throwable e) {
	            ActionErrors errors = new ActionErrors();
	            errors.add("Login", ExceptionHandler.toActionError(e));
	            saveErrors(request, errors);
	            if (secMgr.isSingleSignon()) {
	                return mapping.findForward("loginWin");
	            } else {
	                return mapping.getInputForward();
	            }
	
	        }
		}

    }

    
	   /**
	    * 寄送Login EMAIL通知
	    * @param request
	    */
	   private void sendLoginMail(HttpServletRequest request , String name , String email)
	   {
		   String addr = request.getHeader("X-FORWARDED-FOR");
		   if (addr == null || "".equals(addr)) {
			   addr = request.getRemoteAddr();
		   }
		   //寄Email
		   KycMailUtil sender = new KycMailUtil();

		   //取範本
		   BufferedReader fr;
		   String path = getServlet().getServletContext().getRealPath("/mail/LoginConfirm_zh_TW.html");

		   StringBuffer linebf = new StringBuffer();
		   try {
			   fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
			   String line;
			   linebf = new StringBuffer();
			   line = fr.readLine();
			   while (line != null) {
				   linebf.append(line);
				   line = fr.readLine();
			   }

		   }catch (FileNotFoundException e) {
			   e.printStackTrace();
		   }catch (IOException e) {
			   e.printStackTrace();
		   }

		   String sysdate = DateUtil.getSysDate(DateUtil.WestType, DateUtil.Format_YYYYMMDD, false);
		   String systime = DateUtil.getSysTime();
		   
		   SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   Date current = new Date();
		   
		   String msg = linebf.toString();
		   //姓名隱碼
		   StringBuffer hiddenName = new StringBuffer();
		   if(name.length() < 4){
			   for(int i=0;i<name.length();i++){
				   if(i==1){
					   hiddenName.append("O");
				   }
				   else{
					   hiddenName.append(name.substring(i,i+1));
			   	   }
			   }
		   }
		   else{
			   for(int i=0;i<name.length();i++){
				   if(i==1 || i==2){
					   hiddenName.append("O");
				   }
				   else{
					   hiddenName.append(name.substring(i,i+1));
			   	   }
			   }
		   }
		   		   
		   msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
		   msg = msg.replaceAll("\\{systime\\}", sdFormat.format(current));
		   msg = msg.replaceAll("\\{ipaddr\\}" , addr);

		   sender.setSubject("第一保商務網-登入系統通知");
		   sender.setMessage(msg);
		   sender.addTo(email);
		   sender.sendMail();

		}

}