/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of The First
 * Insurance Co, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with The First Insurance Co, Ltd.
 *
 */
package com.asi.kyc.wb5.forms;

import com.asi.common.struts.AsiActionForm;

/**
 * <--網店頭家查詢保戶投保資料 -->
 *
 * @author: Vincent
 * @CreatDate: 2022/02/15
 * @UpdateDate:
 * @FileName: WB5I180f.java
 */
public class WB5I180f extends AsiActionForm
{
	private String uid;//當前使用者ID
	private String t1507;//ID
	private String t1610;//車牌號碼
	private String t1517y;//保險起日-年
	private String t1517m;//保險起日-月
	private String t1517d;//保險起日-日
	private String t1518y;//保險迄日-年
	private String t1518m;//保險迄日-月
	private String t1518d;//保險迄日-日
	private String t1523sy;//交易日起-年
	private String t1523sm;//交易日起-月
	private String t1523sd;//交易日起-日
	private String t1523ey;//交易日迄-年
	private String t1523em;//交易日迄-月
	private String t1523ed;//交易日迄-日
	private String confirmsts;//保險迄日或交易日判斷
	
	public String getT1507() {
		return t1507;
	}
	public void setT1507(String t1507) {
		this.t1507 = t1507;
	}
	public String getT1610() {
		return t1610;
	}
	public void setT1610(String t1610) {
		this.t1610 = t1610;
	}
	public String getT1517y() {
		return t1517y;
	}
	public void setT1517y(String t1517y) {
		this.t1517y = t1517y;
	}
	public String getT1517m() {
		return t1517m;
	}
	public void setT1517m(String t1517m) {
		this.t1517m = t1517m;
	}
	public String getT1517d() {
		return t1517d;
	}
	public void setT1517d(String t1517d) {
		this.t1517d = t1517d;
	}
	public String getT1518y() {
		return t1518y;
	}
	public void setT1518y(String t1518y) {
		this.t1518y = t1518y;
	}
	public String getT1518m() {
		return t1518m;
	}
	public void setT1518m(String t1518m) {
		this.t1518m = t1518m;
	}
	public String getT1518d() {
		return t1518d;
	}
	public void setT1518d(String t1518d) {
		this.t1518d = t1518d;
	}
	public String getT1523sy() {
		return t1523sy;
	}
	public void setT1523sy(String t1523sy) {
		this.t1523sy = t1523sy;
	}
	public String getT1523sm() {
		return t1523sm;
	}
	public void setT1523sm(String t1523sm) {
		this.t1523sm = t1523sm;
	}
	public String getT1523sd() {
		return t1523sd;
	}
	public void setT1523sd(String t1523sd) {
		this.t1523sd = t1523sd;
	}
	public String getT1523ey() {
		return t1523ey;
	}
	public void setT1523ey(String t1523ey) {
		this.t1523ey = t1523ey;
	}
	public String getT1523em() {
		return t1523em;
	}
	public void setT1523em(String t1523em) {
		this.t1523em = t1523em;
	}
	public String getT1523ed() {
		return t1523ed;
	}
	public void setT1523ed(String t1523ed) {
		this.t1523ed = t1523ed;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getConfirmsts() {
		return confirmsts;
	}
	public void setConfirmsts(String confirmsts) {
		this.confirmsts = confirmsts;
	}
	
	
	
	
	
}
