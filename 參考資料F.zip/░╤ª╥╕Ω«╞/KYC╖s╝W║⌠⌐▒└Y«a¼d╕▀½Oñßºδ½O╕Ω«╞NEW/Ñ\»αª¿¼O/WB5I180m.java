/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of The First
 * Insurance Co, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with The First Insurance Co, Ltd.
 *
 */
package com.asi.kyc.wb5.models;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.asi.common.AsiModel;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.wb5.dao.WB5I180Dao;
import com.asi.kyc.wb5.forms.WB5I180f;

/**
 * <--program instruction-->
 *
 * @author: Vincent
 * @CreatDate: 2022/02/15
 * @UpdateDate:
 * @FileName: WB5I180m.java
 */
public class WB5I180m extends AsiModel
{
		
	private static Log logger = LogFactory.getLog(WB5I180m.class);
	private WB5I180f mform;
	private TransactionControl tx_controller;
	
	public WB5I180m(TransactionControl tx_controller, HttpServletRequest request, AsiActionForm form)
	{
		super(tx_controller, request, form);
		this.tx_controller = tx_controller;
	}
	
	//初始化
	public void init() throws AsiException
	{

		mform = new WB5I180f();
		// 把form做拷貝
		try
		{
			BeanUtils.copyProperties(mform, getForm());
		} catch (InvocationTargetException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		} catch (IllegalAccessException e)
		{
			if (logger.isErrorEnabled())
			{
				logger.error(e);
			}
		}
		setMainForm(mform);

	}
	
	/**
	 * 查詢投保資料
	 * @param 
	 * @return
	 */
	public List<Map> queryData() throws AsiException {
		
		WB5I180Dao dao=new WB5I180Dao(getTransaction());		
		
		String T1517=mform.getT1517y()+mform.getT1517m()+mform.getT1517d();//保險迄日起
		String T1518=mform.getT1518y()+mform.getT1518m()+mform.getT1518d();//保險迄日終
		String T1523S=mform.getT1523sy()+mform.getT1523sm()+mform.getT1523sd();//交易起日
		String T1523E=mform.getT1523ey()+mform.getT1523em()+mform.getT1523ed();//交易迄日
		
		dao.setUid(mform.getUid());//員工編號
		dao.setT1517(T1517);//保險迄日起
		dao.setT1518(T1518);//保險迄日終
		dao.setT1523s(T1523S);//交易起日
		dao.setT1523e(T1523E);//交易迄日
		dao.setT1507(mform.getT1507());//被保人ID
		dao.setT1610(mform.getT1610());//車牌
		dao.setConfirmsts(mform.getConfirmsts());;//條件判斷
		
		List<Map> list=dao.queryData();
		
		return list;
	}
	
 
	@Override
	public void destroy() {
		
	}	

}
