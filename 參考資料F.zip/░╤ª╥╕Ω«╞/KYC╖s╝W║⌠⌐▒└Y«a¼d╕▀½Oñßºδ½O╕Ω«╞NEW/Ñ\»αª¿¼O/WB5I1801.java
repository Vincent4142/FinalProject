package com.asi.kyc.wb5.actions;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.wb5.forms.WB5I180f;
import com.asi.kyc.wb5.models.WB5I180m;
import com.kyc.afl.utils.Employee;
import com.kyc.sec.actions.WebAction;

/**
 * @author Vincent
 * @version 2022/02/15
 * 網店頭家會員查詢統計
 * 
 */
public class WB5I1801 extends WebAction {
	String buffersql = "";

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) arg1;
		if (form1.getActionCode() == 0) {			
			form1.setActionCode(99);
		}
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
		WB5I180f form1 = (WB5I180f)form;   
		
		WB5I180m model = new WB5I180m(tx_controller, request, form1);
		model.init();
		
        HttpSession session = request.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		String user = ui.getUserId();//員工編號          
		String dep=Employee.getEmployee(user).getDept().getId();//0005為電商人員
	
		request.setAttribute("userId", user);
		request.setAttribute("userDep", dep);
		
		//初始進入
		if (form1.getActionCode() == 99){									
			form1.setNextPage(1);
		}
		
		//查詢投保資料
		if (form1.getActionCode() == 4){
			
			List<Map> list=model.queryData();
			request.setAttribute("datalist", list);
			
			form1.setNextPage(2);
		}
		
	}

}