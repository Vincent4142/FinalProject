package com.asi.kyc.wb5.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbutils.QueryRunner;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * <--網店頭家會員查詢統計 -->
 *
 * @author Vincent
 * @Create Date：2022/02/15
 * @UpdateDate:
 * @FileName: WB5I180Dao.java
 */

public class WB5I180Dao extends com.kyc2.ccp.dao.IDao
{
	public WB5I180Dao(TransactionControl txc) {
		super(txc);
	}
	
	
	/**
	 * 查詢投保資料
	 * @param 
	 * @return
	 */
	public List<Map> queryData() throws AsiException { 
		
		List<Map> list=null;
		
		try {
			txc.begin(0);
			
			QueryRunner qr = new QueryRunner(); 
			
			List<Object> strList = new ArrayList<Object>();
			
			StringBuilder sql=new StringBuilder();
			sql.append("SELECT DISTINCT T1501,T1503,T1504,T1517,T1518,T1506,T1507,T1582,T1584,T1610,T1523,C201,C202,C203,C204,C215,C229 FROM PT15PF ");
			sql.append("LEFT JOIN IC02PF ON T1504=C202 AND T1503=C203 ");
			sql.append("LEFT JOIN PT16PF ON T1501=T1601 ");
					
			//查詢條件為 招攬人96883且目前使用者為推薦人才能查到
			String recommenderCode=getRecommenderCode(uid).equals("") ? "123456789" : getRecommenderCode(uid);
			sql.append("WHERE T1520=96883 AND (T1582=? OR T1584=?) AND T1504 IS NOT NULL ");//正式
			strList.add(recommenderCode);//正式
			strList.add(recommenderCode);//正式
			//sql.append("WHERE T1520 IN(96883,96370)");//測試
						
			if(confirmsts.equals("1") && t1507 != null && !t1507.equals("")) {
				sql.append("AND T1507=? ");
				strList.add(t1507);
			}
			if(confirmsts.equals("2") && t1610 != null && !t1610.equals("")) {
				sql.append("AND T1610=? ");
				strList.add(t1610);
			}
			if(confirmsts.equals("3")) {//選擇以保險訖日作條件
				sql.append("AND T1518 BETWEEN ? AND ? ");
				strList.add(Integer.parseInt(t1517));
				strList.add(Integer.parseInt(t1518));
			}
			if(confirmsts.equals("4")) {//選擇以交易日作條件
				sql.append("AND T1523 BETWEEN ? AND ? ");
				strList.add(Integer.parseInt(t1523s));
				strList.add(Integer.parseInt(t1523e));
			}
			
			sql.append("ORDER BY T1501 ");
			
			Object[] params =strList.toArray(new Object[strList.size()]);
			
			list=(List<Map>)qr.query(txc.getConnection(0), sql.toString(),params,new TrimedMapListHandler());
			
			//險別加上中文名稱
			if(list.size() > 0) {
				
				for(int i=0;i<list.size();i++) {
					Map m=list.get(i);
					String kind=getKind(String.valueOf(m.get("T1503")));
					m.put("T1503W",String.valueOf(m.get("T1503")) + "  " + kind);
				}
			}
					
		}catch(Exception e) {
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		return list;
	}
	
	/**
	 * 查詢使用者的推薦人代碼
	 * @param uid 員工編號
	 * @return
	 */
	public String getRecommenderCode(String uid) throws AsiException{
		String code="";//推薦人代號
		
		try {
			txc.begin(0);			
			QueryRunner qr = new QueryRunner(); 			
			Map m=new HashMap();			
			String sql="SELECT M301,C01A17 FROM PSM3PF LEFT JOIN IC01PFA ON M319=C01A01 WHERE M301=? ";
			
			m=(Map)qr.query(txc.getConnection(0), sql,uid,new TrimedMapHandler());
			
			code=m.get("C01A17").toString();		
			
		}catch(Exception e) {
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		
		return code;
	}

	/**
	 * 取得險種中文
	 * @param T1503 險種
	 * @return
	 */
	public String getKind(String T1503){
		String kind="";//險種中文
		if(T1503.equals("A")){
			kind="強制險";
		}
		else if(T1503.equals("B")){
			kind="漁船險";
		}
		else if(T1503.equals("C")){
			kind="任意險";
		}
		else if(T1503.equals("C1")){
			kind="任意險一年期";
		}
		else if(T1503.equals("C2")){
			kind="駕傷險";
		}
		else if(T1503.equals("E")){
			kind="工程險";
		}
		else if(T1503.equals("F")){
			kind="火險";
		}
		else if(T1503.equals("H")){
			kind="船體險";
		}
		else if(T1503.equals("M")){
			kind="水險";
		}
		else if(T1503.equals("O")){
			kind="新種險";
		}
		
		return kind;
	}
	
	
	
	private String uid;//員工編號
	private String t1517;//保險起日
	private String t1518;//保險迄日
	private String t1523s;//交易起日
	private String t1523e;//交易迄日
	private String t1507;//被保人ID
	private String t1610;//車牌
	private String confirmsts;//保險迄日或交易日判斷
	
	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	public String getT1517() {
		return t1517;
	}


	public void setT1517(String t1517) {
		this.t1517 = t1517;
	}


	public String getT1518() {
		return t1518;
	}


	public void setT1518(String t1518) {
		this.t1518 = t1518;
	}


	public String getT1523s() {
		return t1523s;
	}


	public void setT1523s(String t1523s) {
		this.t1523s = t1523s;
	}


	public String getT1523e() {
		return t1523e;
	}


	public void setT1523e(String t1523e) {
		this.t1523e = t1523e;
	}


	public String getT1507() {
		return t1507;
	}


	public void setT1507(String t1507) {
		this.t1507 = t1507;
	}


	public String getT1610() {
		return t1610;
	}


	public void setT1610(String t1610) {
		this.t1610 = t1610;
	}


	public String getConfirmsts() {
		return confirmsts;
	}


	public void setConfirmsts(String confirmsts) {
		this.confirmsts = confirmsts;
	}
	
}
