/**
 * 
 */
package com.kyc.schedule;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * @author John Lai
 * @Create Date：2020/9/22
 * 
 * 團傷加退保平台每日批單轉入AS/400通知
 */
public class SendGPA01 extends AsiAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	protected void portalCheck(ActionMapping mapping,
			HttpServletRequest request, AsiActionForm asiForm)
			throws AsiException {

	}

	@Override
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException
	{
		try
		{
			tx_controller.begin(1);
			
			sendData();
		}
		catch (Throwable e)
		{
			e.printStackTrace();
		}
		arg1.setNextPage(-1);
	}

	private void sendData() throws AsiException, SQLException
	{

		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		sysdate = DateUtil.getOffsetDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, sysdate, -1, false);
		QueryRunner runner = new QueryRunner();
		//取得各區核保人員員工編號(後續寄出信件用)
		StringBuffer sql1 = new StringBuffer();
		sql1.append("select * from EBR0872F where F201='03' and F202 ='1111' ");
		Map<?, ?> maillist = (Map<?, ?>) runner.query(tx_controller.getConnection(1) , sql1.toString(), new TrimedMapHandler());
		//取得要寄出信件的區域(V北市區.W新北市區.K高屏區.A桃竹區.C台中區.N雲嘉南)EX：1100319只有要寄出W.V而已
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT DISTINCT SUBSTR(WB021,1,1) AREA ");
		sql.append("FROM EPXBWF ");
		sql.append("WHERE WB96 = ? AND SUBSTR(WB021,5,4) >= 'A001' AND SUBSTR(WB021,5,4) <= 'J999' and LENGTH(TRIM(WB021)) = 8 ");
		String args[] = new String[1];
		args[0] = sysdate;
		
		List<?> result = (List<?>) runner.query(tx_controller.getConnection(1), sql.toString(), args, new MapListHandler());
		
		for (int i = 0; i < result.size(); i++)
		{
			Map<?, ?> row = (Map<?, ?>) result.get(i);
			
			String area = String.valueOf(row.get("AREA"));//第一次迴圈area的值為W(新北市區)，第二次迴圈area的值為V(北市區)
			//取得EPXBWF的資料(信件原始內容)
			StringBuffer sql2 = new StringBuffer();
			sql2.append("SELECT WB011 || WB021 INSNO, T408, WB96, sum(WB15) AMOUNT ");
			sql2.append("from EPXBWF inner join EPS4PF on SUBSTR(WB30,10,14) = T402 || T403 ");
			sql2.append("where WB96 = ? AND SUBSTR(WB021,1,1) = ?  AND SUBSTR(WB021,5,4) >= 'A001' AND SUBSTR(WB021,5,4) <= 'J999' and LENGTH(TRIM(WB021)) = 8  ");
			sql2.append("group by WB011 || WB021, T408, WB96");
			String args2[] = new String[2];
			args2[0] = sysdate;
			args2[1] = area;

			List<?> result2 = (List<?>) runner.query(tx_controller.getConnection(1), sql2.toString(), args2, new MapListHandler());
			
			//取得EPXHWF.WH02的SUM(信件原始內容WB15的SUM再加上WH02的SUM即是正確金額)
			StringBuffer sql3 = new StringBuffer();
			sql3.append("SELECT WH011 || WH021 INSNO, WH98, sum(WH02) AMOUNT ");
			sql3.append("from EPXHWF ");
			sql3.append("where WH98 = ? AND SUBSTR(WH021,1,1) = ?  AND SUBSTR(WH021,5,4) >= 'A001' AND SUBSTR(WH021,5,4) <= 'J999' and LENGTH(TRIM(WH021)) = 8 ");
			sql3.append("group by WH011 || WH021, WH98");
			String args3[] = new String[2];
			args3[0] = sysdate;
			args3[1] = area;
			
			List<?> result3 = (List<?>) runner.query(tx_controller.getConnection(1), sql3.toString(), args3, new MapListHandler());
			//組成信件的內容(標頭)
			StringBuffer buf = new StringBuffer();
			buf.append("<table class=MsoNormalTable border=1 cellspacing=0 cellpadding=5 width='1000px' align='left' style='font-size: 12px;'>");
			buf.append("<tr bgcolor='#6699cc' style='font-weight:bold;color:white'>");
			buf.append("<th align='center'>批單號碼</th>");
			buf.append("<th align='center'>要保人名稱</th>");
			buf.append("<th align='center'>批改類別</th>");
			buf.append("<th align='center'>批改金額</th>");
			buf.append("<th align='center'>批單作帳日</th>");
			buf.append("</tr>");
			//當天有幾筆資料轉入AS400就要寄幾次(EX：1100319撈出result2共有8筆資料就要寄8次)
			for (int j = 0; j< result2.size(); j++)
			{
				Map row2 = (Map) result2.get(j);
				
				//處理加總WB15+WH02
				for(int k=0;k<result3.size();k++){
					Map<?, ?> row3 = (Map<?, ?>) result3.get(k);
					String num1=String.valueOf(row2.get("INSNO"));//以1100319為例，result2撈出有八筆資料，依序取出row2.get("INSNO")為：1000VT10A189、1000VT10A190、1000VT10A188、1000VT10A195、1000VT10A191、1000VT10A192、1000VT10A187、1000VT10A194
					String num2=String.valueOf(row3.get("INSNO"));//以1100319為例，result3撈出只有三筆資料，依序取出row3.get("INSNO")為：1000VT10A191、1000VT10A194、1000VT10A192，因為並不是每一筆資料都有寫入EPXHWF
					
					if(num1.equals(num2)){//兩邊有一樣的批單號碼就做加總，即1000VT10A191、1000VT10A194(醄醴有限公司)、1000VT10A192會做加總
						Double amt = Double.parseDouble(String.valueOf(row2.get("AMOUNT")));
						Double amt2 = Double.parseDouble(String.valueOf(row3.get("AMOUNT")));
						String sum=String.valueOf(amt+amt2);
						row2.put("AMOUNT", sum);//加總後更新AMOUNT的值				
					}
				}
				
				String wb96 = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD,String.valueOf(row2.get("WB96")));
				Double amt = Double.parseDouble(String.valueOf(row2.get("AMOUNT")));
				String amount = FormatUtil.getDecimalFormat(amt, 0);
				String endType = "文批";
				if (amt > 0) 
					endType = "加保";
				else if (amt < 0) 
					endType = "退保";
				//組成信件的內容(每筆資料內容)
				buf.append("<tr style='background-color: #F3F3F3'>");
				buf.append("<td align='left'>").append(String.valueOf(row2.get("INSNO"))).append("</td>");
				buf.append("<td align='left'>").append(String.valueOf(row2.get("T408"))).append("</td>");
				buf.append("<td align='left'>").append(endType).append("</td>");
				buf.append("<td align='left'>").append(amount).append("</td>");
				buf.append("<td align='left'>").append(wb96).append("</td>");
				buf.append("</tr>");

			}
			buf.append("</table>");
			try
			{
				//信件寄出方法
				KycMailUtil kmu = new KycMailUtil();
				String subject = "團傷加退保平台每日批單轉入AS/400通知";
				kmu.setSubject(subject);
				
				kmu.setFrom("admin@firstins.com.tw");
				kmu.setMessage(buf.toString());
				String[] mail = new String[5];
				//EX：1100319當天需寄出的區域只有W.V，因此迴圈跑兩次，第一次寄出(W)給新北市區所有核保人員，第二次寄出(V)給台北區所有核保人員
				if ("V".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F213")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F213"))).getEmail();//區域核保員編 1-V																																			
					mail[1] = String.valueOf(maillist.get("F214")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F214"))).getEmail();//區域核保員編 2-V
					mail[2] = String.valueOf(maillist.get("F215")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F215"))).getEmail();//區域核保員編 3-V
					mail[3] = String.valueOf(maillist.get("F216")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F216"))).getEmail();//區域核保員編 4-V
					mail[4] = String.valueOf(maillist.get("F217")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F217"))).getEmail();//區域核保員編 5-V
				} else if ("W".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F218")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F218"))).getEmail();//區域核保員編 1-W
					mail[1] = String.valueOf(maillist.get("F219")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F219"))).getEmail();//區域核保員編 2-W
					mail[2] = String.valueOf(maillist.get("F220")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F220"))).getEmail();//區域核保員編 3-W
					mail[3] = String.valueOf(maillist.get("F221")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F221"))).getEmail();//區域核保員編 4-W
					mail[4] = String.valueOf(maillist.get("F222")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F222"))).getEmail();//區域核保員編 5-W
				} else if ("A".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F223")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F223"))).getEmail();
					mail[1] = String.valueOf(maillist.get("F224")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F224"))).getEmail();
					mail[2] = String.valueOf(maillist.get("F225")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F225"))).getEmail();
					mail[3] = String.valueOf(maillist.get("F226")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F226"))).getEmail();
					mail[4] = String.valueOf(maillist.get("F227")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F227"))).getEmail();
				} else if ("C".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F228")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F228"))).getEmail();
					mail[1] = String.valueOf(maillist.get("F229")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F229"))).getEmail();
					mail[2] = String.valueOf(maillist.get("F230")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F230"))).getEmail();
					mail[3] = String.valueOf(maillist.get("F231")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F231"))).getEmail();
					mail[4] = String.valueOf(maillist.get("F232")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F232"))).getEmail();
				} else if ("N".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F233")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F233"))).getEmail();
					mail[1] = String.valueOf(maillist.get("F234")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F234"))).getEmail();
					mail[2] = String.valueOf(maillist.get("F235")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F235"))).getEmail();
					mail[3] = String.valueOf(maillist.get("F236")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F236"))).getEmail();
					mail[4] = String.valueOf(maillist.get("F237")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F237"))).getEmail();
				} else if ("K".equals(area)) {
					mail[0] = String.valueOf(maillist.get("F238")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F238"))).getEmail();
					mail[1] = String.valueOf(maillist.get("F239")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F239"))).getEmail();
					mail[2] = String.valueOf(maillist.get("F240")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F240"))).getEmail();
					mail[3] = String.valueOf(maillist.get("F241")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F241"))).getEmail();
					mail[4] = String.valueOf(maillist.get("F242")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F242"))).getEmail();
				} else {
					mail[0] = String.valueOf(maillist.get("F208")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F208"))).getEmail();
					mail[1] = String.valueOf(maillist.get("F209")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F209"))).getEmail();
					mail[2] = String.valueOf(maillist.get("F210")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F210"))).getEmail();
					mail[3] = String.valueOf(maillist.get("F211")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F211"))).getEmail();
					mail[4] = String.valueOf(maillist.get("F212")) == "0"?" ":Employee.getEmployee(String.valueOf(maillist.get("F212"))).getEmail();
				}
					
				kmu.addTo(mail);
				kmu.sendMail();
			}
			catch (Exception ex)
	        {
	            ex.printStackTrace();
	        }
		}
	}
	
	/**
	 * 
	 * @param empId
	 * @return
	 */
	protected String getEmpName(String empId)
	{
		return Employee.getEmployee(empId).getName();
	}
}
