package com.firstins;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * @author vsg
 * 使用OD-API程式
 *
 */
public class SendODAPI extends AsiAction
{	
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
	{
   	
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		// 取得Header中的token
		String token = arg2.getHeader("Authorization");	
		String source = arg2.getParameter("source") != null ? arg2.getParameter("source").trim() : "";
		// API程式說明
		String desc = source + "-使用OD-API程式";
		
		Map ret = null;
		List retlist = null;
		JSONObject inputprarm = null;
		KyctknAction tkn = null;
		
		//時間戳記，做為kycllog的key
		String timestamp = "";
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmssSS");
		timestamp = sdf.format(new Date());		
		//長度不足17碼時用0往右補滿
		if(timestamp.length() != 17)
			timestamp = StringUtils.rightPad(timestamp, 17, "0");

		try
		{
			tkn = new KyctknAction();
			ret = new HashMap();

			// 檢查token
			if(tkn.isTokenVaild(arg2 , token, source , this.getClass().getSimpleName())){
				
				// 讀取Body資料
				StringBuffer json = new StringBuffer();
				String line = null;
				try {
				   BufferedReader reader = arg2.getReader();
				   while((line = reader.readLine()) != null) 
					   json.append(line);
				   
				   doKycllog_insert(arg2, timestamp, source, desc);//寫入kycllog
				   doKycllog_update_reqdata(timestamp, json.toString());//更新requset data
				}
				catch(Exception e) {
					doKycllog_update_respdata(timestamp, e.toString());//更新response data
				}
				inputprarm = JSONObject.fromObject(json.toString());

				//取出"data":{}中的客戶資料
				Map mp = (Map) JSONObject.fromObject(inputprarm.get("data"));
				String table =  inputprarm.get("tablename") != null ? inputprarm.get("tablename").toString() : "";				
				String tablelist = CodeUtil.getCodeList(servlet, arg2, "OD400TABLE");//設定OD系統可以查詢的TABLE名稱
				
				if(!table.equals("")){
					if(tablelist.indexOf(table) != -1){
						retlist = getAS400Detail(table , mp);
						
						if(retlist != null && retlist.size()>0 ){
							ret.put("tablename", table);
							ret.put("data", retlist);					
						}else{
							ret.put("tablename", table);
							ret.put("code", "7");
							ret.put("msg", "查無資料");						
						}
					}else{
						ret = new HashMap();
						ret.put("tablename", table);
						ret.put("code", "13");
						ret.put("msg", "未提供查詢Table，請與資訊單位確認");						
					}

				}else{
					ret = new HashMap();
					ret.put("tablename", table);
					ret.put("code", "9");
					ret.put("msg", "未傳入Table名稱，請重新再試");
				}

			}else{
				ret = new HashMap();
				ret.put("code", "4");
				ret.put("msg", "token失效，請重新再試");
			}
					
			JSONObject jsonObject = new JSONObject();
			jsonObject.element("result", ret);

			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(jsonObject.toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();

			doKycllog_update_respdata(timestamp, jsonObject.toString());//更新response data
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		
		arg1.setNextPage(-1);
	}
	
   	public String getODAPI_Cookie(){

    	String tkn = "";
    	JSONObject inputprarm = null;
    	
    	try {
			Map mp = new HashMap();
			mp.put("email_address", "FirstinsODAPI@firstins.com.tw");
			mp.put("password", "password");   		
			inputprarm = JSONObject.fromObject(mp);

			String url = "https://ixt-test-api.firstins.com.tw/login";
			
			URL urlpost = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) urlpost.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");	
			conn.setRequestProperty("CSRF-TOKEN","1");//固定一定要放
			conn.setRequestProperty("Content-Type","application/json;charset=utf-8");
			conn.setRequestProperty("Cookie", "CSRF-TOKEN=1; Path=/; Domain=firstins.com.tw;");//固定一定要放
			conn.setConnectTimeout(10000);
			conn.setReadTimeout(10000);
			
			DataOutputStream os = new DataOutputStream(conn.getOutputStream());
	        os.write(inputprarm.toString().getBytes());
	        os.flush();

	        // 讀取 response data
	        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        String inputLine;
	        StringBuffer responseData = new StringBuffer();
	        while ((inputLine = reader.readLine()) != null) {
	          responseData.append(inputLine);
	        }
//	        reader.close();
	        System.out.println(responseData.toString()); // 印出status

	        List cookies = conn.getHeaderFields().get("Set-Cookie"); // 取得response的cookies	        
	        	 
	        Map respmp = conn.getHeaderFields();
	        String[] cookie_content = (String[]) respmp.get("Set-Cookie").toString().split(";");
	        int countt = cookie_content[0].lastIndexOf("ACCESS-TOKEN=");
	        tkn = cookie_content[0].replace("[ACCESS-TOKEN=", "");
	        
	        Map<String, List<String>> hf = conn.getHeaderFields();

            Iterator it = hf.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pairs = (Map.Entry)it.next();
                System.out.println(pairs.getKey() + " = " + pairs.getValue());
            }
            
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return tkn;
   	}
	
   	public String sendODAPI_member(String tkn){

    	JSONObject inputprarm = null;
    	
    	try {
            //test post members
	        String member_json = "{\"number\": \"M99880015\",\"government_id_type\": \"identity_card\",\"government_id\": \"B196094747\",\"birth_date\": \"05-MAY-77\",\"last_name\": \"林\",\"first_name\": \"測P\",\"full_name\": \"林測P\",\"gender\": \"male\"}";

			String url_member = "https://ixt-test-api.firstins.com.tw/members";

			URL post_member = new URL(url_member);
			HttpURLConnection conn_member = (HttpURLConnection) post_member.openConnection();
			conn_member.setDoOutput(true);
			conn_member.setRequestMethod("POST");
			conn_member.setDoInput(true);	
			conn_member.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36)");//一定要放，騙程式用
			conn_member.setRequestProperty("CSRF-TOKEN","1");//固定一定要放
			conn_member.setRequestProperty("Content-Type","application/json;charset=utf-8");//固定一定要放
			conn_member.setRequestProperty("Cookie", "CSRF-TOKEN=1; ACCESS-TOKEN=" + tkn );//取出的TOKEN放這裡
						
			DataOutputStream os_member = new DataOutputStream(conn_member.getOutputStream());
			os_member.write(member_json.getBytes("UTF-8"));//一定要UTF-8才過得去
			os_member.flush();
			
	        // 讀取 response data
	        BufferedReader reader_1 = new BufferedReader(new InputStreamReader(conn_member.getInputStream()));
	        String inputLine_1;
	        StringBuffer responseData_1 = new StringBuffer();
	        while ((inputLine_1 = reader_1.readLine()) != null) {
	        	responseData_1.append(inputLine_1);
	        }
	        reader_1.close();
	        System.out.println(responseData_1.toString()); // 印出status
            
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return tkn;
   	}
	

   	public String sendODAPI_enduser(String tkn){

    	JSONObject inputprarm = null;
    	
    	try {
            //test post members
	        String enduser_json = "{\"government_id_type\":\"identity_card\",\"government_id\":\"B196094747\",\"birth_date\":\"05-MAY-77\",\"last_name\":\"\u6797\",\"first_name\":\"\u6e2cP\",\"gender\":\"male\",\"nationality_country_id\":29,\"is_guest\":false,\"state\":\"active\",\"is_accept_marketing_material\":true,\"city\":\"\u65b0\u5317\u5e02\",\"district\":\"\u677f\u6a4b\u5340\",\"postal_address_line1\":\"\u6587\u5316\u8def\u4e00\u6bb531\u5df710\u865f5\u6a13\",\"postal_address_line2\":\"\",\"postal_code\":\"24453\",\"platform_id\":1,\"postal_address_country_id\":29,\"locale_id\":1,\"end_user_phones\":[{\"type\":\"mobile\",\"phone_number\":\"+886921999014\",\"is_primary\":true,\"is_verified\":true}],\"end_user_emails\":[{\"email_address\":\"vss999@EXAMPLE.COM\",\"is_primary\":true,\"is_verified\":true}],\"end_user_agreements\":[{\"agreement_id\":1,\"agree_time\":\"10-AUG-21\",\"read_time\":\"10-AUG-21\"}]}";
	        
			String url_member = "https://ixt-test-api.firstins.com.tw/end-users";

			URL post_member = new URL(url_member);
			HttpURLConnection conn_member = (HttpURLConnection) post_member.openConnection();
			conn_member.setDoOutput(true);
			conn_member.setRequestMethod("POST");
			conn_member.setDoInput(true);	
			conn_member.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36)");//一定要放，騙程式用
			conn_member.setRequestProperty("CSRF-TOKEN","1");//固定一定要放
			conn_member.setRequestProperty("Content-Type","application/json;charset=utf-8");//固定一定要放
			conn_member.setRequestProperty("Cookie", "CSRF-TOKEN=1; ACCESS-TOKEN=" + tkn );//取出的TOKEN放這裡
						
			DataOutputStream os_member = new DataOutputStream(conn_member.getOutputStream());
			os_member.write(enduser_json.getBytes("UTF-8"));//一定要UTF-8才過得去
			os_member.flush();
			
	        // 讀取 response data
	        BufferedReader reader_1 = new BufferedReader(new InputStreamReader(conn_member.getInputStream()));
	        String inputLine_1;
	        StringBuffer responseData_1 = new StringBuffer();
	        while ((inputLine_1 = reader_1.readLine()) != null) {
	        	responseData_1.append(inputLine_1);
	        }
	        reader_1.close();
	        System.out.println(responseData_1.toString()); // 印出status
            
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return tkn;
   	}

   	
	private List getAS400Detail(String tableName , Map mp){
		
		List ret = null;
		ret = sendDB2Query(tableName, mp);

		return ret ;
	}
		
	/**
	 * 依傳入的Map取得key/value 組成SQL送出查詢
	 * @param table
	 * @param mp
	 * @return
	 */
	private List sendDB2Query(String table , Map mp){
		List ret = null;
		
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		boolean result = false;
		String[] args = null;
	
		try {
			con = AS400Connection.getConnection();

			String sql = "SELECT * FROM " + table + " WHERE ";
			if(mp != null && mp.size()>0){
				args = new String[mp.size()] ;
				
				Set entryset = mp.entrySet();
				Iterator it = entryset.iterator();
				int i = 0;
				while(it.hasNext()){
		            Map.Entry me = (Entry) it.next();
		            String key = me.getKey().toString().toUpperCase();
		            if(i != 0)
		            	sql += "AND " + key + " = ? ";
		            else
		            	sql += key + " = ? ";
		            
		            String value = me.getValue() != null ? me.getValue().toString() : "";
		            args[i] = value;
		            
		            i++;
				}	
			}			
			
			ret = (List) runner.query(con, sql, args, new TrimedMapListHandler());
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret ; 
	}
	
    /**
     * 寫入KYCLLOG記錄檔處理
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_insert( HttpServletRequest request,String key , String source,String desc){

    	String ll01 = this.getClass().getSimpleName();//進入點程式
    	String ll02 = source;//頁面source
    	String ll03 = desc;//頁面說明
    	String ll04 = "B";
    	String ll05 = "";//客戶身分證字號
    	String ll09 = key;//時間戳記
    	String ll17 = "OD";//動作/檢核項目
    	String ll19 = "";//動作說明/檢核錯誤訊息
    	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, "", "", "", "", "", ll17, "", ll19, "", "", "", "", "");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }

    /**
     * 更新KYCLLOG request data
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_update_reqdata( String key , String reqdata){   	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.update_LL32(key, reqdata);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }

    /**
     * 更新KYCLLOG response data
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_update_respdata( String key , String respdata){   	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.update_LL33(key, respdata);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }
 
}
