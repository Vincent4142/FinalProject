package com.firstins;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.CookieStore;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.net.ssl.SSLContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * @author vsg
 * 傳送OD-API程式
 *
 */
public class SendODAPI extends AsiAction
{	
	private String odurl = "";	
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
	{
   	
	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String apitoken = getODAPI_Token(arg2 , arg3);
		sendLiaNewAPI();
		
		// 取得Header中的token
		String token = arg2.getHeader("Authorization");	
		String source = arg2.getParameter("source") != null ? arg2.getParameter("source").trim() : "";
		// API程式說明
		String desc = source + "-查詢AS400檔案公用程式";
		
		Map ret = null;
		List retlist = null;
		JSONObject inputprarm = null;
		KyctknAction tkn = null;
		
		//時間戳記，做為kycllog的key
		String timestamp = "";
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmssSS");
		timestamp = sdf.format(new Date());		
		//長度不足17碼時用0往右補滿
		if(timestamp.length() != 17)
			timestamp = StringUtils.rightPad(timestamp, 17, "0");

		try
		{
			tkn = new KyctknAction();
			ret = new HashMap();

			// 檢查token
			if(tkn.isTokenVaild(arg2 , token, source , this.getClass().getSimpleName())){
				
				// 讀取Body資料
				StringBuffer json = new StringBuffer();
				String line = null;
				try {
				   BufferedReader reader = arg2.getReader();
				   while((line = reader.readLine()) != null) 
					   json.append(line);
				   
				   doKycllog_insert(arg2, timestamp, source, desc);//寫入kycllog
				   doKycllog_update_reqdata(timestamp, json.toString());//更新requset data
				}
				catch(Exception e) {
					doKycllog_update_respdata(timestamp, e.toString());//更新response data
				}
				inputprarm = JSONObject.fromObject(json.toString());

				//取出"data":{}中的客戶資料
				Map mp = (Map) JSONObject.fromObject(inputprarm.get("data"));
				String table =  inputprarm.get("tablename") != null ? inputprarm.get("tablename").toString() : "";				
				String tablelist = CodeUtil.getCodeList(servlet, arg2, "OD400TABLE");//設定OD系統可以查詢的TABLE名稱
				
				if(!table.equals("")){
					if(tablelist.indexOf(table) != -1){
						retlist = getAS400Detail(table , mp);
						
						if(retlist != null && retlist.size()>0 ){
							ret.put("tablename", table);
							ret.put("data", retlist);					
						}else{
							ret.put("tablename", table);
							ret.put("code", "7");
							ret.put("msg", "查無資料");						
						}
					}else{
						ret = new HashMap();
						ret.put("tablename", table);
						ret.put("code", "13");
						ret.put("msg", "未提供查詢Table，請與資訊單位確認");						
					}

				}else{
					ret = new HashMap();
					ret.put("tablename", table);
					ret.put("code", "9");
					ret.put("msg", "未傳入Table名稱，請重新再試");
				}

			}else{
				ret = new HashMap();
				ret.put("code", "4");
				ret.put("msg", "token失效，請重新再試");
			}
					
			JSONObject jsonObject = new JSONObject();
			jsonObject.element("result", ret);

			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(jsonObject.toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();

			doKycllog_update_respdata(timestamp, jsonObject.toString());//更新response data
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		
		arg1.setNextPage(-1);
	}
	
	private List getAS400Detail(String tableName , Map mp){
		
		List ret = null;
		ret = sendDB2Query(tableName, mp);

		return ret ;
	}
		
	/**
	 * 依傳入的Map取得key/value 組成SQL送出查詢
	 * @param table
	 * @param mp
	 * @return
	 */
	private List sendDB2Query(String table , Map mp){
		List ret = null;
		
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		boolean result = false;
		String[] args = null;
	
		try {
			con = AS400Connection.getConnection();

			String sql = "SELECT * FROM " + table + " WHERE ";
			if(mp != null && mp.size()>0){
				args = new String[mp.size()] ;
				
				Set entryset = mp.entrySet();
				Iterator it = entryset.iterator();
				int i = 0;
				while(it.hasNext()){
		            Map.Entry me = (Entry) it.next();
		            String key = me.getKey().toString().toUpperCase();
		            if(i != 0)
		            	sql += "AND " + key + " = ? ";
		            else
		            	sql += key + " = ? ";
		            
		            String value = me.getValue() != null ? me.getValue().toString() : "";
		            args[i] = value;
		            
		            i++;
				}	
			}			
			
			ret = (List) runner.query(con, sql, args, new TrimedMapListHandler());
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret ; 
	}
	
    /**
     * 寫入KYCLLOG記錄檔處理
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_insert( HttpServletRequest request,String key , String source,String desc){

    	String ll01 = this.getClass().getSimpleName();//進入點程式
    	String ll02 = source;//頁面source
    	String ll03 = desc;//頁面說明
    	String ll04 = "B";
    	String ll05 = "";//客戶身分證字號
    	String ll09 = key;//時間戳記
    	String ll17 = "OD";//動作/檢核項目
    	String ll19 = "";//動作說明/檢核錯誤訊息
    	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, "", "", "", "", "", ll17, "", ll19, "", "", "", "", "");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }

    /**
     * 更新KYCLLOG request data
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_update_reqdata( String key , String reqdata){   	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.update_LL32(key, reqdata);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }

    /**
     * 更新KYCLLOG response data
     * @param request
     * @param source
     * @param uid
     */
    private void doKycllog_update_respdata( String key , String respdata){   	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.update_LL33(key, respdata);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }
 
    
	private String sendLiaNewAPI(){
		
		String NEWLIAVPN_ADDR = "https://ixt-test-api.firstins.com.tw/login";
		String retString = "";
		JSONObject inputprarm = null;
		
	   	try {
			
			Map mp = new HashMap();
			mp.put("email_address", "FirstinsODAPI@firstins.com.tw");
			mp.put("password", "password");
    		
			inputprarm = JSONObject.fromObject(mp);

	   		
			PostMethod postmethod = new PostMethod(NEWLIAVPN_ADDR);
			postmethod.setRequestHeader("CSRF-TOKEN","1");//固定一定要放
			postmethod.setRequestHeader("Content-Type","application/json;charset=utf-8");
		   	postmethod.setRequestBody(inputprarm.toString());

			HttpClient client = new HttpClient();
		   	client.setConnectionTimeout(1000);
		   	client.setTimeout(1000);
		   	client.executeMethod(postmethod);

		   	retString = postmethod.getResponseBodyAsString();		   	
		   	
		} catch (HttpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	
		return retString;
	}
	
	
    /**
     * 取得OD-API的TOKEN
     * @return
     */
    private String getODAPI_Token(HttpServletRequest request , HttpServletResponse resp){
    	String tkn = "";
    	JSONObject inputprarm = null;
    	
    	try {
			Map mp = new HashMap();
			mp.put("email_address", "FirstinsODAPI@firstins.com.tw");
			mp.put("password", "password");
    		
			inputprarm = JSONObject.fromObject(mp);

			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);

			String url = "https://ixt-test-api.firstins.com.tw/login";
			 
//			URL urlpost = new URL(url);
//			URLConnection conn = urlpost.openConnection();
//			conn.setRequestProperty("Cookie", "CSRF-TOKEN=1; Domain=firstins.com.tw");
//			
//			conn.connect();
			
//			org.apache.commons.httpclient.Cookie[] cookie = new Cookie("CSRF-TOKEN", "1"); 
//			cookie.setDomain("firstins.com.tw");
			
//			//使用TLS1.2 Protocol上傳
//			SSLContext sslContext;
//			try
//			{
//				sslContext = SSLContext.getInstance("TLSv1.2");
//				sslContext.init(null, null, new SecureRandom());
//			    SSLContext.setDefault(sslContext);
//			    System.setProperty ("jsse.enableSNIExtension", "false");
//			    
//			} catch (NoSuchAlgorithmException e)
//			{
//				e.printStackTrace();
//			} catch (KeyManagementException e)
//			{
//				e.printStackTrace();
//			} 
			
//			System.setProperty("jdk.tls.client.protocols", "TLSv1.3");
			
			PostMethod postmethod = new PostMethod(url);
		   	postmethod.setRequestHeader("CSRF-TOKEN","1");//固定一定要放
		   	postmethod.setRequestHeader("Content-Type","application/json;charset=utf-8");
//		   	postmethod.setRequestHeader("Set-Cookie","CSRF-TOKEN=1; Path=/; Domain=firstins.com.tw;");
		   	postmethod.setRequestBody(inputprarm.toString());
			
			HttpClient client = new HttpClient();
//			client.getState().addCookies(cookie);
		   	client.setConnectionTimeout(1000);
		   	client.setTimeout(1000);
		   	client.executeMethod(postmethod);
		   	
//		   	org.apache.commons.httpclient.Cookie[] currentCookies = client.getState().getCookies();
//		   	
//		   	String getcookie = postmethod.getResponseHeader("Set-Cookie").getValue();
		   	
//		   	System.out.println(postmethod.getResponseHeader("ACCESS-TOKEN"));
		   	System.out.println(postmethod.getResponseHeader("Set-Cookie"));
		   	
		   	SAXReader reader = new SAXReader();
		    Document doc = reader.read(postmethod.getResponseBodyAsStream());
		    Element out = doc.getRootElement();
    		
		    System.out.println(postmethod.getResponseBodyAsStream());
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	
    	
    	
    	return tkn;
    }
    
}
