/*
 * Created on 2005/3/23
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.asi.kyc.reg.actions;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.Calendar;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.reg.forms.RG1M010f;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.actions.SendLineMessage;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.kyc.sec.actions.kycAction;

/**
 * 網路投保 - 會員註冊
 * 
 * @author vsg
 * @CreateDate 2015/4/17上午 9:31:29
 * @UpdateDate 2015/4/17上午 9:31:29
 * @FileName kyc/com.asi.kyc.reg.actions/RG1M010.java
 * @Purpose
 * 
 */
public class RG1M010 extends kycAction
{

	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(5);
		}
		
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException
	{
		RG1M010f form1 = (RG1M010f) form;
		tx_controller.begin(0);
		RG1M010m model = new RG1M010m(tx_controller, request, form);
		String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
		request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
		model.init();
		
		Calendar tzCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		String getcookie = model.getODAPI_Token(request, response);
		
        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("RG", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("RG", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("RG", "description"));
        request.setAttribute("meta_ogtitle"," ");
        request.setAttribute("meta_ogdescription", " ");

		if(form1.getActionCode() == 6)//進入註冊頁
		{
			String referrerCode = request.getParameter("referrerCode") != null ? request.getParameter("referrerCode") : "";
			request.setAttribute("referrerCode", referrerCode);
			
			String insuranceflag=request.getParameter("insuranceflag") != null ? request.getParameter("insuranceflag") : "";
			if(insuranceflag.equals("Y")){
				request.getSession().setAttribute("insuranceflag","Y");
			}
			
			String uname = "";
			String addr="";
			String email ="";
			try {

				if(request.getParameter("username") != null)
					uname = new String(request.getParameter("username").getBytes("UTF-8"),"UTF-8");;
				if(request.getParameter("address") != null)
					addr= new String(request.getParameter("address").getBytes("UTF-8"),"UTF-8");//request.getParameter("address").getBytes("ISO-8859-1").toString();
				if(request.getParameter("email") != null)
					email= new String(request.getParameter("email").getBytes("UTF-8"),"UTF-8");

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("sent_username", uname);
			request.setAttribute("sent_addr", addr);
			request.setAttribute("sent_email", email);
			
			request.getSession().setAttribute("counts","");//因繼承kycAction，非p1的source會被導回首頁
			saveToken(request);
			form.setNextPage(2);
		}
		else if(form1.getActionCode() == 51)//註冊完成動作
		{
			if(!model.isRegistered(request)){
				
				boolean isRegistertok = model.isRegisterOK(request);
				
				if(isRegistertok)
				{	
					model.dealwithIC01PF();//寫入客戶主檔IC01PF，Trigger自動寫入帳號檔SECAJ；更新客戶主檔
					model.sendRegCompleteMail(request);
					request.setAttribute("USNAME", model.getUsername());
					
					//完成註冊若有填寫推薦人代號則LINE推播通知
					HttpSession session = request.getSession();
					String rg31=(String) session.getAttribute("rg31") != null ? (String) session.getAttribute("rg31") : "";
					if(!rg31.equals("") && rg31.length() > 0){
						if(model.isEmployee(rg31)){
							SendLineMessage slm=new SendLineMessage();
							String user_id=slm.getEmployeeCode(rg31);
							slm.sendLine(user_id, "推薦人通知", "註冊：您已推薦"+ slm.getHiddenName(model.getUsername()) +"會員完成註冊，電銷部愛你");
						}
					}					
					session.removeAttribute("rg31");
					
					if(model.login())
						form.setNextPage(5);
					else
						form.setNextPage(5);
				}
				else{
					form.setNextPage(5);
				}
			}
			else{
				model.login();
				form.setNextPage(5);
			}
		}
		else if(form1.getActionCode() == 7)//OTP輸入正確
		{
			boolean isUpdatetok = model.isConfirmOTP();
			
			if(isUpdatetok)
			{
				model.sendRegConfirmMail(request);
				request.setAttribute("USNAME", model.getUsername());
				form.setNextPage(4);
			}
			else{
				request.setAttribute("MSG", "檔案寫入有問題！請再檢驗資料或電洽02-2371-1357專員服務！");
				form.setNextPage(3);
			}

		}
		else if(form1.getActionCode() == 2)//註冊
		{
			//處理重新整理畫面動作
			if (!isTokenValid(request))
			{
				doAction1(form1, request);
			}
			else{
				//有輸入推薦人代號就紀錄
				if(form1.getRg31() !="" && form1.getRg31() != null){
					HttpSession session = request.getSession();
					session.setAttribute("rg31", form1.getRg31());
				}
				
				boolean isInsertok = model.isInsertSucess();//寫入註冊檔KYCREG
				request.setAttribute("RG1M010f", model.getMainForm());
				//紀錄客戶是否同意行銷(IC01PFA)
				String C01A18= request.getParameter("agreeChk4")== null ? "" : request.getParameter("agreeChk4");
				String id=form1.getUserid();
				boolean exist=model.isExistIC01PFA(id);
				model.updateIC01PFA(id, C01A18, exist);
				
				//更新推薦人代號
				model.generateReferrerCode(form1.getUserid(), request,form1.getByear()+form1.getBmonth()+form1.getBdate());
				
				if(isInsertok){
//					model.dealwithIC01PF();//寫入客戶主檔IC01PF，Trigger自動寫入帳號檔SECAJ；更新客戶主檔
					//簡訊和MAIL都要寄送
					model.sendMobileMsg();//發送OTP-簡訊
					model.sendOTPMail(request);//發送OTP-Email
					
					request.setAttribute("uid", model.getInsertedid());
					request.setAttribute("token", model.getEncryptedkey());
					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
					
					resetToken(request);
					saveToken(request);
					form.setNextPage(3);
				}else{
					request.setAttribute("MSG", "檔案寫入有問題！請再檢驗資料或電洽02-2371-1357專員服務！");
					
					resetToken(request);
					saveToken(request);
					form1.setNextPage(2);	
				}	
			}
		}
		else if(form1.getActionCode() == 21){//重新寄發OTP
			
			boolean isUpdatetok = model.isUpdateOTP();
			if(isUpdatetok){
				if(otpswitch.equals("Y"))
					model.sendMobileMsg();//發送簡訊
				else
					model.sendOTPMail(request);
				
				request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");				
				request.setAttribute("uid", model.getInsertedid());
				request.setAttribute("token", model.getEncryptedkey());
				request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

			}else{
				request.setAttribute("uid", model.getInsertedid());
				request.setAttribute("token", model.getEncryptedkey());
				request.setAttribute("exmin", "0");
			}
			form.setNextPage(3);
		}
		else if(form1.getActionCode() == 8){//進入登入OTP驗證頁面
			String uid=request.getParameter("uidshow");
			String otpkey=request.getParameter("otpkey");
			String phone=request.getParameter("phone");
			String mail=request.getParameter("mail");
			String birthday=request.getParameter("birth");
			
			request.setAttribute("uid", uid);
			request.setAttribute("token", otpkey);
			request.setAttribute("phone", getHiddenPhone(phone));
			request.setAttribute("mail", getHiddenMail(mail));
			request.setAttribute("birthday", birthday);
			form.setNextPage(6);
		}
		else
		{
			doAction1(form, request);
		}
		
	}

    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }
    
    /**
     * 手機隱碼
     * @param phone
     * @return
     */
    private String getHiddenPhone(String phone){
    	String hiddenPhone="";
    	hiddenPhone+=phone.subSequence(0, 2)+"*****"+phone.substring(7);  	
		return hiddenPhone;
    }
    
    /**
     * 信箱隱碼
     * @param mail
     * @return
     */
    private String getHiddenMail(String mail){
    	String hiddenMail="";
    	
    	String[] token = mail.split("@");
    	
    	String firsttxt="";
    	for(int i=0;i<token[0].length();i++){
    		if(i==0 || i==1 ||i==2){
    			firsttxt+=token[0].substring(i,i+1);
    		}
    		else{
    			firsttxt+="*";
    		}
    	}
    	
    	String secondttxt="@"+token[1];
    	
    	hiddenMail+=firsttxt+secondttxt;
    	
		return hiddenMail;
    }

	/**
	 * 初始設定
	 * @param form
	 * @param request
	 * @param model
	 * @throws AsiException
	 */
	private void doAction1(AsiActionForm form, HttpServletRequest request) throws AsiException
	{
		
		saveToken(request);
		
		form.setNextPage(1);
	}

}