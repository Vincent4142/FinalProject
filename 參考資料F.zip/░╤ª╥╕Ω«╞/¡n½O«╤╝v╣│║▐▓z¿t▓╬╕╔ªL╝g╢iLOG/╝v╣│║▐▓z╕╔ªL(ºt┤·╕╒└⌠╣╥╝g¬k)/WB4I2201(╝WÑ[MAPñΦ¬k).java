package com.asi.kyc.wb4.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.Codec;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.wb4.forms.WB4I023f;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * 要保書影像管理補印作業
 * 
 * @author chrislee
 * @Create Date：2018/9/18
 */
public class WB4I2201 extends WebAction 
{	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		
	}
	
	public void doProcess(ActionMapping map, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		WB4I023f form1 = (WB4I023f) form;
		HttpSession session = request.getSession();
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		if (form.getSource().equals("WB4I220p1"))
		{
			String sql = "";// 查詢條件
			String insType = form1.getInsType(); // 取得險種

			if (form.getActionCode() == 5)// 快速查詢
			{
				String s = form1.getText1();
				if (form1.getS1().equals("1"))
					sql = " C202='" + s + "'";
				else if (form1.getS1().equals("2"))
					sql = " C201='" + s + "'";
				else if (form1.getS1().equals("3"))
					sql = " C230 like '" + s + "%'";
				else if (form1.getS1().equals("4"))
					sql = " C248='" + s + "'";
			} 
			else if (form.getActionCode() == 10)// 進階查詢
			{
				if (form1.getStartYMD() != null && !"0".equals(form1.getStartYMD()))
					sql = sql + " C206>=" + form1.getStartYMD();
				if (form1.getEndYMD() != null && !"0".equals(form1.getEndYMD()))
				{
					if (sql.length() > 0)
						sql = sql + " AND ";
					sql = sql + " C206<=" + form1.getEndYMD();
				}
			}

			if (form1.getUserid() != null && form1.getUserid().trim().length() > 0)// 招攬人代號
			{
				if (sql.length() > 0)
					sql = sql + " AND ";
				sql = sql + " C213='" + form1.getUserid() + "' ";
			}
			String ins = "";
			if (insType != null)
			{// 險種查詢
				sql = sql + " AND ";
				if (insType.equals("F"))
				{
					sql = sql + "C203 = 'F' ";
				} 
				else if (insType.equals("OA"))
				{
					ins = isAccidentIns();
					sql = sql + "C204 = 'OGP' ";
				} 
				else if (insType.equals("OL"))
				{
					ins = isLiabilityIns();
					sql = sql + "C203 = 'O' AND C204 NOT IN(" + ins + ") ";
				}
			}
			String querySql = getQuerySql(ui, sql);

			List data = getQueryData(querySql);
			for (int i = 0; i < data.size(); i++)
			{
				Map mapData = (Map) data.get(i);
				String t0d06 = null;
				String c202 = mapData.get("c202") != null ? mapData.get("c202").toString().trim() : null;
				String c233 = mapData.get("c233") != null ? mapData.get("c233").toString().trim() : null;

//              取消掉通路+險種的t0D06的原則
//				if (c202 != null && c233 != null)
//				{
//					t0d06 = c202 + c233;
//					mapData.put("t0d06", t0d06);
//				}
//			
				
				String endDate = mapData.get("c205").toString().trim(); //保單生效日
				
				// 可補印期間 火險為生效日半年內、傷害及責任險為續保到期月份+1個月內。
				KycDateUtil kycobj = new KycDateUtil();
				try
				{
					kycobj.setKycDate(endDate);
				} 
				catch (ParseException e)
				{
					e.printStackTrace();
				}
				
				int c205 = Integer.parseInt(kycobj.getKycDate());
				
				if (insType.equals("F"))
				{
					kycobj.add(KycDateUtil.MONTH, 6);
				}
				else
				{
					kycobj.add(KycDateUtil.MONTH, 1);
				}
				
				int edateAdd30 = Integer.parseInt(kycobj.getKycDate());// 下架日期
				int sysdate = Integer.parseInt(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));// 系統日
				boolean check = false;// 險種下架時間 >= 系統日才可選取
				boolean showbox = false;// 是否顯示勾選列印續保單checkbox							
				if (t0d06 != null)
				{
					check = checkPdf(t0d06, c205);
				}
				if (check)
				{
					showbox = true;
				}
				mapData.put("showbox", String.valueOf(showbox));

				if (mapData.get("c204") != null)// 投保型態
				{
					String c204 = mapData.get("c204").toString().trim();
					mapData.put("C204D", CodeUtil.getCodeDesc(getServlet(), request, "INSUREMODE", c204));
				}

				mapData.put("C208D", FormatUtil.getDecimalFormat(Double.parseDouble(String.valueOf(mapData.get("C208"))), 0));
				mapData.put("C206D", FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD, endDate));
				mapData.put("check", check);
			}
			request.setAttribute("detail", data);
			
			try
			{
				form1.setSql(Codec.encode(querySql));
			} 
			catch (IOException e)
			{
				e.printStackTrace();
			}
			form.setNextPage(2);
		}
		else if (form.getActionCode() == 9)// 尋找檔案
		{
			String sysdate = DateUtil.getSysDate(DateUtil.WestType, DateUtil.Format_YYYYMMDD, false) + DateUtil.getSysTime(); // 系統日
			String ckb[] = form1.getCkb(); // 取得選取資料
			String fileName = sysdate;
			ZipOutputStream zos = null;
			FileOutputStream fos = null;
			String zipUrl = SystemParam.getParam("FILE_FOLDER") + "\\WB4I220\\";// 存放ZIP檔
			final String url = "\\\\nas4\\SignImage\\SignByHy\\"; // nas路徑
			
			if (ckb.length > 1) // 選取多筆保單號碼產生ZIP
			{
				File file = new File(zipUrl, fileName +".zip");
				try
				{
					fos = new FileOutputStream(file);
					zos = new ZipOutputStream(fos);
				} 
				catch (FileNotFoundException e)
				{
					e.printStackTrace();
				}
			}
			
			for (int i = 0; i < ckb.length; i++) // 跑每一份選取保單
			{
				String ckbC201 = ckb[i].toString().trim(); // 保單號碼
				File file = new File(url + ckbC201 + ".pdf");
				if (ckb.length == 1) // 只選取一筆保單
				{
					downloadOnePdf(file, response);
					//寫入KYCLLOG紀錄
					writeKyclog(ckb[i],ui,request,form1);
					break;
				}
				else // 選取多筆保單
				{
					try
					{
						addZipFile(file, zos, file.getName()); // 將找到的PDF包進ZIP
						//寫入KYCLLOG紀錄
						writeKyclog(ckb[i],ui,request,form1);
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
//				for (int k = 0; k < 1; k++)// 迴圈執行三次，往後找2個月的資料夾
//				{
//					File file = new File(url);
//					File[] f1 = file.listFiles(); // 取得資料夾內的PDF
//					if (ckbFind[i] == true)
//						break;
//					for (int j = 0; j < f1.length; j++)
//					{
//						if (f1[j].isDirectory()) 
//							break;
//						if (f1[j].getName().equals(ckbC201 + ".pdf")) // 選取保單比對FTP裡的檔名
//						{
//							ckbFind[i] = true;
//							if (ckb.length == 1) // 只選取一筆保單
//							{
//								downloadOnePdf(f1[j], response);
//								break;
//							} 
//							else // 選取多筆保單
//							{
//								try
//								{
//									addZipFile(f1[j], zos, f1[j].getName()); // 將找到的PDF包進ZIP
//								} 
//								catch (Exception e)
//								{
//									e.printStackTrace();
//								}
//							}
//						}
//					}
//				}
			}
			
			if (ckb.length > 1) // 關閉zos並下載壓縮檔
			{
				try
				{					
					zos.finish();
					zos.close();
					fos.close();
				} 
				catch (IOException e)
				{					
					e.printStackTrace();
				}				
				File file = new File(zipUrl + fileName+".zip");
				downloadOnePdf(file, response);
				file.delete();
			}		
			form.setNextPage(-1);
		}
	}
		
	/**
	 * 下載單筆檔案
	 * @param file
	 * @param response
	 */
	private void downloadOnePdf(File file, HttpServletResponse response)
	{
		try
		{
			response.setContentType("application/octect-stream");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
			response.setContentLength((int) file.length());
			InputStream is = new FileInputStream(file);
			OutputStream os = response.getOutputStream();
			int n = 0;
			while ((n = is.read()) != -1)
			{
				os.write(n);
			}
			is.close();
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		} 
	}
	
	/**
	 * 多筆PDF壓縮
	 * @param file
	 * @param zos
	 * @param fileName
	 * @throws Exception
	 */
	private void addZipFile(File file, ZipOutputStream zos, String fileName)
	{	
		try
		{
			int l = 0;
			FileInputStream fis = new FileInputStream(file);
			ZipEntry entry = new ZipEntry(fileName);
			zos.putNextEntry(entry);
			while ((l = fis.read()) != -1)
			{
				zos.write(l);
			}
			entry = null;
			fis.close();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 取得查詢結果資料
	 * 
	 * @param querySql
	 *            查詢SQL
	 * @return
	 * @throws AsiException
	 */
	private List getQueryData(String querySql) throws AsiException
	{
		Connection con = AS400Connection.getConnection();
		try
		{
			QueryRunner runner = new QueryRunner();			
			List list = (List) runner.query(con, querySql, new TrimedMapListHandler());
			return list;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		} 
		finally 
		{
			AS400Connection.closeConnection(con);
		}
	}
	
	/**
	 * 是否為授權人員(可查詢所有資料)
	 * @param id 查詢人員id
	 * @return
	 * @throws AsiException
	 */
	private boolean isAdminQuery(String id) throws AsiException
	{
		Connection con = AS400Connection.getOracleConnection();
		String sql = "SELECT * FROM SECAZ WHERE CODETYPE='AREAMAN-A' AND CODEID=?";
		try
		{
			QueryRunner runner = new QueryRunner();
			List list = (List) runner.query(con, sql, new String[] { id },
					new MapListHandler());
			if (list.size() > 0)
				return true;
			else
				return false;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		} 
		finally
		{
			AS400Connection.closeConnection(con);
		}
	}
	
	/**
	 * 是否有查詢區域權限
	 * @param id 查詢人員id
	 * @return
	 * @throws AsiException
	 */
	private boolean isAreaQuery(String id) throws AsiException
	{
		Connection con = AS400Connection.getOracleConnection();
		String sql = "SELECT * FROM SECAZ WHERE CODETYPE='REGIOMAN-A' AND CODEID=?";
		try
		{
			QueryRunner runner = new QueryRunner();
			List list = (List) runner.query(con, sql,new String[]{id}, new MapListHandler());
			if(list.size()>0)
				return true;
			else
				return false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
	}
	
	/**
	 * 查詢傷害險
	 * @return
	 * @throws AsiException
	 */
	private String isAccidentIns() throws AsiException
	{
		Connection con = AS400Connection.getConnection();
		String sql = "SELECT P201 FROM EPP2PF WHERE P200 = 'P'";
		String P201 = "";
		try
		{
			QueryRunner runner = new QueryRunner();
			List list = (List) runner.query(con, sql, new MapListHandler());
			for (int i = 0; i < list.size(); i++)
			{
				Map map = (Map) list.get(i);
				P201 = P201 + "'O" + map.get("P201").toString().trim() + "'";
				if (i != (list.size() - 1))
				{
					P201 = P201 + ", ";
				}
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		} 
		finally
		{
			AS400Connection.closeConnection(con);
		}
		return P201;
	}
	
	/**
	 * 查詢責任險
	 * @return
	 * @throws AsiException
	 */
	private String isLiabilityIns() throws AsiException
	{
		Connection con = AS400Connection.getConnection();
		String sql = "SELECT P201 FROM EPP2PF";
		String P201 = "";
		try
		{
			QueryRunner runner = new QueryRunner();
			List list = (List) runner.query(con, sql, new MapListHandler());
			for (int i = 0; i < list.size(); i++)
			{
				Map map = (Map) list.get(i);
				P201 = P201 + "'O" + map.get("P201").toString().trim() + "'";
				if (i != (list.size() - 1))
				{
					P201 = P201 + ", ";
				}
			}		
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getLocalizedMessage());
		} 
		finally
		{
			AS400Connection.closeConnection(con);
		}
		return P201;
	}
	

	/**
	 * 依查詢權限及條件取得查詢SQL
	 * 
	 * @param ui
	 * @param querySql 畫面查詢條件
	 * @return
	 */
	private String getQuerySql(UserInfo ui, String querySql) throws AsiException
	{
		// 登入人員權限
		String userlevel = ui.getInfo("USERLEVEL");
		String userlev = "";
		if (userlevel.equals("2"))
		{
			userlev = " JOIN PSM3PF P ON P.M301 = C213 AND P.M333 = '" + ui.getInfo("COMPANY") + "' ";
		} 
		else if (userlevel.equals("3"))
		{
			userlev = " JOIN PSM3PF P ON P.M301 = C213 AND P.M303 = '" + ui.getInfo("DEPARTMENT") + "' ";
		} 
		else if (userlevel.equals("4"))
		{
			userlev = " JOIN PSM3PF P ON P.M301 = C213 AND P.M303 = '" + ui.getInfo("DEPARTMENT") + "' AND P.M304 = '" + ui.getInfo("DIVISION") + "' ";
		} 
		else if (userlevel.equals("5"))
		{
			userlev = " JOIN PSM3PF P ON P.M301 = C213 AND P.M301 = '" + ui.getUserId() + "' ";
		}
		
		if (isAreaQuery(ui.getUserId()))
		{
			Employee emp = Employee.getEmployee(ui.getUserId());
			userlev = " JOIN PSM3PF P ON P.M301 = C213 AND P.M333 = '" + emp.getArea() + "' ";
		}
		
		if (isAdminQuery(ui.getUserId()))
		{
			userlev = "";
		}

		StringBuffer query = new StringBuffer();
		//加上p2會顯示出來的t0D06
		query.append("SELECT C201,C202,C203,C204,C205,C206,C208,C210,C213,C230,C233,T0D06 ");
		query.append("FROM IC02PF ");
		//t0D06用 保單號碼做JOIN的條件
		query.append("LEFT JOIN PT0DPF ");
		query.append("ON C202 = T0D02 ");
		query.append(userlev);
		if (querySql.trim().length() > 0)
		{
			query.append("WHERE ").append(querySql);
		}
		query.append(" AND C207 = '' ORDER BY C210,C205");

		return query.toString();
	}
	
	/**
	 * 判斷保單是否在NAS
	 * @param c202 保單號碼
	 * @param c205 生效日
	 * @return
	 */
	private boolean checkPdf(String c202, int c205)
	{
		boolean check = false;
		String url = "\\\\nas4\\SignImage\\SignByHy\\";
		File file = new File(url + c202 + ".pdf");
		if (file.exists())
		{
			check = true;
		}
		return check;
	}
	
	/**
	 * 取得對應的保單號碼及通路代號
	 * @param c 條碼號
	 * @return
	 */
	public List<Map> getNum(String c){
		StringBuffer sb=new StringBuffer();
		sb.append("SELECT C202,C233,T0D06 FROM IC02PF INNER JOIN PT0DPF ON C202=T0D02 WHERE T0D06= '").append(c+"'");
		
		List<Map> m=null;
		try {
			tx_controller.begin(1);
			QueryRunner qr = new QueryRunner(); 
			m=(List<Map>)qr.query(tx_controller.getConnection(1), sb.toString(),new TrimedMapListHandler());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return m;
	}
	
	/**
	 * 新增KYCLLOG的資料
	 * @param ckb 畫面上所勾選的保單條碼號
	 * @param ui 使用者號碼
	 * @param request 
	 * @param form1
	 * @return
	 */
	public void writeKyclog(String ckb,UserInfo ui,HttpServletRequest request,WB4I023f form1){		
			//lt條碼號對應的資料(保單號碼、通路代號)
			List<Map> lt=getNum(ckb);
			//保單號碼
			String num=lt.get(0).get("C202").toString();
			//通路代號
			String channel=lt.get(0).get("C233").toString();
			
			KycLogger klg = new KycLogger();
			String urid = ui.getUserId();
		
			//新增
			klg.LoggerWriter2(request, this.getClass().getSimpleName(),
					form1.getSource(), "要保書影像管理補印要保書", "B", urid, "", "", "", "", "",
					"", "", "", "", "PR", "", "資料查詢", num,
					"", "", "", "",ckb,channel);
			
	}
}
