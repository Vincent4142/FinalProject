/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.forms;

import com.asi.common.struts.AsiActionForm;

/**
 * 新保 - 旅平險
 * 
 * @author  ：John
 * @version ：$Revision: 1.1 $ $Date: 2006/02/06 09:05:38 $<br>	
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/web/com/asi/kyc/wb1/forms/WB1M040f.java,v 1.1 2006/02/06 09:05:38 john Exp $  
 * 建立日期	：2005/5/6
 * 異動註記	： 
 * </pre></p>
 */
public class WB1M040f extends AsiActionForm {
    private String t1508; //出生日期

    private String t1509; //性別

    private String t1511; //郵遞區號

    private String t1512; //通訊地址

    private String t1513; //聯絡電話 H

    private String t1514; //聯絡電話 O

    private String t1515; //行動電話

    private String t1516; //Email

    private String t1517; //保險期間起

    private String t1518; //保險期間迄

    private String t1539; //總保費

    private String t1546; //要保人

    private String t1547; //要保人ID

    private String t1548; //與被保險人關係

    private String t1550; //旅遊地區
    private String t15501; //旅遊國家

    private String ta1501; //旅遊目的

    private String ta1502; //交通工具
    
    private String ta1503; //年收入
    
    private String ta1504; //服務單位
    
    private String ta1505; //工作性質
    
    private String[] ta1506; //收入來源
    
    private String ta1506o; //收入來源-其他

    private String[] t1807; //被保險人姓名

    private String[] t1808; //被保險人ID

    private String[] t1813; //受益人姓名

    private String[] t1815; //與受益人的關係

    private String[] t1825; //意外死殘

    private String[] t1826; //意外醫療
    
    private String[] t1822;//要保人與被保人關係

    private String[] t1814;//受益人ID
    
    private String[] t1837;//受益人生日
    
    private String t3004; //所在區域

    private String yearFrom; //保險期間起

    private String monthFrom; //保險期間起

    private String dateFrom; //保險期間起

    private String hourFrom; //保險期間起

    private String yearTo; //保險期間迄

    private String monthTo; //保險期間迄

    private String dateTo; //保險期間迄

    private String totalDays; //天數

    private String headCount; //人數

    private String byear;

    private String bmonth;

    private String bdate;

    private String birthDay;

    private String[] birthYear; //出生年

    private String[] birthMonth; //出生月

    private String[] birthDate; //出生日

    private int[] amount; //保費

    private String UID; //登入id

    private String PWD; //登入密碼

    private String seqnumT; //交易序號

    private String c203; //險別

    private String c204; //險種

    private boolean isNew = false; //
    
    private boolean isAdd;//是否附加個人責任暨旅遊不便
    
    private String entry;//網投網要判斷
    private String input_otp;//輸入otp
    
    private String ismobile;
    private String os;
    private String browser;
    private String bro_version;

    private String ta1507; //要保人電話 
    private String ta1508; //被保險人年收入  
    private String[] ta1509; //被保險人收入來源，複選
    private String ta1509o; //被保險人收入來源-其他
    private String[] ta1510; //被保險人交通工具，複選  
    private String ta1510o; //被保險人交通工具-其他
    private String ta1511;//要保人評估職業
    private String ta1512;//被保險人評估職業
    private String[] ta1513;//投保目的，複選  
    private String ta1513o;//投保目的-其他    
    private String ta1514;//是否投保其他商業險
    private String[] ta1515;//主要經濟者為要保人之，複選  
    private String ta1515o;//主要經濟者為要保人之-其他
    private String t15a8;//要保人年收入
    
    private String t1632_A_per;//每一人個責保費
    private String t1632_B_per;//每一人旅遊不便保費
    private String[] t1828;//死殘保費
    private String[] t1829;//醫療保費
    private String p8101;//費率基準日
    
    private boolean isAddOHS;//是否附加海外突發疾病
    private String[] t1909;//海突保額
    private String[] t1910;//海突保費
    private String t1836;//是否有實支實付
    private String[] t1832;//是否有身心障礙
    
    private String ta1520;//是否投保其他家旅平險
    private String ta1521;//投保其他家家數
    private String ta1522;//投保其他家保額
    
    private String[] t1909pub;//公共交通工具保額
    private String[] t1910pub;//公共交通工具保費
    private String tarea;//投保方案    
    private String t1546A;//要保人英文姓名
    private String t1547A;//要保人護照號碼  
    private String[] t1807A;//被保險人英文姓名
    private String[] t1808A;//被保險人護照號碼
    private String kyc_T1575;//電子保單選項
    private String pjcode;//專案代碼
	private String t1584;//專案代碼，車險活動方案   

	private String kyc_T1582;		//推薦人代碼
	
	public String getKyc_T1582() {
		return kyc_T1582;
	}

	public void setKyc_T1582(String kyc_T1582) {
		this.kyc_T1582 = kyc_T1582;
	}
	
	/**
	 * @return the kyc_T1575
	 */
	public String getKyc_T1575() {
		return kyc_T1575;
	}
	/**
	 * @param kyc_T1575 the kyc_T1575 to set
	 */
	public void setKyc_T1575(String kyc_T1575) {
		this.kyc_T1575 = kyc_T1575;
	}

	/**
	 * @return the pjcode
	 */
	public String getPjcode() {
		return pjcode;
	}

	/**
	 * @param pjcode the pjcode to set
	 */
	public void setPjcode(String pjcode) {
		this.pjcode = pjcode;
	}

	/**
	 * @return the t1584
	 */
	public String getT1584() {
		return t1584;
	}

	/**
	 * @param t1584 the t1584 to set
	 */
	public void setT1584(String t1584) {
		this.t1584 = t1584;
	}

	/**
	 * @return the t1807A
	 */
	public String[] getT1807A() {
		return t1807A;
	}

	/**
	 * @param t1807a the t1807A to set
	 */
	public void setT1807A(String[] t1807a) {
		t1807A = t1807a;
	}

	/**
	 * @return the t1808A
	 */
	public String[] getT1808A() {
		return t1808A;
	}

	/**
	 * @param t1808a the t1808A to set
	 */
	public void setT1808A(String[] t1808a) {
		t1808A = t1808a;
	}

	/**
	 * @return the t1546A
	 */
	public String getT1546A() {
		return t1546A;
	}

	/**
	 * @param t1546a the t1546A to set
	 */
	public void setT1546A(String t1546a) {
		t1546A = t1546a;
	}

	/**
	 * @return the t1547A
	 */
	public String getT1547A() {
		return t1547A;
	}

	/**
	 * @param t1547a the t1547A to set
	 */
	public void setT1547A(String t1547a) {
		t1547A = t1547a;
	}

	/**
	 * @return the tarea
	 */
	public String getTarea() {
		return tarea;
	}

	/**
	 * @param tarea the tarea to set
	 */
	public void setTarea(String tarea) {
		this.tarea = tarea;
	}

	/**
	 * @return the t1909pub
	 */
	public String[] getT1909pub() {
		return t1909pub;
	}

	/**
	 * @param t1909pub the t1909pub to set
	 */
	public void setT1909pub(String[] t1909pub) {
		this.t1909pub = t1909pub;
	}

	/**
	 * @return the t1910pub
	 */
	public String[] getT1910pub() {
		return t1910pub;
	}

	/**
	 * @param t1910pub the t1910pub to set
	 */
	public void setT1910pub(String[] t1910pub) {
		this.t1910pub = t1910pub;
	}

	/**
	 * @return the ta1520
	 */
	public String getTa1520() {
		return ta1520;
	}

	/**
	 * @param ta1520 the ta1520 to set
	 */
	public void setTa1520(String ta1520) {
		this.ta1520 = ta1520;
	}

	/**
	 * @return the ta1521
	 */
	public String getTa1521() {
		return ta1521;
	}

	/**
	 * @param ta1521 the ta1521 to set
	 */
	public void setTa1521(String ta1521) {
		this.ta1521 = ta1521;
	}

	/**
	 * @return the ta1522
	 */
	public String getTa1522() {
		return ta1522;
	}

	/**
	 * @param ta1522 the ta1522 to set
	 */
	public void setTa1522(String ta1522) {
		this.ta1522 = ta1522;
	}

	/**
	 * @return the t1832
	 */
	public String[] getT1832() {
		return t1832;
	}

	/**
	 * @param t1832 the t1832 to set
	 */
	public void setT1832(String[] t1832) {
		this.t1832 = t1832;
	}

	/**
	 * @return the t1836
	 */
	public String getT1836() {
		return t1836;
	}

	/**
	 * @param t1836 the t1836 to set
	 */
	public void setT1836(String t1836) {
		this.t1836 = t1836;
	}

	/**
	 * @return the t1909
	 */
	public String[] getT1909() {
		return t1909;
	}

	/**
	 * @param t1909 the t1909 to set
	 */
	public void setT1909(String[] t1909) {
		this.t1909 = t1909;
	}

	/**
	 * @return the t1910
	 */
	public String[] getT1910() {
		return t1910;
	}

	/**
	 * @param t1910 the t1910 to set
	 */
	public void setT1910(String[] t1910) {
		this.t1910 = t1910;
	}

	/**
	 * @return the isAddOHS
	 */
	public boolean isAddOHS() {
		return isAddOHS;
	}

	/**
	 * @param isAddOHS the isAddOHS to set
	 */
	public void setAddOHS(boolean isAddOHS) {
		this.isAddOHS = isAddOHS;
	}

	/**
	 * @return the t1822
	 */
	public String[] getT1822() {
		return t1822;
	}

	/**
	 * @param t1822 the t1822 to set
	 */
	public void setT1822(String[] t1822) {
		this.t1822 = t1822;
	}

	/**
	 * @return the p8101
	 */
	public String getP8101() {
		return p8101;
	}

	/**
	 * @param p8101 the p8101 to set
	 */
	public void setP8101(String p8101) {
		this.p8101 = p8101;
	}

	/**
	 * @return the t1632_A_per
	 */
	public String getT1632_A_per() {
		return t1632_A_per;
	}

	/**
	 * @param t1632_A_per the t1632_A_per to set
	 */
	public void setT1632_A_per(String t1632_A_per) {
		this.t1632_A_per = t1632_A_per;
	}

	/**
	 * @return the t1632_B_per
	 */
	public String getT1632_B_per() {
		return t1632_B_per;
	}

	/**
	 * @param t1632_B_per the t1632_B_per to set
	 */
	public void setT1632_B_per(String t1632_B_per) {
		this.t1632_B_per = t1632_B_per;
	}

	/**
	 * @return the t1828
	 */
	public String[] getT1828() {
		return t1828;
	}

	/**
	 * @param t1828 the t1828 to set
	 */
	public void setT1828(String[] t1828) {
		this.t1828 = t1828;
	}

	/**
	 * @return the t1829
	 */
	public String[] getT1829() {
		return t1829;
	}

	/**
	 * @param t1829 the t1829 to set
	 */
	public void setT1829(String[] t1829) {
		this.t1829 = t1829;
	}

	/**
	 * @return the t15a8
	 */
	public String getT15a8() {
		return t15a8;
	}

	/**
	 * @param t15a8 the t15a8 to set
	 */
	public void setT15a8(String t15a8) {
		this.t15a8 = t15a8;
	}

	/**
	 * @return the ta1514
	 */
	public String getTa1514() {
		return ta1514;
	}

	/**
	 * @param ta1514 the ta1514 to set
	 */
	public void setTa1514(String ta1514) {
		this.ta1514 = ta1514;
	}

	/**
	 * @return the ta1515
	 */
	public String[] getTa1515() {
		return ta1515;
	}

	/**
	 * @param ta1515 the ta1515 to set
	 */
	public void setTa1515(String[] ta1515) {
		this.ta1515 = ta1515;
	}

	/**
	 * @return the ta1515o
	 */
	public String getTa1515o() {
		return ta1515o;
	}

	/**
	 * @param ta1515o the ta1515o to set
	 */
	public void setTa1515o(String ta1515o) {
		this.ta1515o = ta1515o;
	}

	/**
	 * @return the ta1511
	 */
	public String getTa1511() {
		return ta1511;
	}

	/**
	 * @param ta1511 the ta1511 to set
	 */
	public void setTa1511(String ta1511) {
		this.ta1511 = ta1511;
	}

	/**
	 * @return the ta1512
	 */
	public String getTa1512() {
		return ta1512;
	}

	/**
	 * @param ta1512 the ta1512 to set
	 */
	public void setTa1512(String ta1512) {
		this.ta1512 = ta1512;
	}

	/**
	 * @return the ta1513
	 */
	public String[] getTa1513() {
		return ta1513;
	}

	/**
	 * @param ta1513 the ta1513 to set
	 */
	public void setTa1513(String[] ta1513) {
		this.ta1513 = ta1513;
	}

	/**
	 * @return the ta1513o
	 */
	public String getTa1513o() {
		return ta1513o;
	}

	/**
	 * @param ta1513o the ta1513o to set
	 */
	public void setTa1513o(String ta1513o) {
		this.ta1513o = ta1513o;
	}

	/**
	 * @return the ta1507
	 */
	public String getTa1507() {
		return ta1507;
	}

	/**
	 * @param ta1507 the ta1507 to set
	 */
	public void setTa1507(String ta1507) {
		this.ta1507 = ta1507;
	}

	/**
	 * @return the ta1508
	 */
	public String getTa1508() {
		return ta1508;
	}

	/**
	 * @param ta1508 the ta1508 to set
	 */
	public void setTa1508(String ta1508) {
		this.ta1508 = ta1508;
	}

	/**
	 * @return the ta1509
	 */
	public String[] getTa1509() {
		return ta1509;
	}

	/**
	 * @param ta1509 the ta1509 to set
	 */
	public void setTa1509(String[] ta1509) {
		this.ta1509 = ta1509;
	}

	/**
	 * @return the ta1509o
	 */
	public String getTa1509o() {
		return ta1509o;
	}

	/**
	 * @param ta1509o the ta1509o to set
	 */
	public void setTa1509o(String ta1509o) {
		this.ta1509o = ta1509o;
	}

	/**
	 * @return the ta1510
	 */
	public String[] getTa1510() {
		return ta1510;
	}

	/**
	 * @param ta1510 the ta1510 to set
	 */
	public void setTa1510(String[] ta1510) {
		this.ta1510 = ta1510;
	}

	/**
	 * @return the ta1510o
	 */
	public String getTa1510o() {
		return ta1510o;
	}

	/**
	 * @param ta1510o the ta1510o to set
	 */
	public void setTa1510o(String ta1510o) {
		this.ta1510o = ta1510o;
	}

	/**
	 * @return the ismobile
	 */
	public String getIsmobile() {
		return ismobile;
	}

	/**
	 * @param ismobile the ismobile to set
	 */
	public void setIsmobile(String ismobile) {
		this.ismobile = ismobile;
	}

	/**
	 * @return the os
	 */
	public String getOs() {
		return os;
	}

	/**
	 * @param os the os to set
	 */
	public void setOs(String os) {
		this.os = os;
	}

	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * @param browser the browser to set
	 */
	public void setBrowser(String browser) {
		this.browser = browser;
	}

	/**
	 * @return the bro_version
	 */
	public String getBro_version() {
		return bro_version;
	}

	/**
	 * @param bro_version the bro_version to set
	 */
	public void setBro_version(String bro_version) {
		this.bro_version = bro_version;
	}

	/**
	 * @return the input_otp
	 */
	public String getInput_otp() {
		return input_otp;
	}

	/**
	 * @param input_otp the input_otp to set
	 */
	public void setInput_otp(String input_otp) {
		this.input_otp = input_otp;
	}

	/**
     * 由Hitrust傳回的交易編號
     */
    private String ordernumber;

    /**
     * 由Hitruts傳回的回應碼
     */
    private String retcode;

    /**
     * 由Hitruts傳回的授權碼
     */
    private String authCode;

    
    
    
    
    /**
	 * @return the entry
	 */
	public String getEntry() {
		return entry;
	}

	/**
	 * @param entry the entry to set
	 */
	public void setEntry(String entry) {
		this.entry = entry;
	}

	/**
     * @param t1517 The t1517 to set.
     */
    public void setT1517(String t1517) {
        this.t1517 = t1517;
    }

    /**
     * @return Returns the t1517.
     */
    public String getT1517() {
        return t1517;
    }

    /**
     * @param t1518 The t1518 to set.
     */
    public void setT1518(String t1518) {
        this.t1518 = t1518;
    }

    /**
     * @return Returns the t1518.
     */
    public String getT1518() {
        return t1518;
    }

    /**
     * @param t1550 The t1550 to set.
     */
    public void setT1550(String t1550) {
        this.t1550 = t1550;
    }

    /**
     * @return Returns the t1550.
     */
    public String getT1550() {
        return t1550;
    }

    /**
     * @param yearFrom The yearFrom to set.
     */
    public void setYearFrom(String yearFrom) {
        this.yearFrom = yearFrom;
    }

    /**
     * @return Returns the yearFrom.
     */
    public String getYearFrom() {
        return yearFrom;
    }

    /**
     * @param monthFrom The monthFrom to set.
     */
    public void setMonthFrom(String monthFrom) {
        this.monthFrom = monthFrom;
    }

    /**
     * @return Returns the monthFrom.
     */
    public String getMonthFrom() {
        return monthFrom;
    }

    /**
     * @param dateFrom The dateFrom to set.
     */
    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    /**
     * @return Returns the dateFrom.
     */
    public String getDateFrom() {
        return dateFrom;
    }

    /**
     * @param hourFrom The hourFrom to set.
     */
    public void setHourFrom(String hourFrom) {
        this.hourFrom = hourFrom;
    }

    /**
     * @return Returns the hourFrom.
     */
    public String getHourFrom() {
        return hourFrom;
    }

    /**
     * @param yearTo The yearTo to set.
     */
    public void setYearTo(String yearTo) {
        this.yearTo = yearTo;
    }

    /**
     * @return Returns the yearTo.
     */
    public String getYearTo() {
        return yearTo;
    }

    /**
     * @param monthTo The monthTo to set.
     */
    public void setMonthTo(String monthTo) {
        this.monthTo = monthTo;
    }

    /**
     * @return Returns the monthTo.
     */
    public String getMonthTo() {
        return monthTo;
    }

    /**
     * @param dateTo The dateTo to set.
     */
    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    /**
     * @return Returns the dateTo.
     */
    public String getDateTo() {
        return dateTo;
    }

    /**
     * @param totalDays The totalDays to set.
     */
    public void setTotalDays(String totalDays) {
        this.totalDays = totalDays;
    }

    /**
     * @return Returns the totalDays.
     */
    public String getTotalDays() {
        return totalDays;
    }

    /**
     * @param headCount The headCount to set.
     */
    public void setHeadCount(String headCount) {
        this.headCount = headCount;
    }

    /**
     * @return Returns the headCount.
     */
    public String getHeadCount() {
        return headCount;
    }

    /**
     * @param t1825 The t1825 to set.
     */
    public void setT1825(String[] t1825) {
        this.t1825 = t1825;
    }

    /**
     * @return Returns the t1825.
     */
    public String[] getT1825() {
        return t1825;
    }

    /**
     * @param t1826 The t1826 to set.
     */
    public void setT1826(String[] t1826) {
        this.t1826 = t1826;
    }

    /**
     * @return Returns the t1826.
     */
    public String[] getT1826() {
        return t1826;
    }

    /**
     * @param year The year to set.
     */
    public void setBirthYear(String[] year) {
        this.birthYear = year;
    }

    /**
     * @return Returns the year.
     */
    public String[] getBirthYear() {
        return birthYear;
    }

    /**
     * @param month The month to set.
     */
    public void setBirthMonth(String[] month) {
        this.birthMonth = month;
    }

    /**
     * @return Returns the month.
     */
    public String[] getBirthMonth() {
        return birthMonth;
    }

    /**
     * @param date The date to set.
     */
    public void setBirthDate(String[] date) {
        this.birthDate = date;
    }

    /**
     * @return Returns the date.
     */
    public String[] getBirthDate() {
        return birthDate;
    }

    /**
     * @param amount The amount to set.
     */
    public void setAmount(int[] amount) {
        this.amount = amount;
    }

    /**
     * @return Returns the amount.
     */
    public int[] getAmount() {
        return amount;
    }

    /**
     * @param t1539 The t1539 to set.
     */
    public void setT1539(String t1539) {
        this.t1539 = t1539;
    }

    /**
     * @return Returns the t1539.
     */
    public String getT1539() {
        return t1539;
    }

    /**
     * @return Returns the pWD.
     */
    public String getPWD() {
        return PWD;
    }

    /**
     * @param pwd The pWD to set.
     */
    public void setPWD(String pwd) {
        PWD = pwd;
    }

    /**
     * @return Returns the uID.
     */
    public String getUID() {
        return UID;
    }

    /**
     * @param uid The uID to set.
     */
    public void setUID(String uid) {
        UID = uid;
    }

    /**
     * @param ta1501 The ta1501 to set.
     */
    public void setTa1501(String ta1501) {
        this.ta1501 = ta1501;
    }

    /**
     * @return Returns the ta1501.
     */
    public String getTa1501() {
        return ta1501;
    }

    /**
     * @param ta1502 The ta1502 to set.
     */
    public void setTa1502(String ta1502) {
        this.ta1502 = ta1502;
    }

    /**
     * @return Returns the ta1502.
     */
    public String getTa1502() {
        return ta1502;
    }

    /**
     * @param t1508 The t1508 to set.
     */
    public void setT1508(String t1508) {
        this.t1508 = t1508;
    }

    /**
     * @return Returns the t1508.
     */
    public String getT1508() {
        return t1508;
    }

    /**
     * @param t1509 The t1509 to set.
     */
    public void setT1509(String t1509) {
        this.t1509 = t1509;
    }

    /**
     * @return Returns the t1509.
     */
    public String getT1509() {
        return t1509;
    }

    /**
     * @param t1815 The t1815 to set.
     */
    public void setT1815(String[] t1815) {
        this.t1815 = t1815;
    }

    /**
     * @return Returns the t1815.
     */
    public String[] getT1815() {
        return t1815;
    }

    /**
     * @param t1813 The t1813 to set.
     */
    public void setT1813(String[] t1813) {
        this.t1813 = t1813;
    }

    /**
     * @return Returns the t1813.
     */
    public String[] getT1813() {
        return t1813;
    }

    /**
     * @param t1808 The t1808 to set.
     */
    public void setT1808(String[] t1808) {
        this.t1808 = t1808;
    }

    /**
     * @return Returns the t1808.
     */
    public String[] getT1808() {
        return t1808;
    }

    /**
     * @param t1807 The t1807 to set.
     */
    public void setT1807(String[] t1807) {
        this.t1807 = t1807;
    }

    /**
     * @return Returns the t1807.
     */
    public String[] getT1807() {
        return t1807;
    }

    /**
     * @param t1547 The t1547 to set.
     */
    public void setT1547(String t1547) {
        this.t1547 = t1547;
    }

    /**
     * @return Returns the t1547.
     */
    public String getT1547() {
        return t1547;
    }

    /**
     * @param t1546 The t1546 to set.
     */
    public void setT1546(String t1546) {
        this.t1546 = t1546;
    }

    /**
     * @return Returns the t1546.
     */
    public String getT1546() {
        return t1546;
    }

    /**
     * @param t1516 The t1516 to set.
     */
    public void setT1516(String t1516) {
        this.t1516 = t1516;
    }

    /**
     * @return Returns the t1516.
     */
    public String getT1516() {
        return t1516;
    }

    /**
     * @param t1515 The t1515 to set.
     */
    public void setT1515(String t1515) {
        this.t1515 = t1515;
    }

    /**
     * @return Returns the t1515.
     */
    public String getT1515() {
        return t1515;
    }

    /**
     * @param t1514 The t1514 to set.
     */
    public void setT1514(String t1514) {
        this.t1514 = t1514;
    }

    /**
     * @return Returns the t1514.
     */
    public String getT1514() {
        return t1514;
    }

    /**
     * @param t1513 The t1513 to set.
     */
    public void setT1513(String t1513) {
        this.t1513 = t1513;
    }

    /**
     * @return Returns the t1513.
     */
    public String getT1513() {
        return t1513;
    }

    /**
     * @param t1512 The t1512 to set.
     */
    public void setT1512(String t1512) {
        this.t1512 = t1512;
    }

    /**
     * @return Returns the t1512.
     */
    public String getT1512() {
        return t1512;
    }

    /**
     * @param t1511 The t1511 to set.
     */
    public void setT1511(String t1511) {
        this.t1511 = t1511;
    }

    /**
     * @return Returns the t1511.
     */
    public String getT1511() {
        return t1511;
    }

    /**
     * @param byear The byear to set.
     */
    public void setByear(String byear) {
        this.byear = byear;
    }

    /**
     * @return Returns the byear.
     */
    public String getByear() {
        return byear;
    }

    /**
     * @param bmonth The bmonth to set.
     */
    public void setBmonth(String bmonth) {
        this.bmonth = bmonth;
    }

    /**
     * @return Returns the bmonth.
     */
    public String getBmonth() {
        return bmonth;
    }

    /**
     * @param bdate The bdate to set.
     */
    public void setBdate(String bdate) {
        this.bdate = bdate;
    }

    /**
     * @return Returns the bdate.
     */
    public String getBdate() {
        return bdate;
    }

    /**
     * @param t1548 The t1548 to set.
     */
    public void setT1548(String t1548) {
        this.t1548 = t1548;
    }

    /**
     * @return Returns the t1548.
     */
    public String getT1548() {
        return t1548;
    }

    /**
     * @param t3004 The t3004 to set.
     */
    public void setT3004(String t3004) {
        this.t3004 = t3004;
    }

    /**
     * @return Returns the t3004.
     */
    public String getT3004() {
        return t3004;
    }

    /**
     * @param seqnumT The seqnumT to set.
     */
    public void setSeqnumT(String seqnumT) {
        this.seqnumT = seqnumT;
    }

    /**
     * @return Returns the seqnumT.
     */
    public String getSeqnumT() {
        return seqnumT;
    }

    /**
     * @param c203 The c203 to set.
     */
    public void setC203(String c203) {
        this.c203 = c203;
    }

    /**
     * @return Returns the c203.
     */
    public String getC203() {
        return c203;
    }

    /**
     * @param c204 The c204 to set.
     */
    public void setC204(String c204) {
        this.c204 = c204;
    }

    /**
     * @return Returns the c204.
     */
    public String getC204() {
        return c204;
    }

    /**
     * @param birthDay The birthDay to set.
     */
    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    /**
     * @return Returns the birthDay.
     */
    public String getBirthDay() {
        return birthDay;
    }

    /**
     * @param retcode The retcode to set.
     */
    public void setRetcode(String retcode) {
        this.retcode = retcode;
    }

    /**
     * @return Returns the retcode.
     */
    public String getRetcode() {
        return retcode;
    }

    /**
     * @param ordernumber The ordernumber to set.
     */
    public void setOrdernumber(String ordernumber) {
        this.ordernumber = ordernumber;
    }

    /**
     * @return Returns the ordernumber.
     */
    public String getOrdernumber() {
        return ordernumber;
    }

    /**
     * @param authCode The authCode to set.
     */
    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    /**
     * @return Returns the authCode.
     */
    public String getAuthCode() {
        return authCode;
    }

    /**
     * @param isNew The isNew to set.
     */
    public void setNew(boolean isNew) {
        this.isNew = isNew;
    }

    /**
     * @return Returns the isNew.
     */
    public boolean isNew() {
        return isNew;
    }
    
	/**
	 * 是否附加個人責任暨旅遊不便
	 * @param isAdd
	 */
	public void setAdd(boolean isAdd)
	{
		this.isAdd = isAdd;
	}

    /**
     * 是否附加個人責任暨旅遊不便
     * @return
     */
	public boolean isAdd()
	{
		return isAdd;
	}

	/**
	 * @return the t15501
	 */
	public String getT15501()
	{
		return t15501;
	}

	/**
	 * @param t15501 the t15501 to set
	 */
	public void setT15501(String t15501)
	{
		this.t15501 = t15501;
	}

	/**
	 * @return 年收入
	 */
	public String getTa1503()
	{
		return ta1503;
	}

	/**
	 * @param ta1503 年收入
	 */
	public void setTa1503(String ta1503)
	{
		this.ta1503 = ta1503;
	}

	/**
	 * @return 服務單位
	 */
	public String getTa1504()
	{
		return ta1504;
	}

	/**
	 * @param ta1504 服務單位
	 */
	public void setTa1504(String ta1504)
	{
		this.ta1504 = ta1504;
	}

	/**
	 * @return 工作性質
	 */
	public String getTa1505()
	{
		return ta1505;
	}

	/**
	 * @param ta1505 工作性質
	 */
	public void setTa1505(String ta1505)
	{
		this.ta1505 = ta1505;
	}

	/**
	 * @return 收入來源
	 */
	public String[] getTa1506()
	{
		return ta1506;
	}

	/**
	 * @param ta1506 收入來源
	 */
	public void setTa1506(String[] ta1506)
	{
		this.ta1506 = ta1506;
	}

	/**
	 * @return 收入來源-其他
	 */
	public String getTa1506o()
	{
		return ta1506o;
	}

	/**
	 * @param ta1506o 收入來源-其他
	 */
	public void setTa1506o(String ta1506o)
	{
		this.ta1506o = ta1506o;
	}

	/**
	 * @return the t1814
	 */
	public String[] getT1814() {
		return t1814;
	}

	/**
	 * @param t1814 the t1814 to set
	 */
	public void setT1814(String[] t1814) {
		this.t1814 = t1814;
	}

	/**
	 * @return the t1837
	 */
	public String[] getT1837() {
		return t1837;
	}

	/**
	 * @param t1837 the t1837 to set
	 */
	public void setT1837(String[] t1837) {
		this.t1837 = t1837;
	}
	
	
}
