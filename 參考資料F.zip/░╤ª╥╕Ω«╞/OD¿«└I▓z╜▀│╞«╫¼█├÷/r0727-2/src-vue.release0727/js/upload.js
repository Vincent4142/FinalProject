/*
For upload photos(& preview images) form 
*/

const upload_photos_form = {
  data() {
    return {
      errors: {	// Check image 0 & image 1 
        img0: false,
        img1: false
      },
      // token & accident_id from previous form
      token: null,
      accident_id: null,
      // Image for preview & upload
      preview: {},
      previewstyle: {0:'{}', 1:'{}', 2:'{}', 3:'{}', 4:'{}'},
      image: {}
    }
  },
  methods: {
    checkForm: function (e) {
      /*
      to do... Check image 0/1 present
      */
      // Check image 0
      if ( this.previewstyle[0] == "{}" ) {
        this.errors.img0 = true
      } else {
        this.errors.img0 = false
      }
      // Check image 1
      if ( this.previewstyle[1] == "{}" ) {
        this.errors.img1 = true
      } else {
        this.errors.img1 = false
      }
      /*
      e.preventDefault()
      */
      // Display debug info in console:
      console.log("Data:")
      console.log(this.preview)
      console.log(this.image)
      console.log("Error:")
      console.log(this.errors)
      
      //e.preventDefault()
    },
    previewImage: function(event, image_index) {
      var input = event.target;
      if (input.files) {
        var reader = new FileReader();
        reader.onload = (e) => {
          this.preview[image_index] = e.target.result;
          this.previewstyle[image_index] = { 'backgroundImage' : 'url(' + this.preview[image_index] + ')' }
        }
        this.image[image_index]=input.files[0];
        reader.readAsDataURL(input.files[0]);
      }
    }
  }
}

const upload_form = Vue.createApp(upload_photos_form).mount('#upload_form')
