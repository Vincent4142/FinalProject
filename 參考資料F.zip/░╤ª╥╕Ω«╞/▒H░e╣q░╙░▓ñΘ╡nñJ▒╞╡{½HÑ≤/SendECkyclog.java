package com.kyc.schedule;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.KycWorkDayUtil;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * 電商異常登入(假日登入或平日晚上8點後早上7點前登入)通知
 * @author Vincent
 *
 */
public class SendECkyclog extends AsiAction
{	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		//系統今日
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);	
		//系統前一日
		String sysyesterday=DateUtil.getOffsetDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, sysdate, -1, false);
		//判斷寄信前一日是否為工作日
		String yesterday = KycWorkDayUtil.getOffsetWorkDate("00", sysyesterday, 0);		
		//相同部分的SQL
		String sql="SELECT LL05,M302,LL03,LL02,LL10,LL11,LL21 FROM KYCLLOG "
				+ "LEFT JOIN PSM3PF ON LL05 = M301 "
				+ "WHERE LL03 IN "
				+ "('請款確認與取消授權作業',"
				+ " '保險明細資料頁',"
				+ " '保單號碼確認作業',"
				+ " '訂單資料查詢',"
				+ " '配號列印作業')"
				+ " AND  M303 = '0005' ";
		//判斷是假日的SQL
		if(yesterday.trim().length()==0){
			sql+="AND LL10 = ?";
		}
		//判斷是平日的SQL
		else{
			sql+="AND  (LL10 = ? AND LL11 <  70000) "
					+ "OR (LL10 = ? AND LL11 > 200000)";
		}
		//取得連線	
		Connection con = null;
		List data=null;
		try
		{			
			tx_controller.begin(0);
			con=tx_controller.getConnection(0);	
			QueryRunner qr=new QueryRunner();			
			//是假日
			if(yesterday.trim().length()==0){
				Object[] param={Integer.parseInt(sysyesterday)};
				data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
			}
			//平日
			else{
				Object[] param={Integer.parseInt(sysdate),Integer.parseInt(sysyesterday)};
				data = (List) qr.query(con, sql,param, new TrimedMapListHandler());
			}
			//有資料才寄
			if(data!=null && data.size() != 0){
				sendMail(servlet,request,data);
			}			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);		
	}
	
	//送出郵件方法
	private void sendMail(HttpServlet servlet, HttpServletRequest request,List data)
	{
		try
		{
			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");//寄件者
			
			StringBuffer context=new StringBuffer();
			context.append("<html><head></head><body><table style='border:3px #cccccc solid;' cellpadding='10' border='1'>");
			context.append("<tr><td>員工編號</td><td>姓名</td><td>日期</td><td>時間</td><td>IP</td><td>頁面Source</td><td>動作頁面</td></tr>");
			for(int i=0;i<data.size();i++){
				Map m = (Map) data.get(i);
				context.append("<tr><td>");
				context.append(m.get("LL05")+"</td>");
				context.append("<td>");
				context.append(m.get("M302")+"</td>");
				context.append("<td>");
				context.append(m.get("LL10")+"</td>");
				context.append("<td>");
				context.append(m.get("LL11")+"</td>");//時間部分再確認格式是否OK
				context.append("<td>");
				context.append(m.get("LL21")+"</td>");
				context.append("<td>");
				context.append(m.get("LL02")+"</td>");
				context.append("<td>");
				context.append(m.get("LL03")+"</td></tr>");
			}
			
			context.append("</table></body></html>");
			
			kmu.setMessage(context.toString());//內容
			kmu.setSubject("電商登入信件");//標題
			
			String maillist = CodeUtil.getCodeList(servlet, request, "ECLOG");//代碼檔設定之電商窗口，記得到後台加代碼
			String[] getemail = getAuthManList(maillist);//取得人員email
//			kmu.addTo("w92532@firstins.com.tw");//測試好後改成代碼
//			kmu.addTo("benhsu@firstins.com.tw");//測試好後改成代碼
			kmu.addTo(getemail);
			kmu.sendMail();
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * 取出人員帳號檔email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		List<?> rs = null;
		String[] email = null;
		Connection con = null;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List<?>) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}