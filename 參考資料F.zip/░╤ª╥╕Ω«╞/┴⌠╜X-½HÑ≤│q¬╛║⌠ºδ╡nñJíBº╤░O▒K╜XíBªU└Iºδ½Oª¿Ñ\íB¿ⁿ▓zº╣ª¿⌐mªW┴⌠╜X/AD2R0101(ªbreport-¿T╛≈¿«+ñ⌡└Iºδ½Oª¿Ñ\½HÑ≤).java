/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.asi.kyc.ad2.actions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.table.TableModel;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.ReportParameter;
import com.asi.kyc.common.ReportProvider;
import com.asi.kyc.common.ResultSetDataSource;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.TrimedMapHandler;

/**
 * 車險要保書列印
 * 
 * @author  ：YiChuan
 * @version ：$Revision: 1.2 $ $Date: 2006/05/17 12:22:04 $<br>	
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC_Report2/JavaSource/com/asi/kyc/ad2/actions/AD2R0101.java,v 1.2 2006/05/17 12:22:04 john Exp $  
 * 建立日期	：2005/6/1
 * 異動註記	：2006/05/16  John  增加火險要保書列印
 * 			 2019/08/14  vsg  修改網投車險/住火投保完成時都共用這個發送EMAIL功能
 * </pre></p>
 */
public class AD2R0101 extends AsiAction { //之後要再修改,自行寫一個reportAction讓Action程式繼承,然後要做Session的控制
    private byte[] pdf = null; //合併所有保單的pdf檔   

    private Connection conn = null;

    private Locale locale = null;

    private UserInfo userInfo = null;

    private static Log logger = LogFactory.getLog(AD2R0101.class);
    
    private ArrayList rows = null;
    
    private List row_A = null;
    
    private List row_C2 = null;
    
    private String clientName = "";
    
    private List reportList = null;
    
    private String pwd = null;

    public void doProcess(ActionMapping map, AsiActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws AsiException {
    	String[] index = request.getParameterValues("select");
     	String[] T1501 = request.getParameterValues("KYC_T1501a");
    	String[] T1503 = request.getParameterValues("KYC_T1503a");
    	String[] T1542 = request.getParameterValues("KYC_T1542a");
        String source = request.getParameter("source") != null ? request.getParameter("source") : "";
        String sourcepg = request.getParameter("sourcepg") != null ? request.getParameter("sourcepg") : "";
		String emailaddr = request.getParameter("email") != null ? request.getParameter("email") : "";
		String entry = request.getParameter("entry") != null ? request.getParameter("entry") : "";
		String websign = request.getParameter("websign") != null ? request.getParameter("websign") : "N";
		String insName = "";
		String channelName = "";
		String remarkName = "";
		
        if (source.equals("AD2I010p1")) {  //車險   來自 後台列印查詢-車險要保書列印  sourcepg="B2E" 確認要保後
            source = "AD2R010"; //車險   
        } else if (source.equals("AD2I060p1") || source.equals("WB1M050p6")) {  //火險   來自 後台列印查詢-火險要保書列印  sourcepg=null  確認要保後
            source = "AD2R030"; //火險
        }
        
    	if (sourcepg != null && sourcepg.equals("B2C"))// sourcepg="B2C" 確認要保前車險
     	   source = "AD2R010";
        
        if (sourcepg != null && sourcepg.equals("B2C_fire"))// sourcepg="B2C_fire" 確認要保前火險
           source = "AD2R030"; //火險

        //險種說明
        if(source.equals("AD2R010"))
        	insName = "車險";
        else if(source.equals("AD2R030"))
        	insName = "住宅火險";       
        
        //要保或投保說明
        if(entry.equals("1"))
        	channelName = "投保";
        else if(entry.equals("2"))
        	channelName = "要保";
        
		int choiceRows = index.length;
		String[][] choiceReport = new String[choiceRows][];

		for(int i=0 ; i<choiceRows ; i++ ){
		    int x = Integer.parseInt(index[i])-1;
		    choiceReport[i] = new String[]{T1501[x],T1503[x],T1542[x]};
		}       

        if (choiceReport.length <= 0)
            throw new UserException("沒有選擇保單,請重新操作");

        tx_controller.begin(0);
        conn = tx_controller.getConnection(0);
        locale = tx_controller.getUserLocale();
        userInfo = tx_controller.getUserInfo();
        
        reportList = new ArrayList();
        
        //處理報表格式
        callReportObject(choiceReport, servlet, source , sourcepg, websign );
        response.setContentType("application/pdf");
        response.setHeader("Content-disposition", "attachment; filename=report.pdf");            

		File file = null;
		FileOutputStream fos = null;
		EmailAttachment attachment = null;
		HtmlEmail email = null;
		int error = 0;
		String insno = "";

		insno = choiceReport[0][0];

		//有傳入email時用郵件寄發，若無直接列印
		if(emailaddr != null && !emailaddr.equals(""))
		{				
			try
			{
				if (reportList != null) {
				
					file = new File(servlet.getServletContext().getRealPath("/") + insno + ".pdf");
					fos = new FileOutputStream(file);
					
					pdf = exportReport(sourcepg, pwd);

					fos.write(pdf, 0, pdf.length);
					fos.flush();
					fos.close();
									
					// 郵件附加檔
					attachment = new EmailAttachment();
					attachment.setPath(file.getPath());
					attachment.setDisposition(EmailAttachment.ATTACHMENT);
					attachment.setName(insno + ".pdf");

		        }
				
				// 郵件主體
				email = new HtmlEmail();
				KycMailUtil kmu = new KycMailUtil();
				email.setMailSession(kmu.getMailSession());
				email.addTo(emailaddr);// 收件人
				email.addBcc("admin@firstins.com.tw");
				
				if(source.equals("AD2R010") && entry.equals("2") && !choiceReport[0][1].equals("A"))
					if ("Y".equals(websign))
						remarkName = "(已完成線上簽名及回傳要保書，附件為含簽名檔要保書)";
					else
						remarkName = "(非公司車可線上完成簽名及回傳要保書)";

				// 主旨註明是否為測試信
				if (SystemParam.getParam("ENV").equals("KYC"))
					email.setSubject("第一產物保險-" + insName + channelName + "確認通知" + remarkName);
				else
					email.setSubject("【測試】第一產物保險-" + insName + channelName + "確認通知" + remarkName);

				email.setFrom("admin@firstins.com.tw");// 寄件人
				
				//網路要保，且商品代號不為M01單機車強制，C01單汽車強制時，才加入要保書為附件
				if(entry.equals("2"))
				{
					if(!choiceReport[0][1].equals("A"))
						email.attach(attachment);
				}
				email.setCharset("UTF-8");
				email.setHtmlMsg(getMessageContent(request , insno , entry , source , insName , choiceReport[0][1] , websign ));//郵件內文
				email.send();
				logger.info("交易序號：" + insno + "，確認通知信寄發成功！");					
			}
			catch (IOException ioe)
			{
				error++;
				throw new UserException("輸出報表資料時發生錯誤! " + ioe + "交易序號：" + insno);
			}
			catch (EmailException ee)
			{
				error++;
				throw new UserException("Email發送錯誤! " + ee + "交易序號：" + insno);
			}
			catch (Exception e)
			{
				error++;
				throw new UserException("Email發送錯誤! " + e + "交易序號：" + insno);
			}
			finally
			{
				if(file!=null && file.exists())
					file.delete();
				try
				{
					response.setContentType("text/xml;charset=UTF-8");
					response.setHeader("Cache-Control", "no-cache");
					response.getWriter().write("<?xml version=\"1.0\" ?>");
					response.getWriter().write("<out>");
					response.getWriter().write("<mailstatus>");
					response.getWriter().write(error>0?"Email寄發有誤，請聯絡服務專員！":"確認信寄發成功!");
					response.getWriter().write("</mailstatus>");
					response.getWriter().write("</out>");
					
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
			
		}
		else{
	        if (reportList != null) {
	        	try {
	                OutputStream os = response.getOutputStream();
					
					pdf = exportReport(sourcepg, pwd);

	                os.write(pdf, 0, pdf.length);
	                os.flush();
	            } catch (IOException ioe) {
	                throw new UserException("輸出報表資料時發生錯誤! " + ioe);
	            }

	        } else {
	            throw new UserException("報表產生失敗");
	        }
		}
		
		rows = null;
		row_A = null;
		row_C2 = null;
			
        form.setNextPage(-1);
    }

    /**
     * 最後輸出報表文件
     * @param sourcepg
     * @param pwd
     * @return
     */
    private byte[] exportReport(String sourcepg , String pwd){
    	
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
		JRPdfExporter pdf1 = new JRPdfExporter();
		pdf1.setParameter(JRPdfExporterParameter.JASPER_PRINT_LIST, reportList);
		pdf1.setParameter(JRPdfExporterParameter.OUTPUT_STREAM, baos);
		
		//B2C來源及有密碼時，PDF加密
		if(sourcepg.equals("B2C") && pwd != null){
			pdf1.setParameter(JRPdfExporterParameter.IS_ENCRYPTED, Boolean.TRUE);
			pdf1.setParameter(JRPdfExporterParameter.IS_128_BIT_KEY, Boolean.TRUE);
			pdf1.setParameter(JRPdfExporterParameter.USER_PASSWORD, pwd);
			pdf1.setParameter(JRPdfExporterParameter.OWNER_PASSWORD, pwd);
		}

		try {
			pdf1.exportReport();
		} catch (JRException e) {
			e.printStackTrace();
		}
		
		pdf = baos.toByteArray();    	
    	
		return pdf;
    }
    
    public void callReportObject(String[][] choiceReport, HttpServlet servlet, String source ,String sourcepg, String websign ) throws AsiException {
		int reportCount = choiceReport.length; //勾選的交易序號       
		for (int i = 0; i < reportCount; i++) {
			//0:勾選的交易序號, 1:險別, 2:續保單號
			getReport(choiceReport[i][0], choiceReport[i][1], choiceReport[i][2], servlet, source , sourcepg, websign );
		}
	}

    public void getReport(String insNumber, String reportType , String continuePolicyNum , HttpServlet servlet , String source , String sourcepg, String websign ) throws AsiException {
	    TableModel tm = null;
        
        //車險
        if ("AD2R010".equals(source)) {	
            AD2R010 ad2r010 = new AD2R010(insNumber,reportType,continuePolicyNum,conn,locale,servlet,userInfo);
            ad2r010.setSourcepg(sourcepg);
			if(!reportType.equals("A"))//t1503險別：A-強制 ；C1-任意1年,C2-駕傷1或2年
				tm = ad2r010.getTableModel();
						
			//強制險明細顯示用
			row_A = ad2r010.getRow_A();
			//C1任意險明細顯示用
			if(reportType.equals("C1"))
				rows = ad2r010.getRows();
			//C2駕傷險明細顯示用
			if(reportType.equals("C2"))
				row_C2 = ad2r010.getRow_C2();

        }
        
        //火險
        else if ("AD2R030".equals(source)) {
            AD2R0301 ad2r0301 = new AD2R0301();
            tm = ad2r0301.getTableModel(conn, insNumber, sourcepg);
            rows = ad2r0301.getRows();
        }
       	
        if(tm != null){
        	JRDataSource ds = ResultSetDataSource.build(tm);
        	createReportList(ds, source, insNumber, servlet, locale, reportType, continuePolicyNum, tm, sourcepg, websign);
        }
    	
    }
       
    /**
     * 產生報表list
     * @param ds
     * @param key
     * @param insNumber
     * @param servlet
     * @param locale
     * @param reportType
     * @param continuePolicyNum
     * @param tm
     * @param sourcepg
     */
    public void createReportList (JRDataSource ds, String key, String insNumber,HttpServlet servlet, Locale locale, String reportType,String continuePolicyNum, TableModel tm ,String sourcepg, String websign )
    {
    	String img = null;
    	JasperPrint jpP1 = null;
    	
	    try {
	    	
	        img = ReportProvider.getImage("Logo.gif");
	        HashMap param = ReportParameter.getParam(conn, key, insNumber, servlet,locale, reportType, "",continuePolicyNum , sourcepg );
	        param.put("image", img);
	        if ("Y".equals(websign))
	        	param.put("imagesign", getImageSign(conn, insNumber));
	        else
	        	param.put("imagesign", null);
	        int rowCount = 0;
	        if (tm != null) {
	            rowCount = tm.getRowCount();
	        }

	        param.put("rowCount", new Integer(rowCount));
	        param.put("number", insNumber);
	        
	        if(sourcepg.equals("B2C"))
	        	pwd = param.get("T1507").toString();
	        
	        InputStream is = ReportProvider.getReport(key);
	                
			jpP1 = JasperFillManager.fillReport(is, param , ds);
			reportList.add(jpP1);
	                                    
	    } catch (JRException jre) {
            jre.printStackTrace();
	        logger.error("報表編譯失敗", jre);
	    } catch (IOException ioe) {
            ioe.printStackTrace();
	        logger.error("報表轉PDF時失敗", ioe);
	    }

    }
    
    public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1,
        HttpServletRequest arg2, HttpServletResponse arg3)
        throws IOException, ServletException {
    	
        return null;
    }

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3)
	{
		AsiActionForm f = (AsiActionForm) arg1;
		f.setActionCode(GlobalKey.ACTION_SELECT);
	}
    
    protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException {
    }
    
	/**
	 * 組Email內容
	 * @param request
	 * @param number	交易序號
	 * @param entry		投保/要保
	 * @param source	前後台
	 * @param insName	保險名稱
	 * @param t1502		商品代號
	 * @return
	 */
	public String getMessageContent(HttpServletRequest request , String number , String entry , String source , String insName , String t1503, String websign ) {
	              
        //組保險內容
        String html = getInsDetail(source , number);
        
        //顯示或隱藏設定
        String text_display = "";
        if(entry.equals("1")){//網路投保不用列印要保書
        	text_display = "display: none;";
        }	
        else{//網路要保，若僅投保強制不用列印要保書，用商品代號判斷
        	if(t1503.equals("A") || "Y".equals(websign))
        		text_display = "display: none;";
        }
        
        String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
        String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
        String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商接收Email
        
        String sign_ref = "https://kyctest.firstins.com.tw/kyc/WebSign.do?token=" + getDesEncryptString(number); // 網址
        if (SystemParam.getParam("ENV").equals("KYC"))
        	sign_ref = "https://ec.firstins.com.tw/kyc/WebSign.do?token=" + getDesEncryptString(number); // 網址
        
		// 郵件內文樣本
		Template t;
		StringWriter sw = null;
		
		try {
			
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
			ve.init();
			if(source.equals("AD2R010"))
				t = ve.getTemplate("report/mail/InsurancesOrderCarOK.html", "utf-8");
			else
				t = ve.getTemplate("report/mail/InsurancesOrderOK.html", "utf-8");
			
			// 內文使用變數
			VelocityContext context1 = new VelocityContext();
			//姓名隱碼
			StringBuffer hiddenName = new StringBuffer();
			for(int i=0;i<clientName.length();i++){
				if(i==1){
					hiddenName.append("O");
				}
				else{
					hiddenName.append(clientName.substring(i,i+1));
			   	}
			}
			context1.put("name" , hiddenName.toString());//姓名
			context1.put("serialnum" , number);//交易序號
			context1.put("insurancecontent" , html);//投保內容
			context1.put("dsp-hidden" , text_display);//是否需要列印要保書說明文字的顯示控制
			context1.put("ecom-tel" , ecom_tel);//服務電話
			context1.put("ecom-fax" , ecom_fax);//傳真電話
			context1.put("ecom-email" , ecom_email);//客服信箱
			if(source.equals("AD2R010"))
				context1.put("sign-ref" , sign_ref);//行動簽署
			
			sw = new StringWriter();
			t.merge(context1, sw);
			
		} catch (ResourceNotFoundException e) {
			e.printStackTrace();
		} catch (ParseErrorException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return sw.getBuffer().toString();
	}

	/**
	 * 組Email投保明細資料
	 * @param source
	 * @return
	 */
	private String getInsDetail(String source , String number){
		StringBuffer html = new StringBuffer();
		
		String insName_A = "";
		String strdate_A = "";
		String edndate_A = "";
		String deatAmount_A = "";
		String medicalAmount_A = "";
		int premium_A = 0;
		
		String strdate_C = "";
		String edndate_C = "";
				
		int totoalPremium = 0;
		
		try {
			
			//車險，組投保明細畫面
			if(source.equals("AD2R010")){
				html.append("<table class='innertable' border='1' width='100%'>");
				html.append("	<tr>");
				html.append("		<th>保險期間</th>");
				html.append("		<td colspan='2'>");
				
				if(row_A != null && row_A.size() > 0){
					
					for (int i = 0; i < row_A.size(); i++) {
						Map mp = (Map) row_A.get(i);
						
						if(mp.get("T1503").equals("A")){
							insName_A = mp.get("T1705").toString() + "  " +mp.get("PT01").toString() ;//強制代號+險種名稱
							strdate_A = mp.get("T1517") != null ? mp.get("T1517").toString().substring(0, 3) + " 年 " + mp.get("T1517").toString().substring(3, 5) + " 月 " + mp.get("T1517").toString().substring(5, 7) + "日" : "";
							edndate_A = mp.get("T1518") != null ? mp.get("T1518").toString().substring(0, 3) + " 年 " + mp.get("T1518").toString().substring(3, 5) + " 月 " + mp.get("T1518").toString().substring(5, 7) + "日" : "";
							deatAmount_A = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("T1709").toString()) , 0);
							medicalAmount_A = FormatUtil.getDecimalFormat(Double.parseDouble(mp.get("T1708").toString()) , 0);
							
							html.append("強制險或駕傷險起保日：自 ");
							html.append(strdate_A).append(" 十二時起 至").append(edndate_A).append(" 十二時止<br />");
							
							premium_A = Integer.parseInt(mp.get("T1541").toString());
							totoalPremium += premium_A;
						}
						
						if(mp.get("T1503").equals("C1")){
							strdate_C = mp.get("T1517") != null ? mp.get("T1517").toString().substring(0, 3) + " 年 " + mp.get("T1517").toString().substring(3, 5) + " 月 " + mp.get("T1517").toString().substring(5, 7) + "日" : "";
							edndate_C = mp.get("T1518") != null ? mp.get("T1518").toString().substring(0, 3) + " 年 " + mp.get("T1518").toString().substring(3, 5) + " 月 " + mp.get("T1518").toString().substring(5, 7) + "日" : "";
							html.append("任意險起保日：自 ");
							
							html.append(strdate_C).append(" 十二時起 至").append(edndate_C).append(" 十二時止");
						}
						
						//放入被保險人姓名
						clientName = mp.get("T1506") != null ? mp.get("T1506").toString() : "";
					}

				}
				
				html.append("	</tr>");
				html.append("	<tr align='center'>");
				html.append("		<th>要保項目</th>");
				html.append("		<th>投保內容</th>");
				html.append("		<th>直接投保<br />優惠保費</th>");
				html.append("	</tr>");
				
				if(row_A != null && row_A.size() > 0){
					for (int i = 0; i < row_A.size(); i++) {
						Map mp = (Map) row_A.get(i);

						if(mp.get("T1503").equals("A"))
						{
							html.append("	<tr align='center'>");
							html.append("		<td>").append(insName_A).append("</td>");
							html.append("		<td>傷害醫療 ").append(medicalAmount_A).append(" ， 死亡及失能 最高").append(deatAmount_A).append("</td>");
							html.append("		<td>").append(premium_A).append("</td>");
							html.append("	</tr>");
						}
					}
				}
				
				//取用TableModel的ArrayList內容作任意險明細
				if(row_C2 != null && !row_C2.isEmpty()){
					
			    	Object[] tempRows = row_C2.toArray();
			    	Object[][] rowMap = new Object[tempRows.length][];
			    	for(int i = 0; i < tempRows.length; i++){
			    		rowMap[i] = (Object[])tempRows[i];

			    		String arr1 = (String) rowMap[i][0];//要保項目
			    		String arr2 = (String) rowMap[i][1];//投保內容
			    		String arr3 = (String) rowMap[i][2];//保額
			    		String arr5 = (String) rowMap[i][4];//保費
			    		
			    		//保費加總
						totoalPremium += Integer.parseInt(arr5 != null && !arr5.equals("") ? arr5.replace(",", "") : "0");
										
						html.append("	<tr align='center'>");
						
						//要保項目
						if(i > 0 && rowMap[i-1][0].equals(rowMap[i][0]))//若前1項與本項一樣時，顯示空白
							html.append("		<td>").append("").append("</td>");
						else
							html.append("		<td>").append(arr1).append("</td>");
						
						//投保內容，47,48另外給說明同強制
						if(arr1.indexOf("47") != -1 || arr1.indexOf("48") != -1)
							html.append("		<td>").append("單一事故保障，保額同強制險").append("</td>");
						else
							html.append("		<td>").append(arr2).append("  ").append(arr3).append("</td>");
						
						//保費
						html.append("		<td>").append(arr5).append("</td>");
						html.append("	</tr>");
			    	}

				}

				//取用TableModel的ArrayList內容作任意險明細
				if(rows != null && !rows.isEmpty()){
					
			    	Object[] tempRows = rows.toArray();
			    	Object[][] rowMap = new Object[tempRows.length][];
			    	for(int i = 0; i < tempRows.length; i++){
			    		rowMap[i] = (Object[])tempRows[i];

			    		String arr1 = (String) rowMap[i][0];//要保項目
			    		String arr2 = (String) rowMap[i][1];//投保內容
			    		String arr3 = (String) rowMap[i][2];//保額
			    		String arr5 = (String) rowMap[i][4];//保費
			    		
			    		//保費加總
						totoalPremium += Integer.parseInt(arr5 != null && !arr5.equals("") ? arr5.replace(",", "") : "0");
										
						html.append("	<tr align='center'>");
						
						//要保項目
						if(i > 0 && rowMap[i-1][0].equals(rowMap[i][0]))//若前1項與本項一樣時，顯示空白
							html.append("		<td>").append("").append("</td>");
						else
							html.append("		<td>").append(arr1).append("</td>");
						
						//投保內容，47,48另外給說明同強制
						if(arr1.indexOf("47") != -1 || arr1.indexOf("48") != -1)
							html.append("		<td>").append("單一事故保障，保額同強制險").append("</td>");
						else
							html.append("		<td>").append(arr2).append("  ").append(arr3).append("</td>");
						
						//保費
						html.append("		<td>").append(arr5).append("</td>");
						html.append("	</tr>");
			    	}

				}
				
				html.append("	<tr align='center'>");
				html.append("		<td colspan='2' align='right'>合計：</td>");
				html.append("		<td class='text-lightred'><strong>").append(FormatUtil.getDecimalFormat(totoalPremium,0)).append("</strong></td>");
				html.append("	</tr>");
				html.append("	<tr>");
				html.append("		<td colspan='3' align='right'>幣別：新台幣元</td>");
				html.append("	</tr>");
				html.append("</table>");

			}else if(source.equals("AD2R030")){//火險，組明細資料				
				Map mp = getFireIns(number);
				clientName = mp.get("T1506").toString();
				html.append(getFireContent(mp));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
						
		return html.toString();
	}
	
	
	/**
	 * 查詢住宅火險保險明細
	 * @param number
	 * @return
	 */
	private Map getFireIns(String number){		
		String sql = "SELECT * FROM KYCKLA LEFT JOIN KYCKLB ON T1601=T1501 AND T1602=T1502 AND T1603=T1503 WHERE T1501=? ";
		
		String[] arg = new String[1];
		arg[0] = number;

		Connection con = null;
		Map m = null;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			m = (Map) runner.query(con , sql,arg, new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

		return m;
	}
	
    /**
     * 組住火保險明細內容
     * @param mp
     * @return
     * @throws AsiException
     */
    private String getFireContent(Map mp) throws AsiException {
    	
		String strdate_F = mp.get("T1517") != null ? mp.get("T1517").toString().substring(0, 3) + " 年 " + mp.get("T1517").toString().substring(3, 5) + " 月 " + mp.get("T1517").toString().substring(5, 7) + " 日" : "";
		String edndate_F = mp.get("T1518") != null ? mp.get("T1518").toString().substring(0, 3) + " 年 " + mp.get("T1518").toString().substring(3, 5) + " 月 " + mp.get("T1518").toString().substring(5, 7) + " 日" : "";
		
        StringBuffer buf = new StringBuffer();
        
        buf.append("<table class='innertable' border='1' width='100%'>");
        buf.append("	<tr>");
        buf.append("		<th>保險期間</th>");
        buf.append("		<td>").append(strdate_F).append(" 十二時起 至 ").append(edndate_F).append(" 十二時止").append("</td>");
        buf.append("	</tr>");
        
        buf.append("	<tr><th>投保項目</th><th>保額/投保內容</th></tr>");
        buf.append("	<tr>");
        buf.append("		<td align='center'>住宅火險保額</td>");
        buf.append("		<td>").append(FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1558").toString()),0)).append("</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>建築物內動產保額</td>");
        buf.append("		<td>").append(FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1628").toString()),0)).append("</td>");
        buf.append("	</tr>");
        
        buf.append("	<tr>");
        buf.append("		<td align='center'>地震基本險保額</td>");
        buf.append("		<td>").append(FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1559").toString()),0)).append("</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>住宅第三人責任基本保險保額</td>");
        buf.append("		<td>");
        buf.append("			每一個人體傷 1,000,000<br/>");
        buf.append("			每一個人死亡 2,000,000<br/>");
        buf.append("			每一意外事故體傷及死亡 10,000,000<br/>");
        buf.append("			每一意外事故財損 2,000,000<br/>");
        buf.append("			保險期間內最高賠償金額 24,000,000<br/>");
        buf.append("			每一意外事故自負額： 體傷為 2,000 財損為 10,000");
        buf.append("		</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>住宅玻璃保險保額</td>");
        buf.append("		<td>");
        buf.append("			每一次事故賠償金額 10,000<br/>");
        buf.append("			保險期間內累計賠償金額最高 20,000<br/>");
        buf.append("			每一事故自負額： 1,000");
        buf.append("		</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>竊盜保額</td>");
        buf.append("		<td>");
        buf.append("			每一次竊盜事故賠償金額 150,000<br/>");
        buf.append("			保險期間內累計賠償金額最高 300,000<br/>");
        buf.append("			每一事故自負額： 5,000");
        buf.append("		</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>住宅颱風及洪水災害補償</td>");
        buf.append("		<td>");
        buf.append("			本保險契約自動承保住宅颱風及洪水災害補償保險，<br/>");
        buf.append("			其賠償限額依保單條款約定之");
        buf.append("		</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='center'>加保續保約定</td>");
        buf.append("		<td>");
        buf.append("Y".equals(mp.get("T15A9") != null ? mp.get("T15A9").toString() : "") ? "同意" : "不同意");
        buf.append("		</td>");
        buf.append("	</tr>");

        buf.append("	<tr>");
        buf.append("		<td align='right'>保費</td>");
        buf.append("		<td class='text-lightred'><strong>").append(FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1541").toString()),0)).append("</strong></td>");
        buf.append("	</tr>");
        buf.append("	<tr>");
        buf.append("		<td colspan='2' align='right'>幣別：新台幣元</td>");
        buf.append("	</tr>");
        buf.append("</table>");

        return buf.toString();
    }

	/**
	 * 取得WEB簽名檔
	 * @param policyNum 保單號碼/交易序號
	 * @return 簽名圖檔
	 */
	private static String getImageSign(Connection conn, String policyNum) {
		String imageSign = null;
		String sql = "";
		Statement st = null;
		ResultSet rs = null;	
		
		try {
			if(policyNum!=null){			
				sql = "SELECT signid, sign FROM kycwebsign WHERE signid = '" + policyNum + "'";
				st = conn.createStatement();
				rs = st.executeQuery(sql);
				if(rs.next()){
					imageSign = rs.getString("sign").replace("data:image/png;base64,", "");
				}
			}
			
		} catch (SQLException sqle) {
			logger.error("取資料發生錯誤", sqle);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return imageSign;
	}
	
	public static String getDesEncryptString(String pwd){
		String encrypt = "";
		
 		String sql = "SELECT FN_ENCRYPT_PWD('" + pwd + "') RESULT FROM DUAL"; 
 		
 		Connection con = AS400Connection.getOracleConnection();
 		Map mp = null;
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			mp = (Map) runner.query(con, sql.toString(), new TrimedMapHandler());
 			encrypt = mp.get("RESULT").toString();
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

 		return encrypt;
	}
	
}
