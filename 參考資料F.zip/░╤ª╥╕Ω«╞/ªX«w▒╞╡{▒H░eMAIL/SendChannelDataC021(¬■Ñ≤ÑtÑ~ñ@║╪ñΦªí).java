package com.kyc.schedule;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeUtility;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.mail.EmailAttachment;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.KycWorkDayUtil;
import com.firstins.CooperativeBankExService;
import com.firstins.LandBankExService;
import com.kyc.afl.utils.Employee;
import com.kyc.afl.utils.WorkDay;
import com.kyc.bdc.forms.BD2010f;


/**
 * 合庫通路每日出單件明細通知
 * @author 
 *
 */
public class SendChannelDataC021 extends AsiAction
{
	private String fileFolder = SystemParam.getParam("FILE_FOLDER") + "\\COOPERATIVEBANK";// 取得系統設定路徑
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		
		
		//判斷非工作日時不傳送，如為工作日時取前一工作日為資料日期基準
		String workdate = WorkDay.getStrWorkDatebyDays("00", sysdate, false, String.valueOf(1)); 
		if(workdate.trim().length()==0)
			return;
		
		CooperativeBankExService service = new CooperativeBankExService();

		Connection con = null;
		try
		{			
			tx_controller.begin(1);
			con=tx_controller.getConnection(1);
			//取得前一作帳日商住火保單資料-北市區
			List dataV = service.getDataV(con, workdate);
			//取得前一作帳日商住火保單資料-新北市區
			List dataW = service.getDataW(con, workdate);
			//取得前一作帳日商住火保單資料-高坪區
			List dataK = service.getDataK(con, workdate);
			//取得前一作帳日商住火保單資料-桃竹區
			List dataA = service.getDataA(con, workdate);
			//取得前一作帳日商住火保單資料-台中區
			List dataC = service.getDataC(con, workdate);
			//取得前一作帳日商住火保單資料-雲嘉南
			List dataN = service.getDataN(con, workdate);
						
			sendMail(servlet,request,workdate, dataV,dataW,dataK,dataA,dataC,dataN);
			
			//寄完刪除資料夾檔案
			//取得存放的路徑			
			File ffolder = new File(fileFolder+ "\\" +workdate);
			//呼叫刪除資料夾方法
			deleteDir(ffolder);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		arg1.setNextPage(-1);
	}
	//送出郵件方法
	private void sendMail(HttpServlet servlet, HttpServletRequest request,String workdate,List dataV,List dataW,List dataK,List dataA,List dataC,List dataN)
	{
		if (dataV == null && dataW == null && dataK == null && dataA == null && dataC == null && dataN == null)
			return;

		try
		{
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
			ve.init();
			
			//北市區檔案路徑
			String pathV=generateCsvFile(dataV,"北市區-"+workdate);
			//新北市區檔案路徑
			String pathW=generateCsvFile(dataW,"新北市區-"+workdate);
			//高屏區檔案路徑
			String pathK=generateCsvFile(dataK,"高屏區-"+workdate);
			//桃竹區檔案路徑
			String pathA=generateCsvFile(dataA,"桃竹區-"+workdate);
			//台中區檔案路徑
			String pathC=generateCsvFile(dataC,"台中區-"+workdate);
			//雲嘉南檔案路徑
			String pathN=generateCsvFile(dataN,"雲嘉南-"+workdate);
			
			
			if((pathV==null || pathV.length()==0) && (pathW==null || pathW.length()==0) && (pathK==null || pathK.length()==0) && (pathA==null || pathA.length()==0) && (pathC==null || pathC.length()==0) && (pathN==null || pathN.length()==0))
				return;
			
			EmailAttachment[] attachment = new EmailAttachment[6];
			// 郵件附加檔-北市區
			attachment[0] = new EmailAttachment();
			attachment[0].setPath(pathV);
			attachment[0].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[0].setName(MimeUtility.encodeText("北市區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
			// 郵件附加檔-新北市區
			attachment[1] = new EmailAttachment();
			attachment[1].setPath(pathW);
			attachment[1].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[1].setName(MimeUtility.encodeText("新北市區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
			// 郵件附加檔-高屏區
			attachment[2] = new EmailAttachment();
			attachment[2].setPath(pathK);
			attachment[2].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[2].setName(MimeUtility.encodeText("高屏區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
			// 郵件附加檔-桃竹區
			attachment[3] = new EmailAttachment();
			attachment[3].setPath(pathA);
			attachment[3].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[3].setName(MimeUtility.encodeText("桃竹區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
			// 郵件附加檔-台中區
			attachment[4] = new EmailAttachment();
			attachment[4].setPath(pathC);
			attachment[4].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[4].setName(MimeUtility.encodeText("台中區-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)
			// 郵件附加檔-雲嘉南
			attachment[5] = new EmailAttachment();
			attachment[5].setPath(pathN);
			attachment[5].setDisposition(EmailAttachment.ATTACHMENT);
			attachment[5].setName(MimeUtility.encodeText("雲嘉南-"+workdate + ".csv", "UTF-8", "B"));// 處理附件檔名編碼(中文)

			KycMailUtil kmu = new KycMailUtil();
			kmu.addAttachment(attachment);
			
			//郵件內文
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setMessage(workdate+"合庫商住火保單資訊,請查收謝謝。");
			//郵件主旨
			kmu.setSubject("合庫商住火保單資訊-"+workdate + ".csv");
			
			//取得寄件正本人員
			List mailToList = new ArrayList();
			String[][] arrayTo = CodeUtil.getCodeArray(servlet, request, "C231AGENTS");
			for(int i=0;i<arrayTo.length;i++)
			{
				if(arrayTo[i][0]!=null && arrayTo[i][0].trim().length()>0)
					mailToList.add(Employee.getEmployee(arrayTo[i][0]).getEmail());
			}
			if(mailToList.size()>0)
				kmu.addTo(mailToList.toArray());
			
			//取得寄件副本人員
//			List mailCCList = new ArrayList();
//			String[][] arrayCc = CodeUtil.getCodeArray(servlet, request, "LANDBANK_C");
//			for(int i=0;i<arrayCc.length;i++)
//			{
//				if(arrayCc[i][0]!=null && arrayCc[i][0].trim().length()>0)
//					mailCCList.add(Employee.getEmployee(arrayCc[i][0]).getEmail());
//			}
//			if(mailCCList.size()>0)
//				kmu.addCc(mailCCList.toArray());
			
			kmu.sendMailWithAttachments();
			
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 組CSV資料，存到資料夾，並回傳路徑
	 * 
	 * @param response
	 * @throws UserException
	 */
	public String generateCsvFile(List data,
			String filename) throws UserException
	{
		//組CSV資料
		StringBuffer sb = new StringBuffer();

		sb.append("影像編號");
		sb.append(",");
		sb.append("要保人ID");
		sb.append(",");
		sb.append("被保險人ID");
		sb.append(",");
		sb.append("保單生效日期");
		sb.append(",");
		sb.append("保單號碼");
		sb.append(",");
		sb.append("業務來源");
		sb.append(",");
		sb.append("通路代號");
		sb.append(",");
		sb.append("\n");
		for (int i = 0; i < data.size(); i++)
		{
			Map mp = (Map) data.get(i);

			sb.append(" ");
			sb.append(",");
			sb.append(mp.get("c248").toString().trim());
			sb.append(",");
			sb.append(mp.get("c201").toString().trim());
			sb.append(",");
			sb.append(mp.get("c205").toString().trim());
			sb.append(",");
			sb.append(mp.get("c202").toString().trim());
			sb.append(",");
			sb.append(mp.get("c210").toString().trim());
			sb.append(",");
			sb.append(mp.get("c233").toString().trim());
			sb.append(",");
			sb.append("\n");
		}
		//存到資料夾
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String workdate = WorkDay.getStrWorkDatebyDays("00", sysdate, false, String.valueOf(1)); 
		String sysFolder = fileFolder + "\\" +workdate;
		String rptPath = "";		
		try
		{
			File ffolder = new File(sysFolder);
			if(!ffolder.exists())
				ffolder.mkdirs();
			
			
		   	
		   	rptPath = sysFolder + "\\" + filename + ".csv";
		   	FileOutputStream fos = new FileOutputStream(new File(rptPath));
		    //解決CSV亂碼問題
		   	byte[] BOM_UTF8 = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
		   	fos.write(BOM_UTF8);
		   	fos.write(sb.toString().getBytes());
			fos.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			rptPath = null;
		}
		return rptPath;
		//下載到瀏覽器用
//		try{
//			response.setContentType("application/octet-stream");
//			response.setHeader("Content-Disposition","attachment;filename="
//							+ (filename.equals("") ? "export" : new String(
//									filename.getBytes("UTF-8"), "ISO8859_1"))
//							+ ".csv");
//			
//			OutputStream os = response.getOutputStream();
//			//解決CSV亂碼問題
//			byte[] BOM_UTF8 = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
//			os.write(BOM_UTF8);
//			os.write(sb.toString().getBytes());
//		}catch(Exception e){
//			e.printStackTrace();
//		}
		
		
	}
	
	//刪除資料夾方法
	public void deleteDir(File file) {
        if (file.isDirectory()) {
            for (File f : file.listFiles())
                deleteDir(f);
        }
        file.delete();
    }
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}