/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.kyc.sec.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.security.ISecurityManager;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.common.util.ManagerUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.manager.UserManagerWithDB;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * <!--程式說明寫在此-->
 * 
 * @author ：Sergio_Huang
 * @version ：$Revision: 1.2 $ $Date: 2006/11/16 06:59:34 $<br>
 *          存放路徑 ：$Header:
 *          D:/CVSRepository/Financial/KYC/KYC/JavaSource/sec/com/kyc/sec/actions/DupLoginAction.java,v
 *          1.3 2005/07/19 07:25:29 Sergio_Huang Exp $ 建立日期 ：2005/7/13 異動註記 ：
 *          2020/05/06 VSG 增加檢核密碼錯誤3次產生OTP機制，並將暫存OTP記錄至KYKLLOG
 */
public class DupLoginAction extends AsiAction {

	private String otpkey = "";
	
    /**
     * @see com.asi.common.struts.AsiAction#doProcess(org.apache.struts.action.ActionMapping,
     *      com.asi.common.struts.AsiActionForm,
     *      javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     * 
     * @param arg0
     * @param arg1
     * @param arg2
     * @param arg3
     * @throws com.asi.common.exception.AsiException
     */
    public void doProcess(ActionMapping map, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
        /*
         * 1.帳號已登入 2.正確 3.帳號不存在 4.帳號停用 這個帳號目前停用，請洽0800-288-068 5.帳號停用 6.顯示密碥錯誤次數
         * 這個帳號目前停用，請洽資訊室 7. 帳號停用 alert 8. nothing happen 9.第一次登入，顯示密碼提示
         * 10.此帳號尚未開啟，請洽0800-288-068客服專線來啟用您的帳號
         */
    	Map out = new HashMap();
        String errcode = "";
        String errmsg = "";
        String send_otp = "";
        String otpflag = request.getParameter("flag");//OTP驗證是否OK用
        
        try {
            String id = request.getParameter("UID");
            tx_controller.begin(0);
            DBO dbo = tx_controller.getDBO("sec.SECAJt", 0);
            dbo.addParameter("USERID", id);
            dbo.executeSelect();
            
            //登入前檢核，要加傳pwd,check
            if (request.getParameter("check") == null) {
                UserManagerWithDB usrMgr = (UserManagerWithDB) ManagerUtil.getManager(getServlet(), GlobalKey.USER_MANAGER);
                
                if (dbo.getRecordCount() == 0) {
                    errcode = "3";//帳號不存在
                    errmsg = "帳號不存在，請先進行註冊會員動作！";
                } else {
                    String loginRestrict = dbo.getRecordData("LOGINRESTRICT");
                    if (dbo.getRecordData("STATE").equals("Y")) {//強迫停用
                        errcode = "7";
                        errmsg = "這個帳號目前停用，請洽0800-288-068";
                    } else {
              		    
                    	if(otpflag.equals("N")){//無OTP驗證時
                    		
                        	String pass = EncryptUtil.getDesEncryptString(request.getParameter("PWD"));
                            if (!pass.equals(dbo.getRecordData("PASSWORD"))) {
                                ISecurityManager secMgr = (ISecurityManager) ManagerUtil.getManager(getServlet(), GlobalKey.SECURITY_MANAGER);

                                DBO dbo2 = tx_controller.getDBO("sec.SECAJu05", 0);
                                UserInfo ui = new UserInfo();
                                ui.setInfo("USERID", "SYSTEM");
                                ui.setDateFormat(DateUtil.Format_YYYYMMDD);
                                ui.setDateType(DateUtil.ChType);
                                ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
                                ui.setFileDateType(DateUtil.ChType);
                                tx_controller.setUserInfo(ui);
                                dbo2.addParameter("USERID", id);
                                dbo2.execute();

                                String logincnt = dbo.getRecordData("LOGINCOUNT");
                                if (logincnt.equals("0")) {//第一次登錄
                                    errcode = "6";
                                }
                                int errorlimit = secMgr.getErrorLimit();
                                int errorcnt = Integer.parseInt(dbo.getRecordData("ERRCNT")) + 1;
                                if (errorcnt >= errorlimit) {
                                    errcode = "7";
                                    errmsg = "您的帳號已經鎖定，請洽0800-288-068!";
                                    //update secaj set errcnt=0,state='y' where
                                    // userid='id'
                                    DBO dbo3 = tx_controller.getDBO("sec.SECAJu06", 0);
                                    dbo3.addParameter("USERID", id);
                                    dbo3.execute();
                                }
                                else if(errorcnt >= 3) {
                                    errmsg = "您的密碼已連續錯誤達3次，請輸入發送至手機/Email的OTP密碼登入！";
                                    errcode = "66";
                                    
                                    send_otp = doKycllog(request, form, id);
                                    String[] userinfo = getIC01Content(id);
                                    if(userinfo[0] != null && !userinfo[0].isEmpty())//發送otp
                                    	sendMobileMsg(send_otp, dbo.getRecordData("FIRSTNAME"), userinfo[0]);
                                    else if(userinfo[1] != null && !userinfo[1].isEmpty())//發送email
                                    	sendOTPMail(request, send_otp, dbo.getRecordData("FIRSTNAME"), userinfo[1]);
                                }
                                else {
                                    int remain = errorlimit - errorcnt;
                                    errmsg = "密碼錯誤，請重新輸入!";
                                    //errmsg = "密碼錯誤，請重新輸入，您還有" + String.valueOf(remain) + "次機會";
                                    errcode = "6";
                                }

                            } else {
                                if (loginRestrict.equals("Y") && usrMgr.getSessionCount(id) > 0){
                                	errcode = "1";//您的帳號已經登入，按下確定將強制登入
                                	errmsg = "您的帳號已經登入，按下確定將強制登入!";
                                }                             
                                else{
                                    errcode = "2";//正確
                                }
                            }

                            if (dbo.getRecordCount() != 0){
    	                        if(id.length() ==10 && (dbo.getRecordData("RG14").equals("") || dbo.getRecordData("RG14").equals("0")))
    	                        {
    	                        	errcode = "44";
    	                        	errmsg = "您的帳號尚未註冊完成，請先進行註冊後再行登入！";
    	                        }
                            }

                    	}else{
                    		errcode = "2";//正確
                    		
                    	}
                    	
                    }
                }
            //動態顯示帳號狀態用
            } else {
            	int errorcnt = Integer.parseInt(dbo.getRecordData("ERRCNT") != null ? dbo.getRecordData("ERRCNT") : "0");
            	
            	if(otpflag.equals("N")){//無OTP驗證時
            		
                	if (dbo.getRecordCount() == 0)
                    {
                        errcode = "3";//帳號不存在
                        errmsg = "帳號不存在，請先進行註冊會員動作！";
                    }else if (dbo.getRecordData("STATE").equals("Y")) {
                        String usertype = dbo.getRecordData("USERTYPE");
                        //1:客戶，2:員工，3:B2B，4:後台管理者
                        if ("1".equals(usertype)) {
                            
                            if (dbo.getRecordData("STOPCAUSE").equals("2")) {
                                errcode = "10"; //此帳號尚未開啟，請洽0800-288-068客服專線來啟用您的帳號
                                errmsg = "此帳號尚未開啟，請洽0800-288-068客服專線來啟用您的帳號";
                            } else {
                                errcode = "4"; //這個帳號目前停用，請洽0800-288-068
                                errmsg = "這個帳號目前停用，請洽0800-288-068";
                            }

                        }else if (usertype.equals("3")){
                            errcode = "4"; //這個帳號目前停用，請洽0800-288-068
                            errmsg = "這個帳號目前停用，請洽0800-288-068";
                        }else if (usertype.equals("2") || usertype.equals("4")) {
                            errcode = "5"; //這個帳號目前停用，請洽資訊室
                            errmsg = "這個帳號目前停用，請洽0800-288-068";
                        }

                    } else if (dbo.getRecordData("LOGINCOUNT").equals("0")) {
                        errcode = "9";
                        errmsg = "您的密碼預設為出生年月日六碼";
                    } else if(errorcnt >= 3){
                    	errcode = "66";
                    	errmsg = "您的密碼已連續錯誤達3次，請輸入發送至手機/Email的OTP密碼登入！";

                    	send_otp = doKycllog(request, form, id);
                        String[] userinfo = getIC01Content(id);
                        if(userinfo[0] != null && !userinfo[0].isEmpty())//發送otp
                        	sendMobileMsg(send_otp, dbo.getRecordData("FIRSTNAME"), userinfo[0]);
                        else if(userinfo[1] != null && !userinfo[1].isEmpty())//發送email
                        	sendOTPMail(request, send_otp, dbo.getRecordData("FIRSTNAME"), userinfo[1]);

                    } else
                        errcode = "2";
                    
                    if (dbo.getRecordCount() != 0 && !dbo.getRecordData("STATE").equals("Y")){
                        if(id.length() ==10 && (dbo.getRecordData("RG14").equals("") || dbo.getRecordData("RG14").equals("0"))){
                        	errcode = "44";
                        	errmsg = "您的帳號尚未註冊完成，請先進行註冊後再行登入！";
                        }
                    }
            		
            	}else{
            		errcode = "2";//正確
            	}
              
            }
            
            out.put("errcode", errcode);
            out.put("errmsg", errmsg);
            out.put("otpkey", otpkey);
            
            response.setContentType("text/json;charset=UTF-8");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Set-Cookie", "HttpOnly;Secure;SameSite=Strict");
            response.getWriter().write(JSONArray.fromObject(out).toString());
            response.getWriter().flush();
            response.getWriter().close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        form.setNextPage(-1);
    }

	/**
	 * 寫入KYCLLOG記錄檔處理 - 用此檔案記錄登入OTP
	 * @param request
	 * @param form
	 * @param uid
	 */
	private String doKycllog( HttpServletRequest request ,  AsiActionForm form , String uid){

		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();

		String ll01 = this.getClass().getSimpleName();
		String ll02 = "";
		String ll03 = "會員登入頁";
		String ll04 = "F";
		String ll05 = uid;
		String ll09 = sysdate + systime;//當作key值
		String ll17 = "LE";
		String ll19 = "會員登入密碼錯誤達3次";
		String ll12 = "0";//做otp輸入錯誤記錄

		String getotp = KYCEncryptor.genOTP();
		String ll20 = getotp;
		otpkey = ll09;
		
		try {		
			KycLogger klg = new KycLogger();
			klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, ll12, "", "", "", "", ll17, "", ll19, ll20, "", "", "", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ll20;
	}

 	/**
 	 * 寄發OTP密碼簡訊
 	 * @param data
 	 */
 	public void sendMobileMsg(String otp , String username , String cellphone)
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		
 		sb.append("第一產物登入OTP密碼：").append(otp).append("\n");
 		sb.append(" 您在第一產物的登入密碼已錯誤達3次");
 		sb.append("，請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！如有異常情形請來電客服專員！");


 		String sendTel = cellphone;
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);
 			System.out.println("statusCode" + statusCode + " " + getmethod.getResponseBodyAsString());
 			String responseText = getmethod.getResponseBodyAsString();

 			//判斷是否有回傳剩餘點數參數，剩餘200、100時發通知出納課
 			if (responseText.indexOf("LCount=") != -1)
 			{
 				String str = responseText.replaceAll("\n|\r", "");// 清除換行符號
 				if (Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 100
 						|| Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 200)
 				{
 					String content = responseText.replaceFirst("ErrorCode", "訊息代碼");
 					content = content.replaceFirst("LCount", "剩餘點數");
 					content = content.replaceFirst("MsgID000", "簡訊代號");

 					String email = SystemParam.getParam("EMAIL");// 客服信箱
 					sendSysMail(email, content);// 寄發剩餘點數通知
 				}
 			}

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

	private void sendSysMail(String email, String content)
	{
		KycMailUtil kmu = new KycMailUtil();
		kmu.setSubject("網路投保OTP-簡訊服務剩餘儲值點數");
		kmu.setFrom("admin@firstins.com.tw");
		kmu.setMessage(content);
		kmu.addTo(email);
		kmu.sendMail();
	}

	/**
	 * 查詢客戶手機、EMAIL
	 * @param uid
	 * @return String [0]：手機  	String [1]：email 
	 */
	private String[] getIC01Content(String uid){
		
		String sql = "SELECT * FROM IC01PF WHERE C101 = ?";
		String[] result = new String[2];
		
 		Connection con = null;
 		
 		try
 		{
 			con = AS400Connection.getOracleConnection();
 			QueryRunner runner = new QueryRunner();
 			Map mp = (Map) runner.query(con, sql, uid, new TrimedMapHandler());
 			
 			if(mp != null && !mp.isEmpty()){
 				result[0] = mp.get("CA101") != null ? mp.get("CA101").toString() : ""; 
 				result[1] = mp.get("C113") != null ? mp.get("C113").toString() : ""; 
 			}
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

 		return result;
	}
	
	/**
	 * 寄送OTP EMAIL
	 * @param request
	 */
	public void sendOTPMail(HttpServletRequest request ,String otp ,String name , String email)
	{
	   int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;   	

	   //寄Email
	   KycMailUtil sender = new KycMailUtil();

	   //取範本
	   BufferedReader fr;
	   String path = getServlet().getServletContext().getRealPath("/mail/LoginOTP_zh_TW.html");

	   StringBuffer linebf = new StringBuffer();
	   try {
		   fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
		   String line;
		   linebf = new StringBuffer();
		   line = fr.readLine();
		   while (line != null) {
			   linebf.append(line);
			   line = fr.readLine();
		   }

	   }catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }catch (IOException e) {
		   e.printStackTrace();
	   }

	   String msg = linebf.toString();
	   msg = msg.replaceAll("\\{username\\}", name);
	   msg = msg.replaceAll("\\{otp\\}", otp);
	   msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));

	   sender.setSubject("第一保商務網-登入密碼錯誤通知");
	   sender.setMessage(msg);
	   sender.addTo(email);
	   sender.sendMail();

	}

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        AsiActionForm form = (AsiActionForm) arg1;
        form.setActionCode(1);
    }

    public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException {
        return null;
    }

    protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException {

    }
}
