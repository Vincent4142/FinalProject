/*
 * Created on 2021/12/10
 */
package com.kyc.sec.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.MailSender;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.ConfigUtil;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.SystemParam;
import com.kyc.sec.forms.AccountActivateForm;

/**
 * @author Vincent_Huang
 */
public class AccountActivate extends kycAction {

    public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {

    	HttpSession session = request.getSession(false);
    	UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
    	
    	String[] googleCaptchaVerify = GoogleRecaptchaAPI.reCaptchaVerify(request);
    	
    	AccountActivateForm form1 = (AccountActivateForm) form;
        DBO dbo2 = tx_controller.getDBO("sec.SECAJt", 0);
        dbo2.addParameter("USERID", form1.getId());
        dbo2.executeSelect();
        if (dbo2.getRecordCount() == 0) {
            throw new UserException("SEC.PASSERR4",form1.getId());
        }

        String userType = dbo2.getRecordData("USERTYPE");
        String mail = form1.getEmail() ;
        
        //判斷來源別為客戶或員工
        //如果為員工，檢查員工生日
        if (userType.equals("2")) {
            DBO dbo1 = tx_controller.getDBO("kyc.PSM3PFt", 0);
            dbo1.addParameter("M301", form1.getId());
            dbo1.executeSelect();
            
            	
                if (dbo1.getRecordCount() == 0) {
                    throw new UserException("SEC.PASSERR1", form1.getId());
                } else {
                    
                    //google 非機器人驗證，驗證通過再進行資料查詢及檢核
                    if(googleCaptchaVerify[0].equals("true")){

	                	if (dbo1.getRecordData("M318").equals("0") || dbo1.getRecordData("M318").equals(form1.getBirth()))
	                    {
	                        if(mail == null || mail.equals(""))
	                        	mail = dbo2.getRecordData("EMAIL");
	                        
	                        //send(request, form1.getId(), mail);
	                    }
	                    else
	                        throw new UserException("SEC.PASSERR2", form1.getBirth());
                	
                    }else{
                    	String errmsg = googleCaptchaVerify[3].indexOf("timeout") != -1 ? "Google驗證碼超時，請重新輸入！" : googleCaptchaVerify[3] ;
                    	
                    	throw new AsiException(errmsg);
                    }

                }

        } else {
            //從客戶檔判斷來客戶為法人或自然人
            DBO dbo1 = tx_controller.getDBO("kyc.IC01PFs03", 0);
            dbo1.addParameter("C101", form1.getId());
            dbo1.execute();
            if (dbo1.getRecordCount() == 0)
                throw new UserException("SEC.PASSERR3", form1.getId());
            else {
                String tp = dbo1.getRecordData("C106");
                //如果為自然人，寄密碼
                if (tp.equals("1")) {
                    //                  如果為自然人，判斷生日正不正確
                    //if (dbo1.getRecordData("C103").equals("0") || dbo1.getRecordData("C103").equals(form1.getBirth()))
                        //send(request, form1.getId(), mail);
                    //else
                        //throw new UserException("SEC.PASSERR2", form1.getBirth());
                } else {//如果為法人，直接寄信
                    //send(request, form1.getId(), dbo1.getRecordData("C113"));
                }
            }
        }
        form1.setNextPage(2);
    }

    private void send(HttpServletRequest request, String id,String uname, String uemail) throws AsiException {
        try {
        	String uid = id;
        	
        	//啟動交易控制，在執行更新及新增作業時一定要啟動交易，否則會發生錯誤
            tx_controller.begin(0);
            String name = uname;
            String pw = String.valueOf(new Date().getTime());
            pw = pw.substring(pw.length() - 6, pw.length());
            String email = uemail;
            
            DBO dbo1 = tx_controller.getDBO("kyc.SECAJu02", 0);
            dbo1.addParameter("PASSWORD", EncryptUtil.getDesEncryptString(pw));
            dbo1.addParameter("EMAIL", email);
            dbo1.addParameter("USERID", uid);
            dbo1.executeUpdate();
            dbo1.destroy();
            
            sendEmpMail(name, pw, email);
        	
        } catch (Exception e) {
            e.printStackTrace();
        } 

    }

    private void sendEmpMail(String name, String pw, String email) {
        String userSubject = "KYC 帳號開通";
        String userBody = "這是系統寄給您的訊息，通知您被鎖住的帳號已經開通。<br/>帳號開通密碼為：" + pw + "<br/>請於登入 KYC 系統後立即變更密碼！！！";
        String msg = null;
        
        try {
            msg = new String(userBody.getBytes("UTF-8"), "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            //e1.printStackTrace();
        }
        
        //修改 E-Mail 時增加寄送測試信件
        String emailFrom = SystemParam.getParam(KycGlobal.SysParam_EMP_EMAIL_TEST);

        sendMail(userSubject, msg, emailFrom, email);
    }
    
    private void sendMail(String subject, String msg, String mailFrom, String mailto) {

        MailSender sender = new MailSender();
        sender.setSubject(subject);
        sender.setMessage(msg);
        if (mailFrom != null) {
            sender.setMimeType("text/html;charset=UTF-8");
            sender.setFrom(mailFrom);
        }
        sender.addTo(mailto);
        
        try {
            sender.sendMail();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        super.redefineActionCode(arg0, arg1, arg2, arg3);
    }
}