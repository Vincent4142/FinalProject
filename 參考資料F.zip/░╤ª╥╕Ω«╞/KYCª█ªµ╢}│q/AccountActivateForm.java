/*
 * Created on 2005/3/25
 */
package com.kyc.sec.forms;

import com.asi.common.struts.AsiActionForm;

/**
 * @author Sergio_Huang
 */
public class AccountActivateForm extends AsiActionForm {
    private String id;
    private String birth;
    private String email;
    
    /**
     * @return Returns the birth.
     */
    public String getBirth() {
        return birth;
    }
    /**
     * @param birth The birth to set.
     */
    public void setBirth(String birth) {
        this.birth = birth;
    }
    /**
     * @return Returns the id.
     */
    public String getId() {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(String id) {
        this.id = id;
    }
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
    
}
