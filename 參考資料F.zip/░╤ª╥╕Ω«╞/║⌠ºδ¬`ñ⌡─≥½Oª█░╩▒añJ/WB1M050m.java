/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc.
 * Taipei, Taiwan. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * Asgard System, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Asgard.
 *
 */
package com.asi.kyc.wb1.models;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.asi.common.AsiModel;
import com.asi.common.GlobalKey;
import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.StringUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.NumberUtil;
import com.asi.kyc.common.utils.TradeCounter;
import com.asi.kyc.common.utils.UpdateState;
import com.asi.kyc.wb1.actions.AS400Procedure;
import com.asi.kyc.wb1.forms.WB1M050f;
import com.firstins.dao.procedure.FAS24Input;
import com.firstins.dao.procedure.FAS24PRC;
import com.firstins.dao.procedure.FAS24Return;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * 新保-住宅火險
 *
 * @author  ：YiChuan
 * @version ：$Revision: 1.4 $ $Date: 2006/09/11 07:05:56 $<br>
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/web/com/asi/kyc/wb1/models/WB1M050m.java,v 1.4 2006/09/11 07:05:56 john Exp $
 * 建立日期	：2005/5/10
 * 異動註記	：2005/09/26  John  增加判斷使用者是由那個網站進入線上投保
 * 			 2019/08/14  vsg   修改交易完成動，刪除寄發email動作，由report發動
 * </pre></p>
 */
public class WB1M050m extends AsiModel {

    private static Log logger = LogFactory.getLog(WB1M050m.class);

    private WB1M050f mform;


    public WB1M050m(TransactionControl tx_controller, HttpServletRequest request, AsiActionForm form) {
        super(tx_controller, request, form);
    }

    public void init() throws AsiException {

        mform = new WB1M050f();
        //把form做拷貝
        try {
            BeanUtils.copyProperties(mform, getForm());
        } catch (InvocationTargetException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        } catch (IllegalAccessException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        }
        setUserinfo();
        setMainForm(mform);

    }

    private void setUserinfo() {
        if (getTransaction().getUserInfo() == null) {
            UserInfo ui = new UserInfo();
            ui.setInfo("USERID", "SYSTEM");
            ui.setDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setDateType(DateUtil.ChType);
            ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setFileDateType(DateUtil.ChType);
            getTransaction().setUserInfo(ui);
        }
    }
    public void destroy() {
    }

    public void processP1() throws AsiException {
        //總樓層數
        DBO dbo1 = getTransaction().getDBO("kyc.FBZ4PFs01",1);
        dbo1.executeSelect();
        getRequest().setAttribute("dbo1",dbo1);

        //建物結構
        DBO dbo2 = getTransaction().getDBO("kyc.PT31PFs01",1);
        dbo2.executeSelect();
        getRequest().setAttribute("dbo2",dbo2);
        getTransaction().begin(0);

    }
    
    
    /**
     * 計算保費
     * @throws AsiException
     */
    public void processP2() throws AsiException {
    	/* 保險起日  insurStartDate = mform.getYear()+mform.getMonth()+mform.getDate() 取代  DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false)
    	 * 1070413 Don
    	 */
    	String insurStartDate = mform.getYear()+mform.getMonth()+mform.getDate();
        DBO dbo1 = getTransaction().getDBO("kyc.PT29PFs01",1);
        dbo1.addParameter("T2902",mform.getKyc_a01());//建物造價區域
        dbo1.addParameter("T2903",mform.getKyc_a02());//地上樓層起
        dbo1.addParameter("T2904",mform.getKyc_a02());//地上樓層迄
        dbo1.addParameter("SYSDATE", insurStartDate);
        String s=dbo1.getAssembledSQL();
        dbo1.executeSelect();
        long t2906 = 0L;//每坪造價

        //取FBZJPF是否有特殊造價，造價要另外加乘
        DBO fbzjpfDbo = getTransaction().getDBO("kyc.FBZJPFs01",1);//特定建築結構之每坪造價設定檔
	    fbzjpfDbo.addParameter("ZJ01", mform.getKyc_t3101());
	    fbzjpfDbo.addParameter("SYSDATE", insurStartDate);
	    fbzjpfDbo.execute();
	    
	    if(fbzjpfDbo.getRecordCount()>0)
	    {
			if (fbzjpfDbo.getRecordData("ZJ04").equals("Y"))//是否依造價表 'Y': 是 ,' ': 否
			{
				// 每坪造價金額=
				// Round(FIRSTF.PT29PF.T2906*(1+(FGFLIB.FBZJPF.ZJ05/100)),0)+ FGFLIB.FBZJPF.ZJ06
				long zj06 = Long.parseLong(fbzjpfDbo.getRecordData("ZJ06"));
				double zj05 = Double.parseDouble(fbzjpfDbo.getRecordData("ZJ05"));
				long orginalT2906 = Long.parseLong(dbo1.getRecordData("T2906"));
				t2906 = (long)(orginalT2906*(1+zj05/100)+zj06);
			}else{
				t2906 = Long.parseLong(fbzjpfDbo.getRecordData("ZJ07"));//最低造價金額
			}
	    }
		else if(dbo1.getRecordCount()>=1)
		{
			// 每坪造價金額=T2906
			t2906 = Long.parseLong(dbo1.getRecordData("T2906"));
		}


	    mform.setKyc_t2906(String.valueOf(t2906));
        
        DBO dbo2 = getTransaction().getDBO("kyc.FPACPFs01",1);
        dbo2.addParameter("AC01",mform.getKyc_a03());//等級代號
        dbo2.addParameter("AC02",insurStartDate);//實施日期
        dbo2.executeSelect();
        double ac04 = 0;//附加費用率  特別費率優待
        double ac03 = 0;//基本(危險)費率  基本費率
        
        if (dbo2.getRecordCount()>=1)
        {
        	ac04 = Double.parseDouble(dbo2.getRecordData("AC04"));//特別費率優待
        	ac03 = Double.parseDouble(dbo2.getRecordData("AC03"));//基本費率
        }

        DBO dbo3 = getTransaction().getDBO("kyc.FPACPFs02",1);
        dbo3.addParameter("AC02",insurStartDate);
        dbo3.executeSelect();
        long fb05 = 0L;//地震基本保費
        if (dbo2.getRecordCount()>=1){
            fb05 = Long.parseLong(dbo3.getRecordData("AC16"));
            fb05 = (long)MathUtil.round(fb05,0,MathUtil.ROUND);
        }

	    String kyc_a04 = mform.getKyc_a04();//權狀面積
	    /**		主險保額 = 權狀面積*每坪造價+裝潢總價*10000 ， 最小100,000，最大	40,000,000  */
		double fb01 = (Double.parseDouble(kyc_a04))*t2906+(Integer.parseInt(mform.getKyc_a05()))*10000;
	    if (fb01 < 100000)
	        fb01 = 100000;
	    if (fb01 > 40000000)
	        fb01 = 40000000;

	    String floorRate = mform.getKyc_z402();//樓層加費比率	
	    //危險費率=基本危險費率* (1+樓層加費比率/100) 無修件小數6位
	    double dangerrate = MathUtil.round(ac03*(1+Double.parseDouble(floorRate)/100),6,MathUtil.ROUND);
	    
	    //原保費 = 保額*基本簽單費率*(1+高樓加費/100)/1000
	    
	    //增加來源網站欄位的判斷
        String KD19 = (String)getSession().getAttribute(KycGlobal.CaseFrom);
        if (KD19 == null) {
            KD19 = "KYC";
        }
        
        Kyckd kd = new Kyckd();
        kd.setKD01("FR");
        kd.setKD02("F");
        kd.setKD03(" ");
        kd.setKD19(KD19); //來源網站
        DBO dbo4 = kd.executeSelect(getTransaction());
	    //費率自由化修正 -> 原保費/(1-附加費用率(AC04)) X 通路別主險係數 (WJ06)X 長短期係數 (1)
	    double wj06 = getWj06(dbo4.getRecordData("KD16")) ; //KD16是業務來源， 
	    
	    /** 簽單費率 = 危險費率/(1- 附加費率)*通路別主險系數 */   
	    double rate = MathUtil.round(dangerrate/(1-ac04)*wj06,3,MathUtil.ROUND);
	    long fb02;
	    fb02 = (long) MathUtil.round((fb01*rate/1000),0,MathUtil.ROUND);
	    //建築物內動產保額計算公式：建築物保額*30%，最高60萬元
	    //109/01/01建築物內動產保額最高改為80萬
	    double fb03 = fb01*30/100;
	    if (fb03 >= 800000)
	        fb03 = 800000;
	    
	    long equakeTotal = 0;//地震保費
	    long equakeAmount = 0;//地震保額
	    long equakeBuild =0;//地震造價
	    long equakeMax =0;//
	    double equakeRate =0;//

	    DBO dboeq = getTransaction().getDBO("kyc.FPACPFs03",1);
	    dboeq.addParameter("AC02",  insurStartDate);
	    dboeq.execute();
	    equakeRate = Double.parseDouble(dboeq.getRecordData("AC05"));//年簽單費率
	    equakeMax = Long.parseLong(dboeq.getRecordData("AC15"));//最高投保保額
	    
	    DBO pt29pfDbo = getTransaction().getDBO("kyc.PT29PFs02",1);
	    pt29pfDbo.addParameter("T2902", mform.getKyc_a01());
	    pt29pfDbo.addParameter("T2903", mform.getKyc_a02());
	    pt29pfDbo.addParameter("SYSDATE", insurStartDate);
	    pt29pfDbo.execute();
	    equakeBuild = t2906;//每坪造價金額
	    
	    //保額進位至萬位
	    equakeAmount = (long)MathUtil.round((equakeBuild * NumberUtils.toDouble(mform.getKyc_a04()))/10000,0,MathUtil.ROUND_UP)*10000;
	    
	    //若計算出的地震險保額>最大保額，則最終地震險保額=最大保額
	    if(equakeAmount>equakeMax)
	    	equakeAmount = equakeMax;
	    //equakeTotal = equakeAmount * equakeRate;
	    equakeTotal = (long)MathUtil.round((equakeAmount * equakeRate / 1000), 0, MathUtil.ROUND);
	    
	    mform.setFb01(String.valueOf((long)fb01));//主險保額
	    mform.setFb02(String.valueOf(fb02));//主險保費
	    mform.setFb03(String.valueOf((long)fb03));//標的保額 主險保額的三成，最高600000;
	    mform.setFb04(String.valueOf(equakeAmount));
	    mform.setFb05(String.valueOf(equakeTotal));
	    mform.setFb06(String.valueOf(fb02+equakeTotal));//應收保費
	    mform.setFb07(String.valueOf(fb02+equakeTotal));//實收保費
	    mform.setFs(String.valueOf(fb02));//火險優惠保費
	    mform.setQs(String.valueOf(equakeTotal));//地震優惠保費
	    mform.setRate(String.valueOf(rate));//簽單費率
	    mform.setDangerrate(String.valueOf(dangerrate));//危險費率
	    mform.setAddrate(String.valueOf(ac04));//附加費用率
	    mform.setChannelrate(String.valueOf(wj06));//通路別主險係數
	    mform.setEquakerate(String.valueOf(equakeRate));//地震險費率
	    mform.setKYC_T1520(dbo4.getRecordData("KD17"));//招攬人
	    
	    getTransaction().begin(0);
	    TradeCounter.count("F", (UserInfo) getSession().getAttribute(GlobalKey.USER_INFO), getTransaction());
    }

    private double getWj06(String kd16) throws AsiException
	{
		/*
		對應AS/400 FIRSTF.PT40PF的通路代碼（T4003）
		以取出的通路代碼串出FIRSTF.PT39PF的通路別（T3905） 
		得出的通路別代號傳入C65PRC
		*/
    	double wj06 = 0;
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4001= 'F' AND T4002 = ? ";
		String t3902sql = "SELECT T3905 FROM PT39PF WHERE T3901= ? ";
		String wj06sql = "SELECT WJ06 FROM FBWJPF WHERE WJ01=1 AND WJ02=? AND WJ03='RC' AND WJ04='' AND WJ05=" +
				"(SELECT MAX(WJ05) FROM FBWJPF WHERE ? >= WJ05 AND WJ01=1 AND WJ02=? AND WJ03='RC' AND WJ04='')";
		String wj06sqlarg[] = new String[3];
		
		QueryRunner run = new QueryRunner();
		getTransaction().begin(1);
		Connection as400Conn = getTransaction().getConnection(1);
		try
		{
			Map m = (Map) run.query(as400Conn , t4003sql, kd16, new MapHandler());
			Map x = (Map) run.query(as400Conn, t3902sql, m.get("t4003"), new MapHandler());
			String t3905 = (String) x.get("t3905");
			mform.setT4003(m.get("T4003").toString());
			wj06sqlarg[0] = t3905;
			wj06sqlarg[1] = mform.getYear()+mform.getMonth()+mform.getDate();
			wj06sqlarg[2] = t3905;
			Map y = (Map) run.query(as400Conn, wj06sql, wj06sqlarg, new MapHandler());
			wj06 = Double.parseDouble(String.valueOf(y.get("WJ06")));
		}
		catch (SQLException e)
		{
			throw new AsiException("無法取得通路別係數!");
		}
		
		if(wj06==0)
			throw new AsiException("無法取得通路別係數!");
		return wj06;
	}

    private String getDet4003(String kd16) throws AsiException
	{
		/*
		取出的通路代碼 AS/400 FIRSTF.PT40PF的通路代碼（T4003）
		*/
    	String det4003 = "";
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4001= 'F' AND T4002 = ? ";
		QueryRunner run = new QueryRunner();
		getTransaction().begin(1);
		Connection as400Conn = getTransaction().getConnection(1);
		try
		{
			Map m = (Map) run.query(as400Conn , t4003sql, kd16, new MapHandler());
			det4003 = m.get("T4003").toString();
			mform.setT4003(m.get("T4003").toString());
		}
		catch (SQLException e)
		{
			throw new AsiException("無法取得通路代碼!");
		}
		return det4003;
	}

    public boolean processP3() throws AsiException {
        DBO dbo = getTransaction().getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", mform.getUID());
        dbo.executeSelect();
        if (dbo.getRecordCount() == 1) {
            return true;
        }
        mform.setKyc_T1507(mform.getUID());
        mform.setPWD("");
        return false;
    }

    public void processP4(String agentno) throws AsiException {
        
        //查詢洗錢風險評估資料
    	String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
        String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
        
        if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
        	if(isid_switch.equals("Y")){//新版
    	        //被保險人-查詢洗錢風險評估資料
            	if (checkFas24prc_new(mform.getKyc_T1507(),mform.getKyc_T1506(),getBirthDay(),agentno) == false){
            		throw new UserException("WB1.ERROR13");
            	}

            	//要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc_new(mform.getKyc_T1547(),mform.getKyc_T1546(),getqmanBirthDay(),agentno) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}   	     	

        	}else{
    	        //被保險人-查詢洗錢風險評估資料
    	     	if (checkFas24prc(mform.getKyc_T1507(),mform.getKyc_T1506()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
    	     	
    	        //要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc(mform.getKyc_T1547(),mform.getKyc_T1546()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}

        	}
        }
     	
    	if ((mform.getKyc_T1510() == null || mform.getKyc_T1510().equals("")) && mform.getKyc_T1507().length()==8)
            mform.setKyc_T1510("3");


        if (mform.getKyc_T1509() == null || mform.getKyc_T1509().equals(""))
            mform.setKyc_T1509("3");

        String addr;
        if(mform.getAtown().length()==1)
        	mform.setAtown("");
        if (mform.getAddr().equals("new"))
            if (mform.getAa().equals("aa")){
                addr = mform.getAcity()+mform.getAtown()+mform.getAdd();
                mform.setZip(mform.getZip1());
                mform.setT3004(mform.getT30041());
            }
            else{
                addr = mform.getCity() + mform.getTown() + mform.getAddrnew();

            }
        else
            addr = mform.getAddrold();
        mform.setKyc_T1512(addr);

        if (mform.getZv03().equals("0"))
            mform.setZv03("");
        if (mform.getZx02().equals("0")){
            mform.setZx02("");
        }
    }

    public void processP5() throws AsiException {
        String tnumber = null;
        String barcodenumber = null;
        DBO kyckd = null;

        tnumber = Number.getNumber_F(getServlet(), getRequest(), "T");
        mform.setTnumber(tnumber);
        barcodenumber = Number.getNumber_FBC(getServlet(), getRequest(), "T");
        mform.setBarcodenumber(barcodenumber);
        kyckd = getKYCKD();

        getTransaction().begin(0);

        mform.setNewClient(isClient_P(mform.getKyc_T1507()));//檢核是否為新保戶
        
        //產otp
        String otp = KYCEncryptor.genOTP();

        //網路出單交易主檔(LOG檔)
        writeToPT15PF(tnumber,"",kyckd,"2" , otp); //保單號碼傳空白,類別傳入2-表寫入交易LOG檔
        //網路出單標的明細(LOG檔)
        writeToPT16PF(tnumber,kyckd,"2"); //傳入2-表寫入交易LOG檔
        //網路出單交易明細(LOG檔)
        writeToPT17PF(tnumber,kyckd,"Q","2"); //傳入2-表寫入交易LOG檔
        writeToPT17PF(tnumber,kyckd," ","2"); //傳入2-表寫入交易LOG檔

        mform.setNumber(tnumber);
        mform.setKYC_T1501a(tnumber);
        mform.setKYC_T1503a("F");

    }

    public void processP6() throws AsiException {
    	//重新由Session取由WB1M050f
    	mform = (WB1M050f) getSession().getAttribute("WB1M050f");
        setMainForm(mform);

        mform.setRetcode(((WB1M050f) getForm()).getRetcode());//將傳入的回應碼放入mform
        mform.setAuthCode(((WB1M050f) getForm()).getAuthCode());//將傳入的授權碼放入mform

        String tnumber = mform.getTnumber();
        //檢查是否進行過狀態更新及寄送email
        if (!"Yes".equals(getSession().getAttribute(tnumber))) {
            //檢查交易是否有授權成功，交易失敗不寫檔
            if ("00".equals(mform.getRetcode())) {
                //更新金流狀態
                UpdateState.updateKL80_State(getTransaction(), tnumber, "3");

            } else {
                //更新金流狀態
                UpdateState.updateKL80_State(getTransaction(), tnumber, "2");
            }
            //完成註記
            getSession().setAttribute(tnumber, "Yes");
        }

    }

    private DBO getKYCKD() throws AsiException {
        //增加來源網站欄位的判斷
        String KD19 = mform.getPjcode();
        
        if(!KD19.equals(""))
        	if(isProjectCode(KD19)){//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        		KD19 = CodeUtil.getCodeDesc(getServlet(), getRequest(), "PROJSOURCE", KD19.toUpperCase());
        	}
        	else{
        		KD19="BOSS3.0";
        	}       	
        else
        	KD19 = "KYC";

        //kyc.KYCKDs05
        Kyckd kd = new Kyckd();
        kd.setKD01("FR");
        kd.setKD02("F");
        kd.setKD03(" ");
        kd.setKD19(KD19); //來源網站
        DBO dbo = kd.executeSelect(getTransaction());

	    if(dbo.getRecordCount()==0)
	        throw new UserException("WB1.ERROR07");
	    
	    return dbo;
    }


    private String getBirthDay() {
        if (mform.getKyc_T1507().length()==8) return "";
        else
        return StringUtils.leftPad(mform.getByear(), 2, "0") + StringUtils.leftPad(mform.getBmonth(), 2, "0") + StringUtils.leftPad(mform.getBdate(), 2, "0");
    }

	//要保人生日
	private String getqmanBirthDay() {
	    if (mform.getKyc_T15A7_year() != null)
	        return StringUtils.leftPad(mform.getKyc_T15A7_year(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_month(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_date(), 2, "0");
	    else
	        return "0";
	}

    private String getIdentity() {
        if(mform.getKyc_T1507().length()==8)
            return "3";
        else
            return "1";
    }

    private void writeToPT17PF(String number,DBO kyckd,String kind,String type) throws AsiException {
	  	  DBO dbo = null;
	  	dbo = getTransaction().getDBO("kyc.KYCKLCt", 0);//type=2 表寫入交易LOG檔
        dbo.addParameter("T1701", number);
        dbo.addParameter("T1702", "FR");
        dbo.addParameter("T1703", kyckd.getRecordData("KD02"));
        dbo.addParameter("T1704", "1");
        dbo.addParameter("T1705", kind);
        dbo.addParameter("T1706", "1");
        dbo.addParameter("T1707", "31");
        dbo.addParameter("T1708", "0");
        dbo.addParameter("T1709", "0");
        dbo.addParameter("T1710", "");
        dbo.addParameter("T1711", "0");
        dbo.addParameter("T1712", "0");
        dbo.addParameter("T1713", "0");
        dbo.addParameter("T1714", "");
        dbo.addParameter("T1715", "");
        dbo.addParameter("T1716", "");
        dbo.addParameter("T1717", "");
        dbo.addParameter("T1718", "");

        //增加來源網站欄位的判斷
        String KD19 = (String)getSession().getAttribute(KycGlobal.CaseFrom);
        if (KD19 == null) {
            KD19 = "KYC";
        }

        DBO dbo2 = null;
        if (kind.equals("Q")){
	        dbo.addParameter("T1719", mform.getFb04());
	        dbo.addParameter("T1720", mform.getFb05());
	        dbo.addParameter("T1721", NumberUtil.sub(mform.getFb05(), mform.getQs()));

	        //kyc.KYCKDs04
	        Kyckd kd = new Kyckd();
	        kd.setKD01("FR");
	        kd.setKD02("F");
	        kd.setKD03("Q");
	        kd.setKD19(KD19); //來源網站
	        DBO dbo4 = kd.executeSelect(getTransaction());

		    //Q險優惠比率
		    double qkd12 = 0;
		    if (dbo4.getRecordCount()>=1)
		        qkd12 = Double.parseDouble(dbo4.getRecordData("KD12"))*100;

	        dbo.addParameter("T1722", String.valueOf(qkd12));
	        dbo.addParameter("T1723", mform.getQs());

	        dbo2 = getTransaction().getDBO("kyc.FPACPFs02",1);
	        String sdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	        dbo2.addParameter("AC02",sdate);
	        dbo2.executeSelect();

	        dbo.addParameter("T1725", dbo2.getRecordData("AC05"));
	        dbo.addParameter("T1730", "0");
	        dbo.addParameter("T1737", "0");
	        dbo.addParameter("T1742", dbo2.getRecordData("AC04"));
        }
        else{
	        dbo.addParameter("T1719", mform.getFb01());
	        dbo.addParameter("T1720", mform.getFb02());
	        dbo.addParameter("T1721", NumberUtil.sub(mform.getFb02(), mform.getFs()));

	        //kyc.KYCKDs05
	        Kyckd kd = new Kyckd();
	        kd.setKD01("FR");
	        kd.setKD02("F");
	        kd.setKD03(" ");
	        kd.setKD19(KD19); //來源網站
	        DBO dbo4 = kd.executeSelect(getTransaction());

		    //火險優惠比率
		    double fkd12 = 0;
		    if (dbo4.getRecordCount()>=1)
		        fkd12 = Double.parseDouble(dbo4.getRecordData("KD12"))*100;

	        dbo.addParameter("T1722", String.valueOf(fkd12));
	        dbo.addParameter("T1723", mform.getFs());

	        dbo2 = getTransaction().getDBO("kyc.FPACPFs01",1);
	        dbo2.addParameter("AC01",mform.getKyc_a03());
	        String sdate = mform.getYear()+mform.getMonth()+mform.getDate();  
	        dbo2.addParameter("AC02",sdate);
	        dbo2.executeSelect();

	        dbo.addParameter("T1725", mform.getRate());
	        dbo.addParameter("T1730", mform.getKyc_z402());
	        dbo.addParameter("T1737", dbo2.getRecordData("AC04"));
	        dbo.addParameter("T1742", "0");
        }
        dbo.addParameter("T1727", dbo2.getRecordData("AC06"));
        dbo.addParameter("T1728", dbo2.getRecordData("AC03"));
        dbo.addParameter("T1729", dbo2.getRecordData("AC08"));
        dbo.addParameter("T1731", dbo2.getRecordData("AC09"));
        dbo.addParameter("T1732", dbo2.getRecordData("AC10"));
        dbo.addParameter("T1734", dbo2.getRecordData("AC11"));
        dbo.addParameter("T1735", dbo2.getRecordData("AC12"));
        dbo.addParameter("T1736", dbo2.getRecordData("AC13"));
        dbo.addParameter("T1738", dbo2.getRecordData("AC07"));
        dbo.addParameter("T1755", "0");
        dbo.addParameter("T1756", "0");

        dbo.addParameter("T1796", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1797", mform.getKyc_T1507());
        dbo.addParameter("T1798", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1799", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    private void writeToPT16PF(String T1601,DBO kyckd,String type) throws AsiException {
	  	  DBO dbo = null;
			  dbo = getTransaction().getDBO("kyc.KYCKLBt", 0);//type=2 表寫入交易LOG檔
		dbo = getTransaction().getDBO("kyc.KYCKLBt", 0);//type=2 表寫入交易LOG檔
        dbo.addParameter("T1601", T1601);
        dbo.addParameter("T1602", "FR");
        dbo.addParameter("T1603", kyckd.getRecordData("KD02"));
        dbo.addParameter("T1604", "1");
        dbo.addParameter("T1605", "");
        dbo.addParameter("T1606", "0");
        dbo.addParameter("T1607", "0");
        dbo.addParameter("T1608", "");
        dbo.addParameter("T1609", "");
        dbo.addParameter("T1610", "");
        dbo.addParameter("T1611", "0");
        dbo.addParameter("T1612", "0");
        dbo.addParameter("T1613", "");
        dbo.addParameter("T1614", mform.getZip1());
        dbo.addParameter("T1615", mform.getCity1()+mform.getTown1()+mform.getAdd());
        dbo.addParameter("T1616", mform.getKyc_t3101());
        dbo.addParameter("T1617", "01");
        dbo.addParameter("T1618", mform.getKyc_a02());
        dbo.addParameter("T1619", mform.getKyc_a03());
        dbo.addParameter("T1620", mform.getKyc_a04());
        dbo.addParameter("T1621", mform.getBuildyear());
        dbo.addParameter("T1622", mform.getFb01());
        dbo.addParameter("T1623", mform.getFb02());
        dbo.addParameter("T1624", mform.getFb04());
        dbo.addParameter("T1625", mform.getFb05());
        dbo.addParameter("T1626", "建築物");
        dbo.addParameter("T1627", "");
        dbo.addParameter("T1628", mform.getFb03());
        dbo.addParameter("T1629", "");
        dbo.addParameter("T1630", "");
        dbo.addParameter("T1631", "");
        dbo.addParameter("T1632", mform.getFb06());
        dbo.addParameter("T1633", NumberUtil.sub(mform.getFb02(),mform.getFs()));
        dbo.addParameter("T1634", NumberUtil.sub(mform.getFb05(),mform.getQs()));
        dbo.addParameter("T1635", String.valueOf(mform.getFb07()));
        dbo.addParameter("T1636", mform.getKyc_t2906());
        dbo.addParameter("T1637", mform.getKyc_a01());
        dbo.addParameter("T1638", mform.getKyc_z402());
        dbo.addParameter("T1642", mform.getKyc_t1642());
        dbo.addParameter("T1643", mform.getKyc_t1643());
        dbo.addParameter("T1644", mform.getKyc_t1644());
        dbo.addParameter("T1645", mform.getKyc_t1645());
        dbo.addParameter("T1646", mform.getKyc_t1646());
        dbo.addParameter("T1696", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1697", mform.getKyc_T1507());
        dbo.addParameter("T1698", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1699", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    private void writeToPT15PF(String tnumber, String number, DBO kyckd, String type ,String otp) throws AsiException
	{
    	String insNum=getRequest().getSession().getAttribute("insNum") !=null ? (String)getRequest().getSession().getAttribute("insNum") : "" ;//選擇公司投保過的保單號碼
    	
		DBO dbo = null;

		dbo = getTransaction().getDBO("kyc.KYCKLAt", 0);// type=2 表寫入交易LOG檔
		dbo.addParameter("T1501", tnumber);// 交易序號
		dbo.addParameter("T1502", "FR");
		dbo.addParameter("T1503", kyckd.getRecordData("KD02"));
		dbo.addParameter("T1504", number);// 保單號碼
		if (number.length() > 0)
		{
			dbo.addParameter("T1505", number.substring(2, 4));
		}
		else
		{
			dbo.addParameter("T1505", number);
		}
		dbo.addParameter("T1506", mform.getKyc_T1506());// 被保險人
		dbo.addParameter("T1507", mform.getKyc_T1507());
		dbo.addParameter("T1508", getBirthDay());
		dbo.addParameter("T1509", mform.getKyc_T1509());
		dbo.addParameter("T1510", mform.getKyc_T1510());
		dbo.addParameter("T1511", getZip());
		dbo.addParameter("T1512", mform.getKyc_T1512());
		dbo.addParameter("T1513", mform.getKyc_T1513());
		dbo.addParameter("T1514", mform.getKyc_T1514());
		dbo.addParameter("T1515", mform.getKyc_T1515());
		dbo.addParameter("T1516", mform.getKyc_T1516());
		String t1517 = mform.getYear() + StringUtils.leftPad(mform.getMonth(), 2, "0") + StringUtils.leftPad(mform.getDate(), 2, "0");
		dbo.addParameter("T1517", t1517);
		String t1518 = mform.getYear2() + StringUtils.leftPad(mform.getMonth2(), 2, "0") + StringUtils.leftPad(mform.getDate2(), 2, "0");
		dbo.addParameter("T1518", t1518);
		dbo.addParameter("T1519", kyckd.getRecordData("KD16"));
		dbo.addParameter("T1520", kyckd.getRecordData("KD17"));
		dbo.addParameter("T1521", "");
		dbo.addParameter("T1522", "0");
		dbo.addParameter("T1523", DateUtil.getSysDate(getUsrInfo(), false));
		dbo.addParameter("T1524", "0");
		dbo.addParameter("T1525", mform.getZx01());
		dbo.addParameter("T1526", mform.getZv02());
		dbo.addParameter("T1527", "");
		dbo.addParameter("T1528", "");
		dbo.addParameter("T1529", "");
		dbo.addParameter("T1530", "9");
		dbo.addParameter("T1534", "");
		dbo.addParameter("T1535", "");
		dbo.addParameter("T1536", "");
		dbo.addParameter("T1537", "");
		dbo.addParameter("T1538", "B2C");
		dbo.addParameter("T1539", String.valueOf(mform.getFb06()));
		dbo.addParameter("T1540", NumberUtil.sublong(mform.getFb06(), mform.getFb07()));
		dbo.addParameter("T1541", String.valueOf(mform.getFb07()));
		dbo.addParameter("T1542", insNum);
		dbo.addParameter("T1543", "");
		dbo.addParameter("T1544", getIdentity());
		dbo.addParameter("T1545", "");
		dbo.addParameter("T1546", mform.getKyc_T1546());
		dbo.addParameter("T1547", mform.getKyc_T1547());
		dbo.addParameter("T1548", "0");
		dbo.addParameter("T1549", "0");
		dbo.addParameter("T1550", "");
		dbo.addParameter("T1551", "");
		dbo.addParameter("T1552", "");
		dbo.addParameter("T1553", "");
		dbo.addParameter("T1554", "0");
		dbo.addParameter("T1555", "");
		dbo.addParameter("T1556", "12");
		dbo.addParameter("T1557", "12");
		dbo.addParameter("T1558", String.valueOf(mform.getFb01()));
		dbo.addParameter("T1559", String.valueOf(mform.getFb04()));
		dbo.addParameter("T1560", String.valueOf(mform.getFb02()));
		dbo.addParameter("T1561", String.valueOf(mform.getFb05()));
		dbo.addParameter("T1562", mform.getZx01());
		dbo.addParameter("T1563", mform.getZv02());
		dbo.addParameter("T1564", mform.getZx02() + mform.getZv03());
		dbo.addParameter("T1565", "");
		dbo.addParameter("T1566", "");
		dbo.addParameter("T1567", "");
		dbo.addParameter("T1568", "");
		dbo.addParameter("T1569", mform.getKyc_T1569()); //電訪方式
		dbo.addParameter("T1570", "");
		dbo.addParameter("T1571", "");
		dbo.addParameter("T1572", DateUtil.getSysTime(false));
		dbo.addParameter("T1573", "");
		dbo.addParameter("T1574", "Y");
		dbo.addParameter("T1575", "");
		dbo.addParameter("T1576", "");
		dbo.addParameter("T1577", "N");
		dbo.addParameter("T1580", "1");
	    String det4003 = getDet4003(kyckd.getRecordData("KD16")) ; //KD16是業務來源， 

	    dbo.addParameter("T15D4", mform.getBarcodenumber() + det4003);// 交易條碼序號
        mform.setData_otp(otp);
        
        //OTP
        String expireTime = SystemParam.getParam("OTPEXTIME");
        String otpexpireday = getExpireDate();
        String INSARGNO = SystemParam.getParam("ARGDOC_INS_NO"); // 聲明事項文件編號

        mform.setExpireTime(expireTime); 
        mform.setExpireDate(otpexpireday);

        dbo.addParameter("T15B0", mform.isNewClient() ? "1" : "2");
        dbo.addParameter("T15B1", otp);
        dbo.addParameter("T15B2", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T15B3", DateUtil.getSysTime(false));
        dbo.addParameter("T15B4", otpexpireday);
        dbo.addParameter("T15B5", expireTime);
        dbo.addParameter("T15B6", "0");
        dbo.addParameter("T15B7", "0");
        dbo.addParameter("T15B8", "0");
        dbo.addParameter("T15B9", "NCCC");      
        dbo.addParameter("T15C0", mform.getIsmobile());
        dbo.addParameter("T15C1", mform.getOs());
        dbo.addParameter("T15C2", mform.getBrowser());
        dbo.addParameter("T15C3", mform.getBro_version());
        dbo.addParameter("T15C9", INSARGNO);
        //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
        String remoteAddr = getRequest().getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = getRequest().getRemoteAddr();
        }        
        dbo.addParameter("T15C10", remoteAddr);
        dbo.addParameter("T15E0", remoteAddr);
	
		dbo.addParameter("TA1501", "");
		dbo.addParameter("TA1502", "");
		dbo.addParameter("TA1503", "");
		dbo.addParameter("TA1504", "");
		dbo.addParameter("TA1505", "");
		dbo.addParameter("TA1506", "");
        dbo.addParameter("T1594", DateUtil.getSysTime());
        dbo.addParameter("T1595", DateUtil.getSysTime());
		dbo.addParameter("T15A9", mform.getKyc_T15A9() != null ? mform.getKyc_T15A9() : "");
		dbo.addParameter("T1596", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
		dbo.addParameter("T1597", mform.getKyc_T1507());
		dbo.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
		dbo.addParameter("T1599", mform.getKyc_T1507());

        dbo.addParameter("T1544A", mform.getKyc_T1544A());	//被保險人國籍
        dbo.addParameter("TA1512", mform.getKyc_TA1512());	//被保險人評估職業
        dbo.addParameter("T15D0", mform.getKyc_T15D0());	//要保人國籍
        dbo.addParameter("TA1511", mform.getKyc_TA1511());	//要保人評估職業

        dbo.addParameter("TA1505", mform.getKyc_TA1505());	//車險客戶屬性
        dbo.addParameter("TA1506", mform.getKyc_TA1506());	//車險客戶繳交保費來源
        dbo.addParameter("TA1506O", mform.getKyc_TA1506o());	//車險客戶繳交保費來源-其他
        
        dbo.addParameter("T1584", mform.getT1584());	//專案代號
        
        dbo.addParameter("T1582", mform.getPjcode() == null ? "" : mform.getPjcode());	//推薦人代碼
        
		dbo.executeInsert();

	}

    private String getZip() {
        if (mform.getZip().equals("")) {
            DBO dbo = (DBO) getSession().getAttribute(KycGlobal.Kyc_UserInfo);
            return dbo.getRecordData("CA106");
        } else
            return mform.getZip();
    }
    
    /**
     * 檢核地址是否完整
     * @param type 1.標的物地址2.通訊地址
     */
    public void checkAddress(int type)
    {
    	if(type==2 && "aa".equals(mform.getAa()))//檢核地址同標的物地址時，不檢核通訊地址
    		return;
    	
    	String zip = (type==1?mform.getZip1():mform.getZip()) ;
    	String address = (type==1?mform.getAcity()+mform.getAtown()+mform.getAdd()
    							:mform.getCity()+mform.getTown()+mform.getAddrnew());
    	
    	if(type == 2 && mform.getAddr().equals("old")){
    		zip = mform.getOldzip();
    		address = mform.getAddrold();
    	}
    	
    	String msg = "";
    	
    	getTransaction().begin(1);
    	Connection as400Conn = getTransaction().getConnection(1);
    	AS400Procedure as400 = new AS400Procedure();
    	String[] result = as400.callFAS20APRC(as400Conn, "F", "*", "", "", zip, address);
    	
    	if(result[0].trim().length()==0 || "A1".equals(result[0].trim()))
    		msg = "";
    	else if("E3".equals(result[0].trim()))
    		msg = "郵遞區號已停用";
    	else if("E4".equals(result[0].trim()))
    		msg = "地址錯誤";
    	else if("E5".equals(result[0].trim()))
    		msg = "郵遞區號與地址不符";
    	else if("E6".equals(result[0].trim()))
    		msg = "幾段╱街請改輸阿拉伯數字";
    	else
    		msg = "其他錯誤，重新操作或請洽服務人員";
    	
    	if(type ==1)
    		mform.setAdd1msg(msg);
    	else
    		mform.setAdd2msg(msg);
    }
    
    /**
     * 查詢住宅地震基金是否有重複保險
     * @return 無複保險回傳空白，有則回傳訊息
     */
    public void isInsuredMsg()
    {
    	String insuredMsg = "";
    	String url = "";
    	String account = "";
    	String id = "";
    	url = "https://webservice-di.treif.org.tw/WS_CDI/W_CDI.asmx/Call_W_CDI";
		account = "10WSDIREAL";
		id = "DEX2WSAST7";
    	String startDate = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD
    			, (Integer.parseInt(mform.getYear())+1911)+mform.getMonth()+mform.getDate());
    	String endDate = FormatUtil.getDateFormat(DateUtil.Format_YYYYMMDD
    			, (Integer.parseInt(mform.getYear2())+1911)+mform.getMonth2()+mform.getDate2());
    	//1~10碼 使用者帳號 11~20碼 使用者密碼 21~25碼 筆數序 26~45碼 空白 46~55碼 保險期間-開始(YYYY/MM/DD) 56~65碼 保險期間-結束
    	//66~335碼 查詢地址(郵遞區號+地址)
    	String paramValue = account + id + StringUtil.fillPre("1", 5, ' ') + StringUtil.fillPre("", 20, ' ')
    						+startDate + endDate + mform.getZip1() + mform.getAcity()
    						+ mform.getAtown() + mform.getAdd();
    	
    	//跳過SSL憑證檢核
    	Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
    	Protocol.registerProtocol("https", easyhttps);
    	
    	HttpClient  client  =   new   HttpClient();
    	client.setConnectionTimeout(10000);
    	client.setTimeout(10000);
    	
    	PostMethod postmethod = new PostMethod(url);
    	postmethod.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
    	postmethod.addParameter("cdiq", paramValue);
    	Map resultMap = new HashMap();
    	try{
    		mform.setKyc_t1645(getTransaction().getSystemDate());
    		client.executeMethod(postmethod);
        	Document doc = parse(postmethod.getResponseBodyAsStream());
        	Element root = doc.getRootElement();
        	
        	doc = DocumentHelper.parseText(root.getStringValue());
        	root = doc.getRootElement();
        	for (Iterator i = root.elementIterator(); i.hasNext();) {
        		Element element = (Element)i.next();
				resultMap.put(element.getName(), element.getText());
        	}
        	
        	if("0".equals(resultMap.get("Code")))
        	{
        		mform.setKyc_t1642(String.valueOf(resultMap.get("DIInsNo")));
        		mform.setKyc_t1643(String.valueOf(resultMap.get("DINo")));
        		mform.setKyc_t1644("");        		
        	}else{
        		insuredMsg = String.valueOf(resultMap.get("ErrorMessage"));
        		if ("1".equals(resultMap.get("Code"))){
        			insuredMsg = "此地址有復保險";
        		}
        		
        		mform.setKyc_t1644(String.valueOf(resultMap.get("Code")));
        	}
        	
    	} catch (Exception e) {
    		insuredMsg = "網路連線有誤，重新操作或請洽服務人員";
            e.printStackTrace();
        }
    	
    	mform.setKyc_t1646(getTransaction().getSystemDate());    	
    	mform.setInsuredMsg(insuredMsg);
    }
    
    /**
     * 建築結構對應標的樓層是否通過檢核
     * @return
     */
    public boolean checkBuildingFloor()throws AsiException
    {
    	getTransaction().begin(1);
    	Connection as400Conn = getTransaction().getConnection(1);
    	AS400Procedure as400 = new AS400Procedure();
    	String[] result = as400.callFPS457PRC(as400Conn, "1", mform.getKyc_t3101(), mform.getKyc_a02() , "");
    	if(result[0]!=null && !"E".equals(result[0]))
    		return true;
    	else if(result[0]==null)
    	{
    		getRequest().setAttribute("alert", "連線有誤，重新操作或請洽服務人員");
    		return false;
    	}else
    	{
    		DBO dbo1 = getTransaction().getDBO("kyc.QT1M03s05", 1);
            dbo1.addParameter("mg00", result[5]);
            dbo1.executeSelect();
            getRequest().setAttribute("alert", dbo1.getRecordData(1, "mg01")+"，該建物結構最高樓層數為"+result[4]+"樓");
    		return false;
    	}    		
    }
    
    /**
     * 取得建築等級
     * @return
     * @throws AsiException
     */
    public String getBuildingClass()throws AsiException
    {
    	getTransaction().begin(1);
    	Connection as400Conn = getTransaction().getConnection(1);
    	AS400Procedure as400 = new AS400Procedure();
    	String insurStartDate = mform.getYear()+mform.getMonth()+mform.getDate();
    	String[] result = as400.callFPS471PRC(as400Conn, mform.getKyc_t3101(), "RC", mform.getKyc_a02()
    			, insurStartDate, "");
    	return result[5];
    }
    
    private Document parse(InputStream in) throws DocumentException {
        SAXReader reader = new SAXReader();
        Document document = reader.read(in);
        return document;
    }

    
    /**
     * 寄送OTP EMAIL
     * @param request
     */
    public void sendOTPMail(HttpServletRequest request)
    {
    	int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
    	
    	String email = mform.getKyc_T1516();
    	String name = mform.getKyc_T1506();
    	String otp = mform.getData_otp();
    	
 		//寄Email
 		KycMailUtil sender = new KycMailUtil();

 		//取範本
 		BufferedReader fr;
 		String path = getServlet().getServletContext().getRealPath("/mail/TransactionOTP_" + getLocale() + ".html");

 		StringBuffer linebf = new StringBuffer();
 		try {
 			fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
 			String line;
 			linebf = new StringBuffer();
 			line = fr.readLine();
 			while (line != null) {
 				linebf.append(line);
 				line = fr.readLine();
 			}

 		}
 		catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		catch (IOException e) {
 			e.printStackTrace();
 		}

 		//姓名隱碼
 		StringBuffer hiddenName  = new StringBuffer();
 		if(name.length() < 4){
 		   for(int i=0;i<name.length();i++){
 			   if(i==1){
 				   hiddenName.append("O");
 			   }
 			   else{
 				   hiddenName.append(name.substring(i,i+1));
 		   	   }
 		   }
 		}
 		else{
 		    for(int i=0;i<name.length();i++){
 			    if(i==1 || i==2){
 				    hiddenName.append("O");
 			    }
 			    else{
 				    hiddenName.append(name.substring(i,i+1));
 		   	    }
 		    }
 		}
 		
	   	String msg = linebf.toString();
	   	msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
	   	msg = msg.replaceAll("\\{otp\\}", otp);
	   	msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));
	
	   	sender.setSubject("第一保 電子商務網 網路投保交易OTP");
	   	sender.setMessage(msg);
	   	sender.addTo(email);
	   	sender.sendMail();

   }

    
 	/**
 	 * 寄發簡訊
 	 * 
 	 * @param data
 	 */
 	public void sendMobileMsg()
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		sb.append("第一產物交易OTP碼：").append(mform.getData_otp()).append("\n");
 		sb.append(" 您正於第一產物進行網路投保作業\n");
 		sb.append("請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！若無線上作業請忽略此封簡訊，謝謝。");

 		String sendTel = mform.getKyc_T1515();
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

 	
    /**
     * 重新產生OTP,更新交易檔
     * @return
     * @throws AsiException
     */
    public boolean isUpdateOTP() throws AsiException 
    {
 	  boolean isok = false;
   	 
 	  String getotp = KYCEncryptor.genOTP();
 	  mform.setData_otp(getotp);
   	 
 	  String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
 	  String systime = DateUtil.getSysTime();
 	  String otpexpireday = getExpireDate();
   	 
 	  String sql = "UPDATE KYCKLA SET T15B1=?,T15B2=?,T15B3=?,T15B4=?,T15B5=?,T1598=?,T1599=?,T15B8=0 WHERE T1501=?";
   	 
 	  String args[] = new String[8];
 	  args[0] = getotp;
 	  args[1] = sysdate;
 	  args[2] = systime;
 	  args[3] = otpexpireday;
 	  args[4] = SystemParam.getParam("OTPEXTIME");
 	  args[5] = sysdate;
 	  args[6] = mform.getUID();
 	  args[7] = mform.getNumber();

 	  QueryRunner runner = new QueryRunner();
 	  getTransaction().begin(0);

 	  int ret = 0;
   	 
 	  try 
 	  {
 		  Connection con = getTransaction().getConnection(0);
 		  ret = runner.update(con, sql ,args);
 		  if(ret > 0)
 			  isok = true;
   		 
 	  } catch (SQLException e) {
 		  e.printStackTrace();
 		  throw new AsiException(e.getLocalizedMessage());
 	  } 

 	  return isok;
 	}

  	/**
  	 * 取得OTP過期日期
  	 * @return
  	 */
  	public String getExpireDate() {
		String expireday ="";
		KycDateUtil kycdate = new KycDateUtil();
		String sysdate = kycdate.getKycDate();
  	 
      try {
          
         kycdate.setKycDate(sysdate);
         kycdate.add(KycDateUtil.DATE, NumberUtils.toInt(SystemParam.getParam("OTPEXDAY")));//系統參數，系統日加天數
         expireday = kycdate.getKycDate();

      } 
      catch (ParseException e) {
         e.printStackTrace();
      }
      return expireday;
	}

 	/**
 	 * 確認otp是否正確
 	 * @return
 	 * @throws AsiException
 	 */
 	public boolean isRightOTP()throws AsiException
 	{
 		boolean isRight = false;
 		
 		String t1501=mform.getTnumber();
 		
 		DBO dbo = getTransaction().getDBO("kyc.KYCKLAs03", 0);
 		dbo.addParameter("T1501", t1501);
 		dbo.executeSelect();

 		QueryRunner run = new QueryRunner();
		String sql;
		sql = "SELECT * FROM KYCKLA ";
		sql += "WHERE T1501 = ? AND ROWNUM = 1";		

		Map ret = new HashMap();
		try
		{
			getTransaction().begin(0);
			
			ret = (Map) run.query(getTransaction().getConnection(0),sql, t1501 ,new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			System.out.print("bb:" + e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}

 		String inputotp = mform.getInput_otp();
 		String orgotp = ret.get("T15B1").toString();
 		String expired = ret.get("T15B4").toString();
 		
 		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
 		
 		if(Integer.parseInt(sysdate) <= Integer.parseInt(expired))
 			if(inputotp.equals(orgotp))
 				isRight = true;
 		
 		return isRight;
 	}

    /**
     * 查客戶id是否為排除傷害險有效保單客戶
    * @param id
    * @return
    */
   private boolean isClient_P(String id)
   {
	   boolean isNewclient = true;
   	
	   String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	   String sql = "SELECT * FROM IC02PF WHERE C201=? AND C206 >= ? AND C204 NOT IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

	   String[] args = new String[2];
	   args[0] = id;
	   args[1] = sysdate;
				
	   Connection con = AS400Connection.getConnection();
	   List ret = null;
 		
	   try
	   {
		   QueryRunner runner = new QueryRunner();
		   ret = (List) runner.query(con, sql.toString(), args, new TrimedMapListHandler());
 			
		   if(!ret.isEmpty() && ret.size()>0)
			   isNewclient = false;
	   }
	   catch (SQLException e)
	   {
	   	e.printStackTrace();
	   }
	   finally{
	   	AS400Connection.closeConnection(con);
	   }

	   return isNewclient;	   
   }

   /**
    * 傳入姓名、id 查詢法務管制名單及高風險名單
    * 
    * @param name 姓名
    * @param id 身分證字號
    * @param agentno 招攬人
    * @return
    * @throws AsiException
    */
   public boolean checkFas24prc_new(String id , String name ,String birthday , String agentno) throws AsiException {
       /*
        * S24I0	1	文字	執行BRIDGER(ISID)方式(1/2/3)
        * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
        * S24I1A	1	文字	傳入小險別（ /V/T/Z）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
		 * S24I9	7	數字	傳入人員生日(民國年)
		 * S24IA	10	文字	傳入打單人員(AS400使用者帳號)
        * */
   	
       FAS24Input in = new FAS24Input();
       in.setS24i0("1");
       in.setS24i1("C");
       in.setS24i1a("");
       in.setS24i2("1");
       in.setS24i3(id);
       in.setS24i4("");
       in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
       in.setS24i6(name);
       in.setS24i7("");
       in.setS24i8(id);
       in.setS24i9(birthday);
       in.setS24ia(agentno);
       FAS24PRC prc = new FAS24PRC();
       FAS24Return out = prc.execute(in);
       
      if("E".equals(out.getS24o1().trim()))
          return false;
      else
          return true;
   }

   /**
    * 傳入姓名、id 查詢法務管制名單及高風險名單
    * @param id
    * @param name
    * @return
    * @throws AsiException
    */
   public boolean checkFas24prc(String id , String name) throws AsiException {
       /*
        * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
        * */
   	
       FAS24Input in = new FAS24Input();
       in.setS24i1("C");
       in.setS24i2("1");
       in.setS24i3(id);
       in.setS24i4("");
       in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
       in.setS24i6(name);
       in.setS24i7("");
       in.setS24i8(id);
      FAS24PRC prc = new FAS24PRC();
      FAS24Return out = prc.execute(in);
       
      if("E".equals(out.getS24o1().trim()))
          return false;
      else
          return true;
   }
   
   /**
    * 判斷是否為專案代號或推薦人代號(true->專案代號 、false->推薦人代號)
    * @param pjcode
    */
   public boolean isProjectCode(String pjcode){
   	   boolean ispjcode=true;
	
   	   Connection con = AS400Connection.getOracleConnection();
   	   String sql="SELECT * FROM IC01PFA WHERE C01A17 = ?";
   	   List ret = new LinkedList();
		
	   try
	   {
		   QueryRunner runner = new QueryRunner();
		   ret = (List<?>) runner.query(con, sql, pjcode, new TrimedMapListHandler());	
		   if(ret != null && ret.size() > 0){
			   ispjcode=false;
		   }
	   }
	   catch (SQLException e)
	   {
		   e.printStackTrace();
	   }
	   finally{
		   AS400Connection.closeConnection(con);
	   }  
	   
	   return ispjcode;
   }
   
   /**
    * 查找有在公司投保過的保單
    * @param id
    */
   public List queryFireData(String id){
	
   	   Connection con = AS400Connection.getConnection();
   	   String sql="SELECT T2101,T2102,T2136,T2137,T2104,T2105,T2106,T2109,T2110,"
   	   		+ "T2115,T2116,T2140,T2142,T2143,T2111,T2113,T2114,T2115,T2116,T2131,T2132,T2127,T2144,T2145,T2147,"
   	   		+ "C213,C231,ZN04,SUBSTR(A.ZZ03,18,8) AS ZZ03,C204,C210,C233,T2122,"
   	   		+ "case when ZX02 is null then '' else ZX02 end AS T2122D,T2123,case when ZV03 is null then '' else ZV03 end AS T2123D,T2155,T2146,"
   	   		+ "T2151,T2152,T2213,T2214,T2215,T3102 AS T2215D,T2216,T3302 AS T2216D,T2217,T2218,SUBSTR(B.ZZ03,1,10) AS T2218D,T2219,T2235,T2236,T2220 "
   	   		+ "FROM IC02PF "
   	   		+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
   	   		+ "LEFT JOIN FBZNPF ON ZN01='E' AND ZN02=SUBSTR(C202,1,4) "
   	   		+ "LEFT JOIN FBZZPF AS A ON A.ZZ01='BO' AND A.ZZ02=ZN04 "
   	   		+ "LEFT JOIN PT22PF ON T2201=C202 AND T2202=C203 "
   	   		+ "LEFT JOIN PT31PF ON T3101=T2215 "
   	   		+ "LEFT JOIN PT33PF ON T3301=T2216 "
   	   		+ "LEFT JOIN FBZXPF ON ZX01=T2122 "
   	   		+ "LEFT JOIN FBZVPF ON ZV01=T2122 AND ZV02=T2123 "
   	   		+ "LEFT JOIN FBZZPF AS B ON B.ZZ01='BH' AND B.ZZ02=T2218 "
   	   		+ "WHERE T2105=? AND T2102='F' "
   	   		+ "ORDER BY T2116 DESC ";
   	   List ret = null;
		
	   try
	   {
		   QueryRunner runner = new QueryRunner();
		   ret = (List<?>) runner.query(con, sql, id, new TrimedMapListHandler());	
	   }
	   catch (SQLException e)
	   {
		   e.printStackTrace();
	   }
	   finally{
		   AS400Connection.closeConnection(con);
	   }  
	   
	   return ret;
   }
 
   /**
    * 查找保單資料(p3頁顯示用)
    * @param insNum
    */
   public Map queryFireData2(String insNum){
	
   	   Connection con = AS400Connection.getConnection();
   	   String sql="SELECT T2101,T2102,T2136,T2137,T2104,T2105,T2106,T2109,T2110,"
   	   		+ "T2115,T2116,T2140,T2142,T2143,T2111,T2113,T2114,T2115,T2116,T2131,T2132,T2127,T2144,T2145,T2147,"
   	   		+ "C213,C231,ZN04,SUBSTR(A.ZZ03,18,8) AS ZZ03,C204,C210,C233,T2122,"
   	   		+ "case when ZX02 is null then '' else ZX02 end AS T2122D,T2123,case when ZV03 is null then '' else ZV03 end AS T2123D,T2155,T2146,"
   	   		+ "T2151,T2152,T2213,T2214,T2215,T3102 AS T2215D,T2216,T3302 AS T2216D,T2217,T2218,SUBSTR(B.ZZ03,1,10) AS T2218D,T2219,T2235,T2236,T2220 "
   	   		+ "FROM IC02PF "
   	   		+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
   	   		+ "LEFT JOIN FBZNPF ON ZN01='E' AND ZN02=SUBSTR(C202,1,4) "
   	   		+ "LEFT JOIN FBZZPF AS A ON A.ZZ01='BO' AND A.ZZ02=ZN04 "
   	   		+ "LEFT JOIN PT22PF ON T2201=C202 AND T2202=C203 "
   	   		+ "LEFT JOIN PT31PF ON T3101=T2215 "
   	   		+ "LEFT JOIN PT33PF ON T3301=T2216 "
   	   		+ "LEFT JOIN FBZXPF ON ZX01=T2122 "
   	   		+ "LEFT JOIN FBZVPF ON ZV01=T2122 AND ZV02=T2123 "
   	   		+ "LEFT JOIN FBZZPF AS B ON B.ZZ01='BH' AND B.ZZ02=T2218 "
   	   		+ "WHERE T2101=? ";

   	   Map ret = null;
		
	   try
	   {
		   QueryRunner runner = new QueryRunner();
		   ret = (Map) runner.query(con, sql, insNum, new TrimedMapHandler());	
	   }
	   catch (SQLException e)
	   {
		   e.printStackTrace();
	   }
	   finally{
		   AS400Connection.closeConnection(con);
	   }  
	   
	   return ret;
   }
}
