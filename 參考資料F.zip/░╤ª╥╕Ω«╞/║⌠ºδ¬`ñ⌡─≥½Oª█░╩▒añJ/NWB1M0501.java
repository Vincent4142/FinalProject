/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.RequestUtils;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.CharacterUtil;
import com.asi.kyc.common.utils.NCCCUtil;
import com.asi.kyc.reg.models.RG1M010m;
import com.asi.kyc.wb1.dao.KYCWHDDao;
import com.asi.kyc.wb1.forms.WB1M050f;
import com.asi.kyc.wb1.models.WB1M050m;
import com.firstins.dao.procedure.FAS32Input;
import com.firstins.dao.procedure.FAS32PRC;
import com.firstins.dao.procedure.FAS32Return;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.sec.actions.kycAction;


/**
 * @author vsg
 * 網路投保-住宅火險新程式
 */
public class NWB1M0501 extends kycAction
{
    public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        WB1M050f form1 = (WB1M050f) form;
        
    	if(form1.getActionCode()==0 && form1.getRetcode() != null){
    		form1.setActionCode(21);
    	}

        else if (form1.getActionCode() == 0){
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
        }
    }

    public void doProcess(ActionMapping mapping, AsiActionForm form,
        HttpServletRequest request, HttpServletResponse response)
        throws AsiException
    {

    	WB1M050m model = new WB1M050m(tx_controller, request, form);
        String omitcredit = SystemParam.getParam("INS_OMITCREDIT");// 是否略過聯合信用卡刷卡機制，平常-N 測試-Y
        String otpswitch = SystemParam.getParam("OTPSMS_SWITCH"); // 簡訊發送控制
        tx_controller.begin(0);
        RG1M010m model2 = new RG1M010m(tx_controller, request, form);
    	//專案代號
        String pjcode = request.getParameter("pjcode") != null ? request.getParameter("pjcode") : "";       
        if(!pjcode.equals("")) {  
        	//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        	if(model.isProjectCode(pjcode)){
        		pjcode = CodeUtil.getCodeDesc(getServlet(), request, "PROJSOURCE", pjcode.toUpperCase());//由專案代碼找對應的業務來源            	
        	}
        	else{
        		if(!pjcode.equals("BOSS3.0")){
        			request.getSession().setAttribute("referrerCode",pjcode);
        		}
        		pjcode="BOSS3.0";
        	}        	
        }     
        request.setAttribute("pjcode", pjcode);   	
    	
        model.init();
        
        //取代head用
        request.setAttribute("meta_title", getKYCWHDbyKey("F", "title"));
        request.setAttribute("meta_keyword", getKYCWHDbyKey("F", "keyword"));
        request.setAttribute("meta_desc", getKYCWHDbyKey("F", "description"));
        request.setAttribute("meta_ogtitle", getKYCWHDbyKey("F", "ogtitle"));
        request.setAttribute("meta_ogdescription", getKYCWHDbyKey("F", "ogdescription"));
        request.setAttribute("meta_twittertitle", getKYCWHDbyKey("F", "twittertitle"));
        
        //取得招攬人代號，FAS24PRC用
        String agentno = getKYCKD_KD17("FR", "F", " ", "0", pjcode, "41");

        
        if (form.getActionCode() == 21) {
            model.processP6();
            
            request.setAttribute("WB1M050f", model.getMainForm());           
            request.setAttribute("action", "NWB1M0501");
            
            String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商信箱
            String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
            String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
            request.setAttribute("ecom_email", ecom_email);
            request.setAttribute("telno", ecom_tel);
            request.setAttribute("faxno", ecom_fax);

			//完成投保若有填寫推薦人代號則LINE推播通知
            HttpSession session = request.getSession();
			String referrerCode=(String) session.getAttribute("pjcode") != null ? (String) session.getAttribute("pjcode") : "";
			String customer=(String) session.getAttribute("customer") != null ? (String) session.getAttribute("customer") : "";
			if(!referrerCode.equals("") && referrerCode.length() > 0){
				if(!model.isProjectCode(referrerCode)){
					SendLineMessage slm=new SendLineMessage();
					String user_id=slm.getEmployeeCode(referrerCode);
					slm.sendLine(user_id, "推薦人通知", "投保：您推薦"+ slm.getHiddenName(customer) +"會員已完成住火險投保，電銷部很愛你");
				}
			}
			session.removeAttribute("pjcode");
			session.removeAttribute("customer");
			
	        //head用GTM碼
	        request.setAttribute("gtm_head_end", getKYCWHD_GTM("F", "GTM-HEAD-END"));
            
            form.setNextPage(6);
            return;
        }
        
        else if (form.getActionCode() == GlobalKey.ACTION_SELECT){
	        model.processP1();	  
	        
	        UserInfo ui = (UserInfo) request.getSession().getAttribute(GlobalKey.USER_INFO);

            if (ui != null) {//有登入
            	List fdata=model.queryFireData(ui.getUserId());
            	request.setAttribute("fdata", fdata);
            }
	        
	        form.setNextPage(1);
        } else if (form.getSource().equals("WB1M050p1")){
        	int page = 0;        	
        	
        	//先記住客戶是否同意行銷
        	HttpSession session = request.getSession(false);
        	String C01A18= request.getParameter("agreeChk4")== null ? "" : request.getParameter("agreeChk4");
        	session.setAttribute("C01A18",C01A18);
        	
			//有輸入推薦人代號就紀錄
			if(request.getParameter("pjcode") !="" && request.getParameter("pjcode") != null){					
				session.setAttribute("pjcode", request.getParameter("pjcode"));
			}
        	
        	if(request.getParameter("radioins").equals("r1")) {//選公司投保過
        		String insNum=request.getParameter("recordins");//保單號碼
            	String addr=request.getParameter("addr");//標的物地址       	
            	String city=addr.substring(0,3);
            	String town="";
            	String road="";
            	
            	if(city.equals("嘉義市") || city.equals("新竹市")) {
            		road=addr.substring(3);
            	}
            	else {
            		if(addr.substring(5,6).equals("鄉") || addr.substring(5,6).equals("區") || addr.substring(5,6).equals("鎮") || addr.substring(5,6).equals("市")) {//正常狀況ex：中正區
            			town=addr.substring(3,6);
            			road=addr.substring(6);
            		}
            		else if(addr.substring(4,5).equals("區")) {//特殊狀況ex：中區
            			town=addr.substring(3,5);
            			road=addr.substring(5);
            		}
            		else {//特殊狀況ex：那瑪夏區
            			town=addr.substring(3,7);
            			road=addr.substring(7);
            		}
            	}
            	WB1M050f form1 = (WB1M050f) model.getMainForm();
            	form1.setAcity(city);
            	form1.setAtown(town);
            	
            	session.setAttribute("city",city);
            	session.setAttribute("town",town);
            	session.setAttribute("road",road);
            	session.setAttribute("r1","r1");
            	session.setAttribute("insNum",insNum);
        	}     	
        	
        	if(model.checkBuildingFloor())
        	{
        		//金檢改善方案，依FPS471PRC取得建築等級
        		String buildingClass = model.getBuildingClass();
        		if(buildingClass!=null && buildingClass.trim().length()>0)
        		{
        			WB1M050f form1 = (WB1M050f) model.getMainForm();
        			form1.setKyc_a03(buildingClass);
        			model.processP2();
            		page = 2;
        		}else
        		{
        			request.setAttribute("alert", "無法取得建築等級");
        			model.processP1();
            		page = 1;
        		}        		
        	}else
        	{
        		model.processP1();
        		page = 1;
        	}
            request.setAttribute("WB1M050f",model.getMainForm());
            form.setNextPage(page);
        } else if (form.getSource().equals("WB1M050p2")) {	
            form.setNextPage(4);
            request.getSession(false).setAttribute("WB1M050f", model.getMainForm());
            request.setAttribute("WB1M050f", model.getMainForm());
            
            String insNum=request.getSession().getAttribute("insNum") !=null ? (String)request.getSession().getAttribute("insNum") : "" ;//選擇公司投保過的保單號碼
            if(!insNum.equals("")) {
            	Map fdata=model.queryFireData2(insNum);
            	request.setAttribute("fdata", fdata);
            }
            
            
        } else if (form.getSource().equals("WB1M050p3")) {        	
            if (form.getActionCode() == 9) {
                form.setNextPage(4);
                request.setAttribute("WB1M050f", model.getMainForm());
                
                HttpSession session = request.getSession(false);
                WB1M050f form1 = (WB1M050f) model.getMainForm();
                DBO dbo = new SelectDBO();            
                dbo.addRecordData("C101", form1.getUID());
                session.setAttribute(KycGlobal.Kyc_UserInfo, dbo);
            } else {
                if (model.processP3()) {
                    form.setNextPage(7);
                } else{
                    form.setNextPage(4);
                    request.setAttribute("WB1M050f", model.getMainForm());
                }
            }
        } else if (form.getSource().equals("WB1M050p4")) {       	
        	
			WB1M050f form1 = (WB1M050f) model.getMainForm();
			
			//FAS32地址、信箱、電話檢核
			checkFas32prc(form1);
			
			//因投保完成後LINE推播內容要新增姓名，因此先記錄在session
			HttpSession session = request.getSession(false);
			session.setAttribute("customer",form1.getKyc_T1506());
			
			//ID試算保費紀錄
        	doKycllog(request,form.getSource(),form1.getKyc_T1507());
			
            request.getSession(false).removeAttribute("WB1M050f");
            model.processP4(agentno);
            model.checkAddress(1);
            model.checkAddress(2);
            //投保地震險時需檢核，目前固定投保
            model.isInsuredMsg();
            
            request.setAttribute("WB1M050f", form1);
            if((form1.getAdd1msg()!=null && form1.getAdd1msg().trim().length()>0)
            		|| (form1.getAdd2msg()!=null && form1.getAdd2msg().trim().length()>0)
            		|| (form1.getInsuredMsg() !=null && form1.getInsuredMsg().trim().length()>0))
            	form.setNextPage(4);
            else
            	form.setNextPage(5);
        } else if (form.getSource().equals("WB1M050p5")) {

        	  if(form.getActionCode()==51)
          	  {
        		  //紀錄客戶是否同意行銷(IC01PFA)(IC01PF)
        		  HttpSession session = request.getSession(false);
        		  WB1M050f form1 = (WB1M050f) model.getMainForm();
        		  String C01A18= session.getAttribute("C01A18").toString();        		  
        		  boolean exist=model2.isExistIC01PFA(form1.getKyc_T1507());
        		  model2.updateIC01PFA(form1.getKyc_T1507(), C01A18, exist);
        		  model2.insertIC01PF_Insured(form1.getKyc_T1507());
        		  session.removeAttribute("C01A18");
        		  
          		  model.processP5();
          		  //簡訊和MAIL都要寄送
          		  model.sendMobileMsg();//發送投保簡訊
    		      model.sendOTPMail(request);//發送投保email
          		  
          		  request.setAttribute("WB1M050f", model.getMainForm());
          		  request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));
          		  form.setNextPage(8);
          	  }
        	
        } else if (form.getSource().equals("WB1M050p6")) {
            //重新取授權
        	request.setAttribute("WB1M050f",request.getSession(false).getAttribute("WB1M050f"));
            form.setNextPage(5);
        }
        else if (form.getSource().equals("WB1M050p8")) 
        {  
   		  if(form.getActionCode() == 28)
   		  { 			  
   				boolean isUpdatetok = model.isUpdateOTP();
   				if(isUpdatetok){
   					//簡訊和MAIL都要寄送
   					model.sendMobileMsg();//重新發送簡訊
   		        	model.sendOTPMail(request);//發送投保email

   					request.setAttribute("MSG", "OTP驗證碼已重新寄發，請確認您的簡訊！");
   					request.setAttribute("exmin", SystemParam.getParam("OTPEXTIME"));				

   				}else{
   					request.setAttribute("exmin", "0");
   				}

   			  request.setAttribute("WB1M050f", model.getMainForm());
      		  form.setNextPage(8);

   		  }
   		  else{
         	  if(model.isRightOTP())
      		  {
                 
                  request.getSession(false).setAttribute("WB1M050f", model.getMainForm());
                  WB1M050f form1 = (WB1M050f) model.getMainForm();
                  
                  //略過網路投保刷卡動作，測試用
                  if(omitcredit.equals("Y"))
                  {
                	  try {
                    	  response.sendRedirect(RequestUtils.serverURL(request) + request.getContextPath() + "/NWB1M0501.do?actionCode=21&retcode=00&ordernumber=" + form1.getTnumber());
                    	  return;
                      } catch (MalformedURLException e) {

                    	  e.printStackTrace();
                      } catch (IOException e) {

                    	  e.printStackTrace();
                      }
                  }else{
	                  form.setNextPage(-1);
	                  NCCCUtil.callNCCC(form1.getKyc_T1507() , form1.getTnumber(), MathUtil.getDouble(form1.getFb07()), CharacterUtil.cutString(MessageUtil.getMessage(this.getServlet(), request, "WB1M040.TXT98")
	                        + CodeUtil.getCodeDesc(servlet,request,"GOODSID","FR") + form1.getKyc_T1507() + form1.getKyc_T1506(), 40), "NWB1M0501", getServlet(), request, response);
                  }
      		  }
      		  else{
      			  throw new UserException("errors.1000", "OTP輸入錯誤，請重新輸入！");
      		  }
   			  
   		  	}
    
        }
    
    }

    /**
     * 取得預設的招攬人代號
     * @param KD01
     * @param KD02
     * @param KD03
     * @param KD04
     * @param KD19
     * @param KD20
     * @return
     */
    public String getKYCKD_KD17(String KD01,String KD02, String KD03, String KD04,String KD19,String KD20){
    	
    	String kd17 = "0" ; 
        if (KD19.equals("") || KD19 == null) {
            KD19 = "KYC";
        }
        tx_controller.begin(0);
        
        DBO dbo;
        try {
			
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);	//商品代碼
            kd.setKD02(KD02);	//險別
            kd.setKD03(KD03);	//險種
            kd.setKD04(KD04);	//年期
            kd.setKD19(KD19);	//來源網站
            kd.setKD20(KD20);	//通路別

        	dbo = kd.executeSelect(tx_controller.getConnection(0));
        	 
        	kd17 = dbo.getRecordData("KD17").toString();
		} catch (AsiException e) {

			e.printStackTrace();
		}

    	return kd17;
    }


    /**
     * 取得網頁描述檔
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHDbyKey(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHDbyKey();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }

    /**
     * 取得完成頁GTM碼
     * @param whd01
     * @param whd02
     * @return
     */
    private String getKYCWHD_GTM(String whd01 , String whd02 ){
    	String desc="";

    	KYCWHDDao kwhdao = null;    	
    	Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			kwhdao = new KYCWHDDao(con);
			kwhdao.setWhd01(whd01);
			kwhdao.setWhd02(whd02);
			
			desc = kwhdao.getKYCWHD_WHD06();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return desc;
    }

    /**
     * 寫入KYCLLOG記錄檔處理 - 用此檔案記錄ID試算保費次數
     * @param request
     * @param source
     * @param uid
     */
    public void doKycllog( HttpServletRequest request,String source,String uid){

    	String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
    	String systime = DateUtil.getSysTime();

    	String ll01 = this.getClass().getSimpleName();//進入點程式
    	String ll02 = source;//頁面source
    	String ll03 = "住宅火險投保頁";//頁面說明
    	String ll04 = "F";
    	String ll05 = uid;//客戶身分證字號
    	String ll09 = sysdate + systime;//時間戳記
    	String ll17 = "PT";//動作/檢核項目
    	String ll19 = "ID試算保費";//動作說明/檢核錯誤訊息
    	
    	try {		
    		KycLogger klg = new KycLogger();
    		klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, "", "", "", "", "", ll17, "", ll19, "", "", "", "", "");
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    /**
     * FAS32地址、信箱、電話檢核
     * @param form1
     * @throws UserException 
     */
    public void checkFas32prc(WB1M050f form1) throws UserException {
    	
    	String tel=form1.getKyc_T1513() != null && !"".equals(form1.getKyc_T1513()) ? form1.getKyc_T1513() : form1.getKyc_T1514() != null && !"".equals(form1.getKyc_T1514()) ? form1.getKyc_T1514() : "";
    	String phone=form1.getKyc_T1515() != null && !"".equals(form1.getKyc_T1515()) ? form1.getKyc_T1515() : "";
    	String mail=form1.getKyc_T1516() != null && !"".equals(form1.getKyc_T1516()) ? form1.getKyc_T1516() : "";
    	
    	//地址處理
    	String addr="";
        if(form1.getAtown().length()==1)
        	form1.setAtown("");
        if (form1.getAddr().equals("new"))
            if (form1.getAa().equals("aa")){
                addr = form1.getAcity()+form1.getAtown()+form1.getAdd();      
            }
            else{
                addr = form1.getCity() + form1.getTown() + form1.getAddrnew();

            }
        else
            addr = form1.getAddrold();
    	
    	String id=form1.getKyc_T1507() != null && !"".equals(form1.getKyc_T1507()) ? form1.getKyc_T1507() : "";
    	
    	FAS32Input in = new FAS32Input();
        in.setS32i1(tel);
        in.setS32i2(phone);
        in.setS32i3(mail);
        in.setS32i4(addr);
        in.setS32i5(id);
        
        FAS32PRC prc = new FAS32PRC();
        FAS32Return out = prc.execute(in);
        
        String errcode = out.getS32o4().trim();
        String abnormalcode = out.getS32o1().trim();
        String errmsg = "";
        if(!abnormalcode .trim().equals("")){
        	errmsg = getPFMG(errcode);
        	throw new UserException("errors.1000", errmsg);
        }          			
    }

    private String getPFMG(String mg00){
    	Map ret = null;
    	String msg = "";
    	
    	Connection con = null;
    	QueryRunner runner = new QueryRunner();
    	boolean result = false;

    	try {
    		con = AS400Connection.getConnection();

    		String sql = "SELECT * FROM PFMG WHERE MG00 = ? ";
    		String[] args = new String[1] ;
    		args[0] = mg00 ; 
    		
    		ret = (Map) runner.query(con, sql, args, new TrimedMapHandler());
    		
    		if(ret != null && ret.size() >0){
    			msg = ret.get("MG01") != null ? ret.get("MG01").toString() : "";
    		}
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}finally{
    		AS400Connection.closeConnection(con);
    	}

    	return msg;
    }

}
