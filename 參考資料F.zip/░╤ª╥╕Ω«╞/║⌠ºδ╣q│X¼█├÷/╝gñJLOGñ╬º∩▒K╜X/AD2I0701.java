package com.asi.adm.ad2.actions;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.StringUtil;
import com.asi.kyc.common.SystemParam;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.EncryptUtil;

/*
 * 開發人員： Vincent
 * 建立日期： 2020/10/22
 * 程式說明： 電訪及查詢作業
 */
public class AD2I0701 extends AsiAction {
	
	
	//開始進來第一頁
	public void redefineActionCode(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response)
	{			
	    if (form.getActionCode() == 0){
	        	
	        form.setNextPage(1);
	    }
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws AsiException {
		String fileFolder = SystemParam.getParam("FILE_FOLDER") + "\\encryptionExcel";// 取得系統設定路徑
		int T1524s=Integer.parseInt(request.getParameter("T1524s"));
		int T1524e=Integer.parseInt(request.getParameter("T1524e"));
		UserInfo ui = (UserInfo) request.getSession().getAttribute(GlobalKey.USER_INFO);
		String uid=ui.getUserId();
		//按下查詢
		if(form.getActionCode() == 5){
			String T1503D="";
			String T1580D="";
			String RG15D="";
			
			try{
				
				List<Map> data = getData(T1524s,T1524e);
			
				for(int i=0;i<data.size();i++){
					Map mapData = (Map) data.get(i);
				
					T1503D=getKind(mapData.get("T1503").toString());
					if(mapData.get("NT1580")!=null){
						T1580D=getOrderstate(mapData.get("NT1580").toString());
					}
					if(mapData.get("RG15")!=null){
						RG15D=getRG15D(Integer.parseInt(mapData.get("RG15").toString()));
					}							
					mapData.put("T1503D", T1503D);
					mapData.put("T1580D", T1580D);
					mapData.put("RG15D", RG15D);				
				}
				request.setAttribute("data", data);
				
				writeKyclog(ui,request);
				
				form.setNextPage(1);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		//匯出EXCEL
		if(form.getActionCode()==10){
			String T1503D="";
			String T1580D="";
			String RG15D="";
			List<Map> data=getData(T1524s,T1524e);
			for(int i=0;i<data.size();i++){
				Map mapData = (Map) data.get(i);
			
				T1503D=getKind(mapData.get("T1503").toString());
				if(mapData.get("NT1580")!=null){
					T1580D=getOrderstate(mapData.get("NT1580").toString());
				}
				if(mapData.get("RG15")!=null){
					RG15D=getRG15D(Integer.parseInt(mapData.get("RG15").toString()));
				}							
				mapData.put("T1503D", T1503D);
				mapData.put("T1580D", T1580D);
				mapData.put("RG15D", RG15D);				
			}
					
			try {
				String pwd=getPWD(uid);
				pwd=EncryptUtil.getDesDecryptString(pwd);
				//產生加密過excel檔案以便後續輸出，最後下載完會刪掉檔案
				encryptExcelXlsx(data,fileFolder,pwd);
				
				response.setCharacterEncoding("UTF-8");
				response.setContentType("application/vnd.ms-excel");
				response.setHeader(
						"Content-Disposition",
						"attachment;filename=ExportData"
				+ this.tx_controller.getSystemDate() + ".xlsx");
				
				OutputStream os = response.getOutputStream();				
				
				byte[] result=null;
				InputStream input = null;
				//存放檔案的路徑			
				File ffolder = new File(fileFolder+ "\\" +this.tx_controller.getSystemDate() + ".xlsx");
				
		        input = new FileInputStream(ffolder);     
		        result = new byte[1024];  
		        //解決xlsx檔案損毀問題
		        int len = 0;
		        BufferedInputStream bis = new BufferedInputStream(input);
                while ((len = bis.read(result)) > 0) {
                    os.write(result, 0, len);
                }          		        
		        input.close();                        
		        
				os.flush();
				os.close();
				response.flushBuffer();		
				
				//下載完刪除檔案方法
				deleteDir(ffolder);
				
			} catch (IOException e) {
				LogFactory.getLog(AD2I0701.class).error(e.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
			}
			writeKyclog(ui,request);
			form.setNextPage(-1);
		}
		
	}
	
	public List<Map> getData(int T1524s,int T1524e){		
		List<Map> m=null;
		try
		{
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			
			String sql="SELECT DISTINCT PT15PF.*,T1610,RG14,RG15,KYCKLA.T1580 NT1580,KYCKLA.T15C7 NEWT15C7 FROM PT15PF "
					+ "LEFT JOIN KYCREG ON RG01 = PT15PF.T1507 "
					+ "LEFT JOIN KYCKLB ON PT15PF.T1501=T1601 AND PT15PF.T1502=T1602 AND PT15PF.T1503=T1603 "
					+ "LEFT JOIN KYCKLA ON KYCKLA.T1501 = PT15PF.T1501 "
					+ "WHERE PT15PF.T1524 BETWEEN ? AND ? AND PT15PF.T1538='B2C' AND PT15PF.T1502 <> 'TA' AND PT15PF.T1503 <> 'A' AND KYCKLA.T15B9='NCCC' "
					+ "ORDER BY PT15PF.T1596 DESC,PT15PF.T1501,PT15PF.T1580 desc";
			
			Object[] params = {T1524s,T1524e}; 
			
			m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,params,new TrimedMapListHandler());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return m;
	}
	
	public String getPWD(String uid){		
		List<Map> m=null;
		String pwd="";
		try
		{
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			
			String sql="SELECT PASSWORD FROM SECAL WHERE USERID=?";					
			
			m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,uid,new TrimedMapListHandler());
			pwd=(String) m.get(0).get("PASSWORD");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return pwd;
	}
	
	public String getKind(String T1503){
		String kind="";
		if(T1503.equals("A")){
			kind="強制險";
		}
		else if(T1503.equals("B")){
			kind="漁船險";
		}
		else if(T1503.equals("C")){
			kind="任意險";
		}
		else if(T1503.equals("C1")){
			kind="任意險一年期";
		}
		else if(T1503.equals("C2")){
			kind="駕傷險";
		}
		else if(T1503.equals("E")){
			kind="工程險";
		}
		else if(T1503.equals("F")){
			kind="火險";
		}
		else if(T1503.equals("H")){
			kind="船體險";
		}
		else if(T1503.equals("M")){
			kind="水險";
		}
		else if(T1503.equals("O")){
			kind="新種險";
		}
		
		return kind;
	}
	
	public String getOrderstate(String T1580){
		String Orderstate="";
		if(T1580.equals("1")){
			Orderstate="確認投保";
		}
		else if(T1580.equals("2")){
			Orderstate="取得刷卡授權失敗";
		}
		else if(T1580.equals("3")){
			Orderstate="取得刷卡授權成功";
		}
		else if(T1580.equals("4")){
			Orderstate="訂單寫檔完成";
		}
		else if(T1580.equals("5")){
			Orderstate="請款失敗";
		}
		else if(T1580.equals("6")){
			Orderstate="請款成功";
		}
		else if(T1580.equals("7")){
			Orderstate="取消授權失敗";
		}
		else if(T1580.equals("8")){
			Orderstate="取消授權成功";
		}
		else if(T1580.equals("9")){
			Orderstate="金流暫停服務，請手動出單";
		}
		return Orderstate;
	}

	public String getRG15D(int RG15){
		//若RG15不滿6位數則前面補滿0
		String s=StringUtil.fillPre(String.valueOf(RG15), 6, '0');
		String RG15D=s.substring(0,2)+":"+s.substring(2,4)+":"+s.substring(4);
		return RG15D;
	}
	
	//加密EXCEL先下載到資料夾
	public void encryptExcelXlsx(List<Map> data,String fileFolder,String pwd) throws Exception {
	    //構建XSSFWorkbook
	    XSSFWorkbook hssfWorkbook = new XSSFWorkbook();
	    XSSFSheet sheet1 = hssfWorkbook.createSheet("sheet1");
		//第一列
	    XSSFRow row1 = sheet1.createRow(0);
	    createCell(row1, (short) 0, "筆數");
	    createCell(row1, (short) 1, "確認日期");
	    createCell(row1, (short) 2, "交易序號");
	    createCell(row1, (short) 3, "險別");
	    createCell(row1, (short) 4, "牌照號碼");
	    createCell(row1, (short) 5, "保險起日");
	    createCell(row1, (short) 6, "保險迄日");
	    createCell(row1, (short) 7, "被保險人");
	    createCell(row1, (short) 8, "被保險人ID");
	    createCell(row1, (short) 9, "請款狀況");
	    createCell(row1, (short) 10, "註冊日期時間");
	    createCell(row1, (short) 11, "不方便電訪方式");
	    createCell(row1, (short) 12, "電訪音檔/EMAIL");
	    //寫入資料
	    for (int i = 0; i < data.size(); i++) {
	    	row1 = sheet1.createRow(i + 1);
	    	createCell(row1, (short) 0,String.valueOf(i+1));
	    	createCell(row1, (short) 1,String.valueOf(data.get(i).get("T1524")));
	    	createCell(row1, (short) 2,String.valueOf(data.get(i).get("T1501")));
	    	createCell(row1, (short) 3,String.valueOf(data.get(i).get("T1503"))+" "+String.valueOf(data.get(i).get("T1503D")));
	    	createCell(row1, (short) 4,data.get(i).get("T1610")==null ? "" : String.valueOf(data.get(i).get("T1610")));
	    	createCell(row1, (short) 5,String.valueOf(data.get(i).get("T1517")));
	    	createCell(row1, (short) 6,String.valueOf(data.get(i).get("T1518")));
	    	createCell(row1, (short) 7,String.valueOf(data.get(i).get("T1506")));
	    	createCell(row1, (short) 8,String.valueOf(data.get(i).get("T1507")));
	    	createCell(row1, (short) 9,String.valueOf(data.get(i).get("NT1580"))+" "+String.valueOf(data.get(i).get("T1580D")));
	    	createCell(row1, (short) 10,String.valueOf(data.get(i).get("RG14"))+" "+String.valueOf(data.get(i).get("RG15D")));
	    	createCell(row1, (short) 11,data.get(i).get("T1569")==null ? "" : String.valueOf(data.get(i).get("T1569")).equals("1") ? "1.電話訪問":"2.電子郵件或簡訊通知");
	    	createCell(row1, (short) 12,data.get(i).get("NEWT15C7")==null ? "" : String.valueOf(data.get(i).get("NEWT15C7")));
	    }
	    //最後統計總筆數
	    row1 = sheet1.createRow(data.size() + 2);
	    createCell(row1,(short) 0,"總件數");
	    createCell(row1,(short) 1,"電訪比率10%");
	    createCell(row1,(short) 2,"應電訪件數");
	    row1 = sheet1.createRow(data.size() + 3);
	    createCell(row1,(short) 0,String.valueOf(data.size()));
	    createCell(row1,(short) 1,"");
	    createCell(row1,(short) 2,"");
	    
	    //存放路徑不存在則產生資料夾
	    File ffolder = new File(fileFolder);
		if(!ffolder.exists())
			ffolder.mkdirs();
				   	
		String rptPath = ffolder + "\\" +this.tx_controller.getSystemDate() + ".xlsx";
		//保存此XSSFWorkbook對象爲xlsx文件
	    hssfWorkbook.write(new FileOutputStream(rptPath)); 
	    //以下為加密處理
		POIFSFileSystem fs = new POIFSFileSystem();
	    EncryptionInfo info = new EncryptionInfo(EncryptionMode.standard);
	    //final EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile, CipherAlgorithm.aes256, HashAlgorithm.sha256, -1, -1, null);
	    Encryptor enc = info.getEncryptor();

	    //設置密碼
	    enc.confirmPassword(pwd);

	    //加密文件			    
	    OPCPackage opc = OPCPackage.open(new File(rptPath), PackageAccess.READ_WRITE);
	    OutputStream os = enc.getDataStream(fs);
	    opc.save(os);
	    opc.close();				
        
	    //把加密後的文件寫回到流
	    FileOutputStream fos = new FileOutputStream(rptPath);
	    fs.writeFilesystem(fos);
	    fos.close();
	}
	
	//創造每列的資料
	private void createCell(XSSFRow headerRow, short cellcnt,
			String cellString){
		XSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
	}
	
	//刪除資料夾方法
    public void deleteDir(File file) {
	    if (file.isDirectory()) {
	        for (File f : file.listFiles())
	            deleteDir(f);
	    }
	    file.delete();
	}
	
	//以下為舊的EXCEL輸出方法
	public HSSFWorkbook export(List<Map> data) throws AsiException {
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet sheet = workBook.createSheet();
		sheet.createFreezePane(0, 1);// 凍結視窗
		sheet.setDefaultRowHeightInPoints(20);// 預設列高
		sheet.setMargin(HSSFSheet.TopMargin, (double) .30);// 設定上邊界
		sheet.setMargin(HSSFSheet.BottomMargin, (double) .30);// 設定下邊界
		sheet.setMargin(HSSFSheet.LeftMargin, (double) .30);// 設定左邊界
		sheet.setMargin(HSSFSheet.RightMargin, (double) .30);// 設定右邊界
		HSSFCellStyle style = workBook.createCellStyle();// 欄位&Data樣式
		style.setWrapText(false);// 自動換行
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);// 設定下框線樣式
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);// 設定左框線樣式
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);// 設定右框線樣式
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);// 設定上框線樣式
		HSSFRow row = sheet.createRow(0);// 欄位名稱
		createCell1(row, (short) 0, "筆數", style);
		createCell1(row, (short) 1, "確認日期", style);
		createCell1(row, (short) 2, "交易序號", style);
		createCell1(row, (short) 3, "險別", style);
		createCell1(row, (short) 4, "牌照號碼", style);
		createCell1(row, (short) 5, "保險起日", style);
		createCell1(row, (short) 6, "保險迄日", style);
		createCell1(row, (short) 7, "被保險人", style);
		createCell1(row, (short) 8, "被保險人ID", style);
		createCell1(row, (short) 9, "請款狀況", style);
		createCell1(row, (short) 10, "註冊日期時間", style);
		createCell1(row, (short) 11, "不方便電訪方式", style);
		createCell1(row, (short) 12, "電訪音檔/EMAIL", style);
//		String[] key = { "T1501", "T1502", "T1503","NEWT1524", "T1523", "T1507", "T1506",
//				"T1515","T1516","T1584","T1575","T15C10", "T1541" };
		for (int i = 0; i < data.size(); i++) {
			row = sheet.createRow(i + 1);
			createCell1(row, (short) 0,String.valueOf(i+1),style);
			createCell1(row, (short) 1,String.valueOf(data.get(i).get("T1524")),style);
			createCell1(row, (short) 2,String.valueOf(data.get(i).get("T1501")),style);
			createCell1(row, (short) 3,String.valueOf(data.get(i).get("T1503"))+" "+String.valueOf(data.get(i).get("T1503D")),style);
			createCell1(row, (short) 4,data.get(i).get("T1610")==null ? "" : String.valueOf(data.get(i).get("T1610")),style);
			createCell1(row, (short) 5,String.valueOf(data.get(i).get("T1517")),style);
			createCell1(row, (short) 6,String.valueOf(data.get(i).get("T1518")),style);
			createCell1(row, (short) 7,String.valueOf(data.get(i).get("T1506")),style);
			createCell1(row, (short) 8,String.valueOf(data.get(i).get("T1507")),style);
			createCell1(row, (short) 9,String.valueOf(data.get(i).get("NT1580"))+" "+String.valueOf(data.get(i).get("T1580D")),style);
			createCell1(row, (short) 10,String.valueOf(data.get(i).get("RG14"))+" "+String.valueOf(data.get(i).get("RG15D")),style);
			createCell1(row, (short) 11,data.get(i).get("T1569")==null ? "" : String.valueOf(data.get(i).get("T1569")).equals("1") ? "1.電話訪問":"2.電子郵件或簡訊通知",style);
			createCell1(row, (short) 12,data.get(i).get("T15C7")==null ? "" : String.valueOf(data.get(i).get("T15C7")),style);
		}
		//最後統計總筆數
		row = sheet.createRow(data.size() + 2);
		createCell1(row,(short) 0,"總件數",style);
		createCell1(row,(short) 1,"電訪比率10%",style);
		createCell1(row,(short) 2,"應電訪件數",style);
		row = sheet.createRow(data.size() + 3);
		createCell1(row,(short) 0,String.valueOf(data.size()),style);
		createCell1(row,(short) 1,"",style);
		createCell1(row,(short) 2,"",style);
		
		return workBook;
	}	
	private void createCell1(HSSFRow headerRow, short cellcnt,
			String cellString, HSSFCellStyle style) {
		HSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}
	
	/**
	 * 新增KYCLLOG的資料
	 * @param ui 使用者號碼
	 * @param request 
	 * @return
	 */
	public void writeKyclog(UserInfo ui,HttpServletRequest request){				
			KycLogger klg = new KycLogger();
			String urid = ui.getUserId();
		
			//新增
			klg.LoggerWriter2(request, this.getClass().getSimpleName(),
					"AD2I070p1", "電訪及查詢作業", "B", urid, "", "", "", "", "",
					"", "", "", "", "PR", "", "資料查詢及匯出", "",
					"", "", "", "","","");
			
	}
}
