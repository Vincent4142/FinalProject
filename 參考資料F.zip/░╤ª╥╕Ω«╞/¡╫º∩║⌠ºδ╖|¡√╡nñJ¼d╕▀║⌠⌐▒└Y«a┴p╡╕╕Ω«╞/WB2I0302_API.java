package com.asi.kyc.wb2.actions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * @author vsg
 * 查詢整合員工資料檔
 */
public class WB2I0302_API extends AsiAction {
       
    public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
        AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
    }

    public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
        return null;
    }

    protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
    {
     
    }
	public void doProcess(ActionMapping arg0, AsiActionForm form, HttpServletRequest request, HttpServletResponse arg3) throws AsiException
	{
    	String agentid = request.getParameter("agent");
    	
 		String sql = "";
 		sql +=  "  SELECT                                        ";   
 		sql +=  "  VWLINE_EMP1.* ,                               ";   
 		sql +=  "  VWLINE_DEPT.DEPTNAME AS DEPT_NAME,            ";   
 		sql +=  "  VWLINE_DEPT.TEL AS DEPT_TEL,                  ";   
 		sql +=  "  VWLINE_DEPT.FAX AS DEPT_FAX,                  ";   
 		sql +=  "  CASE                                          ";   
 		sql +=  "  	WHEN TRIM(JOBTITLE) = '公有代號' THEN 1         ";    
 		sql +=  "  	ELSE 0                                       "; 
 		sql +=  "  END AS IsPublicCode                           ";   
 		sql +=  "  FROM VWLINE_EMP1                              "; 
 		sql +=  "  LEFT JOIN VWLINE_DEPT                         "; 
 		sql +=  "  ON VWLINE_EMP1.DEPTNO = VWLINE_DEPT.DEPTNO    "; 
 		sql +=  "  WHERE USERID = ?                              "; 
 		
		Map ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getOracleConnection();
			ret = (Map) runner.query(con, sql, agentid, new TrimedMapHandler());
			
			if(ret != null && ret.size() > 0) {
				if(ret.get("telext") != null) {
					if(ret.get("telext").equals("0")) {
						ret.remove("telext");
						ret.put("telext", "");
					}else {
						String ext = ret.get("telext").toString();
						ret.remove("telext");
						ret.put("telext", "#" + ext);						
					}				
				}	else {
					ret.remove("telext");
					ret.put("telext", "");
				}
				
				if(ret.get("fax") == null ) {
					ret.remove("fax");
					ret.put("fax", "");
				}		
			
				if(ret.get("dept_name")==null) {
					ret.remove("dept_name");
					ret.put("dept_name", "");
				}
				
				if(ret.get("companytel")==null) {
					ret.remove("companytel");
					ret.put("companytel", "");
				}
				
				if(ret.get("dept_tel")==null) {
					ret.remove("dept_tel");
					ret.put("dept_tel", "");
				}
				
				if(ret.get("dept_fax")==null) {
					ret.remove("dept_fax");
					ret.put("dept_fax", "");
				}
			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		arg3.setContentType("text/json;charset=UTF-8");
		arg3.setHeader("Cache-Control", "no-cache");
		try {
			arg3.getWriter().write(JSONArray.fromObject(ret).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		} catch (IOException e) {
			e.printStackTrace();
		}
 
		form.setNextPage(-1);
	}
     
}
