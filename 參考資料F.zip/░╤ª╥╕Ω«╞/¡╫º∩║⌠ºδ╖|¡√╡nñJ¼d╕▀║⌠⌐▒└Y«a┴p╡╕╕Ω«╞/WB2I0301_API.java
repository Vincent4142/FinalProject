package com.asi.kyc.wb2.actions;

import java.io.IOException;
import java.sql.Connection;
import java.text.ParseException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import net.sf.json.JSONObject;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.Record;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * 客戶基本功能 - 投保紀錄查詢API
 * @author Ching Chou,Chen
 * @CreateDate 2017/5/2
 * @UpdateDate 
 * @FileName kyc/com.asi.kyc.wb2.actions/WB2I0301_API.java
 * @version
 * <p><pre>
 * API 主KEY
 * USERID = 使用者帳號(身分證)
 * 
 * </pre></p>
 */

public class WB2I0301_API extends AsiAction {
    
    KycDateUtil dateObj = new KycDateUtil(); // first ins date format
    
    public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
        AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
    }

    public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
        return null;
    }

    protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
    {
     
    }
     public void doProcess(ActionMapping arg0, AsiActionForm form, HttpServletRequest request, HttpServletResponse arg3) throws AsiException
     {
         HttpSession session = request.getSession(false);
         UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
         String uid = ui.getUserId();
         
         String USERID = uid;
         int ac1 = Integer.parseInt(request.getParameter("ac1"));
         
         //由交易控制器tx_controller(TransactionControl)取得DBO物件
         DBO dbo1 = (DBO) tx_controller.getDBO("kyc.IC02PFs16", 1);

         // sql condition
         StringBuffer sql = new StringBuffer();
         sql.append(" and C201='" + USERID +  "' and C206 ");
         if (5 == ac1) {
             sql.append(">=");

         } else {
             sql.append("<"); // 歷史紀錄
         }

         try {
     
             dateObj.add(KycDateUtil.YEAR, -1);
             sql.append(dateObj.getKycDate());
             sql.append(" OR C202 IN ");
             sql.append("(SELECT SU01||SU02 FROM EPSUPF WHERE SU05 = '" + USERID + "' AND SU21 > ").append(dateObj.getKycDate()).append(") ");
             
         } catch (Exception e) {
             //throw new UserException("errors.1000", e);
         }

         dbo1.addParameter("WHERE", sql.toString());
         dbo1.execute();

         if(dbo1.getRecordCount()>=1) {        	 
        	 for (int i = 1; i<= dbo1.getRecordCount(); i++){
        		 String c202=dbo1.getRecordData(i,"C202");//保單號碼
        		 String m301=dbo1.getRecordData(i,"M301");//招攬人
        		 Connection conn=null;
        		 if(m301.equals("96883")) {
        			 try {       				 
        				 conn = AS400Connection.getOracleConnection();
            			 String sql2="select T1582 from PT15PF where T1504=?";
            			 QueryRunner runner = new QueryRunner();
            			 Map m=(Map) runner.query(conn,sql2,c202,new TrimedMapHandler());
            			 String t1582=(String) m.get("T1582");
            			 
            			 String sql3="select M301 from PSM3PF left join IC01PFA on M319=C01A01 where C01A17 = ?";
            			 Map m2=(Map) runner.query(conn,sql3,t1582,new TrimedMapHandler());
            			 String m301New=(String) m2.get("M301");
            			 
            			 dbo1.addRecordData(i, "M301", m301New);
            			 
        			 }catch(Exception e) {
        				 e.printStackTrace();
        			 }
        			 finally {
        				 AS400Connection.closeConnection(conn);
        			 }
        			 
        		 }
        		 
        	 }
         }
         
         // 判斷保單狀態
         try {
             dbo1 = checkStatus(dbo1);
         } catch (Exception e) {
             // 傳入的年月日{0}，格式或值錯誤，請檢查程式(DateType={1},DateFormat{2})
             throw new UserException("1015");
         }

         // 重組畫面上顯示的資料
         dbo1 = reData(dbo1, request);

         arg3.setContentType("text/json;charset=UTF-8");
         arg3.setHeader("Cache-Control", "no-cache");
         try {
            arg3.getWriter().write(JSONObject.fromObject(dbo1).toString());
            arg3.getWriter().flush();
            arg3.getWriter().close();
         } catch (IOException e) {
            e.printStackTrace();
         }
         
         form.setNextPage(-1);

     }
     
     
     /**
      * 重組畫面上顯示的資料
      * 
      * @param dbo
      * @param request
      * @param actionCode
      * @return
     * @throws AsiException 
      */
     private DBO reData(DBO dbo, HttpServletRequest request) throws AsiException {
         boolean flag = false;
 
         String path = "WB2R0301";
         try {
             path = getPath(request, "/WB2R0301");
         } catch (Exception e) {
             e.printStackTrace();
         }

         Record record = null;
         int count = dbo.getRecordCount();
         for (int i = 1; i <= count; i++) {
             record = dbo.getRecord(i);

             String status = record.getData("NEWSTATUS");
             String c204 = record.getData("C204");
             String c203 = record.getData("C203");
             
             if(c204.indexOf("GP") != -1 || c204.indexOf("EP") != -1 || c204.indexOf("CG") != -1){
                 record.setData("C208", "");
             }

             // 欄位顏色
             record.setData("COLORINDEX", status);

             // 最新狀態
             String newStatus = MessageUtil.getMessage(this.getServlet(),
                                                       request, "WB2I030.TXT0"
                                                               + status);
             // 續保&投保 Button
             if ("3".equals(status) || "4".equals(status)) {
                 newStatus = "<input type='button' value='" + newStatus
                         + "' onclick=\"otherProcess('" + status + "','"
                         + getType(c204) + "','" + record.getData("C202")
                         + "')\" />";
             }
             record.setData("NEWSTATUS", newStatus);

             // 交易序號 (歷史資料時不必處理)
             if (flag && "O".equals(record.getData("C203"))) {
                 String seq = record.getData("C225");
                 if (seq != null && seq.length() > 0) {
                     seq = "<a href=\"javascript:printProcess('" + path + "', '"
                             + seq + "', 'O', '" + c204 + "')\">" + seq + "</a>";
                     record.setData("uC225", seq);
                 }
             }

             // 險種名稱
             String tempstr = CodeUtil.getCodeDesc(this.getServlet(), request,"INSUREMODE", c204);
             record.setData("uC204", tempstr);

             // 保單狀態
             tempstr = CodeUtil.getCodeDesc(this.getServlet(), request,"B2CSTATE", record.getData("CA201"));
             record.setData("uCA201", tempstr);

             // 是否有理賠
             tempstr = CodeUtil.getCodeDesc(this.getServlet(), request, "YN",record.getData("C214"));
             record.setData("uC214", tempstr);
             
             if(c203.equals("A")|| c203.equals("C1") || c203.equals("C2")){
                 String t2209 = record.getData("T2209");
	             record.setData("T2209", t2209);
             }else{
	             record.setData("T2209","");
             }

         }

         return dbo;
     }

     private String getType(String c204) {
         String t1 = c204.substring(0, 1);
         if (t1.equals("C")) {
             String t2 = c204.substring(c204.length() - 1);
             if (t2.equals("C"))
                 return "C";//汽車
             else
                 return "M";//機車
         }
         return t1;
     }

     /**
      * 判斷保單狀態
      * 
      * @param dbo
      * @param sysdate
      * @return
      * @throws IllegalFirstInsDateFormat
      * @throws ParseException
      */
     private DBO checkStatus(DBO dbo) throws ParseException {
         dateObj.setKycDate("201702021");

         int sDate = Integer.parseInt(dateObj.getKycDate());
         int count = dbo.getRecordCount();
         for (int i = 1; i <= count; i++) {
             String status = "5"; // 請洽業務員
             Record record = dbo.getRecord(i);
             String C206 = record.getData("C206"); // 到期日
             String C221 = record.getData("C221"); // 續保狀態
             String C226 = record.getData("C226"); // 可續保註記
             String KM02 = record.getData("KM02"); //斷保用標記
             String KM03 = record.getData("KM03"); //斷保用標記

             dateObj.setKycDate(C206);

             int eDate = Integer.parseInt(dateObj.getKycDate());

             // 新保件 - 系統日 < 到期日 -2個月
             dateObj.add(KycDateUtil.MONTH, -2);
             if (sDate < Integer.parseInt(dateObj.getKycDate())) {
                 status = "1";
                 record.setData("NEWSTATUS", status);
                 continue;
             }

             // 已續保 - 續保狀態=Y
             if ("Y".equals(C221)) {
                 status = "2";
                 record.setData("NEWSTATUS", status);
                 continue;
             }

             // 請洽業務員 - 可續保註記 <> Y
             if (!"Y".equals(C226)) {
                 record.setData("NEWSTATUS", status);
                 continue;
             }

             // 續保 - 系統日 <= 到期日，且系統日 >= 到期日 -2個月
             if (sDate <= eDate) {
                 if ("Y".equalsIgnoreCase(KM02)) { //提供續保按鈕
                     status = "3";
                 }
                 record.setData("NEWSTATUS", status);
                 continue;
             }

             // 投保 - 系統日 < 到期日 +1個月
             dateObj.add(KycDateUtil.MONTH, 3);
             if (sDate <= Integer.parseInt(dateObj.getKycDate())) {
                 if ("Y".equalsIgnoreCase(KM03)) { //提供斷保按鈕
                     status = "4";
                 }
                 record.setData("NEWSTATUS", status);
                 continue;
             }

             // 請洽業務員 - 其餘情形
             record.setData("NEWSTATUS", status);
         }

         return dbo;
     }

     public String getPath(HttpServletRequest request, String url)
             throws JspException {
      
         String host = System.getProperty("jasper.report-url");
         if (host == null)
         {
             host = ConfigUtil.getConfig(getServlet(), "jasper.report-intra");
         }
         StringBuffer action = new StringBuffer();
         action.append(host).append(url).append(".do");
         logger.info("report action path : " + action.toString());
         return action.toString();
     }
}
