package com.asi.kyc.wb5.dao;

import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.la1.dao.SECAZDao;

public class JsonGetDataByLucky extends AsiAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		return null;
	}

	protected void portalCheck(ActionMapping mapping,
			HttpServletRequest request, AsiActionForm asiForm)
			throws AsiException
	{

	}
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		String luckyid = arg2.getParameter("luckyid") != null ? arg2.getParameter("luckyid").trim() : "";
		List<?> ret1;
		Connection con = null;
		
		try
		{			
			con = AS400Connection.getOracleConnection();
			LuckyDao luckDao = new LuckyDao();
			ret1 = luckDao.getluck1list(con, luckyid);		

			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(ret1).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		arg1.setNextPage(-1);
	}
}
