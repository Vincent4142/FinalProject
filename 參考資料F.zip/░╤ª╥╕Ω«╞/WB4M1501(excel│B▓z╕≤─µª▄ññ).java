package com.asi.kyc.wb4.actions;

/**
 * @author vivchen
 * @Create Date：2016/7/27
 *
 * 程式說明: 續保單報表列印
 */

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.poi.hssf.usermodel.HSSFFooter;
import org.apache.poi.hssf.usermodel.HeaderFooter;
import org.apache.poi.ss.usermodel.Footer;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFPrintSetup;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.utils.Wb4Acct;
import com.asi.kyc.wb1.actions.AS400Procedure;
import com.asi.kyc.wb4.forms.WB4M150f;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

public class WB4M1501 extends WebAction {

	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	@Override
	public void doProcess(ActionMapping mapping, AsiActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException {
		tx_controller.begin(1);
		WB4M150f form1 = (WB4M150f) form;
		Wb4Acct.load(tx_controller, "E0");
		String sysdate = DateUtil.getSysDate(DateUtil.WestType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime(false);

		if (form1.getActionCode() == 5) {
			form1.setNextPage(1);
		} else if (form1.getActionCode() == 7) {
			try {
				XSSFWorkbook workbook = exportExcel(form1, request);
				response.setContentType("application/octect-stream");
				response.setHeader("Content-Disposition", "attachment;filename=" + "report-" + sysdate + systime + ".xlsx");
				OutputStream os = response.getOutputStream();
				workbook.write(os);
				os.flush();
				os.close();
				response.setStatus(HttpServletResponse.SC_OK);
				response.flushBuffer();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				tx_controller.close();
			}
			form.setNextPage(-1);
		}	
	}

	/**
	 * 產生EXCEL
	 * 
	 * @param f
	 * @param request
	 * @return
	 * @throws AsiException
	 */
	public XSSFWorkbook exportExcel(WB4M150f f, HttpServletRequest request)
			throws AsiException {
		try {
			Employee emp = Employee.getEmployee(f.getKYC_C213());
			String empName = emp.getName();
			String[] choiceReport = getC240(f);// 取得分類
			int sheets = 0;
			sheets = choiceReport.length;			
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = null;
			String sheetName = "sheet";
			List rptData = generateData(request, f);
			for (int i = 0; i < sheets; i++) // 產生分類sheet
			{
				if (choiceReport[i].equals("")) {
					sheetName = "sheet" + i;
				} else {
					sheetName = choiceReport[i] +" "+ i;
				}
				sheet = workBook.createSheet(sheetName);
				
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 3));//跨欄置中
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 5));
				sheet.addMergedRegion(new CellRangeAddress(0, 0, 9, 10));
				sheet.addMergedRegion(new CellRangeAddress(1, 1, 7, 8));
				sheet.addMergedRegion(new CellRangeAddress(2, 2, 0, 2));
				sheet.addMergedRegion(new CellRangeAddress(4, 4, 0, 2));
								
				sheet.createFreezePane(0, 6);// 凍結窗格
				
				sheet.setColumnWidth(0, (short) 10 * 256);//設定欄寬
				sheet.setColumnWidth(1, (short) 11 * 256);
				sheet.setColumnWidth(2, (short) 11 * 256);
				sheet.setColumnWidth(3, (short) 30 * 256);
				sheet.setColumnWidth(4, (short) 13 * 256);
				sheet.setColumnWidth(5, (short) 14 * 256);
				sheet.setColumnWidth(6, (short) 9 * 256);
				sheet.setColumnWidth(7, (short) 9 * 256);
				sheet.setColumnWidth(8, (short) 10 * 256);
				sheet.setColumnWidth(9, (short) 10 * 256);
				sheet.setColumnWidth(10, (short) 11 * 256);
				
				sheet.setMargin(XSSFSheet.TopMargin, (double) .10);// 設定上邊界
				sheet.setMargin(XSSFSheet.BottomMargin, (double) .60);// 設定下邊界
				sheet.setMargin(XSSFSheet.LeftMargin, (double) .10);// 設定左邊界
				sheet.setMargin(XSSFSheet.RightMargin, (double) .10);// 設定右邊界
						
				XSSFPrintSetup ps =(XSSFPrintSetup)sheet.getPrintSetup();//設定列印選項
				ps.setPaperSize(PrintSetup.A4_PAPERSIZE);//設定紙張
				ps.setScale((short)90);//列印縮放比例
				ps.setLandscape(true);//橫向列印
				
			 	
				sheet.setRepeatingRows(new CellRangeAddress(0,5,-1,-1));// 標題列列印區域
				
				Footer footer = sheet.getFooter();//設定頁尾
				footer.setCenter(HSSFFooter.font("標楷體", "regular") + "第 " + HeaderFooter.page() + " 頁，共  " + HeaderFooter.numPages() + " 頁 " );
								
				XSSFCellStyle style01 = workBook.createCellStyle();// 標頭樣式1
				XSSFFont font01 = workBook.createFont();
				font01.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
				font01.setFontHeight((short) 480);
				font01.setFontName("標楷體");
				style01.setFont(font01);
				
				XSSFCellStyle style02 = workBook.createCellStyle();// 標頭樣式2
				XSSFFont font02 = workBook.createFont();
				font02.setFontHeight((short) 260);
				font02.setFontName("標楷體");
				style02.setAlignment(XSSFCellStyle.ALIGN_LEFT);
				style02.setFont(font02);
							
				XSSFCellStyle style03 = workBook.createCellStyle();// 標頭樣式3
				XSSFFont font03 = workBook.createFont();
				font03.setFontHeight((short) 300);
				font03.setFontName("標楷體");
				style03.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
				style03.setFont(font03);
			
				XSSFFont font04 = workBook.createFont();//欄位字型1
				font04.setFontHeight((short) 180);// 字體大小
				font04.setFontName("標楷體");
								
				XSSFCellStyle style04 = workBook.createCellStyle();// 欄位樣式1
				style04.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
				style04.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
				style04.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
				style04.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
				style04.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
				style04.setFont(font04);
				
				XSSFCellStyle style05 = workBook.createCellStyle();// 欄位樣式2
				style05.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
				style05.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
				style05.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
				style05.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
				style05.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				style05.setFont(font04);
				
				XSSFCellStyle style06 = workBook.createCellStyle();// 欄位樣式3
				style06.setAlignment(XSSFCellStyle.ALIGN_CENTER);
				style06.setFont(font04);

				XSSFRow row0 = sheet.createRow(0);// 標頭1
				createCell(row0, (short) 0, "第一產物保險股份有限公司", style01);
				createCell(row0, (short) 4, "通路代碼/業務來源：", style03);
				String c233 = f.getKYC_C233()==null?"":f.getKYC_C233();
				String text2 = f.getText2()==null?"":f.getText2();
				if(c233.equals("0"))
				{
					c233 = text2;
				}
				else if(c233.equals("S001"))
				{
					c233 = "明基友達";
				}
				else if(c233.equals("Z001"))
				{
					c233 = "中油";
				}
				else if(c233.equals("Z002"))
				{
					c233 = "台電";
				}
				createCell(row0, (short) 6, c233, style03);
				createCell(row0, (short) 9, "續保名單", style03);
				XSSFRow row1 = sheet.createRow(1);// 標頭2
				createCell(row1, (short) 4, "到期日起：", style02);
				createCell(row1, (short) 5, f.getStart_year1() + "/" + f.getStart_month1() + "/" + f.getStart_date1(), style02);
				createCell(row1, (short) 6, "迄", style02);
				createCell(row1, (short) 7, f.getEnd_year1() + "/" + f.getEnd_month1() + "/" + f.getEnd_date1(), style02);
				XSSFRow row2 = sheet.createRow(2);// 標頭3
				createCell(row2, (short) 0, "服務人員：" + f.getKYC_C213() + empName, style02);
				int rows = 0;
				for (int j = 0; j < rptData.size(); j++) {
					Map currentRowData = (Map) rptData.get(j);
					String c204t = String.valueOf(currentRowData.get("c240")).trim();
					if (f.getKYC_C233().equals("E005")) {
						c204t = String.valueOf(currentRowData.get("c240a")).trim();
					}
					if (c204t.equals((choiceReport[i]))) {
						XSSFRow row3 = sheet.createRow(3);// 標頭4
						createCell(row3, (short) 0, "營業處：", style02);
						createCell(row3, (short) 1, currentRowData.get("t7747") + " " + currentRowData.get("t7748"), style02);
						XSSFRow row4 = sheet.createRow(4);// 標頭5
						createCell(row4, (short) 0, "招攬人姓名：" + currentRowData.get("t7750"), style02);
						createCell(row4, (short) 3, "招攬人ID：" + currentRowData.get("t7749"), style02);
						XSSFRow row5 = sheet.createRow(5);// 欄位名稱
						createCell(row5, (short) 0, "被保險人", style05);
						createCell(row5, (short) 1, "身分證號碼", style05);
						createCell(row5, (short) 2, "連絡電話", style05);
						createCell(row5, (short) 3, "通訊地址", style05);
						createCell(row5, (short) 4, "保單號碼", style05);
						createCell(row5, (short) 5, "險種", style05);
						createCell(row5, (short) 6, "牌照號碼", style05);
						createCell(row5, (short) 7, "保險迄日", style05);
						createCell(row5, (short) 8, "前期保險", style05);
						createCell(row5, (short) 9, "預估保險", style05);
						createCell(row5, (short) 10, "備註", style05);

						XSSFRow row = sheet.createRow(rows + 6);
						String c230 = currentRowData.get("c230") == null ? "" : currentRowData.get("c230").toString().trim();
						String c201 = currentRowData.get("c201") == null ? "" : currentRowData.get("c201").toString().trim();
						String c107 = currentRowData.get("c107") == null ? "" : currentRowData.get("c107").toString().trim();
						String t2109 = currentRowData.get("t2109") == null ? "" : currentRowData.get("t2109").toString().trim();
						String t2110 = currentRowData.get("t2110") == null ? "" : currentRowData.get("t2110").toString().trim();
						String c202 = currentRowData.get("c202") == null ? "" : currentRowData.get("c202").toString().trim();
						String c203 = currentRowData.get("c203") == null ? "" : currentRowData.get("c203").toString().trim();
						String t2209 = currentRowData.get("t2209") == null ? "" : currentRowData.get("t2209").toString().trim();
						String c206 = currentRowData.get("c206") == null ? "" : currentRowData.get("c206").toString().trim();
						String c208 = currentRowData.get("c208") == null ? "" : currentRowData.get("c208").toString().trim();
						String c208old = currentRowData.get("c208old") == null ? "" : currentRowData.get("c208old").toString().trim();
						String t2160 = currentRowData.get("t2160") == null ? "" : currentRowData.get("t2160").toString().trim();
						String c240name = currentRowData.get("c204name") == null ? "" : currentRowData.get("c204name").toString().trim();
						createCell(row, (short) 0, String.valueOf(c230), style04);
						createCell(row, (short) 1, String.valueOf(c201), style04);
						createCell(row, (short) 2, String.valueOf(c107), style04);
						createCell(row, (short) 3, String.valueOf(t2109 + " " + t2110), style04);
						createCell(row, (short) 4, String.valueOf(c202), style04);
						createCell(row, (short) 5, String.valueOf(c203 + " " + c240name), style04);
						createCell(row, (short) 6, String.valueOf(t2209), style05);
						createCell(row, (short) 7, String.valueOf(c206), style05);
						createCell(row, (short) 8, String.valueOf(c208), style05);
						createCell(row, (short) 9, String.valueOf(c208old), style05);
						createCell(row, (short) 10, String.valueOf(t2160), style04);
						rows = rows + 1;
					}
				}
				XSSFRow row = sheet.createRow(rows + 6);
				sheet.addMergedRegion(new CellRangeAddress(rows+6, rows+6, 0, 10));
				createCell(row, (short) 0, "請儘速聯絡客戶辦理續保事宜 ", style06);
			}
			for (int i = 0; i < workBook.getNumberOfSheets(); i++) { // 選取所有sheet
				workBook.getSheetAt(i).setSelected(true);
			}
			return workBook;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AsiException("decode Data error");
		}
	}

	/**
	 * @param headerRow
	 * @param cellcnt
	 * @param cellString
	 * @param style
	 */
	private void createCell(XSSFRow headerRow, short cellcnt,
			String cellString, XSSFCellStyle style) {
		XSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}

	/**
	 * @param request
	 * @param f
	 * @return
	 * @throws AsiException
	 */
	private List generateData(HttpServletRequest request, WB4M150f f)
			throws AsiException {
		LinkedList linkedList = new LinkedList();
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT C240A,C240,C201,C230,C107,C202,C203,C204,C206,C208,");
			sql.append("C213,C207,C210,C233,T2209,T2109,T2110,T2160,T6103,T5803,T6102,T5802 ");
			sql.append(",T7745,T7746,T7747,T7748,T7749,T7750 ");
			sql.append("FROM IC02PF ");
			sql.append("LEFT JOIN PT22PF ON C202=T2201 AND T2203=1 ");
			sql.append("LEFT JOIN IC01PF ON C201=C101 ");
			sql.append("LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 ");
			sql.append("LEFT JOIN PT61PF ON T6102=C240 AND T6104=C240A ");
			sql.append("LEFT JOIN PT58PF ON T5801=SUBSTR(C210,1,4) AND T5802=C240A ");
			sql.append("LEFT JOIN PT77PF ON C202=T7701 AND T7703=C203 AND T7702='' ");
			sql.append("WHERE C213='").append(f.getKYC_C213()).append("' ");
			sql.append("AND C206>=").append(f.getStart_year1() + f.getStart_month1() + f.getStart_date1()).append(" ");
			sql.append("AND C206<=").append(f.getEnd_year1() + f.getEnd_month1() + f.getEnd_date1()).append(" ");
			// 通路別
			if (f.getKYC_C233().equals("A116") || f.getKYC_C233().equals("E005")) // 永達A116 OR 中壽E005
			{
				sql.append("AND C233 = '").append(f.getKYC_C233()).append("' ");
			} else if (f.getKYC_C233().equals("S001")) // 明基友達
			{
				sql.append("AND (C210='M8351' OR C210='M8352' OR C210='Z0874' OR C210='Z0875') ");
			} else if (f.getKYC_C233().equals("Z001")) // 中油
			{
				sql.append("AND (C210='M7791' OR C210='M7792' OR C210='Z0848' OR C210='M12941'  OR C210='M12942'  OR C210='Z1039') ");// 1060721
																																		// 新增中油之業源:
																																		// M12941,
																																		// M12942,
																																		// Z1039
			} else if (f.getKYC_C233().equals("Z002")) // 台電
			{
				sql.append("AND (C210='M13271' OR C210='M13272' OR C210='Z1047' OR C210='M132711'  OR C210='M132722'  OR C210='Z10471') ");// 1061012
																																			// 新增台電之業源:
																																			// M13271,
																																			// M13272,
																																			// Z1047,
																																			// M132711,
																																			// M132722,
																																			// Z10471
			}
			// 業務來源
			if (!f.getText2().equals("")) {
				sql.append("AND C210 LIKE '").append(f.getText2()).append("%' ");
			}
			// 險別
			if (f.getKYC_C203().equals("C")) {
				sql.append("AND (C203='C1' OR C203='C2' OR C203='A') ");
			} else if (!f.getKYC_C203().equals("Z")) {
				sql.append("AND C203 = '").append(f.getKYC_C203()).append("' ");
			}
			sql.append("AND C223<>'Y' ");
			sql.append("AND C207<>'4' ");
			if (f.getKYC_C233().equals("E005"))
				sql.append("ORDER BY C240A, C240, C201, C245 ");
			else
				sql.append("ORDER BY C240, C240A, C201, C245 ");

			QueryRunner run = new QueryRunner();
			System.out.println(sql.toString().trim());
			List ret = (List) run.query(tx_controller.getConnection(1), sql.toString(), new TrimedMapListHandler());

			for (Iterator iterator = ret.iterator(); iterator.hasNext();) {
				Map row = (Map) iterator.next();

				// 抓取投保型態；代碼檔INSUREMODE
				String c204Name = CodeUtil.getCodeDesc(getServlet(), request, "INSUREMODE", row.get("c204").toString().trim());
				row.put("c204name", c204Name);

				// 身分證或統一編號遮罩
				String val = row.get("c201") == null ? "" : row.get("c201").toString().trim();
				if (!val.equals("")) {
					int len = val.length();
					len = (len - 4) / 2;
					if (val.length() == 10) {
						// A123456789
						// val = val.substring(0, 6) + "****";
						val = val.substring(0, len) + "****" + val.substring(val.length() - len, val.length());
					} else if (val.length() == 8) {
						// 12345678
						// val = val.substring(0, 4) + "****";
						val = val.substring(0, len) + "****" + val.substring(val.length() - len, val.length());
					}
					row.put("c201", val);
				} else {
					row.put("c201", "");
				}

				String c203 = row.get("c203") == null ? "" : row.get("c203").toString().trim();
				String c202 = row.get("c202") == null ? "" : row.get("c202").toString().trim();
				BigDecimal c208Old = null;
				if (c203.equals("A") || c203.equals("C1") || c203.equals("C2")) {
					c208Old = getC208Old(c202, c203);
					if (c203.equals("A") && (c208Old == null || c208Old.intValue() == 0)) { 
						c208Old = getF0517(c202);
						if(c208Old==null || c208Old.intValue()==0) { 
							c208Old = setInsPremium(c202); 
							} 
						}					 
				} else {
					c208Old = getT2713(c202);
				}
				row.put("c208old", c208Old);
				String t5802 = row.get("t5802") == null ? "" : row.get("t5802").toString().trim();
				String t5803 = row.get("t5803") == null ? "" : row.get("t5803").toString().trim();
				String t6102 = row.get("t6102") == null ? "" : row.get("t6102").toString().trim();
				String t6103 = row.get("t6103") == null ? "" : row.get("t6103").toString().trim();
				String t7745 = row.get("t7745") == null ? "" : row.get("t7745").toString().trim();
				String t7746 = row.get("t7746") == null ? "" : row.get("t7746").toString().trim();
				String t7747 = row.get("t7747") == null ? "" : row.get("t7747").toString().trim();
				String t7748 = row.get("t7748") == null ? "" : row.get("t7748").toString().trim();
				String t7749 = row.get("t7749") == null ? "" : row.get("t7749").toString().trim();
				String t7750 = row.get("t7750") == null ? "" : row.get("t7750").toString().trim();
				if (t7747.equals(""))
					t7747 = row.get("c240a") == null ? "" : row.get("c240a").toString().trim();
				if (t7749.equals(""))
					t7749 = row.get("c240") == null ? "" : row.get("c240").toString().trim();
				if (t7748.equals(""))
					t7748 = t5803;
				if (f.getKYC_C233().equals("E005")) {
					t7749 = "";
					t7750 = "";
				} else {
					if (t7750.equals(""))
						t7750 = t6103;
				}
				row.put("t7745", t7745);
				row.put("t7746", t7746);
				row.put("t7747", t7747);
				row.put("t7748", t7748);
				row.put("t7749", t7749);
				row.put("t7750", t7750);
				linkedList.add(new HashMap(row));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return linkedList;
	}

	/**
	 * 抓取預估保費
	 * @param c202 保單號碼
	 * @param c203 險別
	 * @return c208old
	 */
	private BigDecimal getC208Old(String c202, String c203) {
		BigDecimal c208old = null;
		try {
			StringBuffer sql = new StringBuffer();
			if (c203.equals("A"))
				sql.append("SELECT * FROM PFFK1 WHERE FK1073 = '").append(c202).append("' ");
			else
				sql.append("SELECT * FROM PFFK1 WHERE FK1001 = '").append(c202).append("' ");
			QueryRunner run = new QueryRunner();
			Map ret = (Map) run.query(tx_controller.getConnection(1), sql.toString(), new MapHandler());
			if (ret != null) {
				if (ret.size() > 0) {
					if (c203.equals("A"))
						c208old = (BigDecimal) ret.get("FK1058");
					else
						c208old = (BigDecimal) ret.get("FK1054");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return c208old;
	}

	/**
	 * 保費查詢中心強制保費資料
	 * @param f0501 保險證號碼
	 * @return f0517 法定總保費
	 */
	private BigDecimal getF0517(String f0501) {
		BigDecimal f0517 = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT F0517 FROM FC05PF WHERE F0501 = '").append(f0501).append("' ");
			QueryRunner run = new QueryRunner();
			Map ret = (Map) run.query(tx_controller.getConnection(1), sql.toString(), new MapHandler());
			if (ret != null) {
				if (ret.size() > 0) {
					f0517 = (BigDecimal) ret.get("F0517");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f0517;
	}

	/**
	 * 火險預估保費抓PT27PF KYC網路續保單主檔
	 * @param t2701 保單號碼
	 * @return t2713 總實收保費
	 * 
	 * 2020/4/9 修正住宅火險保險起日109/1/1~109/12/31預估保費顯示空白
	 */
	private BigDecimal getT2713(String t2701) {
		BigDecimal t2713 = null;
		tx_controller.begin(0);
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM PT27PF WHERE T2701 = '").append(t2701).append("' ");
			QueryRunner run = new QueryRunner();
			@SuppressWarnings("rawtypes")
			Map ret = (Map) run.query(tx_controller.getConnection(0), sql.toString(), new MapHandler());
			if (ret != null) {
				if (ret.size() > 0) {
					String t27017 = ret.get("T2701").toString().substring(6, 7);
					String t2702 = ret.get("T2702").toString();
					Long t2703 = Long.parseLong(ret.get("T2703").toString());
					if (t2703 > 1091231 || t2703 < 1090101 || !("F".equals(t2702.trim()) && ("R".equals(t27017) || "L".equals(t27017)) ))
						t2713 = (BigDecimal) ret.get("T2713");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t2713;
	}

	/**
	 * 分組
	 * @param f
	 * @return c240ID
	 */
	private String[] getC240(WB4M150f f) {
		String[] c240ID = null;
		try {
			StringBuffer sql = new StringBuffer();
			if (f.getKYC_C233().equals("E005"))
				sql.append("SELECT DISTINCT C240A FROM IC02PF ");
			else
				sql.append("SELECT DISTINCT C240 FROM IC02PF ");
			// sql.append("LEFT JOIN PT77PF ON C202=T7701 ");
			sql.append("WHERE C213='").append(f.getKYC_C213()).append("' ");
			sql.append("AND C206>=").append(f.getStart_year1() + f.getStart_month1() + f.getStart_date1()).append(" ");
			sql.append("AND C206<=").append(f.getEnd_year1() + f.getEnd_month1() + f.getEnd_date1()).append(" ");
			// 通路別
			if (f.getKYC_C233().equals("A116") || f.getKYC_C233().equals("E005")) // 永達A116 OR 中壽E005
			{
				sql.append("AND C233 = '").append(f.getKYC_C233()).append("' ");
			} else if (f.getKYC_C233().equals("S001")) // 明基友達
			{
				sql.append("AND (C210='M8351' OR C210='M8352' OR C210='Z0874' OR C210='Z0875') ");
			} else if (f.getKYC_C233().equals("Z001")) // 中油
			{
				sql.append("AND (C210='M7791' OR C210='M7792' OR C210='Z0848' OR C210='M12941'  OR C210='M12942'  OR C210='Z1039') ");// 1060721
																																		// 新增中油之業源:
																																		// M12941,
																																		// M12942,
																																		// Z1039
			} else if (f.getKYC_C233().equals("Z002")) // 台電
			{
				sql.append("AND (C210='M13271' OR C210='M13272' OR C210='Z1047' OR C210='M132711'  OR C210='M132722'  OR C210='Z10471') ");// 1061012
																																			// 新增台電之業源:
																																			// M13271,
																																			// M13272,
																																			// Z1047,
																																			// M132711,
																																			// M132722,
																																			// Z10471
			}
			// 業務來源
			if (!f.getText2().equals("")) {
				sql.append("AND C210 LIKE '").append(f.getText2()).append("%' ");
			}
			// 險別
			if (f.getKYC_C203().equals("C")) {
				sql.append("AND (C203='C1' OR C203='C2' OR C203='A') ");
			} else if (!f.getKYC_C203().equals("Z")) {
				sql.append("AND C203 = '").append(f.getKYC_C203()).append("' ");
			}
			sql.append("AND C223<>'Y' ");
			sql.append("AND C207<>'4' ");
			if (f.getKYC_C233().equals("E005"))
				sql.append("ORDER BY C240A ");
			else
				sql.append("ORDER BY C240 ");
			QueryRunner run = new QueryRunner();
			System.out.println(sql.toString().trim());
			List ret = (List) run.query(tx_controller.getConnection(1), sql.toString(), new MapListHandler());
			c240ID = new String[ret.size()];
			for (int i = 0; i < ret.size(); i++) {
				Map map = (Map) ret.get(i);
				if (f.getKYC_C233().equals("E005"))
					c240ID[i] = map.get("C240A").toString().trim();
				else
					c240ID[i] = map.get("C240").toString().trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return c240ID;
	}

	/**
	 * 重算強制保費
	 * @param c202 保單號碼
	 * @return insPremiumB 強制保費
	 */
	private BigDecimal setInsPremium(String c202) {
		String[] result = null;
		Map row = null;
		BigDecimal insPremiumB = null;
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT * FROM PFUB ");
			sql.append("LEFT JOIN PFUP ON UB00=UP001 ");
			sql.append("LEFT JOIN PFUC ON UB00=UC001 ");
			sql.append("LEFT JOIN PFUI ON UB00=UI001 ");
			sql.append("WHERE UB00 ='").append(c202).append("' ");
			QueryRunner run = new QueryRunner();
			row = (Map) run.query(tx_controller.getConnection(1), sql.toString(), new MapHandler());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if( row != null ){
			AS400Procedure as400 = new AS400Procedure();
			String c65i1 = "21";// 險種代號
			String c65i2 = row.get("uc06")==null?"":row.get("uc06").toString().trim();// 車種
			String c65i3 = row.get("ui02")==null?"":((BigDecimal) row.get("ui02")).toString();// 自負額
			String c65i4 = row.get("uc04")==null?"":row.get("uc04").toString().trim();// 廠牌車型
			String c65i5 = row.get("uc03")==null?"":String.valueOf(row.get("uc03")); // 製造年份
			String c65i6 = row.get("uc02")==null?"":String.valueOf(row.get("uc02")); // 發照年月
			String c65i7 = row.get("uc07")==null?"":((BigDecimal) row.get("uc07")).toString(); // 重置價值
			String c65i8 = row.get("ui01")==null?"":((BigDecimal) row.get("ui01")).toString(); // 保險金額
			String c65i9 = row.get("ui10")==null?"":String.valueOf(row.get("ui10")); // 賠款點數
			String c65ia = row.get("up06")==null?"":row.get("up06").toString().trim();// 身份證字號
			String c65ib = row.get("up03")==null?"":String.valueOf(row.get("up03")).toString().trim(); // 出生日期
			String c65ic = row.get("up01")==null?"":row.get("up01").toString().trim();// 被保險人別
			String c65id = row.get("up04")==null?"":row.get("up04").toString().trim();// 性別
			String ub08 = row.get("ub08")==null?"":String.valueOf(row.get("ub08"));
			String ub09 = row.get("ub09")==null?"":String.valueOf(row.get("ub09"));
			int interval = 0;
			if (!ub08.equals("") && !ub09.equals("")) {
				interval = Integer.parseInt(ub09.substring(0, 3)) - Integer.parseInt(ub08.substring(0, 3));
			}
			ub09 = String.valueOf(Integer.parseInt(ub09.substring(0, 3)) + interval) + ub09.substring(3);
			String c65ie = String.valueOf(row.get("ub09"));// 保單生效起
			String c65if = ub09;// 保單生效迄
			String c65ig = "0";// 多輛優待
			String c65ih = "1";// 費率代碼（其它車種
			String c65ii = "";// 類別 18***
			String c65ij = "";// 1= 貨櫃 2= 貨物 19
			String c65ik = "0";// 原險種保費
			String c65il = "";// 主險險種代號 21
			String c65im = "Y";// 費率類別
			String c65in = row.get("ub13").toString().trim();// 業務來源
			String c65io = "20";// 通路別
			String c65ip = String.valueOf(row.get("ub17"));// 保單作帳日
			try {
				result = as400.callC65PRC(tx_controller.getConnection(1), c65i1,
						c65i2, c65i3, c65i4, c65i5, c65i6, c65i7, c65i8, c65i9,
						c65ia, c65ib, c65ic, c65id, c65ie, c65if, c65ig, c65ih,
						c65ii, c65ij, c65ik, c65il, c65im, c65in, c65io, c65ip);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			String insPremium = result[1];
			insPremiumB = new BigDecimal(insPremium);			
		}else if( row == null ){
			insPremiumB = new BigDecimal(0);//測試機資料，因個資遮罩導致資料有缺少無法重新計算保費，如有計算保費時則傳回0
		}
		return insPremiumB;
	}
}
