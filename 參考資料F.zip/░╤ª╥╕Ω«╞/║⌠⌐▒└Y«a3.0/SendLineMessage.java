package com.asi.kyc.wb1.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;

/**
 * 網投投保完成及註冊完成寄送LINE推播通知
 * 
 * @author Vincent
 * @Create Date 2021年3月24日
 */
public class SendLineMessage extends AsiAction {
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
			form1.setActionCode(GlobalKey.ACTION_SELECT);
		return;
	}

	public ActionForward sessionCheck(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	protected void portalCheck(ActionMapping mapping,
			HttpServletRequest request, AsiActionForm asiForm)
			throws AsiException {

	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest request, HttpServletResponse response)
			throws AsiException {

		String user_id=request.getParameter("user_id");//員工編號或推薦人代號
		//如果是推薦人代號則轉為員工編號
		if(user_id.length() > 5){
			user_id=getEmployeeCode(user_id);
		}
		String message_title=request.getParameter("message_title");//LINE主旨
		String message_body=request.getParameter("message_body");//LINE訊息
		try {
			sendLine(user_id,message_title,message_body);
		} catch (Exception e) {
			e.printStackTrace();
		}


		arg1.setNextPage(-1);
	}

	/**
     * CALL LINE推播API 
     * @param referrerCode
     */    
	public void sendLine(String user_id,String message_title,String message_body) throws AsiException {
		try {
			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);
			
			String postURL="";
			//正式
			if(SystemParam.getParam("ENV").equals("KYC")){
				postURL = "https://1startup.firstins.com.tw/app_web/Handler_Line_Send.ashx";
			}
			//測試
			else{
				postURL = "https://1startupt.firstins.com.tw/app_web/Handler_Line_Send.ashx";
			}
			//設定要CALL API所帶的參數
			NameValuePair[] data = {
					new NameValuePair("apply_type", "REFERRER"),
					new NameValuePair("user_type", "B2E"),
					new NameValuePair("user_id", user_id), 
					new NameValuePair("message_title", message_title), 
					new NameValuePair("message_body", message_body)};
			//CALL API方法
			PostMethod postmethod = new PostMethod(postURL);
			postmethod.setRequestBody(data);
			postmethod.setRequestHeader("Content-Type",
					"application/x-www-form-urlencoded;charset=utf-8");
			HttpClient client = new HttpClient();
			client.setConnectionTimeout(10000);
			client.setTimeout(10000);
			client.executeMethod(postmethod);
			//取得API回傳的訊息
			String str = postmethod.getResponseBodyAsString();
			str=str.replace("[", "");
			str=str.replace("]", "");
			JSONObject jsonObject = JSONObject.fromObject(str);
			if (jsonObject.has("ret_code")) {
				String ret_code = jsonObject.getString("ret_code");
				String ret_msg = jsonObject.getString("ret_msg");
				String ret_time = jsonObject.getString("ret_time");
				
				System.out.println("ret_code: " + ret_code);
				System.out.println("ret_msg: " + ret_msg);
				System.out.println("ret_time: " + ret_time);
			} 

		} catch (Exception e) {
			e.printStackTrace();
			throw new AsiException(e.getMessage());
		}
	}

	/**
     * 由推薦人代號取得員工編號
     * @param referrerCode
     */
	public String getEmployeeCode(String referrerCode) throws AsiException {
		String EmployeeCode = "";
		Connection con = AS400Connection.getOracleConnection();
		try
		{			
			QueryRunner runner = new QueryRunner();
			StringBuffer sql = new StringBuffer();
			sql.append("select * from PSM3PF left join IC01PFA on M319=C01A01 where C01A17 = ?");
			Map<?, ?> ret = (Map<?, ?>) runner.query(con, sql.toString(),referrerCode, new MapHandler());
			EmployeeCode = String.valueOf(ret.get("m301"));
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new AsiException(e.getMessage());
		}
		finally {
			AS400Connection.closeConnection(con);
		}

		return EmployeeCode;
	}
	
	/**
     * LINE推播姓名隱碼
     * @param name
     * @return
     */
    public String getHiddenName(String name){
    	
    	if(name.equals("")){
    		return "";
    	}
  
    	StringBuffer hiddenName  = new StringBuffer();
    	if(name.length() < 4){
    	   for(int i=0;i<name.length();i++){
    		   if(i==1){
    			   hiddenName.append("O");
    		   }
    		   else{
    			   hiddenName.append(name.substring(i,i+1));
    	   	   }
    	   }
    	}
    	else{
    	    for(int i=0;i<name.length();i++){
    		    if(i==1 || i==2){
    			    hiddenName.append("O");
    		    }
    		    else{
    			    hiddenName.append(name.substring(i,i+1));
    	   	    }
    	    }
    	}
    	return hiddenName.toString();
    	
    }
}