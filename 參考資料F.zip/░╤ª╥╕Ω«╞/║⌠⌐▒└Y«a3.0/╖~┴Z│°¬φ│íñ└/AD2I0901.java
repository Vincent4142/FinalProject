package com.asi.adm.ad2.actions;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPrintSetup;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.hssf.util.Region;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * @author vsg
 * @version 2021/03/24
 * 網店頭家業績統計專區
 * 
 */
public class AD2I0901 extends AsiAction {
	String buffersql = "";

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest request, HttpServletResponse response) {
		AsiActionForm form1 = (AsiActionForm) arg1;
		if (form1.getActionCode() == 0) {
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			
			startDate += 1; // 查詢日期區間的起日從當月1日起
			request.setAttribute("strymd", String.valueOf(startDate));
			request.setAttribute("endymd", String.valueOf(sysDate));
			
			form1.setActionCode(5);
		}
	}

	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
		List ret = null;
		if (form.getActionCode() == 1)// 查詢
		{
			form.setNextPage(1);
		}
		else if (form.getActionCode() == 4) { // 匯出Excel
			try {
				KycDateUtil kycdate = new KycDateUtil();
				String sysdate = kycdate.getKycDate();

				ret = getDeatail1(request);
				
				HSSFWorkbook workbook1 = exportScreenExcel1(ret);
				response.setContentType("application/octect-stream");
				response.setHeader("Content-Disposition","attachment;filename=BOSS3.0_" + sysdate + ".xls");
				OutputStream os = response.getOutputStream();
				workbook1.write(os);
				os.flush();
				os.close();
				response.flushBuffer();
			} catch (IOException e) {
				e.printStackTrace();
			}
			form.setNextPage(-1);
		} else {
			form.setNextPage(1);
		}
	}

	private void createCell(HSSFRow headerRow, short cellcnt,
			String cellString, HSSFCellStyle style) {
		HSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}

	/**
	 * 匯出excel格式處理
	 * @param result
	 * @return
	 * @throws AsiException
	 */
	public HSSFWorkbook exportScreenExcel1(List result)
			throws AsiException {
		try {

			HSSFWorkbook workBook = new HSSFWorkbook();
			HSSFSheet sheet = workBook.createSheet();
			workBook.setRepeatingRowsAndColumns(0, -1, -1, 0, 1);//標題列列印區域
			
			sheet.addMergedRegion(new Region(0,(short)0,1,(short)0));//合併儲存格			
			sheet.addMergedRegion(new Region(0,(short)1,1,(short)1));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)2,1,(short)2));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)3,1,(short)3));//合併儲存格
			
			sheet.addMergedRegion(new Region(0,(short)4,0,(short)5));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)6,0,(short)7));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)8,0,(short)9));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)10,0,(short)11));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)12,0,(short)13));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)14,0,(short)15));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)16,0,(short)17));//合併儲存格
			sheet.addMergedRegion(new Region(0,(short)18,0,(short)19));//合併儲存格
			
			sheet.createFreezePane(0, 2);//凍結視窗
//			sheet.setAutobreaks(true);//全部印在同一頁
			sheet.setDefaultRowHeightInPoints(20);//預設列高
			sheet.setDefaultColumnWidth((short)9);//預設欄寬
			sheet.setMargin(HSSFSheet.TopMargin, (double) .30);//設定上邊界
			sheet.setMargin(HSSFSheet.BottomMargin, (double) .30);//設定下邊界
			sheet.setMargin(HSSFSheet.LeftMargin, (double) .30);//設定左邊界
			sheet.setMargin(HSSFSheet.RightMargin, (double) .30);//設定右邊界
			
			HSSFPrintSetup ps = sheet.getPrintSetup();//列印選項
//			ps.setFitHeight((short)1);
//			ps.setFitWidth((short)1);
			ps.setScale((short)70);//縮放比例
			ps.setLandscape(true);//設定橫印
			
			HSSFCellStyle style0 = workBook.createCellStyle();//標頭樣式
			HSSFFont font = workBook.createFont();
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);//粗體字
			font.setFontHeight((short)300);//字體大小
			style0.setFont(font);
			
			HSSFCellStyle style = workBook.createCellStyle();//欄位&Data樣式
			style.setWrapText(false);//自動換行
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);//設定下框線樣式
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);//設定左框線樣式
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);//設定右框線樣式
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);//設定上框線樣式
			style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		
			HSSFRow row = sheet.createRow(0);// 欄位名稱
			HSSFCell cell_0 = row.createCell(0);
			cell_0.setCellValue("單位");
			cell_0.setCellStyle(style);

			HSSFCell cell_1 = row.createCell(1);
			cell_1.setCellValue("姓名");
			cell_1.setCellStyle(style);

			HSSFCell cell_2 = row.createCell(2);
			cell_2.setCellValue("推薦人代碼");
			cell_2.setCellStyle(style);

			HSSFCell cell_3 = row.createCell(3);
			cell_3.setCellValue("員編");
			cell_3.setCellStyle(style);
			
			HSSFCell cell_4 = row.createCell(4);
			cell_4.setCellValue("汽車強制險");
			cell_4.setCellStyle(style);

			HSSFCell cell_5 = row.createCell(5);
			cell_5.setCellValue("");
			cell_5.setCellStyle(style);
			
			HSSFCell cell_6 = row.createCell(6);
			cell_6.setCellValue("汽車任意險");
			cell_6.setCellStyle(style);

			HSSFCell cell_7 = row.createCell(7);
			cell_7.setCellValue("");
			cell_7.setCellStyle(style);

			HSSFCell cell_8 = row.createCell(8);
			cell_8.setCellValue("機車強制險");
			cell_8.setCellStyle(style);

			HSSFCell cell_9 = row.createCell(9);
			cell_9.setCellValue("");
			cell_9.setCellStyle(style);

			HSSFCell cell_10 = row.createCell(10);
			cell_10.setCellValue("機車任意險");
			cell_10.setCellStyle(style);

			HSSFCell cell_11 = row.createCell(11);
			cell_11.setCellValue("");
			cell_11.setCellStyle(style);

			HSSFCell cell_12 = row.createCell(12);
			cell_12.setCellValue("住火險");
			cell_12.setCellStyle(style);

			HSSFCell cell_13 = row.createCell(13);
			cell_13.setCellValue("");
			cell_13.setCellStyle(style);

			HSSFCell cell_14 = row.createCell(14);
			cell_14.setCellValue("旅平險");
			cell_14.setCellStyle(style);

			HSSFCell cell_15 = row.createCell(15);
			cell_15.setCellValue("");
			cell_15.setCellStyle(style);
			
			HSSFCell cell_16 = row.createCell(16);
			cell_16.setCellValue("海域險");
			cell_16.setCellStyle(style);

			HSSFCell cell_17 = row.createCell(17);
			cell_17.setCellValue("");
			cell_17.setCellStyle(style);

			HSSFCell cell_18 = row.createCell(18);
			cell_18.setCellValue("合計");
			cell_18.setCellStyle(style);

			HSSFCell cell_19 = row.createCell(19);
			cell_19.setCellValue("");
			cell_19.setCellStyle(style);

			HSSFRow row_t2 = sheet.createRow(1);// 欄位名稱
			HSSFCell cell2_0 = row_t2.createCell(0);
			cell2_0.setCellValue("");
			cell2_0.setCellStyle(style);

			HSSFCell cell2_1 = row_t2.createCell(1);
			cell2_1.setCellValue("");
			cell2_1.setCellStyle(style);

			HSSFCell cell2_2 = row_t2.createCell(2);
			cell2_2.setCellValue("");
			cell2_2.setCellStyle(style);

			HSSFCell cell2_3 = row_t2.createCell(3);
			cell2_3.setCellValue("");
			cell2_3.setCellStyle(style);
			
			HSSFCell cell2_4 = row_t2.createCell(4);
			cell2_4.setCellValue("件數");
			cell2_4.setCellStyle(style);

			HSSFCell cell2_5 = row_t2.createCell(5);
			cell2_5.setCellValue("保費");
			cell2_5.setCellStyle(style);
			
			HSSFCell cell2_6 = row_t2.createCell(6);
			cell2_6.setCellValue("件數");
			cell2_6.setCellStyle(style);

			HSSFCell cell2_7 = row_t2.createCell(7);
			cell2_7.setCellValue("保費");
			cell2_7.setCellStyle(style);

			HSSFCell cell2_8 = row_t2.createCell(8);
			cell2_8.setCellValue("件數");
			cell2_8.setCellStyle(style);

			HSSFCell cell2_9 = row_t2.createCell(9);
			cell2_9.setCellValue("保費");
			cell2_9.setCellStyle(style);

			HSSFCell cell2_10 = row_t2.createCell(10);
			cell2_10.setCellValue("件數");
			cell2_10.setCellStyle(style);

			HSSFCell cell2_11 = row_t2.createCell(11);
			cell2_11.setCellValue("保費");
			cell2_11.setCellStyle(style);

			HSSFCell cell2_12 = row_t2.createCell(12);
			cell2_12.setCellValue("件數");
			cell2_12.setCellStyle(style);

			HSSFCell cell2_13 = row_t2.createCell(13);
			cell2_13.setCellValue("保費");
			cell2_13.setCellStyle(style);

			HSSFCell cell2_14 = row_t2.createCell(14);
			cell2_14.setCellValue("件數");
			cell2_14.setCellStyle(style);

			HSSFCell cell2_15 = row_t2.createCell(15);
			cell2_15.setCellValue("保費");
			cell2_15.setCellStyle(style);
			
			HSSFCell cell2_16 = row_t2.createCell(16);
			cell2_16.setCellValue("件數");
			cell2_16.setCellStyle(style);

			HSSFCell cell2_17 = row_t2.createCell(17);
			cell2_17.setCellValue("保費");
			cell2_17.setCellStyle(style);

			HSSFCell cell2_18 = row_t2.createCell(18);
			cell2_18.setCellValue("件數");
			cell2_18.setCellStyle(style);

			HSSFCell cell2_19 = row_t2.createCell(19);
			cell2_19.setCellValue("保費");
			cell2_19.setCellStyle(style);
			
			for (int i = 0; i < result.size(); i++) {
				Map mp = (Map) result.get(i);
				row = sheet.createRow(i + 2);
				createCell(row, (short) 0,String.valueOf(mp.get("M303").toString() + mp.get("M203").toString()), style);
				createCell(row, (short) 1,String.valueOf(mp.get("M302").toString()), style);
				createCell(row, (short) 2,String.valueOf(mp.get("T1582").toString()), style);
				createCell(row, (short) 3,String.valueOf(mp.get("M301").toString()), style);

				HSSFCell cell4 = row.createCell((short) 4);
				cell4.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell4.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("CA1").toString())));
				cell4.setCellStyle(style);

				HSSFCell cell5 = row.createCell((short) 5);
				cell5.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell5.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("CA2").toString())));
				cell5.setCellStyle(style);

				HSSFCell cell6 = row.createCell((short) 6);
				cell6.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell6.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("CC1").toString())));
				cell6.setCellStyle(style);

				HSSFCell cell7 = row.createCell((short) 7);
				cell7.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell7.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("CC2").toString())));
				cell7.setCellStyle(style);
			
				HSSFCell cell8 = row.createCell((short) 8);
				cell8.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell8.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("MA1").toString())));
				cell8.setCellStyle(style);

				HSSFCell cell9 = row.createCell((short) 9);
				cell9.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell9.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("MA2").toString())));
				cell9.setCellStyle(style);

				HSSFCell cell10 = row.createCell((short) 10);
				cell10.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell10.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("MC1").toString())));
				cell10.setCellStyle(style);

				HSSFCell cell11 = row.createCell((short) 11);
				cell11.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell11.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("MC2").toString())));
				cell11.setCellStyle(style);

				HSSFCell cell12 = row.createCell((short) 12);
				cell12.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell12.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("FR1").toString())));
				cell12.setCellStyle(style);

				HSSFCell cell13 = row.createCell((short) 13);
				cell13.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell13.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("FR2").toString())));
				cell13.setCellStyle(style);

				HSSFCell cell14 = row.createCell((short) 14);
				cell14.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell14.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("TA1").toString())));
				cell14.setCellStyle(style);

				HSSFCell cell15 = row.createCell((short) 15);
				cell15.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell15.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("TA2").toString())));
				cell15.setCellStyle(style);

				HSSFCell cell16 = row.createCell((short) 16);
				cell16.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell16.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("SE1").toString())));
				cell16.setCellStyle(style);

				HSSFCell cell17 = row.createCell((short) 17);
				cell17.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell17.setCellValue(NumberUtils.toDouble(String.valueOf(mp.get("SE2").toString())));
				cell17.setCellStyle(style);
				
				String rowno = String.valueOf(i + 3);
				String formula_sum_c = "E"+rowno+"+G"+rowno+"+I"+rowno+"+K"+rowno+"+M"+rowno+"+O"+rowno+"+Q"+rowno;//件數加總欄位公式
				String formula_sum_p = "F"+rowno+"+H"+rowno+"+J"+rowno+"+L"+rowno+"+N"+rowno+"+P"+rowno+"+R"+rowno;//保費加總欄位公式

				//件數加總
				HSSFCell cell18 = row.createCell((short) 18);
				cell18.setCellType(HSSFCell.CELL_TYPE_FORMULA);
				cell18.setCellFormula(formula_sum_c);
				cell18.setCellStyle(style);

				//保費加總
				HSSFCell cell19 = row.createCell((short) 19);
				cell19.setCellType(HSSFCell.CELL_TYPE_FORMULA);
				cell19.setCellFormula(formula_sum_p);
				cell19.setCellStyle(style);

			}

			return workBook;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AsiException("decode Data error");
		}
	}


	/**
	 * 統計件數保費
	 * @param request
	 * @return
	 */
	private List getDeatail1(HttpServletRequest request) {
		List ret = null;

		String startYMD = request.getParameter("startYMD") != null ? request.getParameter("startYMD") : "";
		String endYMD = request.getParameter("endYMD") != null ? request.getParameter("endYMD") : "";

		String sql =  "SELECT  X.M303 M303,X.M203 M203,X.M302 M302,X.M301 M301,X.T1582 T1582,                                  "
				+"SUM(X.CA1) CA1,SUM(X.CA2) CA2,SUM(X.CC1) CC1,SUM(X.CC2) CC2,                                            "
				+"SUM(X.MA1) MA1,SUM(X.MA2) MA2,SUM(X.MC1) MC1,SUM(X.MC2) MC2,                                            "
				+"SUM(X.FR1) FR1,SUM(X.FR2) FR2,                                                                          "
				+"SUM(X.TA1) TA1,SUM(X.TA2) TA2,                                                                          "
				+"SUM(X.SE1) SE1,SUM(X.SE2) SE2                                                                           "
				+"FROM (                                                                                                  "
//				+"--汽強                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"COUNT(T1501) CA1,SUM(T1541) CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 LIKE '%C%' AND T1503='A'                                                                      "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--汽任                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,COUNT(T1501) CC1,SUM(T1541) CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 LIKE '%C%' AND T1503 LIKE '%C%'                                                               "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--機強                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,0 CC1,0 CC2,COUNT(T1501) MA1,SUM(T1541) MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 LIKE '%M%' AND T1503='A'                                                                      "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--機任                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,COUNT(T1501) MC1,SUM(T1541) MC2,0 FR1,0 FR2,0 TA1,0 TA2,0 SE1,0 SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 LIKE '%M%' AND T1503 LIKE '%C%'                                                               "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--住火                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,COUNT(T1501) FR1,SUM(T1541) FR2,0 TA1,0 TA2,0 SE1,0 SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 ='FR'                                                                                         "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--旅平                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,0,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,COUNT(T1501) TA1,SUM(T1541) TA2,0 SE1,0 SE2     "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 ='TA'                                                                                         "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+"UNION                                                                                                   "
//				+"--海域                                                                                                  "
				+"SELECT                                                                                                  "
				+"M303,M203,M302,M301,T1582,                                                                              "
				+"0 CA1,0 CA2,0 CC1,0 CC2,0 MA1,0 MA2,0 MC1,0 MC2,0 FR1,0 FR2,0 TA1,0 TA2,COUNT(T1501) SE1,SUM(T1541) SE2 "
				+"FROM PT15PF                                                                                             "
				+"LEFT JOIN IC01PFA ON C01A17 = T1582                                                                     "
				+"LEFT JOIN IC01PF ON C01A01 = C101                                                                       "
				+"RIGHT JOIN PSM3PF ON M319=C101                                                                          "
				+"LEFT JOIN PSM2PF ON M202=M303 AND M201='A1'                                                             "
				+"WHERE T1538='B2C' AND T1582 IS NOT NULL AND M315=0                                                      "
				+"AND T1502 ='SE'                                                                                         "
				+"AND T1523 BETWEEN ? AND ?                                                                               "
				+"GROUP BY M303,M203,M302,M301,T1582                                                                      "
				+") X                                                                                                     "
				+"GROUP BY X.M303,X.M203,X.M302,X.M301,X.T1582                                                            ";

		String args[] = new String[14];
		args[0]  = startYMD;
		args[1]  = endYMD;
		args[2]  = startYMD;
		args[3]  = endYMD;
		args[4]  = startYMD;
		args[5]  = endYMD;
		args[6]  = startYMD;
		args[7]  = endYMD;
		args[8]  = startYMD;
		args[9]  = endYMD;
		args[10] = startYMD;
		args[11] = endYMD;
		args[12] = startYMD;
		args[13] = endYMD;			
		
		Connection con = null;
		
		try {
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			ret = (List) runner.query(con, sql.toString() , args ,new TrimedMapListHandler());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			AS400Connection.closeConnection(con);
		}
		
		return ret;
	}
}