/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * @author vsg
 * 查詢車險專案代號是否存在
 */
public class online_CheckProjectCode extends AsiAction
{	

   public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       AsiActionForm form1 = (AsiActionForm) form;
       if (form1.getActionCode() == 0)
           form1.setActionCode(GlobalKey.ACTION_SELECT);
       return;
   }

   public ActionForward sessionCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
   {
       return null;
   }

   protected void portalCheck(ActionMapping mapping, HttpServletRequest request, AsiActionForm asiForm) throws AsiException
   {
   	
   }
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws AsiException
	{
		String pjcode = arg2.getParameter("projectcode") != null && !arg2.getParameter("projectcode").equals("") ? arg2.getParameter("projectcode").trim().toUpperCase() : "";//專案代號				
		
		QueryRunner run = new QueryRunner();
		//判斷是否有效專案代號SQL
		String sql;
		sql = "SELECT * FROM SECAZ WHERE CODETYPE='PROJSOURCE' AND CODEID = ?";
		//判斷是否有效推薦人代號SQL
		String sql2;
		sql2 = "select * from PSM3PF left join IC01PFA on M319=C01A01 where C01A17 = ?";
		String[] param = new String[1];
		param[0] = pjcode;
		//專案代號查詢結果
		List<?> c;
		//推薦人代號查詢結果
		List<?> r;
		
		Map<String, String> result = new HashMap<String, String>();
		try
		{
			tx_controller.begin(0);			
			c = (List<?>) run.query(tx_controller.getConnection(0),sql,param,new TrimedMapListHandler());
			r = (List<?>) run.query(tx_controller.getConnection(0),sql2,param,new TrimedMapListHandler());
			//此專案代號或推薦人代號有效
			if(c.size() > 0 || r.size() > 0){
				//專案代號
				if(c.size() > 0){
					Map<?, ?> map = (Map<?, ?>) c.get(0);
					String codedesc = map.get("CODEDESC").toString();
						
					if(codedesc.equals("HOLIDAY"))
					{
						if(checkZ42100())
							result.put("result", "true");
						else
							result.put("result", "falseH");
					} else 
						result.put("result", "true");
				}
				//推薦人代號
				else{
					result.put("result", "true");
				}
				
			} else
					result.put("result", "false");
				
			arg3.setContentType("text/json;charset=UTF-8");
			arg3.setHeader("Cache-Control", "no-cache");
			arg3.getWriter().write(JSONArray.fromObject(result).toString());
			arg3.getWriter().flush();
			arg3.getWriter().close();
		}
		catch (SQLException e)
		{
			System.out.print("bb:" + e);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}
		arg1.setNextPage(-1);
	}
	
    public boolean checkZ42100()  {
    	boolean ret = false;
    	String sysDate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sysYM = sysDate.substring(0, sysDate.length() - 2);
		tx_controller.begin(1);	
		if (Integer.parseInt(sysYM) <= 11006) {  
			QueryRunner run = new QueryRunner();
			try
			{
				String sql = "SELECT * FROM AGAGPF WHERE AG04 = ?";  //檢核工作日檔
				String[] param = new String[1];
				param[0] = DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD,false);
				List<?> c = (List<?>) run.query(tx_controller.getConnection(1),sql,param,new TrimedMapListHandler());
				if(c.size() <= 0)
					ret= true;
			}
			catch (Exception e)
			{
				System.out.print("bb:" + e);
			}
		}
    	
    	return ret;
    }
}
