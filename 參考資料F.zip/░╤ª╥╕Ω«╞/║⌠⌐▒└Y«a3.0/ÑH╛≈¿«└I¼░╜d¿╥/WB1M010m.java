/*
 * Created on 2005/4/8
 */
package com.asi.kyc.wb1.models;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.asi.common.AsiModel;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.TransactionControl;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MathUtil;
import com.asi.common.util.MessageUtil;
import com.asi.kyc.common.KYCEncryptor;
import com.asi.kyc.common.KycGlobal;
import com.asi.kyc.common.Kyckd;
import com.asi.kyc.common.MotorIns;
import com.asi.kyc.common.MotorPrice;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.Codec;
import com.asi.kyc.common.utils.InsuranceUtil;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.NumberUtil;
import com.asi.kyc.common.utils.TradeCounter;
import com.asi.kyc.common.utils.UpdateState;
import com.asi.kyc.wb1.actions.AS400Procedure;
import com.asi.kyc.wb1.forms.WB1M010f;
import com.firstins.dao.procedure.FAS24Input;
import com.firstins.dao.procedure.FAS24PRC;
import com.firstins.dao.procedure.FAS24Return;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * @author Sergio_Huang
 * 
 * 異動註記 ：	2005/09/27  John  增加判斷使用者是由那一個網站進入線上投保
 * 			2005/10/18  John  增加判斷投保起日是否大於上次投保迄日-1個月
 * 			2005/12/12  John  修改 getEndDate 中的 GregorianCalendar 月份設定錯誤
 * 			2019/03/12	vsg	      調整無用的程式
 */
public class WB1M010m extends AsiModel {

	private static final long serialVersionUID = 1L;

	private static Log logger = LogFactory.getLog(WB1M010m.class);

    private WB1M010f mform;

    private Map dbocatch = new HashMap();

    /**
     * 建構值
     * 
     * @param tx_controller
     * @param request
     * @param form
     */
    public WB1M010m(TransactionControl tx_controller, HttpServletRequest request, AsiActionForm form) {
        super(tx_controller, request, form);
    }

    public void init() throws AsiException {

        mform = new WB1M010f();
        //把form做拷貝
        try {
            BeanUtils.copyProperties(mform, getForm());
        } catch (InvocationTargetException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        } catch (IllegalAccessException e) {
            if (logger.isErrorEnabled()) {
                logger.error(e);
            }
        }
        setUserinfo();
        setMainForm(mform);

    }

    private void setUserinfo() {
        if (getTransaction().getUserInfo() == null) {
            UserInfo ui = new UserInfo();
            ui.setInfo("USERID", "SYSTEM");
            ui.setDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setDateType(DateUtil.ChType);
            ui.setFileDateFormat(DateUtil.Format_YYYYMMDD);
            ui.setFileDateType(DateUtil.ChType);
            getTransaction().setUserInfo(ui);
        }
    }

    public void destroy() {
    }

    /**
     * 檢查第一頁的資訊內容
     * 
     * @throws AsiException
     */
    public void checkP1() throws AsiException {

    }

    /**
     * 處理第一頁
     * 
     * @throws AsiException
     */
    public void processP1() throws AsiException {
        String key = "";
        String carType = mform.getCartype();//車種
        String year;//年期中文
        String type = mform.getType();		//投保方案
        String period = mform.getPeriod();	//年期
        String project = mform.getPjcode();	//專案 
        if(!project.equals("")){
        	
        }       
        String insamout_31 = mform.getInsamout_31();
        String insamout_32 = mform.getInsamout_32();
        String times_31 = mform.getTimes_31();//31險種倍數
        String lincy = mform.getLicencey();
        String lincm = mform.getLicencem();
        String prdocuty = mform.getKyc_T1607() + mform.getKyc_T1607_MM();       //  String prdocuty = getWestYear(lincy);
        String carno = (mform.getCarnumbertype()!=null && mform.getCarnumbertype().equals("1")) ? mform.getKyc_T1610_old() : mform.getKyc_T1610();
        String id = mform.getKyc_T1507();
        
        String entry = mform.getEntry();
        String check21 = mform.getCkb_ins_21() != null ? mform.getCkb_ins_21() : "N";
        String check47 = mform.getCkb_ins_47() != null ? mform.getCkb_ins_47() : "N";
        String check47E = mform.getCkb_ins_47E() != null ? mform.getCkb_ins_47E() : "N";
        String check31 = mform.getCkb_ins_31() != null ? mform.getCkb_ins_31() : "N";
        String check35 = mform.getCkb_ins_35() != null ? mform.getCkb_ins_35() : "N";
        String ins_35_option = mform.getIns_35_option();
        String insamout_35 = "5000000";
        String insamout_37 = "5000";
        String insamout_37D = "50000";
        String insamout_3G = "50000";
        String insamout_51 = "2000000";
        if ("1".equals(ins_35_option)) 
        	insamout_35 = "3000000";
        if ("Y".equals(check35)) {
        	if ("1".equals(ins_35_option)) 
        		insamout_31 = "2000000";
         	else  
        		insamout_31 = "3000000";
        	insamout_32 = "500000";	
        	mform.setInsamout_31(insamout_31);
        	mform.setInsamout_32(insamout_32);
        }
        mform.setInsamout_35(insamout_35);
        mform.setInsamout_37(insamout_37);
        mform.setInsamout_37D(insamout_37D);
        mform.setInsamout_3G(insamout_3G);
        mform.setInsamout_51(insamout_51);
        
        String kd20 = "41";
        if(entry.equals("2"))
        	kd20 = "40";
        
        //依畫面選取險種判斷方案
        
        if(check21.equals("Y")){
            if(!check47.equals("Y") && !check47E.equals("Y") && !(check31.equals("Y") || check35.equals("Y")))
            	key = "M01";
            else if((check47.equals("Y") || check47E.equals("Y")) && !(check31.equals("Y") || check35.equals("Y")))
            	key = "M02";
            else if(!check47.equals("Y") && !check47E.equals("Y") && (check31.equals("Y") || check35.equals("Y")))
            	key = "M03";
            else if((check47.equals("Y") || check47E.equals("Y")) && (check31.equals("Y") || check35.equals("Y")))
            	key = "M04";
        }else{
        	key = "M05";  
        }
         
        mform.setType(key);
        type = key; 
        
        key += "_" + period + "_" + carType;
        
        if(!project.equals(""))
        	if(isProjectCode(project)){//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        		project = CodeUtil.getCodeDesc(getServlet(), getRequest(), "PROJSOURCE", project.toUpperCase());
        	}
        	else{
        		project="BOSS3.0";
        	}       	
        else
        	project = "KYC";
                
        //強制起保日
        String startDate = mform.getYear()+mform.getMonth()+mform.getDate();
        //任意起保日
        String vol_startDate = mform.getVolyear() + mform.getVolmonth() + mform.getVoldate();
        String insamout_31total = String.valueOf(Integer.parseInt(insamout_31) * Integer.parseInt(times_31));
        
        //查任意等級
        String getgrade[] = cIILVLPRC(carno, id, carType);
            
        MotorIns.setCartype(carType);
        MotorIns.setStartDate(startDate);
        MotorIns.setVol_startdate(vol_startDate);
        MotorIns.setPjcode(project);
        MotorIns.setInsamout_31(insamout_31);
        MotorIns.setInsamout_32(insamout_32);
        MotorIns.setInsamout_35(insamout_35);
        MotorIns.setInsamout_37(insamout_37);
        MotorIns.setInsamout_37D(insamout_37D);
        MotorIns.setInsamout_3G(insamout_3G);
        MotorIns.setInsamout_51(insamout_51);
        MotorIns.setTimes_31(times_31);
        MotorIns.setLicencey(lincy);
        MotorIns.setLicencem(lincm);
        MotorIns.setProducey(prdocuty);
        MotorIns.setGrade(getgrade[2]);
        MotorIns.load(getTransaction() , type , kd20);
        
        double total = 0;
        double total_discount = 0;
        
        mform.setInsamout_31total(insamout_31total);
        mform.setDetail_o1(getDetailPrice(type, period , carType)[0]);
        mform.setDetail_d1(getDetailPrice(type, period , carType)[1]);
        mform.setDetail_o2(getDetailPrice(type, period , carType)[2]);
        mform.setDetail_d2(getDetailPrice(type, period , carType)[3]);
        mform.setDetail_o3(getDetailPrice(type, period , carType)[4]);
        mform.setDetail_d3(getDetailPrice(type, period , carType)[5]);
        mform.setDetail_o4(getDetailPrice(type, period , carType)[6]);
        mform.setDetail_d4(getDetailPrice(type, period , carType)[7]);
        mform.setDetail_o5(getDetailPrice(type, period , carType)[8]);
        mform.setDetail_d5(getDetailPrice(type, period , carType)[9]);
        mform.setDetail_o6(getDetailPrice(type, period , carType)[10]);
        mform.setDetail_d6(getDetailPrice(type, period , carType)[11]);
        mform.setDetail_o7(getDetailPrice(type, period , carType)[12]);
        mform.setDetail_d7(getDetailPrice(type, period , carType)[13]);
        mform.setDetail_o8(getDetailPrice(type, period , carType)[14]);
        mform.setDetail_d8(getDetailPrice(type, period , carType)[15]);
        
        double o1 = mform.getDetail_o1() != null ? Double.parseDouble(mform.getDetail_o1()) : 0;
        double o2 = mform.getDetail_o2() != null ? Double.parseDouble(mform.getDetail_o2()) : 0;
        double o3 = mform.getDetail_o3() != null ? Double.parseDouble(mform.getDetail_o3()) : 0;
        double o4 = mform.getDetail_o4() != null ? Double.parseDouble(mform.getDetail_o4()) : 0;
        double o5 = mform.getDetail_o5() != null ? Double.parseDouble(mform.getDetail_o5()) : 0;
        double o6 = mform.getDetail_o6() != null ? Double.parseDouble(mform.getDetail_o6()) : 0;
        double o7 = mform.getDetail_o7() != null ? Double.parseDouble(mform.getDetail_o7()) : 0;
        double o8 = mform.getDetail_o8() != null ? Double.parseDouble(mform.getDetail_o8()) : 0;
        double d1 = mform.getDetail_d1() != null ? Double.parseDouble(mform.getDetail_d1()) : 0;
        double d2 = mform.getDetail_d2() != null ? Double.parseDouble(mform.getDetail_d2()) : 0;
        double d3 = mform.getDetail_d3() != null ? Double.parseDouble(mform.getDetail_d3()) : 0;
        double d4 = mform.getDetail_d4() != null ? Double.parseDouble(mform.getDetail_d4()) : 0;
        double d5 = mform.getDetail_d5() != null ? Double.parseDouble(mform.getDetail_d5()) : 0;
        double d6 = mform.getDetail_d6() != null ? Double.parseDouble(mform.getDetail_d6()) : 0;
        double d7 = mform.getDetail_d7() != null ? Double.parseDouble(mform.getDetail_d7()) : 0;
        double d8 = mform.getDetail_d8() != null ? Double.parseDouble(mform.getDetail_d8()) : 0;
        
        total = o1 + o2 + o3 + o4 + o5 + o6 + o7 + o8;
        total_discount = d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8;
        
        mform.setTotal(String.valueOf((int) total));
        mform.setDiscount(String.valueOf((int) total_discount));

        if (period.equals("1"))
            year = MessageUtil.getMessage(getServlet(), getRequest(), "WB1M010.remark32");//一年期
        else
            year = MessageUtil.getMessage(getServlet(), getRequest(), "WB1M010.remark38");//二年期
        
        if (carType.equals("02"))
            carType = MessageUtil.getMessage(getServlet(), getRequest(), "WB1M010.remark52");//輕型機車
        else if (carType.equals("01"))
            carType = MessageUtil.getMessage(getServlet(), getRequest(), "WB1M010.remark53");//重型機車
        else
            carType = MessageUtil.getMessage(getServlet(), getRequest(), "WB1M010.remark55");//超重型機車
        
        getRequest().setAttribute("year", year);
        getRequest().setAttribute("cartype", carType);
        setMainForm(mform);
        getTransaction().begin(0);
        TradeCounter.count(getKG01(), (UserInfo) getSession().getAttribute(GlobalKey.USER_INFO), getTransaction());
    }

    /**
     * 檢查第二頁的資訊內容
     * 
     * @throws AsiException
     */
    public void checkP2() throws AsiException {
    }

    /**
     * 處理第二頁
     * 
     * @throws AsiException
     */
    public void processP2() throws AsiException {

    }

    /**
     * @return
     * @throws AsiException
     *  
     */
    public boolean processP3() throws AsiException {
        DBO dbo = getTransaction().getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", mform.getUID());
        dbo.executeSelect();
        if (dbo.getRecordCount() == 1) {
            getRequest().setAttribute(KycGlobal.InsureType, KycGlobal.MotorInsurance);
            return true;
        }
        mform.setPWD("");
        mform.setKyc_T1507(mform.getUID());
        return false;
    }

    /**
     * @throws AsiException
     *  
     */
    public void processP4(String agentno) throws AsiException {

        //增加判斷投保起日是否大於上次投保迄日-1個月
//        DBO dbo2 = getTransaction().getDBO("kyc.PT15PFs08", 0);
//        dbo2.addParameter("T1507", mform.getKyc_T1507()); //pt15pf.t1507身份證
//        dbo2.addParameter("T1610", (mform.getCarnumbertype()!=null && mform.getCarnumbertype().equals("1")) ? mform.getKyc_T1610_old() : mform.getKyc_T1610()); //pt16pf.t1610車號
//        System.out.println(dbo2.getAssembledSQL());
//        dbo2.execute();
//        if (dbo2.getRecordCount() > 0) {
//            validDate(dbo2.getRecordData("T1518"), mform.getYear() + mform.getMonth() + mform.getDate());
//        }
//        dbo2.destroy();
        
        //生日 => 檢核小於等於系統日
        if (DateUtil.getDateInterval(getUsrInfo(), DateUtil.getSysDate(getUsrInfo(), false), getBirthDay()) < 0)
            throw new UserException("WB1.ERROR02");

        //原始發照民國 => 檢核小於等於系統年月
        if (DateUtil.getDateInterval(getUsrInfo(), DateUtil.getSysDate(getUsrInfo(), false), mform.getLicencey() + StringUtils.leftPad(mform.getLicencem(), 2, "0") + "01") < 0)
            throw new UserException("WB1.ERROR03");

        //查詢洗錢風險評估資料
		String isid_switch = SystemParam.getParam("ISID_SWITCH");// 法遵管制名單新版程式啟用註記，測試機已啟用-Y 正式機若尚未啟用-N
        String omitFAS24 = SystemParam.getParam("INS_OMITFAS24");// 是否略過查FAS24PRC，平常-N 測試-Y
        
        if(!omitFAS24.equals("Y")){//是否略過查詢FAS24
        	
        	if(isid_switch.equals("Y")){//新版
            	//被保險人-查詢洗錢風險評估資料
            	if (checkFas24prc_new(mform.getKyc_T1507(),mform.getKyc_T1506(),getBirthDay(),agentno) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}

    	        //要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc_new(mform.getKyc_T1547(),mform.getKyc_T1546(),getqmanBirthDay(),agentno) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}   	     	
        	}else{//舊版
            	//被保險人-查詢洗錢風險評估資料
            	if (checkFas24prc(mform.getKyc_T1507(),mform.getKyc_T1506()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
    	
    	        //要保人-查詢洗錢風險評估資料
    	     	if (checkFas24prc(mform.getKyc_T1547(),mform.getKyc_T1546()) == false){
    	    		throw new UserException("WB1.ERROR13");
    	    	}
        	}
        }
        

        String addr;
        if (mform.getAddr().equals("new"))
            addr = mform.getCity() + mform.getTown() + mform.getAddrnew();
        else
            addr = mform.getAddrold();
        mform.setKyc_T1512(addr);
        
        if(mform.getKyc_T1510().equals("")){
            mform.setKyc_T1510("3");
        }
        
        DBO dbo = getTransaction().getDBO("kyc.PFBNs03",0);
        dbo.addParameter("BN00",mform.getBN00());
        dbo.execute();
        mform.setBN00d(dbo.getRecordData("BN01"));
                
        try {
			String htmlcode = mform.getInstypename().replace("\n", "").replace("\r", "").replace("\t", "").replace("<tbody>", "").replace("</tbody>", "");
        	
			mform.setInstypename(Codec.encode(htmlcode));
		} catch (IOException e) {
			e.printStackTrace();
		}
            
    }

    /**
     * //寫交易記錄檔提供金流Server比對交易用
     */
    public void processP5() throws AsiException {
        String number = Number.getNumber_AC("AM", getServlet(), getRequest(), "T");
        mform.setNumber(number);
        mform.setKYC_T1501a(number);
        mform.setKYC_T1503a("C1");

        //測試寫檔完成用******************************************************************************************
//        mform.setRetcode("00");//測試寫檔完成用
//        try {
//        	getRequest().setAttribute("decodedata", Codec.decode(mform.getInstypename()));
//        } catch (IOException e) {
//      	  e.printStackTrace();
//        }        
        //****************************************************************************************************
        
        getTransaction().begin(0);
        mform.setNewClient(isClient_P(mform.getKyc_T1507()));//檢核是否為新保戶
        
        //判斷伺服器機車線上投保方案紀錄是否變更，如是則重新計算
        //強制起保日
        String startDate = mform.getYear()+mform.getMonth()+mform.getDate();
        //任意起保日
        String vol_startDate = mform.getVolyear() + mform.getVolmonth() + mform.getVoldate();

        String pjcode = mform.getPjcode();
        String carType = mform.getCartype();
        String prdocuty = mform.getKyc_T1607();       // String prdocuty = getWestYear(lincy);
        String id = mform.getKyc_T1507();
        
        if(!pjcode.equals("")) {
        	if(isProjectCode(pjcode)){//判斷pjcode是專案代號(ture)或是推薦人代號(false)
        		pjcode = CodeUtil.getCodeDesc(getServlet(), getRequest(), "PROJSOURCE", pjcode.toUpperCase());
            	if (pjcode.equals("HOLIDAY"))
            		pjcode = "KYC";
        	}
        	else{
        		pjcode="BOSS3.0";
        	}        	
        } else
        	pjcode = "KYC";
        
        //查任意等級
        String getgrade[] = cIILVLPRC(mform.getKyc_T1610(), id, carType);
        
        if(!startDate.equals(MotorPrice.getStartDate()) || !mform.getType().equals(MotorPrice.getType()) || 
        	!mform.getCartype().equals(MotorIns.getCartype()) || !pjcode.equals(MotorIns.getPjcode()) ||
        	!mform.getInsamout_31().equals(MotorIns.getInsamout_31()) || !mform.getInsamout_32().equals(MotorIns.getInsamout_32())	)
        {     	
            MotorIns.setCartype(mform.getCartype());
            MotorIns.setStartDate(startDate);
            MotorIns.setVol_startdate(vol_startDate);
            MotorIns.setPjcode(pjcode);
            MotorIns.setInsamout_31(mform.getInsamout_31());
            MotorIns.setInsamout_32(mform.getInsamout_32());
            MotorIns.setTimes_31(mform.getTimes_31());
            MotorIns.setLicencey(mform.getLicencey());
            MotorIns.setLicencem(mform.getLicencem());
            MotorIns.setProducey(prdocuty);
            MotorIns.setGrade(getgrade[2]);
            MotorIns.load(getTransaction() , mform.getType() , mform.getEntry().equals("2") ? "40" : "41" );
        }        
        
        //產otp
        String otp = KYCEncryptor.genOTP();

        String channelCode = (mform.getEntry() != null && mform.getEntry().equals("2")) ? "40" : "41";
        String check21 = mform.getCkb_ins_21() != null ? mform.getCkb_ins_21() : "N";
        String check47 = mform.getCkb_ins_47() != null ? mform.getCkb_ins_47() : "N";
        String check47E = mform.getCkb_ins_47E() != null ? mform.getCkb_ins_47E() : "N";
        String check31 = mform.getCkb_ins_31() != null ? mform.getCkb_ins_31() : "N";
        String check35 = mform.getCkb_ins_35() != null ? mform.getCkb_ins_35() : "N";
        
        if (mform.getType().equals("M01")) {//基本型
            if (mform.getPeriod().equals("1")) {//一年期,01,03,05
                DBO dbo = getKYCKD("M01", "A", "21", "1", getCarCC(), pjcode , channelCode);
                String ins21Total = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.total, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                
                //網路出單交易主檔
                writeToPT15PF(number, "M01", "A", ins21Total, ins21Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M01", "A", ins21Total, ins21Discount, "2");//類別傳入2-表寫入交易LOG檔
                //網路出單交易明細
                writeToPT17PF(number, "M01", "A", ins21Total, ins21Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔

            } else {
                DBO dbo = getKYCKD("M01", "A", "21", "2", getCarCC(), pjcode , channelCode);
                String ins21Total = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.total, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                
                //網路出單交易主檔
                writeToPT15PF(number, "M01", "A", ins21Total, ins21Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M01", "A", ins21Total, ins21Discount, "2");//類別傳入2-表寫入交易LOG檔                
                //網路出單交易明細
                writeToPT17PF(number, "M01", "A", ins21Total, ins21Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔

            }
            
            mform.setKYC_T1503a("A");
            
        } else if (mform.getType().equals("M02")) {//加值型
            if (mform.getPeriod().equals("1")) {//一年期,01,03,05
                //機車強制險
                DBO dbo = getKYCKD("M02", "A", "21", "1", getCarCC(), pjcode , channelCode);
                String ins21Total = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.total, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                
                //網路出單交易主檔
                writeToPT15PF(number, "M02", "A", ins21Total, ins21Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M02", "A", ins21Total, ins21Discount, "2");//類別傳入2-表寫入交易LOG檔
                //網路出單交易明細
                writeToPT17PF(number, "M02", "A", ins21Total, ins21Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔
                
                //駕駛人傷害險
                String ins47Discount ="0";
                if(check47.equals("Y")){
                	dbo = getKYCKD("M02", "C", "47", "1", getCarCC(), pjcode , channelCode);
                	ins47Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47);
                } else {
                	dbo = getKYCKD("M02", "C", "47E", "1", getCarCC(), pjcode , channelCode);
                	ins47Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47E);
                }
                
                //網路出單交易主檔
                writeToPT15PF(number, "M02", "C1", ins47Discount, ins47Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M02", "C1", ins47Discount, ins47Discount, "2");//類別傳入2-表寫入交易LOG檔
                //網路出單交易明細
                writeToPT17PF(number, "M02", "C1", ins47Discount, ins47Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔     
                
                mform.setKYC_T1503a("C1");
            } else {             
                //機車強制險
                DBO dbo = getKYCKD("M02", "A", "21", "2", getCarCC(), pjcode , channelCode);
                String ins21Total = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.total, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                
                //網路出單交易主檔
                writeToPT15PF(number, "M02", "A", ins21Total, ins21Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M02", "A", ins21Total, ins21Discount, "2");//類別傳入2-表寫入交易LOG檔                
                //網路出單交易明細
                writeToPT17PF(number, "M02", "A", ins21Total, ins21Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔

                //駕駛人傷害險
                String ins47Discount ="0";
                if(check47.equals("Y")){
                	dbo = getKYCKD("M02", "C", "47", "2", getCarCC(), pjcode , channelCode);
                	ins47Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins47);
                } else {
                	dbo = getKYCKD("M02", "C", "47E", "2", getCarCC(), pjcode , channelCode);
                	ins47Discount = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins47E);
                }
                
                //網路出單交易主檔
                writeToPT15PF(number, "M02", "C2", ins47Discount, ins47Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                //網路出單標的明細
                writeToPT16PF(number, "M02", "C2", ins47Discount, ins47Discount, "2");//類別傳入2-表寫入交易LOG檔
                //網路出單交易明細
                writeToPT17PF(number, "M02", "C2", ins47Discount, ins47Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔
                
                mform.setKYC_T1503a("C2");
            }
            
        } else if (mform.getType().equals("M03")) {
            if (mform.getPeriod().equals("1")) {//一年期,01,03,05
                //機車強制險-----------------------------------------------------------------------------------------------------------
                DBO dbo = getKYCKD("M03", "A", "21", "1", getCarCC(), pjcode , channelCode);                
                String ins21Total = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                
                writeToPT15PF(number, "M03", "A", ins21Total, ins21Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                writeToPT16PF(number, "M03", "A", ins21Total, ins21Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                writeToPT17PF(number, "M03", "A", ins21Total, ins21Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

            	if(check31.equals("Y")){
	                dbo = getKYCKD("M03", "C", "31", "1", getCarCC(), pjcode , channelCode);
	                
	                String insYear2_31_32_discount = MotorPrice.getInsYear2_31_32(getCarCC(), MotorPrice.discount);                
	
	                writeToPT15PF(number, "M03", "C1", insYear2_31_32_discount, insYear2_31_32_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
	                writeToPT16PF(number, "M03", "C1", insYear2_31_32_discount, insYear2_31_32_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
	              
	                String ins31Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
	                writeToPT17PF(number, "M03", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	
	                dbo = getKYCKD("M03", "C", "32", "1", getCarCC(), pjcode , channelCode);
	                String ins32Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
	                writeToPT17PF(number, "M03", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	                
	                mform.setKYC_T1503a("C1");
            	} else if(check35.equals("Y")){
                	dbo = getKYCKD("M03", "C", "31", "1", getCarCC(), pjcode , channelCode);
                    
                    String insYear1_35_discount = MotorPrice.getInsType3_Year1_35(getCarCC(), MotorPrice.discount);
                    
                    writeToPT15PF(number, "M03", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M03", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    
                    String ins31Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                    writeToPT17PF(number, "M03", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "32", "1", getCarCC(), pjcode , channelCode);
                    String ins32Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                    writeToPT17PF(number, "M03", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "35", "1", getCarCC(), pjcode , channelCode);
                    String ins35Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                    writeToPT17PF(number, "M03", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "37", "1", getCarCC(), pjcode , channelCode);
                    String ins37Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                    writeToPT17PF(number, "M03", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                    String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                    writeToPT17PF(number, "M03", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "51", "1", getCarCC(), pjcode , channelCode);
                    String ins51Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                    writeToPT17PF(number, "M03", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    mform.setKYC_T1503a("C1");
            	}
            } else {//二年期                
                //機車強制險-----------------------------------------------------------------------------------------------------------
                DBO dbo = getKYCKD("M03", "A", "21", "2", getCarCC(), pjcode , channelCode);
                String ins21Total = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                String ins21Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                
                writeToPT15PF(number, "M03", "A", ins21Total, ins21Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔                
                writeToPT16PF(number, "M03", "A", ins21Total, ins21Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                writeToPT17PF(number, "M03", "A", ins21Total, ins21Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                //其餘險--------------------------------------------------------------------------------------------------------------
            	if(check31.equals("Y")){
	                dbo = getKYCKD("M03", "C", "31", "1", getCarCC(), pjcode , channelCode);
	                
	                String insYear2_31_32_discount = MotorPrice.getInsYear2_31_32(getCarCC(), MotorPrice.discount);                
	
	                writeToPT15PF(number, "M03", "C1", insYear2_31_32_discount, insYear2_31_32_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
	                writeToPT16PF(number, "M03", "C1", insYear2_31_32_discount, insYear2_31_32_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
	              
	                String ins31Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
	                writeToPT17PF(number, "M03", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	
	                dbo = getKYCKD("M03", "C", "32", "1", getCarCC(), pjcode , channelCode);
	                String ins32Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
	                writeToPT17PF(number, "M03", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	                
	                mform.setKYC_T1503a("C1");
            	} else if(check35.equals("Y")){
                	dbo = getKYCKD("M03", "C", "31", "1", getCarCC(), pjcode , channelCode);
                    
                    String insYear1_35_discount = MotorPrice.getInsType3_Year1_35(getCarCC(), MotorPrice.discount);
                    
                    writeToPT15PF(number, "M03", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M03", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    
                    String ins31Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                    writeToPT17PF(number, "M03", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "32", "1", getCarCC(), pjcode , channelCode);
                    String ins32Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                    writeToPT17PF(number, "M03", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "35", "1", getCarCC(), pjcode , channelCode);
                    String ins35Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                    writeToPT17PF(number, "M03", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "37", "1", getCarCC(), pjcode , channelCode);
                    String ins37Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                    writeToPT17PF(number, "M03", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                    String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                    writeToPT17PF(number, "M03", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M03", "C", "51", "1", getCarCC(), pjcode , channelCode);
                    String ins51Discount = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                    writeToPT17PF(number, "M03", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    mform.setKYC_T1503a("C1");
            	}
            }
        } else if (mform.getType().equals("M04")) {
        	DBO dbo = null;
        	
        	if (mform.getPeriod().equals("1")) {//一年期,01,03,05
                //機車強制險-----------------------------------------------------------------------------------------------------------
        		if(check21.equals("Y")){
                    dbo = getKYCKD("M04", "A", "21", "1", getCarCC(), pjcode , channelCode);                
                    String ins21Total = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                    String ins21Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins21);
                    
                    writeToPT15PF(number, "M04", "A", ins21Total, ins21Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M04", "A", ins21Total, ins21Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    writeToPT17PF(number, "M04", "A", ins21Total, ins21Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
        		}
	                
                if(!startDate.equals(vol_startDate)){
                	//任意險 + 駕傷險一年，強制與任意保期不同時，駕傷與任意拆開--------------------------------------------------------------------------------------------------------------
                	//駕傷寫檔用C2
                	if(check47.equals("Y")){
                    	dbo = getKYCKD("M04", "C", "47", "1", getCarCC(), pjcode , channelCode);
                        
                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47);
                        
                        writeToPT15PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                        writeToPT16PF(number, "M04", "C2", ins47Discount, ins47Discount, "2");//類別傳入2-表寫入交易LOG檔
                        writeToPT17PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔
                        
                        mform.setKYC_T1503b("C2");
                	} else if(check47E.equals("Y")){
                    	dbo = getKYCKD("M04", "C", "47E", "1", getCarCC(), pjcode , channelCode);
                        
                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47E);
                        
                        writeToPT15PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2" , otp);//類別傳入2-表寫入交易LOG檔
                        writeToPT16PF(number, "M04", "C2", ins47Discount, ins47Discount, "2");//類別傳入2-表寫入交易LOG檔
                        writeToPT17PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2");//類別傳入2-表寫入交易LOG檔
                        
                        mform.setKYC_T1503b("C2");
                	}
                    
                    //任意險寫檔用C1
                	if(check31.equals("Y")){
                        dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                        
                        String insYear1_discount = MotorPrice.getInsType4_Year1_31_32(getCarCC(), MotorPrice.discount);
                        
                        writeToPT15PF(number, "M04", "C1", insYear1_discount, insYear1_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                        writeToPT16PF(number, "M04", "C1", insYear1_discount, insYear1_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                        String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                        writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
                        String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                        writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔               
                        
                        mform.setKYC_T1503a("C1");
                	} else if(check35.equals("Y")){
                    	dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                        
                        String insYear1_35_discount = MotorPrice.getInsType4_Year1_35(getCarCC(), MotorPrice.discount);
                        
                        writeToPT15PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                        writeToPT16PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                        
                        String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                        writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
                        String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                        writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "35", "1", getCarCC(), pjcode , channelCode);
                        String ins35Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                        writeToPT17PF(number, "M04", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "37", "1", getCarCC(), pjcode , channelCode);
                        String ins37Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                        writeToPT17PF(number, "M04", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                        String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                        writeToPT17PF(number, "M04", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "51", "1", getCarCC(), pjcode , channelCode);
                        String ins51Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                        writeToPT17PF(number, "M04", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        mform.setKYC_T1503a("C1");
                	}

                }else{
                    //任意險 + 駕傷險一年--------------------------------------------------------------------------------------------------------------
                	if(check31.equals("Y")){
	                    dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
	                    
	                    String insYear1_discount = "0";
	                    if(check47.equals("Y"))
	                    	insYear1_discount = MotorPrice.getInsType4_Year1_47_31_32(getCarCC(), MotorPrice.discount, "47");
	                    else
	                    	insYear1_discount = MotorPrice.getInsType4_Year1_47_31_32(getCarCC(), MotorPrice.discount, "47E");
	                    
	                    writeToPT15PF(number, "M04", "C1", insYear1_discount, insYear1_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
	                    writeToPT16PF(number, "M04", "C1", insYear1_discount, insYear1_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
	                    
	                    if(check47.equals("Y")){
	                        dbo = getKYCKD("M04", "C", "47", "1", getCarCC(), pjcode , channelCode);
	                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47);
	                        writeToPT17PF(number, "M04", "C1", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔                    	
	                    } else if(check47E.equals("Y")){
	                        dbo = getKYCKD("M04", "C", "47E", "1", getCarCC(), pjcode , channelCode);
	                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47E);
	                        writeToPT17PF(number, "M04", "C1", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔                    	
	                    }
	
	                    dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
	                    String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
	                    writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	
	                    dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
	                    String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
	                    writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
	                    
	                    mform.setKYC_T1503a("C1");
                	} else if(check35.equals("Y")){
                    	dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                        
                        String insYear1_35_discount = "0";
                        if(check47.equals("Y"))
                        	insYear1_35_discount = MotorPrice.getInsType4_Year1_35(getCarCC(), MotorPrice.discount, "47");
                        else
                        	insYear1_35_discount = MotorPrice.getInsType4_Year1_35(getCarCC(), MotorPrice.discount, "47E");
                        
                        writeToPT15PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                        writeToPT16PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                        
	                    if(check47.equals("Y")){
	                        dbo = getKYCKD("M04", "C", "47", "1", getCarCC(), pjcode , channelCode);
	                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47);
	                        writeToPT17PF(number, "M04", "C1", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔                    	
	                    } else if (check47E.equals("Y")){
	                        dbo = getKYCKD("M04", "C", "47E", "1", getCarCC(), pjcode , channelCode);
	                        String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins47E);
	                        writeToPT17PF(number, "M04", "C1", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔                    	
	                    }
                        
	                   	dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                        String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                        writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
                        String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                        writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "35", "1", getCarCC(), pjcode , channelCode);
                        String ins35Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                        writeToPT17PF(number, "M04", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "37", "1", getCarCC(), pjcode , channelCode);
                        String ins37Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                        writeToPT17PF(number, "M04", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                        String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                        writeToPT17PF(number, "M04", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        dbo = getKYCKD("M04", "C", "51", "1", getCarCC(), pjcode , channelCode);
                        String ins51Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                        writeToPT17PF(number, "M04", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                        mform.setKYC_T1503a("C1");
                	}
                }
               
            } else {//二年期                
                //機車強制險-----------------------------------------------------------------------------------------------------------
            	if(check21.equals("Y")){
                	dbo = getKYCKD("M04", "A", "21", "2", getCarCC(), pjcode , channelCode);
                    String ins21Total = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                    String ins21Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins21);
                    
                    writeToPT15PF(number, "M04", "A", ins21Total, ins21Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔                
                    writeToPT16PF(number, "M04", "A", ins21Total, ins21Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    writeToPT17PF(number, "M04", "A", ins21Total, ins21Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

            	}
            	
                //駕駛人傷害險---------------------------------------------------------------------------------------------------------
            	if(check47.equals("Y")){
                    dbo = getKYCKD("M04", "C", "47", "2", getCarCC(), pjcode , channelCode);
                    String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins47);
                    
                    writeToPT15PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M04", "C2", ins47Discount, ins47Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    writeToPT17PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔           
                    
                    mform.setKYC_T1503b("C2");
            	} else if (check47E.equals("Y")){
                    dbo = getKYCKD("M04", "C", "47E", "2", getCarCC(), pjcode , channelCode);
                    String ins47Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins47E);
                    
                    writeToPT15PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M04", "C2", ins47Discount, ins47Discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    writeToPT17PF(number, "M04", "C2", ins47Discount, ins47Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔           
                    
                    mform.setKYC_T1503b("C2");
            	} 

                //其餘險--------------------------------------------------------------------------------------------------------------
            	if(check31.equals("Y")){
                	dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                    
                    String insYear1_31_32_discount = MotorPrice.getInsType4_Year1_31_32(getCarCC(), MotorPrice.discount);
                    
                    writeToPT15PF(number, "M04", "C1", insYear1_31_32_discount, insYear1_31_32_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M04", "C1", insYear1_31_32_discount, insYear1_31_32_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    
                    String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins31);
                    writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
                    String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year2, getCarCC(), MotorPrice.ins32);
                    writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
                    
                    mform.setKYC_T1503a("C1");
            	} else if(check35.equals("Y")){
                	dbo = getKYCKD("M04", "C", "31", "1", getCarCC(), pjcode , channelCode);
                    
                    String insYear1_35_discount = MotorPrice.getInsType4_Year1_35(getCarCC(), MotorPrice.discount);
                    
                    writeToPT15PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                    writeToPT16PF(number, "M04", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                    
                    String ins31Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                    writeToPT17PF(number, "M04", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "32", "1", getCarCC(), pjcode , channelCode);
                    String ins32Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                    writeToPT17PF(number, "M04", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "35", "1", getCarCC(), pjcode , channelCode);
                    String ins35Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                    writeToPT17PF(number, "M04", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "37", "1", getCarCC(), pjcode , channelCode);
                    String ins37Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                    writeToPT17PF(number, "M04", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                    String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                    writeToPT17PF(number, "M04", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    dbo = getKYCKD("M04", "C", "51", "1", getCarCC(), pjcode , channelCode);
                    String ins51Discount = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                    writeToPT17PF(number, "M04", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                    mform.setKYC_T1503a("C1");
            	}
            }
        }else if(mform.getType().equals("M05")){
        	DBO dbo = null;
        	
        	if(check31.equals("Y")){
            	dbo = getKYCKD("M05", "C", "31", "1", getCarCC(), pjcode , channelCode);
                
                String insYear1_31_32_discount = MotorPrice.getInsType5_Year1_31_32(getCarCC(), MotorPrice.discount);
                
                writeToPT15PF(number, "M05", "C1", insYear1_31_32_discount, insYear1_31_32_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                writeToPT16PF(number, "M05", "C1", insYear1_31_32_discount, insYear1_31_32_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                
                String ins31Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                writeToPT17PF(number, "M05", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "32", "1", getCarCC(), pjcode , channelCode);
                String ins32Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                writeToPT17PF(number, "M05", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔
                
                mform.setKYC_T1503a("C1");
        		
        	} else if(check35.equals("Y")){
            	dbo = getKYCKD("M05", "C", "31", "1", getCarCC(), pjcode , channelCode);
                
                String insYear1_35_discount = MotorPrice.getInsType5_Year1_35(getCarCC(), MotorPrice.discount);
                
                writeToPT15PF(number, "M05", "C1", insYear1_35_discount, insYear1_35_discount, dbo, "2" , otp);//網路出單交易主檔,類別傳入2-表寫入交易LOG檔
                writeToPT16PF(number, "M05", "C1", insYear1_35_discount, insYear1_35_discount, "2");//網路出單標的明細,類別傳入2-表寫入交易LOG檔
                
                String ins31Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins31);
                writeToPT17PF(number, "M05", "C1", ins31Discount, ins31Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "32", "1", getCarCC(), pjcode , channelCode);
                String ins32Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins32);
                writeToPT17PF(number, "M05", "C1", ins32Discount, ins32Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "35", "1", getCarCC(), pjcode , channelCode);
                String ins35Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins35);
                writeToPT17PF(number, "M05", "C1", ins35Discount, ins35Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "37", "1", getCarCC(), pjcode , channelCode);
                String ins37Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins37);
                writeToPT17PF(number, "M05", "C1", ins37Discount, ins37Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "3G", "1", getCarCC(), pjcode , channelCode);
                String ins3GDiscount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins3G);
                writeToPT17PF(number, "M05", "C1", ins3GDiscount, ins3GDiscount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                dbo = getKYCKD("M05", "C", "51", "1", getCarCC(), pjcode , channelCode);
                String ins51Discount = MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, MotorPrice.year1, getCarCC(), MotorPrice.ins51);
                writeToPT17PF(number, "M05", "C1", ins51Discount, ins51Discount, dbo, "2");//網路出單交易明細,類別傳入2-表寫入交易LOG檔

                mform.setKYC_T1503a("C1");
        	}
      	
        }

    }

    /**
     * 處理授權後的寫檔動作
     * 
     * @throws AsiException
     *  
     */
    public void processP6() throws AsiException {
    	
    	//重新由Session取由WB1M010f
        mform = (WB1M010f) getRequest().getSession().getAttribute("WB1M010f");
        setMainForm(mform);
        System.out.println("取得號碼" + mform.getNumber() + " " + mform.getInstypename());
        
        mform.setRetcode(((WB1M010f) getForm()).getRetcode());//將傳入的回應碼放入mform
        mform.setAuthCode(((WB1M010f) getForm()).getAuthCode());//將傳入的授權碼放入mform
        System.out.println("取得號碼" + mform.getRetcode() + " " + mform.getAuthCode());
        
        String number = ((WB1M010f) getForm()).getOrdernumber();
        String no1 =  ((WB1M010f) getForm()).getAuthCode();
        mform.setNumber(number);
        
        try {
        	getRequest().setAttribute("decodedata", Codec.decode(mform.getInstypename()));
        } catch (IOException e) {
      	  e.printStackTrace();
        }        
        
        System.out.println("交易序號" + number + " 授權碼" + no1);
        if ("00".equals(((WB1M010f) getForm()).getRetcode())) {
            //更新金流狀態
        	System.out.println("開始更新");
            UpdateState.updateKL80_State(getTransaction(), number, "3");
            System.out.println("更新完成");

        }
        else
        {
        	UpdateState.updateKL80_State(getTransaction(), number, "2");
        }
        System.out.println("完成更新動作");
    }

    public void setExtraValue() throws AsiException {
        mform.setPWD(getPassword());
    }


	/**
	 * 取得報表路徑
	 * 
	 * @param url
	 * @return
	 * @throws JspException
	 */
	public String getPath(String url) throws JspException
	{
		String host = System.getProperty("jasper.report-url");
		if (host == null)
		{
			host = ConfigUtil.getConfig(getServlet(), "jasper.report-intra");
		}
		StringBuffer action = new StringBuffer();
		action.append(host).append(url).append(".do");
		logger.info("report action path : " + action.toString());
		return action.toString();
	}

	/**
	 * 機車確認投保通知
	 * @param number
	 * @param request
	 */
	public void sendMail(String number , HttpServletRequest request) {

        WB1M010f mform = (WB1M010f) request.getSession().getAttribute("WB1M010f");
		
        KycMailUtil sender = new KycMailUtil();
        sender.setSubject(MessageUtil.getMessage(getServlet() , request , "WB1M010.remark114"));
        String entry = mform.getEntry();
        
        BufferedReader fr;
        String path = "";
        if(entry.equals("2"))
        	if (!mform.getType().equals("M01")){
        		path = getServlet().getServletContext().getRealPath("/mail/motorInsurances_2_OrderOK.html");
        	} else {
        		path = getServlet().getServletContext().getRealPath("/mail/motorInsurances_2_40_OrderOK.html");
            }
        else
        	path = getServlet().getServletContext().getRealPath("/mail/motorInsurancesOrderOK.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        //投保內容
        String decodedata = "";
        try {
        	decodedata = Codec.decode(mform.getInstypename()).toString();
        } catch (IOException e) {
        	e.printStackTrace();
        }
        	    
        //組下載要保書連結
        StringBuffer url = new StringBuffer();
        if(mform.getType().equals("M01"))
        	url.append("") ;
        else{        	
    		try {
    			url.append("<a href=\"");
    			url.append(getPath("/AD2R0101") + "?select=1&sourcepg=B2C");
    			url.append("&KYC_T1501a=" + number);
    			url.append("\" target=\"_blank\" > 【下載要保書】</a>");
    		} catch (JspException e) {
    			e.printStackTrace();
    		}       	        	
        }
                      
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", mform.getKyc_T1506());
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{total\\}", FormatUtil.getDecimalFormat(Double.parseDouble(mform.getTotal()), 0));
        msg = msg.replaceAll("\\{discount\\}", FormatUtil.getDecimalFormat(Double.parseDouble(mform.getDiscount()), 0));
        if (mform.getTotal().equals(mform.getDiscount())) {
            msg = msg.replaceAll("\\{showdiscount\\}", "none");
        }
        msg = msg.replaceAll("\\{type\\}", mform.getType());
        msg = msg.replaceAll("\\{carKind\\}", mform.getCARKIND());
        msg = msg.replaceAll("\\{insurancecontent\\}", decodedata);
        msg = msg.replaceAll("\\{printdoc\\}", url.toString());

        msg = msg.replaceAll("\\{stry\\}", mform.getYear());
        msg = msg.replaceAll("\\{strm\\}", mform.getMonth());
        msg = msg.replaceAll("\\{strd\\}", mform.getDate());
        msg = msg.replaceAll("\\{endy\\}", mform.getYear2());
        msg = msg.replaceAll("\\{endm\\}", mform.getMonth2());
        msg = msg.replaceAll("\\{endd\\}", mform.getDate2());
        
        msg = msg.replaceAll("\\{time\\}", "十二");
        
        sender.setMessage(msg);
        sender.addTo(mform.getKyc_T1516());
        sender.sendMail();

	}

    /**
     * @return 商品代碼
     */
    public String getKG01() {
        if (mform.getType().equals("1"))
            return "M01";
        else if (mform.getType().equals("2"))
            return "M02";
        else
            return "M03";
    }

    /**
     * @return
     * @throws AsiException
     */
    private String getPassword() throws AsiException {
        DBO dbo = getTransaction().getDBO("sec.SECAJt", 0);
        dbo.addParameter("USERID", mform.getKyc_T1507());
        dbo.executeSelect();
        mform.setPWD(dbo.getRecordData("PASSWORD"));
        return mform.getPWD();
    }

    //強制、駕傷起保日
    private String getInsureStart() {
        return mform.getYear() + StringUtils.leftPad(mform.getMonth(), 2, "0") + StringUtils.leftPad(mform.getDate(), 2, "0");
    }
    //強制、駕傷到期日
    private String getInsureEnd() {
        return mform.getYear2() + StringUtils.leftPad(mform.getMonth2(), 2, "0") + StringUtils.leftPad(mform.getDate2(), 2, "0");
    }
    //任意起保日
    private String get_vol_InsureStart() {
        return mform.getVolyear() + StringUtils.leftPad(mform.getVolmonth(), 2, "0") + StringUtils.leftPad(mform.getVoldate(), 2, "0");
    }
    //任意到期日
    private String get_vol_InsureEnd() {
        return mform.getVolyear2() + StringUtils.leftPad(mform.getVolmonth2(), 2, "0") + StringUtils.leftPad(mform.getVoldate(), 2, "0");
    }

    private String getBirthDay() {
        if (mform.getByear() != null)
            return StringUtils.leftPad(mform.getByear(), 2, "0") + StringUtils.leftPad(mform.getBmonth(), 2, "0") + StringUtils.leftPad(mform.getBdate(), 2, "0");
        else
            return "0";
    }
    
	//要保人生日
	private String getqmanBirthDay() {
	    if (mform.getByear() != null)
	        return StringUtils.leftPad(mform.getKyc_T15A7_year(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_month(), 2, "0") + StringUtils.leftPad(mform.getKyc_T15A7_date(), 2, "0");
	    else
	        return "0";
	}
  
    /**
     * 網路出單交易明細
     * 
     * @param number 交易單號
     * @param T1702 商品代碼
     * @param dbo kyckd
     * @throws AsiException
     */
    private void writeToPT17PF(String number, String T1702, String T703, String T1720, String T1723, DBO kyckd, String type) throws AsiException {
    	DBO dbo = null;
    	dbo = getTransaction().getDBO("kyc.KYCKLCt", 0);//type=2 表寫入交易LOG檔 
				
        //任意險總保額判斷********************************************************
        String t1705 = kyckd.getRecordData("KD03");
		String t1708 = "0";		//每一人體傷死亡保額
        String t1709 = "0";		//每一人體傷死亡保額
		String t1719 = "0";		//總保額
        String t1724 = null;    //kyckd.getRecordData("KD09"); //限額代號；倍數
        // 網路要投保汽機車３１險２倍型時，限額代號欄寫入空白，其他倍數型則依其倍數寫入。其他險種初值為null(轉入400則空白)(參考KYC報價的設定)  VI71001-K
        if(t1705.equals("31")){
        	t1708 = mform.getInsamout_31() != null ?  mform.getInsamout_31() : kyckd.getRecordData("KD07");
        	t1709 = mform.getInsamout_31() != null ?  mform.getInsamout_31() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_31total() != null ?  mform.getInsamout_31total() : kyckd.getRecordData("KD06");
        	t1724 = mform.getTimes_31() != null && "2".equals(mform.getTimes_31()) ? " " : mform.getTimes_31() != null && !"2".equals(mform.getTimes_31()) ? mform.getTimes_31() : kyckd.getRecordData("KD09");
        }
        else if (t1705.equals("32")){
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_32() != null ?  mform.getInsamout_32() : kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("51")) {
        	t1708 = "0";
        	t1709 = mform.getInsamout_51() != null ?  mform.getInsamout_51() : kyckd.getRecordData("KD08");
        	t1719 = mform.getInsamout_51() != null ?  mform.getInsamout_51() : kyckd.getRecordData("KD06");
        	t1724 = "1";	//人數減一
        }
        else if (t1705.equals("35")) {
        	t1719 = mform.getInsamout_35() != null ?  mform.getInsamout_35() : kyckd.getRecordData("KD06");
        }
        else if (t1705.equals("37")) {
        	t1708 = mform.getInsamout_37();//每一人住院保額
        	t1709 = mform.getInsamout_37D();//每一人身故保額
        	t1719 = mform.getInsamout_37() != null ?  mform.getInsamout_37() : kyckd.getRecordData("KD06");
        	t1724 = mform.getTimes_31() != null && "2".equals(mform.getTimes_31()) ? " " : mform.getTimes_31() != null && !"2".equals(mform.getTimes_31()) ? mform.getTimes_31() : kyckd.getRecordData("KD09");	
        }
        else if (t1705.equals("3G")) {
         	t1719 = mform.getInsamout_3G() != null ?  mform.getInsamout_3G() : kyckd.getRecordData("KD06");
        } else {
        	t1708 = kyckd.getRecordData("KD07");
        	t1709 = kyckd.getRecordData("KD08");
        	t1719 = kyckd.getRecordData("KD06");
        }
        //*********************************************************************
        
        dbo.addParameter("T1701", number);
        dbo.addParameter("T1702", T1702);
        dbo.addParameter("T1703", T703);
        dbo.addParameter("T1704", "1");
        dbo.addParameter("T1705", t1705);
        dbo.addParameter("T1706", "");
        dbo.addParameter("T1707", "");      
        dbo.addParameter("T1708", t1708);
        dbo.addParameter("T1709", t1709);
        dbo.addParameter("T1710", "");
        dbo.addParameter("T1711", "");
        dbo.addParameter("T1712", "");
        dbo.addParameter("T1713", "");
        dbo.addParameter("T1714", "");
        dbo.addParameter("T1715", "");
        dbo.addParameter("T1716", "");
        dbo.addParameter("T1717", "");
        dbo.addParameter("T1718", "");
        dbo.addParameter("T1719", t1719);       
        dbo.addParameter("T1720", T1720);
        dbo.addParameter("T1721", NumberUtil.sub(T1720, T1723));//20-23
        dbo.addParameter("T1722", "");
        dbo.addParameter("T1723", T1723);
        dbo.addParameter("T1724", t1724);       
        dbo.addParameter("T1725", "");
        if (kyckd.getRecordData("KD03").equals("21") || kyckd.getRecordData("KD03").equals("47") || kyckd.getRecordData("KD03").equals("47E")) {//機車賠點除了乘客險外都存4
            dbo.addParameter("T1726", "4");
        } else {
            dbo.addParameter("T1726", String.valueOf(Integer.parseInt(mform.getGrade_31()) + 4));
        }
        dbo.addParameter("T1727", "");
        dbo.addParameter("T1728", "");
        dbo.addParameter("T1729", "");
        dbo.addParameter("T1730", "");
        dbo.addParameter("T1731", "");
        dbo.addParameter("T1732", "");
        dbo.addParameter("T1733", "");
        dbo.addParameter("T1734", "");
        dbo.addParameter("T1735", "");
        dbo.addParameter("T1736", "");
        dbo.addParameter("T1737", "");
        dbo.addParameter("T1738", "");
        dbo.addParameter("T1739", "");
        dbo.addParameter("T1740", "");
        dbo.addParameter("T1741", "");
        dbo.addParameter("T1742", "");
        dbo.addParameter("T1755", "0");
        dbo.addParameter("T1756", "0");

        dbo.addParameter("T1794", DateUtil.getSysTime());
        dbo.addParameter("T1795", DateUtil.getSysTime());
        dbo.addParameter("T1796", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1797", mform.getKyc_T1507());
        dbo.addParameter("T1798", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1799", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    /**
     * 網路出單標的明細
     * 
     * @param T1601 保單/交易序號
     * @param T1602 商品代碼
     * @param T1603 險別
     * @param T1632 依商品檔內設定相關險種保費
     * @param T1635 實收保費
     * @throws AsiException
     */
    private void writeToPT16PF(String T1601, String T1602, String T1603, String T1632, String T1635, String type) throws AsiException {
    	DBO dbo = null;
    	dbo = getTransaction().getDBO("kyc.KYCKLBt", 0);//type=2 表寫入交易LOG檔

        dbo.addParameter("T1601", T1601);
        dbo.addParameter("T1602", T1602);
        dbo.addParameter("T1603", T1603);
        dbo.addParameter("T1604", "1");
        if(mform.getCkb() != null && mform.getCkb().length() != 0 && mform.getCkb().equals("MH")){//電動機車判斷，廠牌代碼補到8位，最後一位為1
      	  dbo.addParameter("T1605", StringUtils.rightPad(mform.getBN00(), 7, "0") + "1");
        }
        else{
      	  dbo.addParameter("T1605", StringUtils.rightPad(mform.getBN00(), 8, "0")); 
        }        
        dbo.addParameter("T1606", mform.getLicencey() + StringUtils.leftPad(mform.getLicencem(), 2, "0"));
        dbo.addParameter("T1607", mform.getKyc_T1607() + mform.getKyc_T1607_MM()); 
        dbo.addParameter("T1608", mform.getCartype());
        dbo.addParameter("T1609", mform.getKyc_T1609());
        dbo.addParameter("T1610", (mform.getCarnumbertype()!=null && mform.getCarnumbertype().equals("1")) ? mform.getKyc_T1610_old() : mform.getKyc_T1610());
        dbo.addParameter("T1611", mform.getKyc_T1611());
        dbo.addParameter("T1612", "2");
        dbo.addParameter("T1613", "P");
        dbo.addParameter("T1614", "");
        dbo.addParameter("T1615", "");
        dbo.addParameter("T1616", "");
        dbo.addParameter("T1617", "");
        dbo.addParameter("T1618", "");
        dbo.addParameter("T1619", "");
        dbo.addParameter("T1620", "");
        dbo.addParameter("T1621", "");
        dbo.addParameter("T1622", "0");
        dbo.addParameter("T1623", "0");
        dbo.addParameter("T1624", "0");
        dbo.addParameter("T1625", "0");
        dbo.addParameter("T1626", "");
        dbo.addParameter("T1627", "");
        dbo.addParameter("T1628", "");
        dbo.addParameter("T1629", "");
        dbo.addParameter("T1630", "");
        dbo.addParameter("T1631", "");
        dbo.addParameter("T1632", T1632);
        dbo.addParameter("T1633", NumberUtil.sub(T1632, T1635));
        dbo.addParameter("T1634", "0");
        dbo.addParameter("T1635", T1635);
        dbo.addParameter("T1636", "");
        dbo.addParameter("T1637", "");
        dbo.addParameter("T1638", "");
        dbo.addParameter("T1642", "");
        dbo.addParameter("T1643", mform.getKYC_T1643());
        dbo.addParameter("T1644", "");
        dbo.addParameter("T1645", "0");
        dbo.addParameter("T1646", "0");
        dbo.addParameter("T1694", DateUtil.getSysTime());
        dbo.addParameter("T1695", DateUtil.getSysTime());
        dbo.addParameter("T1696", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1697", mform.getKyc_T1507());
        dbo.addParameter("T1698", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1699", mform.getKyc_T1507());
        dbo.executeInsert();
    }

    /**
     * @return 車種代號
     */
    private String getCarCC() {
        if (mform.getCartype().equals("02"))
            return MotorPrice.motorLight;
        else if (mform.getCartype().equals("01"))
            return MotorPrice.motorHeavy;
        else
            return MotorPrice.motorSuper;
    }

    /**
     * 網路出單交易主檔
     * 
     * @param T1501
     * @param T1502 商品代碼
     * @param T1503 險別
     * @throws AsiException
     *  
     */
    private void writeToPT15PF(String number, String T1502, String T1503, String T1539, String T1541, DBO kyckd, String type , String otp) throws AsiException {
    	DBO dbo = null;   	
		dbo = getTransaction().getDBO("kyc.KYCKLAt", 0);//type=2 表寫入交易LOG檔
        dbo.addParameter("T1501", number);
        dbo.addParameter("T1502", T1502);
        dbo.addParameter("T1503", T1503);
        dbo.addParameter("T1504", "");
        dbo.addParameter("T1505", Employee.getEmployee(kyckd.getRecordData("KD17")).getCarInsArea());
        dbo.addParameter("T1506", mform.getKyc_T1506());//被保險人
        dbo.addParameter("T1507", mform.getKyc_T1507());
        dbo.addParameter("T1508", getBirthDay());
        dbo.addParameter("T1509", mform.getKyc_T1509());
        dbo.addParameter("T1510", mform.getKyc_T1510());
        dbo.addParameter("T1511", getZip());
        dbo.addParameter("T1512", mform.getKyc_T1512());
        dbo.addParameter("T1513", mform.getKyc_T1513());
        dbo.addParameter("T1514", mform.getKyc_T1514());
        dbo.addParameter("T1515", mform.getKyc_T1515());
        dbo.addParameter("T1516", mform.getKyc_T1516());
        
        //起保日
        String strdate = "0";
        String enddate = "0";
        if(T1503.equals("A") || T1503.equals("C2")){
        	strdate = getInsureStart();
        	enddate = getInsureEnd();
        }
        else if(T1503.equals("C1")){      	
        	if(mform.getCkb_ins_21().equals("Y")){
            	if(!mform.getCkb_ins_31().equals("Y") && !mform.getCkb_ins_35().equals("Y")){
                	strdate = getInsureStart();
                	enddate = getInsureEnd();      		
            	}else{    		
                	strdate = get_vol_InsureStart();
                	enddate = get_vol_InsureEnd();
            	}
        	}else{
            	strdate = get_vol_InsureStart();
            	enddate = get_vol_InsureEnd();
        	}
        }      		
        
        dbo.addParameter("T1517", strdate);
        dbo.addParameter("T1518", enddate);
        dbo.addParameter("T1519", kyckd.getRecordData("KD16"));
        dbo.addParameter("T1520", kyckd.getRecordData("KD17"));
        dbo.addParameter("T1521", "");
        dbo.addParameter("T1522", "0");
        dbo.addParameter("T1523", DateUtil.getSysDate(getUsrInfo(), false));
        dbo.addParameter("T1524", "0");
        dbo.addParameter("T1525", "");
        dbo.addParameter("T1526", "");
        dbo.addParameter("T1527", "");
        dbo.addParameter("T1528", "");
        dbo.addParameter("T1529", "");
        dbo.addParameter("T1530", "9");
        dbo.addParameter("T1534", "");
        dbo.addParameter("T1535", "");
        dbo.addParameter("T1536", "");
        dbo.addParameter("T1537", "");
        dbo.addParameter("T1538", "B2C");
        dbo.addParameter("T1539", T1539);
        dbo.addParameter("T1540", NumberUtil.sub(T1539, T1541));
        dbo.addParameter("T1541", T1541);
        dbo.addParameter("T1542", "");
        dbo.addParameter("T1543", "");
        dbo.addParameter("T1544", mform.getKyc_T1544());
        
        dbo.addParameter("T1546", mform.getKyc_T1546());
        dbo.addParameter("T1547", mform.getKyc_T1547());
        dbo.addParameter("T1548", mform.getKyc_T1548());
        dbo.addParameter("T1549", "0");
        dbo.addParameter("T1550", "");
        dbo.addParameter("T1551", mform.getKyc_T1551());
        dbo.addParameter("T1552", "");
        dbo.addParameter("T1553", "");
        dbo.addParameter("T1554", "0");
        dbo.addParameter("T1555", "");
        
        //寫入t1556車體無賠款年度 , t1557賠款次數
        if(!T1503.equals("A")){
            dbo.addParameter("T1556", mform.getNonclaimYear());
            dbo.addParameter("T1557", mform.getClaimTimes());
        }else{
            dbo.addParameter("T1556", "0");
            dbo.addParameter("T1557", "0");
        }

        dbo.addParameter("T1558", "0");
        dbo.addParameter("T1559", "0");
        dbo.addParameter("T1560", "0");
        dbo.addParameter("T1561", "0");
        dbo.addParameter("T1562", "");
        dbo.addParameter("T1563", "");
        dbo.addParameter("T1564", "");
        dbo.addParameter("T1565", "");
        dbo.addParameter("T1566", "");
        dbo.addParameter("T1567", "");
        dbo.addParameter("T1568", "");       
        //任意險且為網投
        if(!mform.getType().equals("M01") && mform.getEntry().equals("1")){
        	dbo.addParameter("T1569", mform.getKyc_T1569());	//電訪註記
        }
        else{
        	dbo.addParameter("T1569", "");	//電訪註記
        }       
        dbo.addParameter("T1570", "");
        dbo.addParameter("T1571", getT1571(kyckd));
        dbo.addParameter("T1572", DateUtil.getSysTime(false));
        dbo.addParameter("T1573", mform.getKyc_T1573());
        dbo.addParameter("T1574", "N");
        
        String t1575 = mform.getKyc_T1575();//用以註記電子式保單
        if(T1503.equals("A"))//強制險一律為電子式
        	t1575 = "Y";
        
        dbo.addParameter("T1575", t1575);
        dbo.addParameter("T1576", mform.getKyc_T1576());
        dbo.addParameter("T1577", "N");
        dbo.addParameter("TA1501", "");
        dbo.addParameter("TA1502", "");
        dbo.addParameter("TA1503", "");
        dbo.addParameter("TA1504", "");
        dbo.addParameter("TA1505", "");
        dbo.addParameter("TA1506", "");
        dbo.addParameter("TA1507", mform.getKyc_TA1507());
        dbo.addParameter("T1594", DateUtil.getSysTime());
        dbo.addParameter("T1595", DateUtil.getSysTime());
        dbo.addParameter("T1596", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1597", mform.getKyc_T1507());
        dbo.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T1599", mform.getKyc_T1507());
        dbo.addParameter("T1580", "1");	//交易狀態碼，初次寫入為1：表確認投保，待刷卡完成才會更新會已取得授權
        dbo.addParameter("T15A7", getqmanBirthDay());//要保人生日
        
        mform.setData_otp(otp);
        
        //OTP
        String expireTime = SystemParam.getParam("OTPEXTIME");
        String otpexpireday = getExpireDate();
        String INSARGNO = SystemParam.getParam("ARGDOC_INS_NO"); // 聲明事項文件編號

        mform.setExpireTime(expireTime); 
        mform.setExpireDate(otpexpireday);

        dbo.addParameter("T15B0", mform.isNewClient() ? "1" : "2");
        dbo.addParameter("T15B1", otp);
        dbo.addParameter("T15B2", DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        dbo.addParameter("T15B3", DateUtil.getSysTime(false));
        dbo.addParameter("T15B4", otpexpireday);
        dbo.addParameter("T15B5", expireTime);
        dbo.addParameter("T15B6", "0");
        dbo.addParameter("T15B7", "0");
        dbo.addParameter("T15B8", "0");
        dbo.addParameter("T15B9", mform.getEntry().equals("1") ? "NCCC" : "Hitrust");
        
        dbo.addParameter("T15C0", mform.getIsmobile());
        dbo.addParameter("T15C1", mform.getOs());
        dbo.addParameter("T15C2", mform.getBrowser());
        dbo.addParameter("T15C3", mform.getBro_version());
        dbo.addParameter("T15C9", INSARGNO);
        //在HEADER的X-FORWARDED-FOR的標籤中找到真實的IP
        String remoteAddr = getRequest().getHeader("X-FORWARDED-FOR");
        if (remoteAddr == null || "".equals(remoteAddr)) {
            remoteAddr = getRequest().getRemoteAddr();
        }        
        dbo.addParameter("T15C10", remoteAddr);

        dbo.addParameter("T15E0", remoteAddr);

        if(!T1503.equals("A")){       	
        	if(mform.getCkb_ins_21() != null && !mform.getCkb_ins_21().equals("Y")){
        		dbo.addParameter("T1545", mform.getKyc_T1545());//強制證號碼
        		dbo.addParameter("T1545A", mform.getKyc_T1545A());	//有效強制證保期起日
	            dbo.addParameter("T1545B", mform.getKyc_T1545B());	//有效強制證保期迄日
        	}
        	dbo.addParameter("T15A1", mform.getQueryno_31());	//任意關貿查詢序號
        }else{
        	dbo.addParameter("T1545", "");
        	dbo.addParameter("T1545A", "");	//有效強制證保期起日
            dbo.addParameter("T1545B", "");	//有效強制證保期迄日
            dbo.addParameter("T15A1", "");	//強制關貿查詢序號：目前機車沒有使用CIIPRICE先查詢等級及序號，故先放空白
        }
        
        dbo.addParameter("T1544A", mform.getKyc_T1544A());	//被保險人國籍
        dbo.addParameter("TA1512", mform.getKyc_TA1512());	//被保險人評估職業
        dbo.addParameter("T15D0", mform.getKyc_T15D0());	//要保人國籍
        dbo.addParameter("TA1511", mform.getKyc_TA1511());	//要保人評估職業

        dbo.addParameter("TA1505", mform.getKyc_TA1505());	//車險客戶屬性
        dbo.addParameter("TA1506", mform.getKyc_TA1506());	//車險客戶繳交保費來源
        dbo.addParameter("TA1506O", mform.getKyc_TA1506o());	//車險客戶繳交保費來源-其他

        dbo.addParameter("T1584", mform.getKyc_T1584());	//促銷代碼
        
        dbo.addParameter("T1582", mform.getPjcode() == null ? "" : mform.getPjcode());	//促銷代碼
              
        dbo.executeInsert();

    }

  	/**
  	 * 取得OTP過期日期
  	 * @return
  	 */
  	public String getExpireDate() {
		String expireday ="";
		KycDateUtil kycdate = new KycDateUtil();
		String sysdate = kycdate.getKycDate();
  	 
      try {
          
         kycdate.setKycDate(sysdate);
         kycdate.add(KycDateUtil.DATE, NumberUtils.toInt(SystemParam.getParam("OTPEXDAY")));//系統參數，系統日加天數
         expireday = kycdate.getKycDate();

      } 
      catch (ParseException e) {
         e.printStackTrace();
      }
      return expireday;
	}

    /**
     * 寄送OTP EMAIL
     * @param request
     */
    public void sendOTPMail(HttpServletRequest request)
    {
    	int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
    	
    	String email = mform.getKyc_T1516();
    	String name = mform.getKyc_T1506();
    	String otp = mform.getData_otp();
    	
 		//寄Email
 		KycMailUtil sender = new KycMailUtil();

 		//取範本
 		BufferedReader fr;
 		String path = getServlet().getServletContext().getRealPath("/mail/TransactionOTP_" + getLocale() + ".html");

 		StringBuffer linebf = new StringBuffer();
 		try {
 			fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
 			String line;
 			linebf = new StringBuffer();
 			line = fr.readLine();
 			while (line != null) {
 				linebf.append(line);
 				line = fr.readLine();
 			}

 		}
 		catch (FileNotFoundException e) {
 			e.printStackTrace();
 		}
 		catch (IOException e) {
 			e.printStackTrace();
 		}

	   	String msg = linebf.toString();
	   	msg = msg.replaceAll("\\{username\\}", name);
	   	msg = msg.replaceAll("\\{otp\\}", otp);
	   	msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));
	
	   	sender.setSubject("第一保 電子商務網 網路投保交易OTP");
	   	sender.setMessage(msg);
	   	sender.addTo(email);
	   	sender.sendMail();

   }
   
 	/**
 	 * 寄發簡訊
 	 * 
 	 * @param data
 	 */
 	public void sendMobileMsg()
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		sb.append("第一產物交易OTP碼：").append(mform.getData_otp()).append("\n");
 		sb.append(" 您正於第一產物進行網路投保作業\n");
 		sb.append("請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！若無線上作業請忽略此封簡訊，謝謝。");

 		String sendTel = mform.getKyc_T1515();
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

 	/**
 	 * 確認otp是否正確
 	 * @return
 	 * @throws AsiException
 	 */
 	public boolean isRightOTP()throws AsiException
 	{
 		boolean isRight = false;
 		
 		String t1501=mform.getNumber();
 		
 		DBO dbo = getTransaction().getDBO("kyc.KYCKLAs03", 0);
 		dbo.addParameter("T1501", t1501);
 		dbo.executeSelect();

 		QueryRunner run = new QueryRunner();
		String sql;
		sql = "SELECT * FROM KYCKLA ";
		sql += "WHERE T1501 = ? AND ROWNUM = 1";		

		Map ret = new HashMap();
		try
		{
			getTransaction().begin(0);
			
			ret = (Map) run.query(getTransaction().getConnection(0), sql, t1501, new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			System.out.print("bb:" + e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("IOException with JsonAction");
		}

 		String inputotp = mform.getInput_otp();
 		String orgotp = ret.get("T15B1").toString();
 		String expired = ret.get("T15B4").toString();
 		
 		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
 		
 		if(Integer.parseInt(sysdate) <= Integer.parseInt(expired))
 				if(inputotp.equals(orgotp))
 					isRight = true;
 		
 		return isRight;
 	}

	/**
    * 查客戶id是否為排除傷害險有效保單客戶
	* @param id
	* @return
	*/
	private boolean isClient_P(String id)
	{
		boolean isNewclient = true;
  	
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sql = "SELECT * FROM IC02PF WHERE C201=? AND C206 >= ? " +
		" AND C204 NOT IN ('OIP','OFP','OWP','OTP','OFR','OTA','OPH','ODI','ODH','OGP','OGR','OGH','OGN','OGS','OGM','OCG','OCT')";

		Connection con = AS400Connection.getConnection();
		List<?> ret = null;
		
		String[] args = new String[2];
		args[0] = id;
		args[1] = sysdate;
		
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = (List<?>) runner.query(con, sql.toString(),args, new TrimedMapListHandler());
			
			if(!ret.isEmpty() && ret.size()>0)
				isNewclient = false;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally{
			AS400Connection.closeConnection(con);
		}
		
		return isNewclient;
   }
  
   /**
    * 重新產生OTP,更新交易檔
    * @return
    * @throws AsiException
    */
   public boolean isUpdateOTP() throws AsiException 
   {
	  boolean isok = false;
  	 
	  String getotp = KYCEncryptor.genOTP();
	  mform.setData_otp(getotp);
  	 
	  String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
	  String systime = DateUtil.getSysTime();
	  String otpexpireday = getExpireDate();
  	 
	  String sql = "UPDATE KYCKLA SET T15B1=?,T15B2=?,T15B3=?,T15B4=?,T15B5=?,T1598=?,T1599=?,T15B8=0 WHERE T1501=?";
  	 
	  String args[] = new String[8];
	  args[0] = getotp;
	  args[1] = sysdate;
	  args[2] = systime;
	  args[3] = otpexpireday;
	  args[4] = SystemParam.getParam("OTPEXTIME");
	  args[5] = sysdate;
	  args[6] = mform.getUID();
	  args[7] = mform.getNumber();

	  QueryRunner runner = new QueryRunner();
	  getTransaction().begin(0);

	  int ret = 0;
  	 
	  try 
	  {
		  Connection con = getTransaction().getConnection(0);
		  ret = runner.update(con, sql ,args);
		  if(ret > 0)
			  isok = true;
  		 
	  } catch (SQLException e) {
		  e.printStackTrace();
		  throw new AsiException(e.getLocalizedMessage());
	  } 

	  return isok;
	}

   
    /**
     * @param kyckd
     * @return
     */
    private String getT1571(DBO kyckd) {
        String discount = kyckd.getRecordData("KD11");
        if(discount.equals("0"))
            discount = kyckd.getRecordData("KD12");
        return discount;
    }

    /**
     * @param KD01 商品代碼
     * @param KD02 險別
     * @param KD03 險種
     * @param KD04 年期
     * @param KD05 車種
     * @param KD06 保額
     * @return dbo
     * @throws AsiException
     */
    private DBO getKYCKD(String KD01, String KD02, String KD03, String KD04, String KD05, String KD19, String KD20) throws AsiException {
        //增加來源網站欄位的判斷
        if (KD19 == null) {
            KD19 = "KYC";
        }
        
        String key = KD01 + KD02 + KD03 + KD04 + KD05 + KD19;
        DBO dbo;
        if (dbocatch.get(key) == null) 
        {
            Kyckd kd = new Kyckd();
            kd.setKD01(KD01);
            kd.setKD02(KD02);
            kd.setKD03(KD03);
            kd.setKD04(KD04);
            kd.setKD19(KD19); //來源網站
            kd.setKD20(KD20); //通路別
            dbo = kd.executeSelect(getTransaction());
        } 
        else
        {
            dbo = (DBO) dbocatch.get(key);
        }

        setDiscount(dbo);
        return dbo;
    }

    /**
     * 計算實收保費
     * 
     * @param dbo1
     * @throws AsiException
     */
    private void setDiscount(DBO dbo1) throws AsiException {
        double kd10 = MathUtil.getDouble(dbo1.getRecordData("KD10"));
        String discount = dbo1.getRecordData("KD11");
        double discount_d;//加上優惠後的保費
        if (discount == null || discount.equals("0")) {
            double t = MathUtil.getDouble(dbo1.getRecordData("KD12"));//優惠比率
            discount_d = kd10 * (1 - t / 100);
        } else {
            discount_d = MathUtil.getDouble(dbo1.getRecordData("KD10")) - MathUtil.getDouble(dbo1.getRecordData("KD11"));
        }
        discount_d = MathUtil.round(discount_d, 0, MathUtil.ROUND);
        dbo1.addRecordData("_discount", String.valueOf(discount_d).replaceAll("\\.0", ""));
    }
 
    /**
     * @return
     */
    private String getZip() {
        if (mform.getZip().equals("")) {
            DBO dbo = (DBO) getSession().getAttribute(KycGlobal.Kyc_UserInfo);
            return dbo.getRecordData("CA106");
        } else
            return mform.getZip();
    }

    //判斷投保起日是否大於上次投保迄日-1個月
    private void validDate(String lastEndDate, String nowBeginDate) throws UserException {
        if(!InsuranceUtil.isStartGreaterThanLastEndDate(nowBeginDate, lastEndDate))
            throw new UserException("WB1.ERROR12");
    }
    
    /**
     * 取得選擇明細價格
     * @param type	方案
     * @param carKind	年期&車種
     * @return [0]:明細原保費1 [1]:明細優惠保費1 [2]:明細原保費2 [3]:明細優惠保費2 [4]:明細原保費3 [5]:明細優惠保費3 [6]:明細原保費4 [7]:明細優惠保費4
     */
    public String[] getDetailPrice(String type , String period , String cartype){
    	String[] arr = new String[16];
    	String year = "";
		String moto = "";
		if(period.equals("1")){
			year = MotorPrice.year1;
		}else year = MotorPrice.year2;
		
		if(cartype.equals("02")){
			moto = MotorPrice.motorLight;
		}else if(cartype.equals("01")){
			moto = MotorPrice.motorHeavy;
		}else moto = MotorPrice.motorSuper;
    	
    	if(type.equals("M01")){//基本型
    		arr[0] = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.total, year, moto, MotorPrice.ins21);
			arr[1] = MotorPrice.getPrice(MotorPrice.type1, MotorPrice.discount, year, moto, MotorPrice.ins21);
    	}else if(type.equals("M02")){//加值型
    		arr[0] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.total, year, moto, MotorPrice.ins21);
			arr[1] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, year, moto, MotorPrice.ins21);
    		if(mform.getCkb_ins_47() != null && mform.getCkb_ins_47().equals("Y")){
    			arr[2] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.total, year, moto, MotorPrice.ins47);
    			arr[3] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, year, moto, MotorPrice.ins47);
    		}else if(mform.getCkb_ins_47E() != null && mform.getCkb_ins_47E().equals("Y")){
    			arr[2] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.total, year, moto, MotorPrice.ins47E);
    			arr[3] = MotorPrice.getPrice(MotorPrice.type2, MotorPrice.discount, year, moto, MotorPrice.ins47E);
    		}else{
    			arr[2] = "0";
    			arr[3] = "0";
    		}
     	}else if(type.equals("M03")){//套餐型
    		arr[0] = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins21);
			arr[1] = MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins21);
			year = MotorPrice.year1;
			double ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins31));
			double ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins32));
			//31-業務員保費 : 直接通路保費
			arr[2] = String.valueOf(ins31);
			ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins31));
			arr[3] = String.valueOf(ins31);
			//31-業務員保費 : 直接通路保費
			arr[4] = String.valueOf(ins32);
			ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins32));
			arr[5] = String.valueOf(ins32);	
			if(mform.getCkb_ins_35() != null && mform.getCkb_ins_35().equals("Y")){
				double ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins35));
				arr[6] = String.valueOf(ins35);
				ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins35));
				arr[7] = String.valueOf(ins35);
	
				double ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins3G));
				arr[8] = String.valueOf(ins3G);
				ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins3G));
				arr[9] = String.valueOf(ins3G);
	
				double ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins37));
				arr[10] = String.valueOf(ins37);
				ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins37));
				arr[11] = String.valueOf(ins37);
	
				double ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.total, year, moto, MotorPrice.ins51));
				arr[12] = String.valueOf(ins51);
				ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type3, MotorPrice.discount, year, moto, MotorPrice.ins51));
				arr[13] = String.valueOf(ins51);
			} else {
				arr[6] = "0";
				arr[7] = "0";
				arr[8] = "0";
				arr[9] = "0";
				arr[10] = "0";
				arr[11] = "0";
				arr[12] = "0";
				arr[13] = "0";
			}
    	}else if(type.equals("M04")){//套餐型
    		if(mform.getCkb_ins_21() != null && mform.getCkb_ins_21().equals("Y")){
        		arr[0] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins21);
    			arr[1] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins21);
    		}else{
        		arr[0] = "0";
    			arr[1] = "0";
    		}
    		if(mform.getCkb_ins_47() != null && mform.getCkb_ins_47().equals("Y")){
    			arr[2] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins47);
    			arr[3] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins47);
    		}else if(mform.getCkb_ins_47E() != null && mform.getCkb_ins_47E().equals("Y")){
    			arr[2] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins47E);
    			arr[3] = MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins47E);
    		}else{
    			arr[2] = "0";
    			arr[3] = "0";
    		}
    		year = MotorPrice.year1;
			double ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins31));
			double ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins32));
			//31-業務員保費 : 直接通路保費
			arr[4] = String.valueOf(ins31);
			ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins31));
			arr[5] = String.valueOf(ins31);
			//31-業務員保費 : 直接通路保費
			arr[6] = String.valueOf(ins32);
			ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins32));
			arr[7] = String.valueOf(ins32);	
			if(mform.getCkb_ins_35() != null && mform.getCkb_ins_35().equals("Y")){
				double ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins35));
				arr[8] = String.valueOf(ins35);
				ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins35));
				arr[9] = String.valueOf(ins35);
	
				double ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins3G));
				arr[10] = String.valueOf(ins3G);
				ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins3G));
				arr[11] = String.valueOf(ins3G);
	
				double ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins37));
				arr[12] = String.valueOf(ins37);
				ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins37));
				arr[13] = String.valueOf(ins37);
	
				double ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.total, year, moto, MotorPrice.ins51));
				arr[14] = String.valueOf(ins51);
				ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type4, MotorPrice.discount, year, moto, MotorPrice.ins51));
				arr[15] = String.valueOf(ins51);
			} else {
				arr[8] = "0";
				arr[9] = "0";
				arr[10] = "0";
				arr[11] = "0";
				arr[12] = "0";
				arr[13] = "0";
				arr[14] = "0";
				arr[15] = "0";
			}

    	}else if(type.equals("M05")){
    		
			double ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins31));
			//31-業務員保費 : 直接通路保費
			arr[0] = String.valueOf(ins31);
			//31-業務員保費 : 直接通路保費
			ins31 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins31));
			arr[1] = String.valueOf(ins31);

			double ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins32));
			arr[2] = String.valueOf(ins32);
			ins32 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins32));
			arr[3] = String.valueOf(ins32);	

			if(mform.getCkb_ins_35() != null && mform.getCkb_ins_35().equals("Y")){
				double ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins35));
				arr[4] = String.valueOf(ins35);
				ins35 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins35));
				arr[5] = String.valueOf(ins35);
	
				double ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins3G));
				arr[6] = String.valueOf(ins3G);
				ins3G = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins3G));
				arr[7] = String.valueOf(ins3G);
	
				double ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins37));
				arr[8] = String.valueOf(ins37);
				ins37 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins37));
				arr[9] = String.valueOf(ins37);
	
				double ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.total, year, moto, MotorPrice.ins51));
				arr[10] = String.valueOf(ins51);
				ins51 = Double.parseDouble(MotorPrice.getPrice(MotorPrice.type5, MotorPrice.discount, year, moto, MotorPrice.ins51));
				arr[11] = String.valueOf(ins51);
			} else {
				arr[4] = "0";
				arr[5] = "0";
				arr[6] = "0";
				arr[7] = "0";
				arr[8] = "0";
				arr[9] = "0";
				arr[10] = "0";
				arr[11] = "0";
			}

    	}
    	return arr;
    }
    
    
    /**
     * 查詢客戶所有的機車牌照號碼及保單狀態
     * @param uid
     * @return
     */
    public List<?> getCustomerCarNos(String uid)
    {
    	//列出所有車牌號碼
    	StringBuffer sql1 = new StringBuffer();
    	sql1.append("SELECT DISTINCT(UC09) CARNO FROM PFUP ");
    	sql1.append("LEFT JOIN PFUC ON UC001=UP001 ");
    	sql1.append("RIGHT JOIN PFBN ON BN00=SUBSTR(UC04,1,2) AND BN03='Y' ");//BN03：空白-汽車 ；Y -機車
    	sql1.append("WHERE UP06=? AND TRIM(UC09)<>'' ");

 		Connection con = AS400Connection.getConnection();
 		List ret = new LinkedList();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List<?>) runner.query(con, sql1.toString(), uid, new TrimedMapListHandler());			 				
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
 		
 		return ret;
    }

    /**
     * 查詢賠點級數
     * @param carno
     * @param id
     * @param cartype
     * @return
     * @throws UserException
     */
    public String[] cIILVLPRC(String carno, String id , String cartype) throws UserException 
    {
		Connection as400Conn = null;
        String[] ciilvlReturn = null;

		try
		{
			as400Conn = AS400Connection.getConnection();
		     
            AS400Procedure prc = new AS400Procedure();
            ciilvlReturn = prc.callCIILVLPRC(as400Conn, carno, id, cartype);

            String carbodypoint = ciilvlReturn[1];
            String level = ciilvlReturn[2];
            String querynolv = ciilvlReturn[3].substring(2, ciilvlReturn[3].length());
            // String point_24 = ciilvlReturn[4];
            // String taxiPoint = ciilvlReturn[5];
            String bodyYear = ciilvlReturn[6];
            String claimCount = ciilvlReturn[7];
			
            mform.setGrade_31(level);
            mform.setQueryno_31(querynolv);
            mform.setNonclaimYear(bodyYear);
            mform.setClaimTimes(claimCount);
            
			//車體賠點過高判斷
			if (Double.parseDouble(carbodypoint) > 4){
				throw new UserException("WB1.ERROR13");
			}
			//責任級數過高判斷
			if (Double.parseDouble(level) > 5){
				throw new UserException("WB1.ERROR13");
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new UserException("CALL CIILVLPRC ERROR.");
		}
		finally
		{

			AS400Connection.closeConnection(as400Conn);
		}
		
		return ciilvlReturn;
	}
    
    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * 
     * @param id 身分證字號
     * @param name 姓名
     * @param birthday 生日
     * @param agentno 招攬人
     * @return
     * @throws AsiException
     */
    public boolean checkFas24prc_new(String id, String name, String birthday ,String agentno) throws AsiException {
        /*
         * S24I0	1	文字	執行BRIDGER(ISID)方式(1/2/3)
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
         * S24I1A	1	文字	傳入小險別（ /V/T/Z）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
		 * S24I9	7	數字	傳入人員生日(民國年)
		 * S24IA	10	文字	傳入打單人員(AS400使用者帳號)
         * */
    	
        FAS24Input in = new FAS24Input();
        in.setS24i0("1");
        in.setS24i1("C");
        in.setS24i1a("");
        in.setS24i2("1");
        in.setS24i3(id);
        in.setS24i4("");
        in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        in.setS24i6(name);
        in.setS24i7("");
        in.setS24i8(id);
        in.setS24i9(birthday);
        in.setS24ia(agentno);
        FAS24PRC prc = new FAS24PRC();
        FAS24Return out = prc.execute(in);
        
       if("E".equals(out.getS24o1().trim()))
           return false;
       else
           return true;
    }
  
    /**
     * 傳入姓名、id 查詢法務管制名單及高風險名單
     * @param id
     * @param name
     * @return
     * @throws AsiException
     */
    public boolean checkFas24prc(String id , String name) throws AsiException {
        /*
         * S24I1	1	文字	傳入大險別（C/F/M/B/H/E/O）
		 * S24I2	1	文字	傳入檢核類別（１保單 /２批單 /３理賠 / ４其他 / 5高風險批單 (包含PEPS) /6高風險理賠(包含PEPS) ）
		 * S24I3	16	文字	傳入單據號碼（保單 / 批單 / 理賠）
		 * S24I4	2	文字	傳入賠付次數
		 * S24I5	7,0	數字	傳入判別基準日
		 * S24I6    120	文字	傳入人員姓名
		 * S24I7	3	文字	傳入國家代碼
		 * S24I8	30	文字	傳入人員ID
         * */
    	
        FAS24Input in = new FAS24Input();
        in.setS24i1("C");
        in.setS24i2("1");
        in.setS24i3(id);
        in.setS24i4("");
        in.setS24i5(DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false));
        in.setS24i6(name);
        in.setS24i7("");
        in.setS24i8(id);
        FAS24PRC prc = new FAS24PRC();
        FAS24Return out = prc.execute(in);
        
       if("E".equals(out.getS24o1().trim()))
           return false;
       else
           return true;
    }
    
    /**
     * 判斷是否為專案代號或推薦人代號(true->專案代號 、false->推薦人代號)
     * @param pjcode
     */
    public boolean isProjectCode(String pjcode){
    	boolean ispjcode=true;
    	
    	String str= pjcode.substring(0,1);
    	String str2= pjcode.substring(1,4);
    	String regex = ".*[a-zA-z].*";
    	boolean isEng=str2.matches(regex);//true：含有英文
    	
    	if((str.equals("1") || str.equals("2")) && isEng){
    		ispjcode=false;
    	}
    	    	    	
    	return ispjcode;
    }

}