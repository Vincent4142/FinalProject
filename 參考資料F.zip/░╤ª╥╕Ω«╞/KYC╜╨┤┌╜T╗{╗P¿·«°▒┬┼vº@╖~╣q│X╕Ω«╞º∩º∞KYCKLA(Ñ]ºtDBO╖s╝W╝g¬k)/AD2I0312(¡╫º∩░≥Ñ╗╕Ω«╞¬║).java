/*
 * Copyright (c) 2000-2004 Asgard System, Inc. Taipei, Taiwan. All rights
 * reserved. This software is the confidential and proprietary information of
 * Asgard System, Inc. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Asgard.
 */
package com.asi.adm.ad2.actions;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.dbo.SelectDBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

public class AD2I0312 extends AsiAction
{
	String t1501;
	String t1502;
	String t1503;
	String t1506;
	String t1507;
	String t1508;
	String t1509;
	String t1510;
	String addr;
	String zip;
	String address;
	String city;
	String town;
	String t1511;
	String t1512;
	String t1515;
	String t1513;
	String t1514;
	String t1516;
	String t1517;
	String t1518;
	String t1519;
	String t1520;
	String t1517c1;
	String t1518c1;
	String t1581;

	String t1608;
	String t1610;
	String t1612;
	String t1613;
	String bn00;// 機車廠牌
	String t1609;
	String t1606;
	String t1611;
	String t1607;// 製造年
	String t1647;// 製造月
	String t1640;// 重置價值
	String t1705;// 車險險種
	String t1709;// 車體保額
	String updatept17pf;
	String t1605;// 廠牌車系車型

	String pfbn;// 汽車廠牌
	String pfbo;
	String ckb;//電動機車選項
	
	String t15c4;
	String t15c5;
	String t15c6;
	String t15c7;
	String t15c8;
	
	String t1539;
	String t1540;
	String t1541;
	String t1542;

	String t1546;
	String t1547;
	String t1548;
	String t1573;
	String ta1507;
	
	String t1545;
	String t1545A;
	String t1545B;
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		t1501 = request.getParameter("KYC_T1501");
		t1502 = request.getParameter("KYC_T1502");
		t1503 = request.getParameter("KYC_T1503");
		t1506 = request.getParameter("T1506");
		t1507 = request.getParameter("T1507");
		t1508 = request.getParameter("T1508");
		t1509 = request.getParameter("T1509");
		t1510 = request.getParameter("T1510");
		addr = request.getParameter("addr");
		zip = request.getParameter("zip");
		address = request.getParameter("address");
		city = request.getParameter("city");
		town = request.getParameter("town");
		t1511 = request.getParameter("T1511");
		t1512 = request.getParameter("T1512");
		t1515 = request.getParameter("T1515");
		t1513 = request.getParameter("T1513");
		t1514 = request.getParameter("T1514");
		t1516 = request.getParameter("T1516");
		t1517 = request.getParameter("T1517");
		t1518 = request.getParameter("T1518");
		t1519 = request.getParameter("T1519");
		t1520 = request.getParameter("T1520");
		t1517c1 = request.getParameter("T1517C1");
		t1518c1 = request.getParameter("T1518C1");
		t1581 = request.getParameter("T1581");

		t1608 = request.getParameter("T1608");
		t1610 = request.getParameter("T1610");
		t1612 = request.getParameter("T1612");
		t1613 = request.getParameter("T1613");
		bn00 = request.getParameter("BN00");// 機車廠牌
		t1609 = request.getParameter("T1609");
		t1606 = request.getParameter("T1606");
		t1611 = request.getParameter("T1611");
		t1607 = request.getParameter("T1607"); // 製造年  
		t1647 = request.getParameter("T1647"); // 製造月 
		t1640 = request.getParameter("T1640"); // 重置價值  
		t1705 = request.getParameter("T1705"); // 車體險種  
		t1709 = request.getParameter("T1709"); // 車體保額  		
		updatept17pf = request.getParameter("flag_udpatePT17PF");//是否更新車體保額
		t1605 = request.getParameter("T1605");

		pfbn = request.getParameter("pfbn");// 汽車廠牌
		pfbo = request.getParameter("pfbo");
		ckb = request.getParameter("ckb");////電動機車選項
		
		t15c4 = request.getParameter("T15C4");
		t15c7 = request.getParameter("T15C7");
		t15c8 = request.getParameter("T15C8");
		
		t1539 = request.getParameter("T1539");
		t1540 = request.getParameter("T1540");
		t1541 = request.getParameter("T1541");
		t1542 = request.getParameter("T1542");
		System.out.println("--- t1542 == ---" + t1542 );


		t1546 = request.getParameter("T1546");
		t1547 = request.getParameter("T1547");
		t1548 = request.getParameter("T1548");
		t1573 = request.getParameter("T1573");
		ta1507 = request.getParameter("TA1507");
		
		t1545 = request.getParameter("T1545");
		t1545A = request.getParameter("T1545A");
		t1545B = request.getParameter("T1545B");

		System.out.println("--- test0 ---" );

		UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
		String urid = ui.getUserId();

		tx_controller.begin(0);

		if (form.getActionCode() == 7)
		{
				if (t1502.substring(0, 1).equals("C"))
				{
					updateCarData(request, form , urid);
				}
				else
				{
					updateMotorData(request, form, urid);
				}
				request.setAttribute("MSG", "資料已更新");
				
				SelectDBO dbo1 = getPt15Data(request);
				request.setAttribute("dbo1", dbo1);
				request.setAttribute("dbo2", getCarData(request, dbo1));
				request.setAttribute("dbo2", getCarData(request, dbo1));
				form.setNextPage(2);
				
				System.out.println("--- 7end ---");
				return;
		}
		else if(form.getActionCode() == 9){
			updateCallout(request, form, urid);
		}
		else if(form.getActionCode() == 11){
			int result = update21Premium();
			if(result == 3 )
				request.setAttribute("MSG", "強制保費修改成功！");
			else
				request.setAttribute("MSG", "強制保費修改失敗！");
		}
		System.out.println("--- test1 ---" );


		SelectDBO dbo1 = getPt15Data(request);
		
		System.out.println("--- dbo1 ---" + dbo1);

		request.setAttribute("dbo1", dbo1);
		request.setAttribute("dbo2", getCarData(request, dbo1));
		System.out.println("--- dbo2 ---" + getCarData(request, dbo1));

		
		form.setNextPage(1);
	}
	
	private int update21Premium() throws UserException
	{
		QueryRunner run = new QueryRunner();
		// 修改kyckla-強制保費
		String updatekyckla = "UPDATE KYCKLA SET T1539=?,T1540=?,T1541=?,T1595=?,T1598=?,T1599=?"
				+ " WHERE T1501=? AND T1502=? AND T1503=?";
		
		String updatekycklb = "UPDATE KYCKLB SET T1632=?,T1633=?,T1635=?,T1695=?,T1698=?,T1699=?"
				+ " WHERE T1601=? AND T1602=? AND T1603=?";

		String updatekycklc = "UPDATE KYCKLC SET T1720=?,T1721=?,T1723=?,T1795=?,T1798=?,T1799=?"
				+ " WHERE T1701=? AND T1702=? AND T1703=? AND T1705='21'";
		
		String args[] = new String[9];
		args[0] = t1539;
		args[1] = t1540;
		args[2] = t1541;
		args[3] = DateUtil.getSysTime(false);
		args[4] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		args[5] = tx_controller.getUserId();
		args[6] = t1501;
		args[7] = t1502;
		args[8] = t1503;
		
		int c1=0 ,c2=0 ,c3=0;
		
		try
		{
			c1 = run.update(tx_controller.getConnection(0), updatekyckla, args);
			c2 = run.update(tx_controller.getConnection(0), updatekycklb, args);
			c3 = run.update(tx_controller.getConnection(0), updatekycklc, args);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new UserException("error");
		}
		
		return c1+c2+c3;
	}
	
	private void updateCallout( HttpServletRequest request, AsiActionForm form1 , String urid) throws UserException
	{
		QueryRunner run = new QueryRunner();
		// 更改資料 機車
		String updatekyckla = "UPDATE KYCKLA SET T15C4=?,T15C5=?,T15C6=?,T15C7=?,T15C8=?"
				+ " WHERE T1501=?";
		String args[] = new String[6];
		args[0] = t15c4!=null?t15c4:"";
		args[1] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		args[2] = DateUtil.getSysTime(false);
		args[3] = t15c7;
		args[4] = t15c8;
		args[5] = t1501;
	
		try
		{
			int c = run.update(tx_controller.getConnection(0), updatekyckla, args);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new UserException("error");
		}

		//寫入KYCLLOG記錄檔處理
		KycLogger klg = new KycLogger();
		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保險明細資料頁", "B", urid, "", "", "", request.getParameter("KYC_T1501"), "", "", "", "", "", "U", "", "電訪記錄修改", updatekyckla, "", "", "", "");

	}
	
	private void updateMotorData( HttpServletRequest request, AsiActionForm form1 , String urid) throws UserException
	{
		QueryRunner run = new QueryRunner();
		// 更改資料 機車
		String updatekyckla = "UPDATE KYCKLA SET T1506=?,T1507=?,T1508=?,T1509=?,T1510=?,T1511=?,T1512=?,T1513=?,T1514=?,T1515=?,"
				+ "T1516=?,T1517=?,T1518=?,T1519=?,T1520=?,T1581=?,T1598=?,T1599=?,T1546=?,T1547=?,T1548=?,T1573=?,TA1507=?,T1545=?,T1545A=?,T1545B=? WHERE T1501=? AND T1502=? AND T1503=? AND T1580<>4";
		String args[] = new String[29];
		args[0] = t1506;
		args[1] = t1507;
		args[2] = t1508;
		args[3] = t1509;
		args[4] = t1510;
		args[5] = addr.equals("new") ? zip : t1511;
		args[6] = addr.equals("new") ? city+town+address : t1512;
		args[7] = t1513;
		args[8] = t1514;
		args[9] = t1515;
		args[10] = t1516;
		args[11] = t1517;
		args[12] = t1518;
		args[13] = t1519;
		args[14] = t1520;
		args[15] = t1581;
		args[16] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		args[17] = tx_controller.getUserId();
		
		args[18] = t1546;
		args[19] = t1547;
		args[20] = t1548;
		args[21] = t1573;
		args[22] = ta1507;
	
		args[23] = t1545;
		args[24] = t1545A;
		args[25] = t1545B;		
	
		args[26] = t1501;
		args[27] = t1502;
		args[28] = t1503;

		String updatekycklb = "UPDATE KYCKLB SET T1605=?,T1606=?,T1608=?,T1609=?,t1610=?,t1611=?,t1612=?,t1613=?,t1698=?,t1699=?,t1607=? where t1601=?";
		String argsklb[] = new String[12];

		if(ckb != null && ckb.length() != 0 && ckb.equals("MH")){//電動機車判斷，廠牌代碼補到8位，最後一位為1
			argsklb[0] = StringUtils.rightPad(bn00, 7, "0") + "1";
		}
		else{
			argsklb[0] = StringUtils.rightPad(bn00, 8, "0");
		}        

		argsklb[1] = t1606;
		argsklb[2] = t1608;
		argsklb[3] = t1609;
		argsklb[4] = t1610;
		argsklb[5] = t1611;
		argsklb[6] = t1612;
		argsklb[7] = t1613;
		argsklb[8] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		argsklb[9] = tx_controller.getUserId();
		argsklb[10] = t1607;
		argsklb[11] = t1501;

		try
		{
			int c = run.update(tx_controller.getConnection(0), updatekyckla, args);
			if (c > 0)
				run.update(tx_controller.getConnection(0), updatekycklb, argsklb);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new UserException("error");
		}
		
		//寫入KYCLLOG記錄檔處理
		KycLogger klg = new KycLogger();
		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保險明細資料頁", "B", urid, "", "", "", request.getParameter("KYC_T1501"), "", "", "", "", "", "U", "", "交易資料修改", "修改交易資料相關檔案(含交易主通檔、明細檔)", "", "", "", "");

	}

	private void updateCarData(HttpServletRequest request , AsiActionForm form1 , String urid) throws UserException
	{
		QueryRunner run = new QueryRunner();
		// 更改資料 汽車
		String updatekyckla = "UPDATE KYCKLA SET T1506=?,T1507=?,T1508=?,T1509=?,T1510=?,T1511=?,T1512=?,T1513=?,T1514=?,T1515=?,"
				+ "T1516=?,T1517=?,T1518=?,T1519=?,T1520=?,T1581=?,T1598=?,T1599=?,T1546=?,T1547=?,T1548=?,T1573=?,TA1507=?,T1545=?,T1545A=?,T1545B=?,T1542=? WHERE T1501=? AND T1502=? AND T1503=? AND T1580<>4";
		String args[] = new String[30];
		args[0] = t1506;
		args[1] = t1507;
		args[2] = t1508;
		args[3] = t1509;
		args[4] = t1510;
		args[5] = addr.equals("new") ? zip : t1511;
		args[6] = addr.equals("new") ? city+town+address : t1512;
		args[7] = t1513;
		args[8] = t1514;
		args[9] = t1515;
		args[10] = t1516;
		args[11] = t1517;
		args[12] = t1518;
		args[13] = t1519;
		args[14] = t1520;
		args[15] = t1581;
		args[16] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		args[17] = tx_controller.getUserId();

		args[18] = t1546;
		args[19] = t1547;
		args[20] = t1548;
		args[21] = t1573;
		args[22] = ta1507;
		
		args[23] = t1545;
		args[24] = t1545A;
		args[25] = t1545B;	
		args[26] = t1542;		

	
		args[27] = t1501;
		args[28] = t1502;
		args[29] = t1503;
		
		String updatekycklb = "UPDATE KYCKLB SET T1605=?,T1606=?,T1608=?,T1609=?,t1610=?,t1611=?,t1612=?,t1613=?,t1698=?,t1699=?,t1607=?,t1647=?,t1640=? where t1601=?";
		String argsklb[] = new String[14];
		argsklb[0] = t1605;
		argsklb[1] = t1606;
		argsklb[2] = t1608;
		argsklb[3] = t1609;
		argsklb[4] = t1610;
		argsklb[5] = t1611;
		argsklb[6] = t1612;
		argsklb[7] = t1613;
		argsklb[8] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		argsklb[9] = tx_controller.getUserId();
		argsklb[10] = t1607;
		argsklb[11] = t1647 != null ? t1647 : "0";
		argsklb[12] = t1640;
		argsklb[13] = t1501;
		
		String updatekycklc = "UPDATE KYCKLC SET T1709=?,T1719=?,T1795=?,T1798=?,T1799=? WHERE T1701=? AND T1705=?";
		String argsklc[] = new String[7];
		argsklc[0] = t1709;
		argsklc[1] = t1709;
		argsklc[2] = DateUtil.getSysTime(false);;
		argsklc[3] = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);;
		argsklc[4] = tx_controller.getUserId();;
		argsklc[5] = t1501;
		argsklc[6] = t1705;

		try
		{
			int c = run.update(tx_controller.getConnection(0), updatekyckla, args);
			if (c > 0)
				run.update(tx_controller.getConnection(0), updatekycklb, argsklb);
			
			if(updatept17pf != null && updatept17pf.equals("Y"))
				run.update(tx_controller.getConnection(0), updatekycklc, argsklc);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new UserException("error");
		}
		
		//寫入KYCLLOG記錄檔處理
		KycLogger klg = new KycLogger();
		klg.LoggerWriter(request, this.getClass().getSimpleName(), form1.getSource(), "保險明細資料頁", "B", urid, "", "", "", request.getParameter("KYC_T1501"), "", "", "", "", "", "U", "", "交易資料修改", "修改交易資料相關檔案(含交易主通檔、明細檔)", "", "", "", "");

	}

	/**
	 * @return
	 * @throws AsiException
	 */
	private SelectDBO getPt15Data(HttpServletRequest request) throws AsiException
	{
		String t1501 = request.getParameter("KYC_T1501");
		String t1502 = request.getParameter("KYC_T1502");
		String t1503 = request.getParameter("KYC_T1503");
		String t1542 = request.getParameter("KYC_T1542a");
		String isOrder = request.getParameter("isOrder");

		System.out.println("--- getPt15Data t1542---" + t1542);

		
		SelectDBO dbo1;
		if (isOrder.equals("0"))
		{
			dbo1 = (SelectDBO) tx_controller.getDBO("kyc.KYCKLAs02", 0);
		}
		else
		{
			dbo1 = (SelectDBO) tx_controller.getDBO("kyc.PT15PFs03", 0);
		}

		StringBuffer buffer = new StringBuffer();
		buffer.append("A.T1501='").append(t1501).append("'");
		buffer.append(" AND A.T1502='").append(t1502).append("'");
		buffer.append(" AND A.T1503='").append(t1503).append("'");
		if (t1542 == null || t1542.equals(""))
		{
			// T1542須加rtrim,因現trigger會updtae此欄位為空白
			//buffer.append(" AND RTRIM(A.T1542) IS NULL");
		}
		else
		{
			buffer.append(" AND A.T1542='").append(t1542).append("'");
		}
		
		System.out.println("getPt15Data SQL = " +buffer.toString());

		dbo1.addParameter("WHERE", buffer.toString());
		System.out.println("WHERE=== "+ dbo1.getAssembledSQL());

		dbo1.execute();
			
		//將電訪顯示的資料改為抓KYCKLA
		String sql="select T1501,T15C4,T15C5,T15C6,T15C7,T15C8 from KYCKLA where T1501=? AND T1502=? AND T1503=?";
		String[] param={t1501,t1502,t1503};
		List<Map> m= null;
		try{
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			
			m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,param,new TrimedMapListHandler());
		}catch(Exception e){
			e.printStackTrace();
		}
		dbo1.addRecordData("T15C4", m.get(0).get("T15C4") != null ? m.get(0).get("T15C4").toString() : "");
		dbo1.addRecordData("T15C5", m.get(0).get("T15C5") != null ? m.get(0).get("T15C5").toString() : "");
		dbo1.addRecordData("T15C6", m.get(0).get("T15C6") != null ? m.get(0).get("T15C6").toString() : "");
		dbo1.addRecordData("T15C7", m.get(0).get("T15C7") != null ? m.get(0).get("T15C7").toString() : "");
		dbo1.addRecordData("T15C8", m.get(0).get("T15C8") != null ? m.get(0).get("T15C8").toString() : "");
		
		System.out.println("dbo1=== "+ dbo1.getRecordCount());

		int rows = 1;
		for (int i = 1; i <= rows; i++)
		{
			String T1502 = dbo1.getRecordData(i, "T1502");
			String T1503 = dbo1.getRecordData(i, "T1503");
			String T1508 = dbo1.getRecordData(i, "T1508");
			System.out.println("dbo1===end 0001 ");
			System.out.println("T1508=== " + T1508);
			if(T1508 != null){
				if (T1508.length() == 5)
					T1508 = "0" + T1508;
			}
			String T1509 = dbo1.getRecordData(i, "T1509");
			String T1510 = dbo1.getRecordData(i, "T1510");
			String T1574 = dbo1.getRecordData(i, "T1574");
			String T1575 = dbo1.getRecordData(i, "T1575");
			String T1548 = dbo1.getRecordData(i, "T1548");
			System.out.println("dbo1===end 0002 ");

			dbo1.addRecordData(i, "T1502D", CodeUtil.getCodeDesc(getServlet(), request, "GOODSID", T1502));
			dbo1.addRecordData(i, "T1503D", CodeUtil.getCodeDesc(getServlet(), request, "KIND", T1503));
			dbo1.addRecordData(i, "T1508D", T1508);
			dbo1.addRecordData(i, "T1509D", CodeUtil.getCodeDesc(getServlet(), request, "SEX2", T1509));
			dbo1.addRecordData(i, "T1510D", CodeUtil.getCodeDesc(getServlet(), request, "MARRIAGE", T1510));
			dbo1.addRecordData(i, "T1574D", CodeUtil.getCodeDesc(getServlet(), request, "YN", T1574));
			System.out.println("dbo1===end 0003 ");

			dbo1.addRecordData(i, "T1575D", CodeUtil.getCodeDesc(getServlet(), request, "YN", T1575));
			dbo1.addRecordData(i, "T1548D", CodeUtil.getCodeDesc(getServlet(), request, "RELATION", T1548));
		}
		
		System.out.println("dbo1===end 0004 ");

		String t1517 = dbo1.getRecordData(1,"T1517");
		
		System.out.println("t1517=== " +  t1517);

		dbo1.addRecordData("T1517y", t1517.substring(0, 2));
		dbo1.addRecordData("T1517d", t1517.substring(2));
		
		System.out.println("dbo1===end 0005 ");

		String t1518 = dbo1.getRecordData(1,"T1518");
		dbo1.addRecordData("T1518y", t1518.substring(0, 2));
		dbo1.addRecordData("T1518d", t1518.substring(2));
		dbo1.addRecordData("T1517C1", t1517);
		System.out.println("dbo1===end ");

		return dbo1;
	}

	/**
	 * 抓取車籍資料
	 * 
	 * @param t1503
	 * @param isOrder
	 * @param dbo1
	 * @return
	 * @throws AsiException
	 */
	private DBO getCarData(HttpServletRequest request, SelectDBO dbo1) throws AsiException
	{

		String t1503 = request.getParameter("KYC_T1503");
		String isOrder = request.getParameter("isOrder");
		DBO dbo2;
		if (isOrder.equals("0"))
		{
			dbo2 = tx_controller.getDBO("kyc.KYCKLBt", 0);
		}
		else
		{
			dbo2 = tx_controller.getDBO("kyc.PT16PFt", 0);
		}
		dbo2.addParameter("T1601", dbo1.getRecordData("T1501"));
		dbo2.addParameter("T1602", dbo1.getRecordData("T1502"));
		dbo2.addParameter("T1603", t1503);
		dbo2.addParameter("T1604", "1");
		dbo2.executeSelect();

		if (dbo2.getRecordCount() > 0)
		{
			String brand = dbo2.getRecordData("T1605").substring(0, 2);
			String kind = dbo2.getRecordData("T1605").substring(2, 4);
			dbo2.addRecordData("CT01", getCarType(dbo2.getRecordData("T1608")));
			dbo2.addRecordData("BN01", getCarBrand(brand));
			dbo2.addRecordData("PC01", getCarKind(brand, kind));
		}
		
		Map pt17 = isIns_A(dbo1.getRecordData("T1501"), isOrder);
		boolean isExistFc71pf = false;
		
		if(pt17 != null && pt17.size()>0){
			dbo2.addRecordData("T1705", pt17.get("T1705").toString());
			dbo2.addRecordData("T1709", pt17.get("T1709").toString());
			isExistFc71pf = isExistFc71pf(dbo2.getRecordData("T1610"));
			
			if(isExistFc71pf)
				dbo2.addRecordData("isFC71PF", "Y");
			else
				dbo2.addRecordData("isFC71PF", "N");
		}else
			dbo2.addRecordData("T1709", "0");
		
		return dbo2;
	}

	/**
	 * 查詢交易資料是否有含車體險種
	 * @param t1701
	 * @param isorder
	 * @return
	 */
	private Map isIns_A(String t1701 , String isorder)
	   {
	  	
	  	StringBuffer sb = new StringBuffer();
	  	sb.append("SELECT * FROM ");
	  	if(isorder.equals("0"))
	  		sb.append("KYCKLC ");
	  	else
	  		sb.append("PT17PF ");
	  	sb.append("RIGHT JOIN KYCCA ON CA01=T1705 AND CA13='A0' ");//串KYCCA, 找險種類別為A0→車體險
	  	sb.append("WHERE T1701='").append(t1701).append("' ");

	  	Map ret = null;

		try
		{

			QueryRunner runner = new QueryRunner();
			ret = (Map) runner.query(tx_controller.getConnection(0), sb.toString(), new TrimedMapHandler());
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	private boolean isExistFc71pf(String carno){
		boolean result = false;
		
	  	StringBuffer sb = new StringBuffer();
	  	sb.append("SELECT * FROM FC71PF WHERE F7101='").append(carno).append("' ");

	  	Map ret = null;

	  	tx_controller.begin(1);
		try
		{			
			QueryRunner runner = new QueryRunner();
			ret = (Map) runner.query(tx_controller.getConnection(1), sb.toString(), new TrimedMapHandler());
			if(ret != null && ret.size() > 0)
				result = true;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
	private String getCarType(String ct00) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFCTs04", 0);
		dbo.addParameter("WHERE", " where ct00='" + ct00 + "'");
		dbo.executeSelect();
		return dbo.getRecordData("CT01").trim();
	}

	private String getCarBrand(String bn00) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFBNs03", 0);
		dbo.addParameter("BN00", bn00);
		dbo.executeSelect();
		return dbo.getRecordData("BN01").trim();
	}

	private String getCarKind(String brand, String kind) throws AsiException
	{
		DBO dbo = tx_controller.getDBO("kyc.PFBOs01", 0);
		dbo.addParameter("BO001", brand);
		dbo.addParameter("BO002", kind);
		dbo.executeSelect();
		if (dbo.getRecordData("BO02") == null)
		{
			return "";
		}
		return dbo.getRecordData("BO02").trim();
	}

}
