/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with The First Insurance Co. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.naming.NamingException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.table.TableModel;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.StringUtil;
import com.asi.kyc.common.Employee;
import com.asi.kyc.common.ReportProvider;
import com.asi.kyc.common.ResultSetDataSource;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycDateUtil;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.TrimedMapHandler;
import com.asi.kyc.common.utils.TrimedMapListHandler;
import com.asi.kyc.wb1.forms.WB1R040f;
import com.kyc.sec.actions.kycAction;

/**
 * 要保書列印 - 旅平險
 * 
 * 存放路徑	：$Header: D:/Repositories/KYC_Report2/JavaSource/com/asi/kyc/wb1/actions/WB1R0401.java,v 1.2 2006/09/08 03:50:58 john Exp $  
 * 建立日期	：2005/4/25   2010/07/26 update by Ryan
 * 異動註記	：2018/02/02 Dachun
 * 			：2018/05/29 vsg
 * 			:2020/07/13 vsg 增加海域綜合保險
 */
public class WB1R0401 extends kycAction
{
	private byte[] pdf = null; // 合併所有保單的pdf檔
	private String mainPage1 = "WB1R040";//旅平險要保書
	private String extendPage1 = "WB1R041";//保險需求評估
	private String extendPage2 = "WB1R042";//受監護宣告書
	private String extendPage3 = "WB1R043";//新版明細表
	private String extendPage4 = "WB1R044";//申根證明
	private String extendPage5 = "WB1R045";//投保須知
	
	private String mainPage2 = "WB1R046";//海域要保書
	private String extendPage6 = "WB1R047";//海域明細
	
	private String insDesc01 = "個人旅遊平安綜合保險";
	private String insDesc02 = "海域活動綜合保險";

	private String pages = "1";//控制列印報表參數
	private String roles = "1";//控制寄發核保參數
	private String entry = "2";//投保要保選項，投保-1；要保-2
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		WB1R040f form1 = (WB1R040f) form;

		DBO dbo1 = (DBO) request.getAttribute("dbo1");
		String nature = (String) request.getAttribute("nature");
		pages = (String) request.getAttribute("pages"); // 1：僅列印要保書 ；2：僅列印保險需求評估報告書 3：上述2種一起印 4：列印申根證明
		roles = (String) request.getAttribute("roles"); // 1：寄要保人 ；2：寄核保人員 3：寄要保人+核保人員
		entry = (String) request.getAttribute("entry");
		String emailaddr = (String) request.getAttribute("email");
		
		String t1501 = dbo1.getRecordData("T1501"); // 交易序號
		String t1502 = dbo1.getRecordData("T1502"); // 商品代碼
		String t1503 = dbo1.getRecordData("T1503"); // 險別

		long duringDays = 0;// 保險總天數
		try
		{
			KycDateUtil kycUtil = new KycDateUtil(dbo1.getRecordData("T1517"));
			long timeBegin = kycUtil.getDate().getTime();
			kycUtil.setKycDate(dbo1.getRecordData("T1518"));
			long timeEnd = kycUtil.getDate().getTime();
			duringDays = (timeEnd - timeBegin) / 24 / 60 / 60 / 1000;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		DBO dbo2 = null;
		if (nature == null)
		{
			dbo2 = (DBO) tx_controller.getDBO("kyc.PT18PFs01", 0);
		}
		else
		{
			dbo2 = (DBO) tx_controller.getDBO("kyc.KYCKLDs01", 0);
		}
		dbo2.addParameter("T1801", t1501);
		dbo2.addParameter("T1802", t1502);
		dbo2.addParameter("T1803", t1503);
		dbo2.addParameter("T1804", t1502); // 險種
		dbo2.execute();

        //明細筆數
        int detailcounts = dbo2.getRecordCount();
        
		HashMap param = new HashMap();
		
		String t4003 = getT4003(dbo1.getRecordData("T1519"));
		param.put("T4003", t4003);//通路代號
		param.put("T1554year", dbo1.getRecordData("T1554").substring(0, dbo1.getRecordData("T1554").length() - 4));// 要保人-出生年
		param.put("T1554month", dbo1.getRecordData("T1554").substring(dbo1.getRecordData("T1554").length() - 4, dbo1.getRecordData("T1554").length() - 2));// 要保人-出生月
		param.put("T1554day", dbo1.getRecordData("T1554").substring(dbo1.getRecordData("T1554").length() - 2, dbo1.getRecordData("T1554").length()));// 要保人-出生日
		param.put("T1501", t1501);// 交易序號
		param.put("T1501barcode", "*" + t1501 + t4003 + "*");// 交易序號 + 通路代號 Barcode
		param.put("T1504", dbo1.getRecordData("T1504"));// 保險單號碼
		param.put("T1517year", dbo1.getRecordData("T1517").substring(0, dbo1.getRecordData("T1517").length() - 4));// 保險期間起-年
		param.put("T1517month", dbo1.getRecordData("T1517").substring(dbo1.getRecordData("T1517").length() - 4, dbo1.getRecordData("T1517").length() - 2));// 保險期間起-月
		param.put("T1517day", dbo1.getRecordData("T1517").substring(dbo1.getRecordData("T1517").length() - 2, dbo1.getRecordData("T1517").length()));// 保險期間起-日
		param.put("T1556", dbo1.getRecordData("T1556"));// 保險期間起-時
		param.put("duringDays", String.valueOf(duringDays));// 保險總天數
		param.put("T1506", dbo1.getRecordData("T1506"));// 被保人
		param.put("T1506A", dbo1.getRecordData("T1506A"));// 被保人英文姓名
		param.put("T1507", dbo1.getRecordData("T1507").substring(0, 4) + "****" + dbo1.getRecordData("T1507").substring(8, 10));// 被保人身份證號碼
		param.put("T1507A", dbo1.getRecordData("T1507A"));// 被保人護照號碼
		param.put("T1548DESC", "".equals(dbo1.getRecordData("T1548"))?"同旅行成員之一":CodeUtil.getCodeDesc(servlet, tx_controller.getUserLocale(), "RELATION", dbo1.getRecordData("T1548")));// 要保人與被保險人關係
		param.put("T1548", dbo1.getRecordData("T1548"));// 要保人與被保險人關係
		param.put("T1807", dbo2.getRecordData("T1807"));// 被保險人-第一筆
		param.put("groupCount", String.valueOf(dbo2.getRecordCount()));// 被保險人筆數
		param.put("T1809year", dbo2.getRecordData("T1809").substring(0, dbo2.getRecordData("T1809").length() - 4));// 被保險人-第一筆-出生年
		param.put("T1809month", dbo2.getRecordData("T1809").substring(dbo2.getRecordData("T1809").length() - 4, dbo2.getRecordData("T1809").length() - 2));// 被保險人-第一筆-出生月
		param.put("T1809day", dbo2.getRecordData("T1809").substring(dbo2.getRecordData("T1809").length() - 2, dbo2.getRecordData("T1809").length()));// 被保險人-第一筆-出生日
		param.put("T1511", dbo1.getRecordData("T1511"));// 要保人連絡地址郵遞區號
		param.put("T1512", dbo1.getRecordData("T1512"));// 要保人連絡地址
		param.put("T1513", dbo1.getRecordData("T1513"));// 聯絡電話
		param.put("T1515", dbo1.getRecordData("T1515"));// 手機
		param.put("T1550", dbo1.getRecordData("T1550"));// 旅遊地區
		//param.put("T1813", dbo2.getRecordData("T1813"));// 身故保險受益人
		//param.put("T1815", CodeUtil.getCodeDesc(servlet, tx_controller.getUserLocale(), "RELATION", dbo2.getRecordData("T1815")));// 身故保險受益人與被保險人關係
		param.put("T1541", FormatUtil.getDecimalFormat(Double.parseDouble(dbo1.getRecordData("T1541")), 0));// 總保險費
		param.put("T1523year", dbo1.getRecordData("T1523").substring(0, dbo1.getRecordData("T1523").length() - 4));// 保險期間起-年
		param.put("T1523month", dbo1.getRecordData("T1523").substring(dbo1.getRecordData("T1523").length() - 4, dbo1.getRecordData("T1523").length() - 2));// 保險期間起-月
		param.put("T1523day", dbo1.getRecordData("T1523").substring(dbo1.getRecordData("T1523").length() - 2, dbo1.getRecordData("T1523").length()));// 保險期間起-日
		param.put("T1519", dbo1.getRecordData("T1519"));// 業務來源
		param.put("T1520", dbo1.getRecordData("T1520"));// 業務員(招攬人)
		param.put("T1546", dbo1.getRecordData("T1546"));// 要保人
		param.put("T1546A", dbo1.getRecordData("T1546A"));// 要保人英文姓名
		param.put("T1547_ORG", dbo1.getRecordData("T1547"));//要保人ID原始，用於密碼
		param.put("T1547", dbo1.getRecordData("T1547").substring(0, 4) + "****" + dbo1.getRecordData("T1547").substring(8, 10));// 要保人ID
		param.put("T1547A", dbo1.getRecordData("T1547A"));// 要保人護照號碼
		param.put("T1516", dbo1.getRecordData("T1516"));// Email
		param.put("T1508year", dbo1.getRecordData("T1508").substring(0, dbo1.getRecordData("T1508").length() - 4));// 被保險人-出生年
		param.put("T1508month", dbo1.getRecordData("T1508").substring(dbo1.getRecordData("T1508").length() - 4, dbo1.getRecordData("T1508").length() - 2));// 被保險人-出生月
		param.put("T1508day", dbo1.getRecordData("T1508").substring(dbo1.getRecordData("T1508").length() - 2, dbo1.getRecordData("T1508").length()));// 被保險人-出生日
		param.put("TA1501", dbo1.getRecordData("TA1501"));// 旅遊目的
		param.put("TA1502", dbo1.getRecordData("TA1502"));// 交通工具
		param.put("T1575", dbo1.getRecordData("T1575"));// 電子保單選項
		param.put("T1537",dbo1.getRecordData("T1537"));//方案代碼
		
		String crttime = StringUtil.fillPre(dbo1.getRecordData("T1594"), 6, '0');//處理建檔時間
		param.put("T1594", crttime.substring(0, 2) + ":" + crttime.substring(2, 4) + ":" + crttime.substring(4, 6));// 建檔時間
		
		String t1909_ohs = getT1909(t1501, "OHS");
		String t1909_pa67 = getT1909(t1501, "PA67");
		
		String t1523w = formatDateToWest(dbo1.getRecordData("T1523").toString());
		param.put("T1523W", t1523w);
		
		if(detailcounts > 1){
			param.put("T1813", "詳如名冊");// 受益人
			param.put("T1814", "");// 受益人ID
			param.put("T1815", "");// 受益人與被保人關係
			param.put("T1837", "0");// 受益人生日		
			param.put("T1825", "詳如名冊");// 死殘保額
			param.put("T1826", "詳如名冊");// 醫療保額
			param.put("T1909_OHS", "詳如名冊");// 海突保額
			param.put("T1909_PA67", "詳如名冊");// 公交保額
		}else{
			param.put("T1813", dbo1.getRecordData("T1813"));// 受益人
			param.put("T1814", dbo1.getRecordData("T1814") != null && !dbo1.getRecordData("T1814").equals("") ? dbo1.getRecordData("T1814").substring(0, 4) + "****" + dbo1.getRecordData("T1814").substring(8, 10) : "");// 受益人ID
			param.put("T1815", CodeUtil.getCodeDesc(servlet, tx_controller.getUserLocale(), "RELATION", dbo1.getRecordData("T1815")));// 受益人與被保人關係
			param.put("T1837", dbo1.getRecordData("T1837"));// 受益人生日
			param.put("T1825", FormatUtil.getDecimalFormat(Double.parseDouble(dbo1.getRecordData("T1825")), 0));// 死殘保額
			param.put("T1826", FormatUtil.getDecimalFormat(Double.parseDouble(dbo1.getRecordData("T1826")), 0));// 醫療保額
			param.put("T1909_OHS", FormatUtil.getDecimalFormat(Double.parseDouble(t1909_ohs), 0));// 海突保額
			param.put("T1909_PA67", FormatUtil.getDecimalFormat(Double.parseDouble(t1909_pa67), 0));// 公交保額
		}
		String isExistPt16pf = getKYCKLB(t1501);
		param.put("isPT16PF", isExistPt16pf);//是否有保不便險
				
		int t15a8 = Integer.parseInt(dbo1.getRecordData("T15A8")) / 10000 ;
		param.put("t15a8", String.valueOf(t15a8));// 要保人年收入
		param.put("ta1504", dbo1.getRecordData("TA1504"));// 要保人服務單位
		param.put("ta1505", dbo1.getRecordData("TA1505"));// 要保人工作性質
		param.put("ta1506", dbo1.getRecordData("TA1506"));// 要保人收入來源
		param.put("ta1506o", dbo1.getRecordData("TA1506O"));// 要保人收入來源-其他
		int ta1508 = Integer.parseInt(dbo1.getRecordData("TA1508")) / 10000 ;
		param.put("ta1508", String.valueOf(ta1508));// 被保險人年收入
		param.put("ta1509", dbo1.getRecordData("TA1509"));// 被保險人收入來源
		param.put("ta1509o", dbo1.getRecordData("TA1509O"));// 被保險人收入來源-其他
		param.put("ta1510", dbo1.getRecordData("TA1510"));// 被保險人日常交通工具
		param.put("ta1510o", dbo1.getRecordData("TA1510O"));// 被保險人日常交通工具-其他
		
		param.put("ta1511", dbo1.getRecordData("TA1511"));// 要保人評估職業
		param.put("ta1512", dbo1.getRecordData("TA1512"));// 被保險人評估職業
		param.put("ta1513", dbo1.getRecordData("TA1513"));// 投保目的
		param.put("ta1513o", dbo1.getRecordData("TA1513O"));// 投保目的-其他
		param.put("ta1514", dbo1.getRecordData("TA1514"));// 是否投保其他商業險
		param.put("ta1515", dbo1.getRecordData("TA1515"));// 主要經濟者為要保人之
		param.put("ta1515o", dbo1.getRecordData("TA1515O"));// 主要經濟者為要保人之-其他
		param.put("TA1516", dbo1.getRecordData("TA1516"));// 收件通報序號
		param.put("TA1520", dbo1.getRecordData("TA1520"));// 是否有投保其他家旅平險
		param.put("TA1521", dbo1.getRecordData("TA1521"));// 投保其他家旅平險家數
		param.put("TA1522", dbo1.getRecordData("TA1522"));// 投保其他家旅平險保額
		
		param.put("T1832", dbo2.getRecordData("T1832"));// 身心障礙類別 Y/N
		param.put("T1833", dbo2.getRecordData("T1833"));// 身心障礙等級 Y/N
		param.put("T1836", dbo2.getRecordData("T1836"));// 投保他家MR Y/N
		
		String t1520 = dbo1.getRecordData("T1520").toString();
		String IdNo = "";
		IdNo = Employee.getEmployee(t1520).getLicenceNo();
		param.put("agentcode", IdNo);
		
		String key = mainPage1;
		String insDesc = insDesc01;
		
		if(t1502.equals("SE")){
			key = mainPage2;
			insDesc = insDesc02;
		}	

		String t1575 = dbo1.getRecordData("T1575");
		String t1546a = dbo1.getRecordData("T1546A");
		boolean isEpolicy = t1575.equals("Y") ? true : false;
		boolean isSchengen = !t1546a.equals("") ? true : false;		
		
		tx_controller.begin(0);
        Connection conn = tx_controller.getConnection(0);
        Locale locale = tx_controller.getUserLocale();
        UserInfo userInfo = tx_controller.getUserInfo();
        
		WB1R0402 wb1r0402 = new WB1R0402(t1501, conn, locale, servlet, userInfo);
		TableModel tm = wb1r0402.getTableModel(nature , detailcounts);

		JRDataSource ds = null;
		if (tm != null)
		{
			ds = ResultSetDataSource.build(tm);
		}		
		
		byte[][] report = new byte[2][];
		report[0] = createReport(t1502 , ds, key, param, servlet, locale, tm , emailaddr , wb1r0402 , detailcounts);

		response.setContentType("application/pdf");
		response.setHeader("Content-disposition", "attachment; filename=" + t1502 + "-" + t1501 + ".pdf");
		
		// pdf = 傳回來的陣列
		if (pdf != null)
		{
			File file = null;
			FileOutputStream fos = null;
			EmailAttachment attachment = null;
			HtmlEmail email = null;
			int error = 0;
			
			// 內文用資料
			String name = dbo1.getRecordData("T1506");
			String total = FormatUtil.getDecimalFormat(Double.parseDouble(dbo1.getRecordData("T1541")), 0);
			String headcount = String.valueOf(dbo2.getRecordCount());
	        StringBuffer sb = new StringBuffer();
	        sb.append(insDesc + " – 共 ").append(headcount).append(" 人投保 ");

			//有傳入email時用郵件寄發客戶，若無直接列印
			if(emailaddr != null && !emailaddr.equals("")){				
				try
				{
					file = new File(servlet.getServletContext().getRealPath("/") + t1501 + ".pdf");
					fos = new FileOutputStream(file);

					fos.write(pdf, 0, pdf.length);
					fos.flush();
					fos.close();
									
					// 郵件附加檔
					attachment = new EmailAttachment();
					attachment.setPath(file.getPath());
					attachment.setDisposition(EmailAttachment.ATTACHMENT);
					attachment.setName(t1501 + ".pdf");

					// 郵件主體
					email = new HtmlEmail();
					KycMailUtil kmu = new KycMailUtil();
					email.setMailSession(kmu.getMailSession());
					email.addTo(emailaddr);// 收件人
					email.addBcc("admin@firstins.com.tw");

					// 主旨註明是否為測試信
					if (SystemParam.getParam("ENV").equals("KYC"))
					{
						if(!pages.equals("4")){
							if(entry.equals("1"))
								email.setSubject("第一產物保險 - " + insDesc + "投保確認通知");
							else
								email.setSubject("第一產物保險 - " + insDesc + "要保確認通知");

						}else{
							email.setSubject("第一產物保險 - " + insDesc + "(申根證明)");
						}
						
					}
					else{
						if(!pages.equals("4")){
							if(entry.equals("1"))
								email.setSubject("【測試】第一產物保險 - " + insDesc + "投保確認通知");
							else
								email.setSubject("【測試】第一產物保險 - " + insDesc + "要保確認通知");
						}else{
							email.setSubject("【測試】第一產物保險 - " + insDesc + "(申根證明)");
						}
					}
						

					email.setFrom("admin@firstins.com.tw");// 寄件人
					if(!entry.equals("1") || pages.equals("4"))
						email.attach(attachment);
					
					email.setCharset("UTF-8");
					email.setHtmlMsg(getMessage(name, t1501, total, sb.toString() , entry , pages , roles , isEpolicy , isSchengen));//郵件內文
					email.send();
										
				}
				catch (IOException ioe)
				{
					error++;
					throw new UserException(insDesc + "-輸出報表資料時發生錯誤! " + ioe + "交易序號：" + t1501);
				}
				catch (NamingException ne)
				{
					error++;
					throw new UserException(insDesc +"-Email發送錯誤! " + ne + "交易序號：" + t1501);
				}
				catch (EmailException ee)
				{
					error++;
					throw new UserException(insDesc + "-Email發送錯誤! " + ee + "交易序號：" + t1501);
				}
				catch (Exception e)
				{
					error++;
					throw new UserException(insDesc + "-Email發送錯誤! " + e + "交易序號：" + t1501);
				}
				finally
				{
					if(file!=null && file.exists())
						file.delete();
					try
					{
						response.setContentType("text/xml;charset=UTF-8");
						response.setHeader("Cache-Control", "no-cache");
						response.getWriter().write("<?xml version=\"1.0\" ?>");
						response.getWriter().write("<out>");
						response.getWriter().write("<mailstatus>");
						response.getWriter().write(error>0?"Email寄發有誤，請聯絡服務專員！":"確認信寄發成功!");
						response.getWriter().write("</mailstatus>");
						response.getWriter().write("</out>");
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
				
			}
			else
			{	
				try
				{
					OutputStream os = response.getOutputStream();
					os.write(pdf, 0, pdf.length);
					os.flush();
					os.close();
				}
				catch (IOException ioe)
				{
					throw new UserException(insDesc + "-輸出報表資料時發生錯誤! " + ioe);
				}
			}
			
			//發寄核保人員&電商窗口及主管動作
			if(!roles.equals("1"))
			{
				try
				{			
					//重新產生要保書+業報書資料
					ds = null;
					if (tm != null)
					{
						ds = ResultSetDataSource.build(tm);
					}		
					report[0] = createReport(t1502 , ds, key, param, servlet, locale, tm , emailaddr , wb1r0402 , detailcounts);
	
					file = new File(servlet.getServletContext().getRealPath("/") + t1501 + ".pdf");
					fos = new FileOutputStream(file);	
					fos.write(pdf, 0, pdf.length);
					fos.flush();
					fos.close();
	
					//郵件附加檔
					attachment = new EmailAttachment();
					attachment.setPath(file.getPath());
					attachment.setDisposition(EmailAttachment.ATTACHMENT);
					attachment.setName(t1501 + ".pdf");
					
					//郵件主體
					//取得核保人員
					String maillist = CodeUtil.getCodeList(servlet, request, "TA-AUTHMAN");//代碼檔設定之核保人員
					String[] getauthemail = getAuthManList(maillist);//取得核保人員email
										
					//寄發email&檔案
					
					email = new HtmlEmail();
					KycMailUtil kmu = new KycMailUtil();
					email.setMailSession(kmu.getMailSession());
					
					for (int i = 0; i < getauthemail.length; i++) {
						email.addTo(getauthemail[i]);// 收件人
					}
					email.addBcc("admin@firstins.com.tw");

					// 主旨註明是否為測試信
					if (SystemParam.getParam("ENV").equals("KYC"))
					{
						if(!pages.equals("4")){
							if(entry.equals("1"))
								email.setSubject("投保通知 - " + insDesc + "網路投保");
							else
								email.setSubject("核保通知 - " + insDesc + "網路要保");
						}else{
							email.setSubject("第一產物保險 - " + insDesc + "(申根證明)，請協助補發用印");
						}
						
					}
					else{
						if(!pages.equals("4")){
							if(entry.equals("1"))
								email.setSubject("【測試】投保通知 - " + insDesc + "網路投保");
							else
								email.setSubject("【測試】核保通知 - " + insDesc + "網路投保");
						}else{
							email.setSubject("【測試】第一產物保險 - " + insDesc + "(申根證明)，請協助補發用印");				
						}
					}

					email.setFrom("admin@firstins.com.tw");// 寄件人
					if(!entry.equals("1") || pages.equals("4"))
						email.attach(attachment);

					email.setCharset("UTF-8");
					email.setHtmlMsg(getMessage(name, t1501, total, sb.toString() , entry , pages , roles , isEpolicy , isSchengen));//郵件內文
					email.send();
					System.out.println(insDesc + t1501 + " 寄發核保人員通知信成功");
					
					
					if(!pages.equals("4")){
						//取得電商窗口及主管
						String ec_maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
						String[] getecemail = getAuthManList(ec_maillist);//取得人員email

						//寄發email&檔案					
						email = new HtmlEmail();
						email.setMailSession(kmu.getMailSession());
						for (int i = 0; i < getecemail.length; i++) {
							email.addTo(getecemail[i]);// 收件人
						}
						email.addBcc("admin@firstins.com.tw");

						// 主旨註明是否為測試信
						if (SystemParam.getParam("ENV").equals("KYC"))
						{
							if(entry.equals("1"))
								email.setSubject("投保通知 - " + insDesc + "網路投保");
							else
								email.setSubject("核保通知 - " + insDesc + "網路要保");
						}
						else{
							if(entry.equals("1"))
								email.setSubject("【測試】投保通知 - " + insDesc + "網路投保");
							else
								email.setSubject("【測試】核保通知 - " + insDesc + "網路投保");
						}

						email.setFrom("admin@firstins.com.tw");// 寄件人
						email.setCharset("UTF-8");
						email.setHtmlMsg(getMessage(name, t1501, total, sb.toString() , entry , pages , roles , isEpolicy , isSchengen));//郵件內文
						email.send();
						System.out.println(insDesc + t1501 + " 寄發電商人員通知信成功");
					}
				
				}
				catch (IOException ioe)
				{
					error++;
					throw new UserException(insDesc +"-輸出報表資料時發生錯誤! " + ioe + "交易序號：" + t1501);
				}
				catch (NamingException ne)
				{
					error++;
					throw new UserException(insDesc +"-Email發送錯誤! " + ne + "交易序號：" + t1501);
				}
				catch (EmailException ee)
				{
					error++;
					throw new UserException(insDesc +"Email發送錯誤! " + ee + "交易序號：" + t1501);
				}
				catch (Exception e)
				{
					error++;
					throw new UserException(insDesc +"-Email發送錯誤! " + e + "交易序號：" + t1501);
				}
				finally
				{
					if(file!=null && file.exists())
						file.delete();
					try
					{
						response.setContentType("text/xml;charset=UTF-8");
						response.setHeader("Cache-Control", "no-cache");
						response.getWriter().write("<?xml version=\"1.0\" ?>");
						response.getWriter().write("<out>");
						response.getWriter().write("<mailstatus>");
						response.getWriter().write(error>0?"Email寄發有誤，請聯絡服務專員！":"核保信寄發成功!");
						response.getWriter().write("</mailstatus>");
						response.getWriter().write("</out>");
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}

				}
			}
						
		}
		else
		{
			throw new UserException(insDesc +"-報表產生失敗");
		}

		form1.setNextPage(-1);
	}

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3)
	{
		AsiActionForm aform = (AsiActionForm) arg1;
		aform.setActionCode(GlobalKey.ACTION_SELECT);
	}
	
	/**
	 * 產生報表的byte陣列
	 * 
	 * @param ds
	 *            JRDataSource明細
	 * @param key
	 *            報表代號
	 * @param insNumber
	 *            交易號碼T1501
	 * @param servlet
	 * @param locale
	 * @return
	 * @throws AsiException 
	 */
	public byte[] createReport(String insType , JRDataSource ds, String key, HashMap param, HttpServlet servlet, Locale locale, TableModel tm , String email , WB1R0402 wb1r0402 , int detailcounts) throws AsiException
	{
		int totalpages = 0;//報表總頁數
		
        double countpages = Math.ceil(Double.parseDouble(String.valueOf(detailcounts)) / 10); 
        int detailpages = (int) countpages;
		
		String img = null;
		String img1 = null;
		
		try
		{
			img = ReportProvider.getImage("Logo.gif");
			param.put("image", img);
			
			img = ReportProvider.getImage("TA-INSForm-200dpi.jpg");
			param.put("bgLogo", img );

			if(insType.equals("TA")){
				img = ReportProvider.getImage("qr-firstins-ta.png");
				param.put("barcode_img", img );
			} else {
				img1 = ReportProvider.getImage("qr-firstins-se.jpg");
				param.put("barcode_img", img1 );
			}
			
			
			img = ReportProvider.getImage("Logo2.jpg");
			param.put("logo2", img );
			
			img = ReportProvider.getImage("First_A&H_Sign.jpg");
			if(!roles.equals("2"))
				param.put("image_sign", img );
			else
				param.put("image_sign", null );
				
			img = ReportProvider.getImage("TA-Doc03.jpg");
			param.put("doc03", img );
			
			

			int rowCount = 0;
			if (tm != null)
			{
				rowCount = tm.getRowCount();
			}
			param.put("rowCount", new Integer(rowCount));
			
			InputStream is1 = null;//要保書明細表
			InputStream is2 = null;//保險需求評估
			InputStream is4 = null;//新版明細表
			InputStream is5 = null;//申根證明
			InputStream is6 = null;//投保需知
			
			JasperPrint jpP1 = null;
			JasperPrint jpP2 = null;
			JasperPrint jpP4 = null;
			JasperPrint jpP5 = null;
			JasperPrint jpP6 = null;

			List list = new ArrayList();
			String detailTemplate = extendPage3;
			if(insType.equals("SE"))
				detailTemplate = extendPage6;
			
			if(pages.equals("1")){								
				//如果筆數大於1筆以上
				if(detailcounts > 1){//要保書+明細表
					
					//報表總頁數
					totalpages = 2 + detailpages;
					param.put("totalpages", String.valueOf(totalpages));

					//依照TableModel的陣列數，產生空白的datasource
					TableModel tm_blank = wb1r0402.getTableModel_blank5();
					JRDataSource dsblank = ResultSetDataSource.build(tm_blank);
					
					is1 = ReportProvider.getReport(key, 0, 0, "");//要保書
					jpP1 = JasperFillManager.fillReport(is1, param , dsblank);
					list.add(jpP1);
					
					//正確的明細資料載入新的明細表
					is4 = ReportProvider.getReport(detailTemplate, 0, 0, "");//明細表
					jpP4 = JasperFillManager.fillReport(is4, param , ds);
					list.add(jpP4);
										
				}else{//要保書
					//報表總頁數
					totalpages = 2 ;
					param.put("totalpages", String.valueOf(totalpages));

					is1 = ReportProvider.getReport(key, 0, 0, "");//要保書
					jpP1 = JasperFillManager.fillReport(is1, param , ds);
					list.add(jpP1);
				}
				
				//投保需知
				is6 = ReportProvider.getReport(extendPage5, 0, 0, "");
				jpP6 = JasperFillManager.fillReport(is6, param );
				list.add(jpP6);

			}
			
			if(pages.equals("2")){
				is2 = ReportProvider.getReport(extendPage1, 0, 0, "");//保險需求評估
				jpP2 = JasperFillManager.fillReport(is2, param );
				list.add(jpP2);
			}

			if(pages.equals("3")){				
				//如果筆數大於1筆以上
				if(detailcounts > 1){//要保書+明細表+保險需求評估
					
					//報表總頁數
					totalpages = 2 + detailpages;
					param.put("totalpages", String.valueOf(totalpages));

					//依照TableModel的陣列數，產生空白的datasource
					TableModel tm_blank = wb1r0402.getTableModel_blank5();
					JRDataSource dsblank = ResultSetDataSource.build(tm_blank);
					
					is1 = ReportProvider.getReport(key, 0, 0, "");//要保書
					jpP1 = JasperFillManager.fillReport(is1, param , dsblank);
					list.add(jpP1);
					
					//正確的明細資料載入新的明細表
					is4 = ReportProvider.getReport(detailTemplate, 0, 0, "");//明細表
					jpP4 = JasperFillManager.fillReport(is4, param , ds);
					System.out.println(jpP4.getPages());
					list.add(jpP4);
					
					is2 = ReportProvider.getReport(extendPage1, 0, 0, "");//保險需求評估
					jpP2 = JasperFillManager.fillReport(is2, param );
					list.add(jpP2);
					
				}else{
					//報表總頁數
					totalpages = 1 ;
					param.put("totalpages", String.valueOf(totalpages));

					is1 = ReportProvider.getReport(key, 0, 0, "");//要保書明細表
					jpP1 = JasperFillManager.fillReport(is1, param , ds);
					list.add(jpP1);
					
					is2 = ReportProvider.getReport(extendPage1, 0, 0, "");//保險需求評估
					jpP2 = JasperFillManager.fillReport(is2, param );
					list.add(jpP2);

				}
				
			}

			if(pages.equals("4")){
				List insData = getPT18PFDetail(param.get("T1501").toString());
				
				ds =  new JRMapCollectionDataSource(insData);
				is5 = ReportProvider.getReport(extendPage4, 0, 0, "");//申根證明
				jpP5 = JasperFillManager.fillReport(is5, param , ds );
				list.add(jpP5);
			}
						
			//使用下列的方式，可以依照加入list的頁面格式自行展現，不須使用setOrientation的方式處理
			ByteArrayOutputStream baos = new ByteArrayOutputStream();       
			JRPdfExporter exporter = new JRPdfExporter();       
			//this sets the list of jasperPrint objects to be exported and merged
			exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, list);
			//the bookmarks is a neat extra that creates a bookmark for each jasper print
			exporter.setParameter(JRPdfExporterParameter.IS_CREATING_BATCH_MODE_BOOKMARKS, Boolean.TRUE);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baos);
			
			if(roles.equals("1")){
				exporter.setParameter(JRPdfExporterParameter.IS_ENCRYPTED, Boolean.TRUE);
				exporter.setParameter(JRPdfExporterParameter.IS_128_BIT_KEY, Boolean.TRUE);
				exporter.setParameter(JRPdfExporterParameter.USER_PASSWORD, param.get("T1547_ORG"));
				exporter.setParameter(JRPdfExporterParameter.OWNER_PASSWORD, param.get("T1547_ORG"));
			}else if(roles.equals("2"))
			{
				exporter.setParameter(JRPdfExporterParameter.IS_ENCRYPTED, Boolean.TRUE);
				exporter.setParameter(JRPdfExporterParameter.IS_128_BIT_KEY, Boolean.TRUE);
				exporter.setParameter(JRPdfExporterParameter.USER_PASSWORD, "03359109");
				exporter.setParameter(JRPdfExporterParameter.OWNER_PASSWORD, "03359109");				
			}
			
			exporter.exportReport();
			
			pdf = baos.toByteArray();

		}
		catch (JRException jre)
		{
			logger.error("報表編譯失敗", jre);
		}
		catch (IOException ioe)
		{
			logger.error("報表轉PDF時失敗", ioe);
		}
		return pdf;
	}
	
	/**
	 * 查詢每一被保險人明細
	 * @param t1501
	 * @return
	 */
	private List getPT18PFDetail(String t1501){
		
		List ret = null;
		String sql = "SELECT T1546A,T1807A,T1809,T1808,T1504,T1517,T1556,T1518,T1557,T1825,T1826,T1831, "
				+ "P16A.T1635 PREMIUM_TPL_ALL , P16B.T1635 PREMIUM_TII_ALL, "
				+ "P19A.T1909 T1909_OHS,P19A.T1910 PREMIUM_OHS , P19B.T1909 T1909_PA67,P19B.T1910 PREMIUM_PA67 "
				+ "FROM PT15PF "
				+ "LEFT JOIN PT16PF P16A ON P16A.T1601=T1501 AND P16A.T1602=T1502 AND P16A.T1627='TPL' AND P16A.T1635 <>0 "
				+ "LEFT JOIN PT16PF P16B ON P16B.T1601=T1501 AND P16B.T1602=T1502 AND P16B.T1627='TII' AND P16B.T1635 <>0 "
				+ "LEFT JOIN PT18PF ON T1801=T1501 AND T1802=T1502 "
				+ "LEFT JOIN PT19PF P19A ON P19A.T1901=T1801 AND P19A.T1902=T1802 AND P19A.T1906=T1806 AND P19A.T1907='OHS' "
				+ "LEFT JOIN PT19PF P19B ON P19B.T1901=T1801 AND P19B.T1902=T1802 AND P19B.T1906=T1806 AND P19B.T1907='PA67' "
				+ "WHERE T1501=? " ;

		QueryRunner run = new QueryRunner();
		Connection con = null;
		
		String[] args = new String[2];
		
		try
		{
			con = AS400Connection.getOracleConnection();
			ret = (List) run.query(con , sql, t1501, new TrimedMapListHandler());
			
			int rowsize = ret.size();
			int tpl_per = 0;
			int tii_per = 0;
			int t1831_per = 0;
			int ohs_per = 0;
			int pa67_per = 0;
			int permium_per = 0;
						
			for (int i = 0; i < ret.size(); i++) {
				Map mp = (Map) ret.get(i);
				
				//每人保費計算
				tpl_per = Integer.parseInt(mp.get("PREMIUM_TPL_ALL") != null ? mp.get("PREMIUM_TPL_ALL").toString() : "0") / rowsize;
				tii_per = Integer.parseInt(mp.get("PREMIUM_TII_ALL") != null ? mp.get("PREMIUM_TII_ALL").toString() : "0") / rowsize;
				ohs_per = Integer.parseInt(mp.get("PREMIUM_OHS") != null ? mp.get("PREMIUM_OHS").toString(): "0");
				pa67_per = Integer.parseInt(mp.get("PREMIUM_PA67") != null ? mp.get("PREMIUM_PA67").toString() : "0");
				t1831_per = Integer.parseInt(mp.get("T1831") != null ? mp.get("T1831").toString() : "0");
				permium_per = tpl_per + tii_per + ohs_per + pa67_per + t1831_per ;
				mp.put("PREMIUM_PER", FormatUtil.getDecimalFormat(permium_per , 0));
				
				//出生年月日
				String t1809d = formatDateToWest(mp.get("T1809").toString());
				mp.remove("T1809");
				mp.put("T1809", t1809d);

				//生效日期
				String t1517d = formatDateToWest(mp.get("T1517").toString());
				mp.remove("T1517");
				mp.put("T1517", t1517d);

				//到期日期
				String t1518d = formatDateToWest(mp.get("T1518").toString());
				mp.remove("T1518");
				mp.put("T1518", t1518d);

				//身故保額
				String t1825d = FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1825").toString()) , 0);
				mp.remove("T1825");
				mp.put("T1825", t1825d);

				//醫療保額
				String t1826d = FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1826").toString()) , 0);
				mp.remove("T1826");
				mp.put("T1826", t1826d);

				//公交保額
				String t1909_PA67 = FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1909_PA67") != null ? mp.get("T1909_PA67").toString() : "0") , 0);
				mp.remove("T1909_PA67");
				mp.put("T1909_PA67", t1909_PA67);

				//海突保額
				String t1909_OHS = FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T1909_OHS").toString()) , 0);
				mp.remove("T1909_OHS");
				mp.put("T1909_OHS", t1909_OHS);

			}
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally {
            AS400Connection.closeConnection(con);
        }
		
		return ret;	
	}
	
	private String formatDateToWest(String date){
		
		int westdate = Integer.parseInt(date) + 19110000;
		
		return String.valueOf(westdate).substring(0, 4) + "/" + String.valueOf(westdate).substring(4, 6) + "/" + String.valueOf(westdate).substring(6, 8);
	}
	
	/**
	 * 組內文資料
	 * @param name
	 * @param serialnum
	 * @param total
	 * @param insurancecontent
	 * @return
	 * @throws Exception
	 */
	private String getMessage(String name , String serialnum , String total , String insurancecontent ,String entry , String pages , String roles ,boolean isEpolicy,boolean isSchengen) throws Exception
	{
        String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 服務電話
        String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 傳真電話
        String ecom_email = SystemParam.getParam("ECOM_EMAIL"); // 電商接收Email
		
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty("file.resource.loader.path", servlet.getServletContext().getRealPath("/"));
		ve.init();
		
		// 郵件內文樣本
		Template t = null ; 
		
		if(entry.equals("1"))
			t = ve.getTemplate("report/mail/TA_OrderOK_41.html", "utf-8");
		else
			t = ve.getTemplate("report/mail/TA_OrderOK.html", "utf-8");	
		
		if(pages.equals("4") && roles.equals("1"))
			t = ve.getTemplate("report/mail/TA_SchengenProof.html", "utf-8");
		if(pages.equals("4") && roles.equals("2"))
			t = ve.getTemplate("report/mail/TA_SchengenProof_UnderWriting.html", "utf-8");
		
		StringBuffer sb = new StringBuffer();
		if(isEpolicy)
			sb.append("<p>※ 您此次選擇使用電子保單，於核保完成後的第一個營業日，將電子保單發送至您留存的E-MAIL信箱。</p>");
		else
			sb.append("<p>※ 您此次選擇使用紙本保單，於核保完成後的約7~10個營業日寄送至您留存之通訊地址，還請留意收件。</p>");
		if(isSchengen)
			sb.append("<p>Ps.您有選擇開立英文投保證明，將同電子保單一併發送至EMAIL，請出發前自行列印即可。</p>");
		else
			sb.append("<p>Ps.您有選擇開立英文投保證明，核保完成後電子檔將發送至您留存的EMAIL，請出發前自行列印即可。"
					+ "如須紙本式證明，請於投保成功後以下列方式通知。1.電子商務行銷部專線： "
					+ ecom_tel + " 2.免費服務專線：0800-288-068</p>");
		
		// 內文使用變數
		VelocityContext context1 = new VelocityContext();
		//姓名隱碼
		StringBuffer hiddenName = new StringBuffer();
		for(int i=0;i<name.length();i++){
			if(i==1){
				hiddenName.append("O");
			}
			else{
				hiddenName.append(name.substring(i,i+1));
		   	}
		}

		context1.put("name" , hiddenName.toString());
		context1.put("serialnum" , serialnum);
		context1.put("total" , total);
		context1.put("insurancecontent" , insurancecontent);
		context1.put("ecom-tel" , ecom_tel);//服務電話
		context1.put("ecom-fax" , ecom_fax);//傳真電話
		context1.put("ecom-email" , ecom_email);//客服信箱
		context1.put("addDesc" , sb);//電子保單及申根說明

		StringWriter sw = new StringWriter();
		t.merge(context1, sw);

		return sw.getBuffer().toString();
	}

	
	/**
	 * 取出核保人員及主管email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		tx_controller.begin(0);
		Connection conn = tx_controller.getConnection(0);
		List rs = null;
		String[] email = null;

		try
		{
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(conn, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return email;
	}

	
	/**
	 * 查詢是否有存在KYCKLB，用於判斷是否有投保不便險
	 * @param T1601
	 * @return
	 * @throws AsiException
	 */
	private String getKYCKLB(String T1601) throws AsiException
	{
		String result = "N";
		String sql = "SELECT * FROM KYCKLB WHERE T1601 = ? ";

		QueryRunner run = new QueryRunner();
		List m = null;
		Connection con = null;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			m = (List) run.query(con , sql, T1601, new TrimedMapListHandler());
			if(m.size() > 0)
				result = "Y";
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally {
            AS400Connection.closeConnection(con);
        }
		
		return result;	
	}

	/**
	 * 查詢是否有存在KYCKLD，查詢海突或公交保額
	 * @param T1601
	 * @return
	 * @throws AsiException
	 */
	private String getT1909(String T1901 , String T1907) throws AsiException
	{
		String T1909 = "0";
		String sql = "SELECT T1909 FROM KYCKLE WHERE T1901 = ? AND T1902='TA' AND T1906='1' AND T1907=? ";

		QueryRunner run = new QueryRunner();
		Map m = null;
		Connection con = null;
		
		String[] args = new String[2];
		args[0] = T1901;
		args[1] = T1907;
		
		try
		{
			con = AS400Connection.getOracleConnection();
			m = (Map) run.query(con , sql, args, new TrimedMapHandler());
			
			if(m != null && m.size() > 0)
				T1909 = m.get("T1909").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally {
            AS400Connection.closeConnection(con);
        }
		
		return T1909;	
	}

	
	/**
	 * 取得通路代碼
	 * @param t4002
	 * @return
	 * @throws AsiException
	 */
	private String getT4003(String t4002) throws AsiException
	{

		String t4003 = null;
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4001= 'E' AND T4002 = ? ";

		QueryRunner run = new QueryRunner();
		Map m = null;
		Connection con = null;
		
		try
		{
			con = AS400Connection.getConnection();
			m = (Map) run.query(con , t4003sql, t4002, new MapHandler());
			t4003 = m.get("T4003").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally {
            AS400Connection.closeConnection(con);
        }
		
		if(t4003==null)
			throw new AsiException("無法取得通路類別!");
		
		return t4003;	
	}

}
