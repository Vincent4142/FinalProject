--新增 首頁
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('HOME', 'ogtitle', '【第一產物網路投保】強制險、超額險、汽車保險推薦一次了解', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('HOME', 'ogdescription', '【第一CP值車險推薦】網友最推薦 NO.1線上投保，線上投保享第一優惠！ 新手也秒懂的汽機車險，強制險、第三人、超額險、車體險等任意險輕鬆選，就讓第一產物讓你輕鬆保車險享第一優惠', '1100106', '120000', '47117', '0', '0');


--新增 汽車險
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('C', 'ogtitle', '強制險省330元、5分鐘快速投保｜網友最推薦第一網路投保', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('C', 'ogdescription', '汽車險線上試算享第一優惠輕鬆投保！網路投保強制險省360元，立即投保立即省。', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('C', 'twittertitle', '強制險省350元、5分鐘快速投保｜網友最推薦第一網路投保', '1100106', '120000', '47117', '0', '0');


--新增 機車險
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('M', 'ogtitle', '機車強制險現折最高245元、3分鐘快速投保｜網友最推薦第一網路投保', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('M', 'ogdescription', '機車險線上試算享第一優惠！網路投保機車強制險最高享優惠 245 元，立即免費試算立即省！', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('M', 'twittertitle', '機車強制險現折最高245元、3分鐘快速投保｜網友最推薦第一網路投保', '1100106', '120000', '47117', '0', '0');


--新增 住火險
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('F', 'ogtitle', '住宅火險地震險+第一保，免登入試算，投保享第一產險優惠', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('F', 'ogdescription', '網友口碑最推薦火險地震險選第一產險。推薦您一定要保住火險，無論是颱風、淹水或地震造成家中屋內損失，皆有保障，線上投保享第一優惠', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('F', 'twittertitle', '住宅火險地震險+第一保，免登入試算，投保享第一產險優惠', '1100106', '120000', '47117', '0', '0');


--新增 旅平險
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('TA', 'ogtitle', '旅平險+不便險，享第一優惠│第一產險│快速試算', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('TA', 'ogdescription', '不用再比了！旅平險+保第一就夠了。自助旅行、全家出國、大人小孩都能保，快速試算立即享第一優惠', '1100106', '120000', '47117', '0', '0');


--新增 海域險
INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('SE', 'ogtitle', '海域保險眾多網友推薦享第一優惠│第一產險│快速試算', '1100106', '120000', '47117', '0', '0');


INSERT INTO "FIRSTCRM"."KYCWHD" (WHD01, WHD02, WHD03, CRTDT, CRTTM, CRTUR, UPDDT, UPDTM) 
VALUES ('SE', 'ogdescription', '不用再比了！海域險+保第一就夠了。域活動意外傷害事故、醫療運送費用、緊急救援費用等完善保障，實支實付傷害醫療保險金，海域保險眾多網友推薦第一保', '1100106', '120000', '47117', '0', '0');



--修改 首頁
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一產物網路投保】強制險、超額險、汽機車保險、住火險、旅平險、海域險輕鬆選享第一優惠' 
WHERE WHD01='HOME' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '汽車保險、機車保險、強制險、機車險、車險推薦' 
WHERE WHD01='HOME' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一CP值車險推薦】網友最推薦 NO.1線上投保，線上投保享第一優惠！ 新手也秒懂的汽機車險，強制險、第三人、超額險、車體險等任意險輕鬆選，就讓第一產物讓你輕鬆保車險享第一優惠' 
WHERE WHD01='HOME' and WHD02='description';

--修改 會員登入
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '會員登入｜第一產物網路投保享第一優惠' 
WHERE WHD01='RG' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '會員,登入會員' 
WHERE WHD01='RG' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '請登入會員,輕鬆保享第一會員專屬優惠！' 
WHERE WHD01='RG' and WHD02='description';

--修改 汽車險
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一網路投保專區】3分鐘輕鬆投保汽車險＋享第一優惠，立即免費試立即省' 
WHERE WHD01='C' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '強制險,強制險優惠,強制責任險,強制險內容,汽車強制險多少錢,強制險理賠項目,強制險保險查詢' 
WHERE WHD01='C' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '汽車險線上試算享第一優惠輕鬆投保！網路投保強制險省360元，立即投保立即省。' 
WHERE WHD01='C' and WHD02='description';

--修改 機車險
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一網路投保專區】3分鐘輕鬆投保機車險＋第一優惠，立即免費試立即省' 
WHERE WHD01='M' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '強制險,強制險優惠,強制責任險,強制險內容,機車強制險多少錢,強制險理賠項目,強制險保險查詢' 
WHERE WHD01='M' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '機車險線上試算享第一優惠！網路投保機車強制險最高享優惠 245 元，立即免費試算立即省！' 
WHERE WHD01='M' and WHD02='description';


--修改 住火險
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一網路投保專區】住宅火險免登入試算，投保享第一優惠|第一保輕鬆選' 
WHERE WHD01='F' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '住宅火險、地震險、地震、颱風、淹水、房貸、第一產險' 
WHERE WHD01='F' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '網友口碑最推薦火險地震險選第一產險。推薦您一定要保住火險，無論是颱風、淹水或地震造成家中屋內損失，皆有保障，線上投保享第一優惠' 
WHERE WHD01='F' and WHD02='description';

--修改 旅平險
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一網路投保專區】旅平險享第一優惠│第一產險輕鬆保│快速試算' 
WHERE WHD01='TA' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '旅遊不便險、快速理賠、旅平險、線上投保、旅遊險推薦第一保' 
WHERE WHD01='TA' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '不用再比了！旅平險+保第一就夠了。自助旅行、全家出國、大人小孩都能保，快速試算立即享第一優惠' 
WHERE WHD01='TA' and WHD02='description';

--修改 海域險
UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '【第一網路投保專區】海域險為戶外活動添加完善保障享第一優惠│第一產險輕鬆保│快速試算' 
WHERE WHD01='SE' and WHD02='title';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '海域保險、線上投保推薦第一保' 
WHERE WHD01='SE' and WHD02='keyword';

UPDATE "FIRSTCRM"."KYCWHD" SET WHD03 = '推薦愛去海邊的你，線上投保第一享優惠，保費享85折，立即試算立即省！第一產物海域活動險提供浮潛、潛水、衝浪、游泳、水上摩托車、香蕉船等多項水上活動保障，出發前1小時即可投保！' 
WHERE WHD01='SE' and WHD02='description';













