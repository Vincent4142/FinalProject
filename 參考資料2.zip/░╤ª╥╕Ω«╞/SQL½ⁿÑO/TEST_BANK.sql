SELECT T1504,T1575 FROM FIRSTF.PT15PF@AS400 WHERE T1504='100009TA700283';



SELECT                                                             
TRIM(C201),TRIM(C202),TRIM(C203),TRIM(C205),TRIM(C206),TRIM(C210), 
TRIM(C213),TRIM(C231),TRIM(C233),TRIM(C248),TRIM(ZN04),
CASE WHEN TRIM(ZN04)='V' THEN '�_����'                           
  WHEN TRIM(ZN04)='W' THEN '�s�_����'                            
  WHEN TRIM(ZN04)='K' THEN '���̰�'                              
  WHEN TRIM(ZN04)='A' THEN '��˰�'                              
  WHEN TRIM(ZN04)='C' THEN '�x����'                              
  WHEN TRIM(ZN04)='N' THEN '���ūn'                              
  ELSE '' END AS AREADESC 
FROM FIRSTF.IC02PF@AS400 
LEFT JOIN FGFLIB.FBZNPF@AS400  ON TRIM(ZN01)=TRIM(C203) 
AND TRIM(ZN02)=SUBSTR(C202,1,4) 
WHERE TRIM(C203) ='F' AND TRIM(C233)='C021' 
AND C231>1090401



