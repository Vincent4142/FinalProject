--M201(分類代碼EX:B2-所屬群組 B4-職階),M202(代號),M203(代號的內容)
select M301,M303,M203,M205,M206,SUBSTR(M281,11,2)
from PSM3PF 
left join PSM2PF on M303=M202
where M201='A1' and M301=47117;

select M301,M305,M203
from PSM3PF
left join PSM2PF on M305=M202
where M201='A5' and M301=47117;

select M301,M203
from PSM3PF
left join PSM2PF on M333=M206
where M301=47117 and M201='B2' and M202 =1;

select B.M301,A.M203 from PSM2PF A
left join (select M301,M303,M203,M205,M206,SUBSTR(M281,11,2) CODE 
from PSM3PF 
left join PSM2PF on M303=M202
where M201='A1' and M301=47117) B 
on A.M201=B.M205 and A.M202=B.CODE
where A.M201='B2' and A.M202=1;