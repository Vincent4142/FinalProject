--���عO��
SELECT lpt02,lde02, 
sum(case when floor(com_lptt.crtdt / 10000) = 109 then 1 else 0 end) LAWCNT1, 
sum(case when floor(com_lptt.crtdt / 10000) = 110 then 1 else 0 end) LAWCNT2, 
sum(case when floor(com_lptt.crtdt / 10000) = 111 then 1 else 0 end) LAWCNT3, 
sum(case when floor(com_lptt.crtdt / 10000) = 112 then 1 else 0 end) LAWCNT4, 
sum(case when floor(com_lptt.crtdt / 10000) = 113 then 1 else 0 end) LAWCNT5 
FROM com_lptt inner join com_ldep on lpt02 = lde01
left join com_lpdelog on lpt01=com_lpdelog.lpd01
left join com_lpde on lpt01=com_lpde.lpd01
WHERE LPT05 = 'Y' and (case when lpt07 = 0 then case when lpt06 < 1090826 then 1 else 0 end else case when lpt06 < lpt07 then 1 else 0 end end = 1) 
and com_lptt.crtdt between 1090801 and 1090826 
and lpt02 like 10
and (com_lpdelog.lpd07 <> 'N' or com_lpde.lpd07 is null or com_lpde.lpd07 ='Y')
Group By lpt02, lde02 Order By lpt02;

--�ץ�O��
SELECT com_lpde.lpd02,lde02, 
sum(case when floor(com_lman.crtdt / 10000) = 109 then 1 else 0 end) LAWCNT1, 
sum(case when floor(com_lman.crtdt / 10000) = 110 then 1 else 0 end) LAWCNT2, 
sum(case when floor(com_lman.crtdt / 10000) = 111 then 1 else 0 end) LAWCNT3, 
sum(case when floor(com_lman.crtdt / 10000) = 112 then 1 else 0 end) LAWCNT4, 
sum(case when floor(com_lman.crtdt / 10000) = 113 then 1 else 0 end) LAWCNT5 
FROM com_lman INNER JOIN com_lpde ON lma01 = com_lpde.lpd01 inner join com_ldep on com_lpde.lpd02 = lde01 
left join com_lpdelog on com_lpde.lpd01=com_lpdelog.lpd01 
WHERE (case when (com_lpde.LPD08 is null or com_lpde.LPD08 = 0) then case when LMA09 < 1090819 then 1 else 0 end else case when LMA09 < com_lpde.LPD08 then 1 else 0 end end = 1) 
and com_lman.crtdt between 1090801 and 1090826 
and com_lpde.lpd02 like 10 
and (com_lpdelog.lpd07 <> 'N' or com_lpde.lpd07 is null or com_lpde.lpd07 ='Y')
group By com_lpde.lpd02,lde02 Order By com_lpde.lpd02;


--���عO������
SELECT lpt01, lma06, lpt05, lpt06, lpt07, lpt08, secaz.codedesc as sendItem, secaz1.codedesc AS viewItem 
FROM com_lptt INNER JOIN com_lman ON lpt01 = lma01 
INNER JOIN secaz secaz1 ON lpt03 = secaz1.codetype AND lpt04 = secaz1.codeid 
INNER JOIN secaz ON secaz1.codetype = secaz.codeid
left join com_lpdelog on lpt01=com_lpdelog.lpd01
left join com_lpde on lpt01=com_lpde.lpd01
WHERE lpt05 = 'Y' AND CASE WHEN lpt07 = 0 THEN CASE WHEN lpt06 < 1090826 THEN 1 ELSE 0 END ELSE CASE WHEN lpt06 < lpt07 THEN 1 ELSE 0 END END = 1 
AND floor(com_lptt.crtdt / 10000) = 109 AND com_lptt.crtdt between 1090801 and 1090826 AND lpt02 = 10 AND secaz.codetype = 'COMPLIANCE'
and (com_lpdelog.lpd07 <> 'N' or com_lpde.lpd07 is null or com_lpde.lpd07 ='Y')
ORDER BY lpt01, lpt03, lpt04 ;


--�ץ�O������
SELECT lma01,lma06, lma09, case when com_lpde.lpd07='Y' then '�ŦX' else case when com_lpde.lpd07='N' then '�h��' else ' ' end end as lpd07, com_lpde.lpd08, com_lpde.lpd09 
FROM com_lman INNER JOIN com_lpde ON lma01 = com_lpde.lpd01
left join com_lpdelog on com_lpde.lpd01=com_lpdelog.lpd01 
INNER JOIN com_ldep on com_lpde.lpd02 = lde01 
WHERE (case when (com_lpde.LPD08 is null or com_lpde.LPD08 = 0 or com_lpde.lpd07 = 'N') then case when LMA09 < 1090826 then 1 else 0 end else case when LMA09 < com_lpde.LPD08 then 1 else 0 end end = 1) 
AND floor(com_lpde.crtdt / 10000) = 109 AND com_lpde.crtdt between 1090801 and 1090826 AND com_lpde.lpd02 like 10
and (com_lpdelog.lpd07 <> 'N' or com_lpde.lpd07 is null or com_lpde.lpd07 ='Y')
ORDER BY lma01;
