package com.asi.adm.ad1.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.models.ConfirmHandlerFac;
import com.asi.adm.ad1.models.IConfirmHandler;
import com.asi.common.GlobalKey;
import com.asi.common.dbo.DBO;
import com.asi.common.exception.AsiException;
import com.asi.common.security.UserInfo;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.common.util.MessageUtil;
import com.asi.common.util.StringUtil;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.common.utils.NCCCUtil;
import com.asi.kyc.wb1.actions.AS400Procedure;
import com.asi.kyc.wb1.forms.WB1M010f;
import com.hitrust.b2ctoolkit.b2cpay.B2CPayOther;
import com.kyc.inc.dao.TrimedMapHandler;

/**
 * <!--程式說明寫在此-->
 * 
 * @author ：sergio
 * @version ：$Revision: 1.11 $ $Date: 2006/11/08 03:58:08 $<br>
 *          <p>
 * 
 * <pre>
 *  存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/adm/com/asi/adm/ad1/actions/AD1M0801.java,v 1.11 2006/11/08 03:58:08 cvsuser Exp $  
 *  建立日期	：2006/8/24
 *  異動註記	： 2019/05/29 取消授權寄發email
 * </pre>
 * 
 * </p>
 */
public class AD1M0801 extends AsiAction
{

	private static Log logger = LogFactory.getLog(AD1M0801.class);;
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm f = (AsiActionForm) form;
		
		if (f.getActionCode() == 0)
		{
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType,
					DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			startDate += 1; // 查詢日期區間的起日從當月1日起

			request.setAttribute("strymd", String.valueOf(startDate));
			request.setAttribute("endymd", String.valueOf(sysDate));
			saveToken(request);

		}
	}
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		String number = request.getParameter("T1501C");
		String t15b9 = request.getParameter("T15B9");
		
		/** 是否有分險種的處理不同 */
		/** 取消授權->hitrust->更新KYCKLA.T1580-7.成功，8.失敗*/
		tx_controller.begin(0);
		
		if (isTokenValid(request,true))
		{
			if (form.getActionCode() == 20)
			{
				boolean isCancelOk = false;
				
				if(t15b9.equals("NCCC"))
				{
					isCancelOk = NCCCUtil.cancelAuth(request, number);
					
					if(!isCancelOk){
						String error = "聯信取消授權失敗，交易序號："+number;
						Logger.getLogger(this.getClass()).error(error);
						request.setAttribute("hitrustmsg", error);
						update80(request, number, "7");

					}
					else{
						request.setAttribute("hitrustmsg", "交易序號："+number+"，取消授權成功.");
						update80(request, number, "8");
					}
				}
				else{
					isCancelOk = cancelHitrustAuth(number);
					
					if (!isCancelOk)
					{
						String error = "Hitrust取消授權失敗，交易序號："+number;
						Logger.getLogger(this.getClass()).error(error);
						request.setAttribute("hitrustmsg", error);
						update80(request, number, "7");
					}
					else
					{
						request.setAttribute("hitrustmsg", "交易序號："+number+"，取消授權成功.");
						update80(request, number, "8");
					}	
				}
				
				//取消授權成功時，發送email通知
				if(isCancelOk)
				{										
					DBO kyckla = tx_controller.getDBO("kyc.KYCKLAs03", 0);
			        kyckla.addParameter("T1501", number);
			        kyckla.executeSelect();

					String t1502 = kyckla.getRecordData("T1502");//
					String ta1516 = kyckla.getRecordData("TA1516");
					
					//旅平險：寄發取消通知
					if(t1502.equals("TA")){
						String subject = "第一產物-旅平險審核結果通知";
						String resultword = "審核未通過！";
						String addword = "＊提醒您，本交易取消僅取消信用卡授權，不會進行扣款動作 </br>＊審核未通過可能為下列其一原因：1.已投保同業合計保額超過2500萬 2.已投保同業超過三間以上 3.要保人主動告知取消 4.其他核保因素";
						
						//寄客戶
						sendConfirmMail_TA(number, request , kyckla , kyckla.getRecordData("T1516") , subject , resultword , addword);
						//寄經辦窗口
						String maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
						String[] getauthemail = getEmailList(maillist);//取得人員email
						
						for (int i = 0; i < getauthemail.length; i++) {
							sendConfirmMail_TA(number, request , kyckla , getauthemail[i] , "第一產物-旅平險取消收件通報通知(" + ta1516 + ")" , resultword , addword);
						}

						//寄核保窗口
						String maillist_1 = CodeUtil.getCodeList(servlet, request, "TA-AUTHMAN");//代碼檔設定之核保人員
						String[] getauthemail_1 = getEmailList(maillist_1);//取得人員email
						
						for (int i = 0; i < getauthemail_1.length; i++) {
							sendConfirmMail_TA(number, request , kyckla , getauthemail_1[i] , "第一產物-旅平險取消收件通報通知(" + ta1516 + ")" , resultword , addword);
						}
					}
					//機汽車險
					else if(t1502.substring(0, 1).equals("C") || t1502.substring(0, 1).equals("M")) {
						//取得機汽車交易資料
						Map<?, ?> mp = getCarPt15pf(number);
						
						//寄發取消通知
						String subject = "第一產物-交易資料取消授權通知";
						
						String name = mp.get("T1506").toString();
						String carno = mp.get("T1610").toString();
						String t1523 = mp.get("T1523").toString();
						String t1516 = mp.get("T1516").toString();
						String t1541sum = mp.get("T1541SUM").toString();
						//姓名隱碼
						String name2 = mp.get("T1546").toString();
						StringBuffer hiddenName = new StringBuffer();
						for(int i=0;i<name2.length();i++){
							if(i==1){
								hiddenName.append("O");
							}
							else{
								hiddenName.append(name2.substring(i,i+1));
						   	}
						}
						String t1546 = hiddenName.toString();//要保人姓名
						
						//寄客戶
						sendCancelMail(number, request, t1546, carno, t1523 , t1541sum , t1516, subject);
						//寄經辦窗口
						String maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
						String[] getauthemail = getEmailList(maillist);//取得人員email
						
						for (int i = 0; i < getauthemail.length; i++) {
							sendCancelMail(number, request, t1546, carno, t1523 , t1541sum , getauthemail[i], subject);
						}
					}

				}
				
			}
			else if (form.getActionCode() == 21)
			{	/** 確認請款->hitrust->更新KYCKLA.T1580-5.成功，6.失敗 */
				// if成功 轉資料至PT15.....&更新狀態KYCKLA.T1580-4.訂單寫檔完成	
				
				if(t15b9.equals("NCCC"))//聯信刷卡
				{
					
					// updatePnumber---------------------------------
					DBO kyckla = tx_controller.getDBO("kyc.KYCKLAs03", 0);
					updatePnumber(request, number, kyckla);
					
					List<?> handlerList = ConfirmHandlerFac.getHandler(kyckla);
					for(int i=0;i<handlerList.size();i++)
					{
						IConfirmHandler handler = (IConfirmHandler) handlerList.get(i);
						handler.kycklaDbo = kyckla;
						// 新增保單檔IC02
						handler.modifyIC02(tx_controller,request);
						// 更新或新增客戶IC01
						if(i>0)
							continue;
						handler.modifyIC01(tx_controller,request);
					}
					
					KycklaTransfer.transferKL(tx_controller,number);
					update80(request, number, "4");

				}
				else{
					
					String retCode = confirmOrder(number);
//					String notifyNo = "";
					
					//本機測試用
//					retCode = "00";
					
					if (!retCode.equals("00"))
					{
						String error = "請款失敗，交易序號："+number+",returnCode："+retCode;
						Logger.getLogger(this.getClass()).error(error);
						request.setAttribute("hitrustmsg", error);
						update80(request, number, "5");
					}
					else
					{
						request.setAttribute("hitrustmsg", "交易序號："+number+"，確認請款成功.");
						update80(request, number, "6");
						
						// updatePnumber---------------------------------
						DBO kyckla = tx_controller.getDBO("kyc.KYCKLAs03", 0);
						updatePnumber(request, number, kyckla);
						
						List<?> handlerList = ConfirmHandlerFac.getHandler(kyckla);
						for(int i=0;i<handlerList.size();i++)
						{
							IConfirmHandler handler = (IConfirmHandler) handlerList.get(i);
							handler.kycklaDbo = kyckla;
							// 新增保單檔IC02
							handler.modifyIC02(tx_controller,request);
							// 更新或新增客戶IC01
							if(i>0)
								continue;
							handler.modifyIC01(tx_controller,request);
						}
						
						//旅平險確認時才進行通報寫檔作業，1070411決議改由前端執行
						
						String t1502 = kyckla.getRecordData("T1502");
						/**
						if(t1502.equals("TA")){
							//查詢被保險人明細資料
							DBO kyckld = tx_controller.getDBO("kyc.KYCKLDs01", 0);
							kyckld.addParameter("T1801", number);
							kyckld.execute();
							//進行收件通報寫檔作業
							notifyNo = getNotificationNo(request, number, kyckla , kyckld);
							//更新收件通報序號
							updateTA1516(request, number, notifyNo);							
						}
						*/
						
						KycklaTransfer.transferKL(tx_controller,number);
						update80(request, number, "4");
						
						//寄發核保完成通知
						if(t1502.equals("TA")){
							String subject = "第一產物-旅平險審核結果通知";
							String resultword = "恭喜您！審核通過！";
							
							//寄客戶
							sendConfirmMail_TA(number, request , kyckla , kyckla.getRecordData("T1516") , subject , resultword , "");
							//寄經辦窗口
							String maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
							String[] getauthemail = getEmailList(maillist);//取得核保人員email
							
							for (int i = 0; i < getauthemail.length; i++) {
								sendConfirmMail_TA(number, request , kyckla , getauthemail[i] , subject , resultword , "");
							}
												
						}
						
					}
				}
			}
			else if (form.getActionCode() == 25)//查詢前一天交易資料
			{			
				request.setAttribute("isCheck", "Y");
			}

		} 
		else 
		{
			saveToken(request);
		}

		DBO dbo = getKYCKL(request);
		
		//記錄kycllog處理
		doKycllog(request, form, dbo, number , t15b9);
		
		request.setAttribute("dbo", dbo);
		saveToken(request);
		
		form.setNextPage(1);
	}

    private Map<?, ?> getCarPt15pf(String t1501)
    {
		Map<?, ?> data = null;
		
    	StringBuffer sql = new StringBuffer();
    	sql.append("SELECT T1501,T1546,T1506,T1516,T1523,T1610,SUM(T1541) T1541SUM FROM KYCKLA  ");
    	sql.append("LEFT JOIN KYCKLB ON T1601=T1501 AND T1602=T1502 AND T1603=T1503 ");
    	sql.append("WHERE T1501=? ");
    	sql.append("GROUP BY T1501,T1546,T1506,T1516,T1523,T1610");

    	String args[] = new String[1];
    	args[0] = t1501;
		
 		tx_controller.begin(0);
		try
		{
 			QueryRunner runner = new QueryRunner();
 			data = (Map<?, ?>) runner.query(tx_controller.getConnection(0) , sql.toString(), args,  new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return data;  	
    }

	
	/**
	 * 寫入KYCLLOG記錄檔處理
	 * @param request
	 * @param form
	 * @param dbo
	 * @param number
	 * @param t15b9
	 */
	private void doKycllog( HttpServletRequest request ,  AsiActionForm form , DBO dbo , String number , String t15b9){

		UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
		String urid = ui.getUserId();

		String ll01 = this.getClass().getSimpleName();
		String ll02 = form.getSource();
		String ll03 = "請款確認與取消授權作業";
		String ll04 = "B";
		String ll05 = urid;
		String ll09 = "";
		String ll17 = "S";
		String ll19 = "資料查詢";
		String ll20 = "";
		
		try {
			if(form.getActionCode() == 20 ){
				ll17 = "U";
				ll09 = number;
				ll19 = "信用卡取消授權";
				if(t15b9.equals("NCCC"))
					ll20 = "傳至NCCC聯合信用卡取消授權";
				else
					ll20 = "傳至Hitrust網際威信取消授權";
				
			}else if (form.getActionCode() == 21){
				ll17 = "U";
				ll09 = number;
				ll19 = "信用卡確認請款";	
				if(t15b9.equals("NCCC"))
					ll20 = "網路投保資料確認寫檔，尚需至NCCC請款";
				else
					ll20 = "傳至Hitrust網際威信確認請款";
			}
			else {
				ll20 = dbo.getAssembledSQL();
			}
			
			KycLogger klg = new KycLogger();
			klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, "", "", "", "", "", ll17, "", ll19, ll20, "", "", "", "");
			
		} catch (AsiException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 取出核保人員及主管email
	 * @param list
	 * @return
	 */
	private String[] getEmailList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		tx_controller.begin(0);
		Connection conn = tx_controller.getConnection(0);
		List<?> rs = null;
		String[] email = null;

		try
		{
			QueryRunner runner = new QueryRunner();
			rs = (List<?>) runner.query(conn, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map<?, ?> m = (Map<?, ?>) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return email;
	}


	/**
	 * 取得收件通報序號，寫入通報主檔/明細檔，並回傳通報序號
	 * @param request
	 * @param insno
	 * @param dbo1
	 * @param dbodetail
	 * @return
	 * @throws AsiException
	 */
	private String getNotificationNo(HttpServletRequest request , String insno , DBO dbo1 , DBO dbodetail) throws AsiException
	{
		String result = "";//通報序號
		
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		Connection con = AS400Connection.getConnection();
		AS400Procedure prc = new AS400Procedure();

		String s329i1 = "C";//資料來源
		String s329i2 = "99";//區域別
		String s329i3 = "99";//通路別
		// 收件通報序號
		String pf01 = "";

		try {

			pf01 = prc.callEPSU329PRC(con, s329i1, s329i2, s329i3, sysdate);
			String pf04 = getT4003(con, dbo1.getRecordData("T1519"));
			String pf05 = "";
			String pf06 = dbo1.getRecordData("T1523").toString();//要保日／收件日
			String pf07 = dbo1.getRecordData("T1518").toString();//到期日
			String pf08 = dbo1.getRecordData("T1546").toString();//要保人
			String pf09 = dbo1.getRecordData("T1547").toString();//要保人ID
			
			String pf10 = getIdNationSex(pf09)[0];//要保人身份
			String pf11 = getIdNationSex(pf09)[1];//要保人性別
			String pf12 = dbo1.getRecordData("T1554").toString();//要保人生日
		
			String pf19 = "3";//類別：1 個傷 2 團傷 3 旅平 4 健康 5 微型
			String pf20 = "01";//保單狀況：01: 有效 ,06: 契約撤銷 ,12: 鍵值欄位通報錯誤 ,15: 通報更正
			String pf23 = s329i1;
			String pf24 = "";//保經代分類

			String pf13 = dbodetail.getRecordData(1, "T1807").toString();//被保險人姓名
			String pf14 = dbodetail.getRecordData(1, "T1808").toString();//被保險人身份證號
			String pf15 = getIdNationSex(pf14)[0];//被保險人身份
			String pf16 = dbodetail.getRecordData(1, "T1809").toString();//被保險人出生日期
			String pf17 = getIdNationSex(pf14)[1];//被保險人性別
			
			String t1548 = dbo1.getRecordData("T1548").toString();//要被保人關係
			String pf18 = "";//要被保人關係
			
			if(t1548.equals("0"))
				pf18 = "01";//本人
			else if(t1548.equals("2"))
				pf18 = "02";//配偶
			else if(t1548.equals("3") || t1548.equals("B"))
				pf18 = "03";//父母
			else if(t1548.equals("A"))
				pf18 = "04";//子女
			else
				pf18 = "05";//其他
			
			String pf21 = insno;//受理編號，用交易序號
			
			int insertCount = 0;
			//寫入檔案FGFLIB/EPB501PF(傷健險收件通報作業主檔)
			insertCount = insertCount + insertEPB501PF(request, con, pf01, pf04, pf05, pf06, pf07, pf08, pf09, pf10, pf11, pf12, pf13, pf14, pf15, pf16, pf17, pf18, pf19, pf20, pf21, pf23, pf24);

			String pf205 = "";
			String pf206 = "";
			String pf207 = "";
			String pf208 = "";
			String pf209 = "";
			String pf210 = "0";//死殘保額
			String pf211 = "0";//傷害醫療限額
			String pf212 = "0";//傷害住院日額
			String pf213 = "0";//重大疾病保額
			String pf214 = "0";//住院醫療保額
			String pf215 = "0";//健康住院日額
			String pf216 = "0";//防癌保額
			String pf217 = "";//保單號碼
			
			int datasize = dbodetail.getRecordCount();
			for (int i = 1; i <= datasize; i++) // dbo recordcount 從1開始
			{
				pf205 = dbodetail.getRecordData(i, "T1807");//被保險人姓名
				pf206 = dbodetail.getRecordData(i, "T1808");//被保險人id
				pf207 = getIdNationSex(pf206)[0];//被保險人身份
				pf208 = dbodetail.getRecordData(i, "T1809");//被保險人生日
				pf209 = getIdNationSex(pf206)[1];//被保險人性別
				pf210 = dbodetail.getRecordData(i, "T1825");//死殘保額
				pf211 = dbodetail.getRecordData(i, "T1826");//傷害醫療限額
				
				//寫入檔案FGFLIB/EPB502PF(傷健險收件通報作業明細檔)
				insertCount = insertCount + insertEPB502PF(request, con, pf01, String.valueOf(i), pf205, pf206, pf207, pf208, pf209, pf210, pf211, pf212, pf213, pf214, pf215, pf216, pf217);
			}
			
			//新增筆數與查詢總筆數不同時，刪除收件通報資料，並傳出空白收件序號
			if(insertCount != (datasize + 1))
			{
				//清除未新增完整資料筆數
				deleteEPB501PF(con, pf01);
				deleteEPB502PF(con, pf01);
				result = "";
			}else{
				result = pf01;
			}
					
		} catch (Exception e) {
			//錯誤時直接刪除400資料
			deleteEPB501PF(con, pf01);
			deleteEPB502PF(con, pf01);

			e.printStackTrace();
		} finally{
			AS400Connection.closeConnection(con);
		}

		return result;
	}
	
	/**
	 * 傳入id取得本國外國籍代號、性別英文代號
	 * @param id
	 * @return [0]：本國外國籍代號 [1]：性別英文代號
	 */
	public String[] getIdNationSex(String id){
		String[] result = new String[2];
		
		if("ABCD89".indexOf(id.substring(1, 2)) != -1)
			result[0] = "C";//外國人							
		else
			result[0] = "A";//本國人
			
		if("BD29".indexOf(id.substring(1, 2)) != -1)
			result[1] ="F";//女性
		else
			result[1] ="M";//男性

		return result;
	}
	
		
	/**
	 * 取得通路代碼
	 * @param con
	 * @param t4002
	 * @return
	 * @throws AsiException
	 */
	private String getT4003(Connection con , String t4002) throws AsiException
	{

		String t3905 = null;
		String t4003sql = "SELECT T4003 FROM PT40PF WHERE T4001= 'E' AND T4002 = ? ";

		QueryRunner run = new QueryRunner();
		Map<?, ?> m = null;
		try
		{
			m = (Map<?, ?>) run.query(con , t4003sql, t4002, new MapHandler());
			t3905 = m.get("T4003").toString();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		if(t3905==null)
			throw new AsiException("無法取得通路類別!");
		
		return t3905;	
	}


	
	
	public int insertEPB501PF(HttpServletRequest request,Connection con,String pf01,String pf04,String pf05,String pf06,String pf07,String pf08,String pf09,String pf10,String pf11
			,String pf12,String pf13,String pf14,String pf15,String pf16,String pf17,String pf18,String pf19,String pf20,String pf21,String pf23,String pf24)
	{
		HttpSession session = request.getSession(false);
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		
		String userid = ui.getUserId();
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = "INSERT INTO EPB501PF( "
			+"PF01,PF02,PF03,PF04,PF05,PF06,PF07,PF08,PF09,PF10 "
			+",PF11,PF12,PF13,PF14,PF15,PF16,PF17,PF18,PF19,PF20 "
			+",PF21,PF22,PF23,PF24,PF70,PF71,PF72,PF73,PF74,PF75"
			+",PF90,PF91,PF92,PF94,PF95,PF96,PF97,PF98,PF99)VALUES"
			+"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String[] param = new String[39];
		param[0] = pf01;//收件通報序號
		param[1] = "01";//次數
		param[2] = "";//保經代公司代碼
		param[3] = pf04;//通路代號
		param[4] = pf05;//商品／專案代號
		param[5] = pf06;//要保日／收件日
		param[6] = pf07;
		param[7] = pf08;
		param[8] = pf09;
		param[9] = pf10;
		param[10] = pf11;
		param[11] = pf12;
		param[12] = pf13;
		param[13] = pf14;
		param[14] = pf15;//被保人身份別
		param[15] = pf16;//被保險人出生日期
		param[16] = pf17;//被保險人性別
		param[17] = pf18;//要／被保人關係
		param[18] = pf19;//類別 1 個傷 2 團傷 3 旅平 4 健康 5 微型
		param[19] = pf20;//保單狀況,01: 有效 ,06: 契約撤銷 ,12: 鍵值欄位通報錯誤 ,15: 通報更正
		param[20] = pf21;//受理編號
		param[21] = "NTD";//幣別
		param[22] = pf23;//來源,A: 保經代自建系統,B: 關貿,C: 本公司 WEB,D: AS/400,E: KYC
		param[23] = pf24;//保經代分類,97: 保險公司代通報,98: 保經代健康險 ( 補傷害醫療及健康險 ),99: 保經代壽險與傷害險 ( 自行通報件 )
		param[24] = sysdate;//通報日期
		param[25] = systime;//通報時間
		param[26] = "KYCB2C";//通報人員
		param[27] = "";//KYC 通報檔名
		param[28] = "NB";//類型
		param[29] = "";//保單號碼
		param[30] = "0";//轉檔日期
		param[31] = "0";//轉檔時間
		param[32] = "";//轉檔人員
		param[33] = systime;
		param[34] = systime;
		param[35] = sysdate;
		param[36] = userid;
		param[37] = sysdate;
		param[38] = userid;
		
		int ret =0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, param);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}

	/**
	 * 刪除傷健險收件通報作業主檔資料檔
	 * @param con
	 * @param pf01 收件通報序號
	 * @return
	 */
	public int deleteEPB501PF(Connection con,String pf01)
	{
		int ret = 0;
		String sql = "DELETE FROM EPB501PF WHERE PF01=?";
		
		QueryRunner runner = new QueryRunner();
		try
		{
			ret = runner.update(con, sql, pf01);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 新增傷健險收件通報作業明細資料檔
	 * @param con
	 * @param pf201 收件通報序號
	 * @param pf204 編號
	 * @param pf205 被保險人姓名
	 * @param pf206 被保險人身份證號
	 * @param pf207 被保險人身份
	 * @param pf208 被保險人出生日期
	 * @param pf210 死殘保額
	 * @param pf211 傷害醫療限額
	 * @param pf212 傷害住院日額
	 * @param pf213 重大疾病保額
	 * @param pf214 住院醫療保額
	 * @param pf215 健康住院日額
	 * @param pf216 防癌保額
	 * @param pf217保單號碼
	 * @return
	 */
	public int insertEPB502PF(HttpServletRequest request , Connection con,String pf201,String pf204,String pf205,String pf206,String pf207,String pf208,String pf209,String pf210
			,String pf211,String pf212,String pf213,String pf214,String pf215,String pf216,String pf217)
	{
		HttpSession session = request.getSession(false);
		UserInfo ui = (UserInfo) session.getAttribute(GlobalKey.USER_INFO);
		
		String userid = ui.getUserId();
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		
		String sql = "INSERT INTO EPB502PF( "
			+"PF201,PF202,PF203,PF204,PF205,PF206,PF207,PF208,PF209,PF210 "
			+",PF211,PF212,PF213,PF214,PF215,PF216,PF217 "
			+",PF294,PF295,PF296,PF297,PF298,PF299) "
			+"VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		String[] param = new String[23];
		param[0] = pf201;//收件通報序號
		param[1] = "01";//次數
		param[2] = "0";//組別
		param[3] = pf204;//編號
		param[4] = pf205;//被保險人姓名
		param[5] = pf206;//被保險人身份證號
		param[6] = pf207;//被保險人身份
		param[7] = pf208;//被保險人出生日期
		param[8] = pf209;//被保險人性別
		param[9] = pf210;//死殘保額
		param[10] = pf211;//傷害醫療限額
		param[11] = pf212;//傷害住院日額
		param[12] = pf213;//重大疾病保額
		param[13] = pf214;//住院醫療保額
		param[14] = pf215;//健康住院日額
		param[15] = pf216;//防癌保額
		param[16] = pf217;//保單號碼
		param[17] = systime;
		param[18] = systime;
		param[19] = sysdate;
		param[20] = userid;
		param[21] = sysdate;
		param[22] = userid;
		
		int ret =0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, param);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return ret;
	}
	
	/**
	 * 刪除傷健險收件通報作業明細資料檔
	 * @param con
	 * @param pf201 收件通報序號
	 * @return
	 */
	public int deleteEPB502PF(Connection con,String pf201)
	{
		int ret = 0;
		String sql = "DELETE FROM EPB502PF WHERE PF201=?";
		
		QueryRunner runner = new QueryRunner();
		try
		{
			ret = runner.update(con, sql, pf201);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 寄發請款&核保確認信_旅平險
	 * @param number		交易序號
	 * @param request
	 * @param kyckla		查詢結果dbo
	 * @param targetemail	寄發email
	 * @param subject		主旨
	 * @param resultword	審核結果文字
	 */
	private void sendConfirmMail_TA(String number , HttpServletRequest request , DBO kyckla , String targetemail , String subject , String resultword , String addword) 
	{
        KycMailUtil sender = new KycMailUtil();
        sender.setSubject(subject);
        BufferedReader fr;
        String path = getServlet().getServletContext().getRealPath("/mail/travelInsurancesConfirmOK.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", kyckla.getRecordData("T1546"));
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{insName\\}", "旅平險");
        String t1523 = kyckla.getRecordData("T1523");
        String stry = t1523.substring(0, 3);
        String strm = t1523.substring(3, 5);
        String strd = t1523.substring(5, 7);
        msg = msg.replaceAll("\\{stry\\}", stry);
        msg = msg.replaceAll("\\{strm\\}", strm);
        msg = msg.replaceAll("\\{strd\\}", strd);
        msg = msg.replaceAll("\\{resultword\\}", resultword);
        msg = msg.replaceAll("\\{addword\\}", (addword != null && !addword.equals("")) ? addword : "");
            
        sender.setMessage(msg);
        sender.addTo(targetemail);
        sender.sendMail();
	}

	/**
	 * @param number
	 * @param request
	 * @param kyckla
	 * @param targetemail
	 * @param subject
	 * @param resultword
	 * @param addword
	 */
	private void sendCancelMail(String number , HttpServletRequest request , String name , String carno ,String t1523, String t1541sum, String targetemail , String subject ) 
	{
        KycMailUtil sender = new KycMailUtil();
        sender.setSubject(subject);
        BufferedReader fr;
        String path = getServlet().getServletContext().getRealPath("/mail/TransactionCancel.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", name);
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{carno\\}", carno);
        msg = msg.replaceAll("\\{t1501\\}", number);
        msg = msg.replaceAll("\\{t1523\\}", t1523);
        msg = msg.replaceAll("\\{t1541sum\\}", t1541sum);
        String stry = t1523.substring(0, 3);
        String strm = t1523.substring(3, 5);
        String strd = t1523.substring(5, 7);
        msg = msg.replaceAll("\\{stry\\}", stry);
        msg = msg.replaceAll("\\{strm\\}", strm);
        msg = msg.replaceAll("\\{strd\\}", strd);
            
        sender.setMessage(msg);
        sender.addTo(targetemail);
        sender.sendMail();
	}
	
	private void sendConfirmMail(String number , HttpServletRequest request) 
	{

		KycMailUtil sender = new KycMailUtil();
        sender.setSubject(MessageUtil.getMessage(getServlet() , request , "WB1M010.remark114"));

        BufferedReader fr;
        String path = getServlet().getServletContext().getRealPath("/mail/motorInsurancesConfirmOK.html");

        StringBuffer linebf = new StringBuffer();
        try {
            fr = new BufferedReader(new InputStreamReader(
                    new FileInputStream(path), "UTF-8"));
            String line;
            linebf = new StringBuffer();
            line = fr.readLine();
            while (line != null) {
                linebf.append(line);
                line = fr.readLine();
            }

        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        WB1M010f mform = (WB1M010f) request.getSession().getAttribute("WB1M010f");
        
        String msg = linebf.toString();
        msg = msg.replaceAll("\\{name\\}", mform.getKyc_T1506());
        msg = msg.replaceAll("\\{serialnum\\}", number);
        msg = msg.replaceAll("\\{total\\}", FormatUtil.getDecimalFormat(Double.parseDouble(mform.getTotal()), 0));
        msg = msg.replaceAll("\\{discount\\}", FormatUtil.getDecimalFormat(Double.parseDouble(mform.getDiscount()), 0));
        if (mform.getTotal().equals(mform.getDiscount())) {
            msg = msg.replaceAll("\\{showdiscount\\}", "none");
        }
        msg = msg.replaceAll("\\{type\\}", mform.getType());
        msg = msg.replaceAll("\\{carKind\\}", mform.getCARKIND());

        msg = msg.replaceAll("\\{stry\\}", mform.getYear());
        msg = msg.replaceAll("\\{strm\\}", mform.getMonth());
        msg = msg.replaceAll("\\{strd\\}", mform.getDate());
        msg = msg.replaceAll("\\{endy\\}", mform.getYear2());
        msg = msg.replaceAll("\\{endm\\}", mform.getMonth2());
        msg = msg.replaceAll("\\{endd\\}", mform.getDate2());
        
        msg = msg.replaceAll("\\{time\\}", "十二");
        
        sender.setMessage(msg);
        sender.addTo(mform.getKyc_T1516());
        sender.sendMail();

	}

	
	/**
	 * @param request
	 * @param number 保單號碼
	 * @param kyckla 
	 * @throws AsiException
	 */
	private void updatePnumber(HttpServletRequest request, String number, DBO kyckla) throws AsiException
	{
        kyckla.addParameter("T1501", number);
        kyckla.executeSelect();
        
        String pNumber = null;
        
        for (int i = 1; i <= kyckla.getRecordCount(); i++) {
        	String t1503= kyckla.getRecordData(i,"T1503");
        	if(t1503.equals("F"))
			{
				//是否同意自動續保，保單號碼由 由60001開始編,ex.100003RCY60001,1000區域別、03年度、RCY類別、600001序號
				if("Y".equals(kyckla.getRecordData("T15A9")))
					pNumber = Number.getNumber_F_RE(servlet, request);
				else
					pNumber = Number.getNumber_F(getServlet(), request, "P");
				
				DBO updKLA = tx_controller.getDBO("kyc.KYCKLAu05", 0);
				updKLA.addParameter("T1501", number);
				updKLA.addParameter("T1504", pNumber);
				updKLA.execute();
	            
	            kyckla.addRecordData("T1504", pNumber);
			}
			else if(t1503.equals("O"))
			{
				if(kyckla.getRecordData("T1502").equals("TA"))//旅平
					pNumber = Number.getNumber_O("TA",getServlet(), request, "P");
				else if(kyckla.getRecordData("T1502").equals("PA600"))//傷害
					pNumber = Number.getNumber_O("IP",getServlet(), request, "P");
				else if(kyckla.getRecordData("T1502").equals("PA1000"))//傷害
					pNumber = Number.getNumber_O("IP2",getServlet(), request, "P");
				
				DBO updKLA = tx_controller.getDBO("kyc.KYCKLAu05", 0);
				updKLA.addParameter("T1501", number);
				updKLA.addParameter("T1504", pNumber);
				updKLA.execute();
	            
	            kyckla.addRecordData("T1504", pNumber);
	
	            //更新招攬人為登入人員
				DBO updKLA_agentno = tx_controller.getDBO("kyc.KYCKLAu07", 0);
				updKLA_agentno.addParameter("T1501", number);
				UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
				updKLA_agentno.addParameter("T1520", ui.getUserId());
				updKLA_agentno.execute();
	
			} 
        }
	}

	/**
	 * 確認請款
	 * @param number
	 * @return
	 * @throws AsiException
	 */
	private String confirmOrder(String number) throws AsiException
	{
//		return "00";
		B2CPayOther trx1 = new B2CPayOther();
		trx1.setStoreId(SystemParam.getParam("STOREID"));
		trx1.setType(trx1.CAPTURE);
		trx1.setOrderNo(number);
		DBO sum = tx_controller.getDBO("kyc.PT15PFs99", 0);
		sum.addParameter("T1501", number);
		sum.execute();
		String total = sum.getRecordData("T1541");
		total = String.valueOf(Integer.parseInt(total)*100);
		trx1.setAmount(total);//總應收保費
		trx1.setQueryFlag("1");
		trx1.transaction();
		B2CPayOther trx = trx1;
		
		return trx.getRetCode();
	}

	/**
	 * 更新交易狀態
	 * @param request
	 * @param number
	 * @param orderstate 交易狀態KL80
	 * @throws AsiException
	 */
	private void updateTA1516(HttpServletRequest request, String number, String TA1516) throws AsiException
	{
		DBO upd = tx_controller.getDBO("kyc.KYCKLAu08",0);
		upd.addParameter("TA1516",TA1516);
		upd.addParameter("T1501", number);
		upd.execute();
	}

	/**
	 * 更新交易狀態
	 * @param request
	 * @param number
	 * @param orderstate 交易狀態KL80
	 * @throws AsiException
	 */
	private void update80(HttpServletRequest request, String number, String orderstate) throws AsiException
	{
		DBO upd = tx_controller.getDBO("kyc.KYCKLAu04",0);
		upd.addParameter("T1580",orderstate);
		upd.addParameter("T1598", DateUtil.getSysDate(DateUtil.ChType,DateUtil.Format_YYYYMMDD, false));
		UserInfo ui = (UserInfo) request.getSession(false).getAttribute(GlobalKey.USER_INFO);
		upd.addParameter("T1599", ui.getUserId());
		upd.addParameter("T1501", number);
		upd.execute();
	}

	/**
	 * 取消Hitrust授權
	 * @param number
	 * @return
	 */
	private boolean cancelHitrustAuth(String number)
	{
		boolean result = false;
		
		B2CPayOther b2cPayOther = new B2CPayOther();
		b2cPayOther.setStoreId(SystemParam.getParam("STOREID"));
		b2cPayOther.setType(b2cPayOther.RE_AUTH);// 取消授權
		b2cPayOther.setOrderNo(number);
		b2cPayOther.setQueryFlag("1");
		b2cPayOther.transaction();

		String retCode = b2cPayOther.getRetCode();
		
		if(retCode.equals("00"))
			result = true;
		
		return result;
	}

	/**
	 * @param request
	 * @return
	 * @throws AsiException
	 */
	private DBO getKYCKL(HttpServletRequest request) throws AsiException
	{
		String t1501 = request.getParameter("T1501");
		String t1580 = request.getParameter("T1580");
		String t1507 = request.getParameter("T1507");
		String t1610 = request.getParameter("T1610");
		String t1503 = request.getParameter("T1503");
		String t15b0 = request.getParameter("T15B0");
		String t15c4 = request.getParameter("T15C4");
		String t15b9 = request.getParameter("T15B9s");
		String kd19 = request.getParameter("KD19");
		String conditionsDay = request.getParameter("conditionsDay");
		
		DBO dbo = tx_controller.getDBO("kyc.KYCKLAs01", 0);
		StringBuffer where = new StringBuffer("  ");
		if ("T1523".equals(conditionsDay)){
			//交易日期
			where.append("WHERE KYCKLA.T1523 BETWEEN ");
			where.append(request.getParameter("T1523s"));
			where.append(" AND ").append(request.getParameter("T1523e"));
		} else {
			//確認日期
			where.append("WHERE PT15PF.T1524 BETWEEN ");
			where.append(request.getParameter("T1524s"));
			where.append(" AND ").append(request.getParameter("T1524e"));
		}
		
		
		//交易序號
		if (!t1501.equals("")) {
			where.append(" AND KYCKLA.T1501='").append(t1501).append("'");
		}
		//刷卡狀態
		if (!t1580.equals("0")) {
			where.append(" AND KYCKLA.T1580='").append(t1580).append("'");
		}
		//客戶別
		if (!t15b0.equals("0")) {
			where.append(" AND KYCKLA.T15B0='").append(t15b0).append("'");
		}
		//被保險人字號或統編
		if (!t1507.equals("")) {
			where.append(" AND KYCKLA.T1507='").append(t1507).append("'");
		}
		//車牌號碼
		if (!t1610.equals("")) {
			where.append(" AND t1610 like '%").append(t1610).append("%'");
		}
		//險別
		if (!t1503.equals("0"))
			where.append(" AND KYCKLA.t1503 = '").append(t1503).append("'");
		//電訪狀況
		if (!t15c4.equals("0"))
		{
			if(t15c4.equals("Y"))
				where.append(" AND t15c4 = '").append(t15c4).append("'");
			else if(t15c4.equals("N"))
				where.append(" AND t15c4 IS NULL ");
		}		
		//刷卡來源
		if (!t15b9.equals("0"))
			where.append(" AND t15b9 = '").append(t15b9).append("'");
		//進件來源
		if (!kd19.equals("0"))
			where.append(" AND kd19 = '").append(kd19).append("'");
		
        
		dbo.addParameter("WHERE", where.toString());
		dbo.execute();
		
		System.out.println(dbo.getAssembledSQL());

		for (int i = 1; i <= dbo.getRecordCount(); i++) {
			String T1503 = dbo.getRecordData(i, "T1503");
			dbo.addRecordData(i, "T1503D", CodeUtil.getCodeDesc(getServlet(), request, "KIND",T1503 ));
			String T1577 = dbo.getRecordData(i, "T1577");
			dbo.addRecordData(i, "T1577D", CodeUtil.getCodeDesc(getServlet(), request, "YN",T1577 ));
			String T1580 = dbo.getRecordData(i, "T1580");
			dbo.addRecordData(i, "T1580D", CodeUtil.getCodeDesc(getServlet(), request, "ORDERSTATE",T1580 ));
			
			//註冊顯示時間
			if(dbo.getRecordData(i, "RG15") != null && !dbo.getRecordData(i, "RG15").equals("")){
				String rg15 = StringUtil.fillPre(dbo.getRecordData(i, "RG15"), 6, '0');
				String rg15_format = rg15.substring(0, 2) + ":" + rg15.substring(2, 4) + ":" + rg15.substring(4, 6);
				dbo.addRecordData(i, "RG15D", rg15_format);
			}
			else
				dbo.addRecordData(i, "RG15D", "");
			//電子保單選項
			String T1575 = dbo.getRecordData(i, "T1575") != null ? dbo.getRecordData(i, "T1575") : "N";
			if(T1575.equals("Y"))
				dbo.addRecordData(i, "T1575D", "電子");
			else
				dbo.addRecordData(i, "T1575D", "紙本");
		}
        
		return dbo;
	}
    /**
	 * 關閉資料物件
	 * @param stmt
	 * @param rs
	 */
	public static void closeResultSet(ResultSet rs,Statement stmt){
		if (rs != null) {
			try {				
				rs.close();
				stmt.close();
			}catch(SQLException sqle){
				logger.error("取投保內容(PT17PF)資料時發生錯誤",sqle);    
			}
		}	
	}
	
}
