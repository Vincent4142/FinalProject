select * from KYCLCA where LCA04='08IP900005';

--LCA12 要保人郵遞區號 400轉出的TXT檔有值，在KYC保單管理系統(傷健險續保明細上傳)上傳後寫入KYCLCA也有值
--LCA13 要保人通訊地址



--LCA16 被保人郵遞區號 400轉出的TXT檔沒有資料，在KYC保單管理系統(傷健險續保明細上傳)上傳後寫入KYCLCA當然是NULL
--LCA17 被保人通訊地址