/*
 *
 * Copyright (c) 2000-2004 Asgard System, Inc. 
 * Taipei, Taiwan. All rights reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * Asgard System, Inc. ("Confidential Information").  You shall not 
 * disclose such Confidential Information and shall use it only in 
 * accordance with the terms of the license agreement you entered into 
 * with Asgard. 
 * 
 */
package com.kyc.sec.actions;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * <!--程式說明寫在此-->
 * 
 * @author ：Sergio_Huang
 * @version ：$Revision: 1.2 $ $Date: 2006/11/16 06:59:34 $<br>
 *          存放路徑 ：$Header:
 *          D:/CVSRepository/Financial/KYC/KYC/JavaSource/sec/com/kyc/sec/actions/DupLoginAction.java,v
 *          1.3 2005/07/19 07:25:29 Sergio_Huang Exp $ 建立日期 ：2005/7/13 異動註記 ：
 *          2020/05/06 VSG 增加檢核密碼錯誤3次產生OTP機制，並將暫存OTP記錄至KYKLLOG
 */
public class DupLoginAction extends AsiAction {

	
    /**
     * @see com.asi.common.struts.AsiAction#doProcess(org.apache.struts.action.ActionMapping,
     *      com.asi.common.struts.AsiActionForm,
     *      javax.servlet.http.HttpServletRequest,
     *      javax.servlet.http.HttpServletResponse)
     * 
     * @param arg0
     * @param arg1
     * @param arg2
     * @param arg3
     * @throws com.asi.common.exception.AsiException
     */
    public void doProcess(ActionMapping map, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException {
        /*
         * 1.帳號已登入 2.正確 3.帳號不存在 4.帳號停用 這個帳號目前停用，請洽0800-288-068 5.帳號停用 6.顯示密碥錯誤次數
         * 這個帳號目前停用，請洽資訊室 7. 帳號停用 alert 8. nothing happen 9.第一次登入，顯示密碼提示
         * 10.此帳號尚未開啟，請洽0800-288-068客服專線來啟用您的帳號
         */
    	Map out = new HashMap();
        String errcode = "";
        String errmsg = "";
        String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
        String otpkey = sysdate+systime;
        String phone = "";
        String mail = "";
        List<Map> result=null;
        
        try {
            String id = request.getParameter("UID");
            String birth = request.getParameter("BIRTH");
            result=queryAccount(id,birth);        
            //帳號不存在    
            if (result.size() == 0) {
                errcode = "1";
                errmsg = "帳號不存在";
            }
            //存在此帳號
            else{            	            	
            	//帳號為停用狀態               	            	
            	if (result.get(0).get("STATE").toString().equals("Y")) { 
            		
            		SimpleDateFormat sim=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            		//取得被鎖帳號的時間
            		long lockTime=sim.parse(result.get(0).get("LOCKTIME").toString()).getTime();              	
                	//取得現在時間
            		Date date=new Date();            		
            		String now=sim.format(date);
            		long nowTime = sim.parse(now).getTime();
					//計算天數
	                int day=(int) ((nowTime-lockTime)/86400000);
	                //計算小時
	                int hour=(int) (((nowTime-lockTime)%86400000)/3600000);
	                //計算分鐘
	                int minute=(int)(((nowTime-lockTime)%86400000)%3600000)/60000;
              
                    //鎖帳號超過30分鐘就自動解鎖，一樣寄出OTP
            		if(day>0 || hour>0 || minute>=30){
            			//解鎖
            			unlockAccount(id);
            			
                    	//紀錄OTP資料                		
                    	String otp = doKycllog(request, form, id,otpkey);
                    	//修改SECAJ登入的密碼PASSWORD
                    	updateSECAJPassword(id,otp);
                    	//查詢客戶手機和mail，contactMethod[0]是手機，contactMethod[1]是MAIL
                    	String[] contactMethod=getIC01Content(id);
                    	phone=contactMethod[0];
                    	mail=contactMethod[1];
                    	//寄出簡訊
                    	if(phone!=""){           
                    		sendMobileMsg(otp ,(String) result.get(0).get("FIRSTNAME") , phone);   
                    	}                		             		
                    	//寄出mail
                    	if(mail!=""){
                    		sendOTPMail(request ,otp ,(String) result.get(0).get("FIRSTNAME") , mail);
                    	}
            		}
            		//鎖帳號沒超過30分鐘一樣停用
            		else{
            			 errcode = "2";
                         errmsg = "這個帳號目前暫停使用，請洽0800-288-068開通";
            		}                                      
                }
                //帳號生日都正確，在kycllog紀錄OTP資料，並寄出驗證信件
                else{                         	
                	//紀錄OTP資料                		
                	String otp = doKycllog(request, form, id,otpkey);
                	//修改SECAJ登入的密碼PASSWORD
                	updateSECAJPassword(id,otp);
                	//查詢客戶手機和mail，contactMethod[0]是手機，contactMethod[1]是MAIL
                	String[] contactMethod=getIC01Content(id);
                	phone=contactMethod[0];
                	mail=contactMethod[1];
                	//寄出簡訊
                	if(phone!=""){           
                		sendMobileMsg(otp ,(String) result.get(0).get("FIRSTNAME") , phone);   
                	}                		             		
                	//寄出mail
                	if(mail!=""){
                		sendOTPMail(request ,otp ,(String) result.get(0).get("FIRSTNAME") , mail);
                	}               		
                }
            }      
            
            out.put("errcode", errcode);
            out.put("errmsg", errmsg);
            out.put("otpkey", otpkey);
            out.put("phone", phone);
            out.put("mail", mail);
            
            response.setContentType("text/json;charset=UTF-8");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Set-Cookie", "HttpOnly;Secure;SameSite=Strict");
            response.getWriter().write(JSONArray.fromObject(out).toString());
            response.getWriter().flush();
            response.getWriter().close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e1) {
			e1.printStackTrace();
		}
        form.setNextPage(-1);
    }

	/**
	 * 寫入KYCLLOG記錄檔處理 - 用此檔案記錄登入OTP
	 * @param request
	 * @param form
	 * @param uid
	 */
	private String doKycllog( HttpServletRequest request ,  AsiActionForm form , String uid,String otpkey){
		

		String ll01 = this.getClass().getSimpleName();
		String ll02 = "";
		String ll03 = "會員登入頁";
		String ll04 = "F";
		String ll05 = uid;
		String ll09 = otpkey;//當作key值
		String ll17 = "LE";
		String ll19 = "會員登入密碼錯誤達3次";
		String ll12 = "0";//做otp輸入錯誤記錄

		String getotp = randomOTP();
		String ll20 = getotp;
		otpkey = ll09;
		
		try {		
			KycLogger klg = new KycLogger();
			klg.LoggerWriter(request, ll01, ll02, ll03, ll04, ll05, "", "", "", ll09, ll12, "", "", "", "", ll17, "", ll19, ll20, "", "", "", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ll20;
	}

 	/**
 	 * 寄發OTP密碼簡訊
 	 * @param data
 	 */
 	public void sendMobileMsg(String otp , String username , String cellphone)
 	{
 		int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;
 		
 		StringBuffer sb = new StringBuffer();
 		
 		sb.append("第一產物會員登入驗證碼：").append(otp).append("\n");
 		sb.append("您好，您正於第一產物進行會員登入");
 		sb.append("，請於" + String.valueOf(extime) + "分鐘內於網頁上輸入！");


 		String sendTel = cellphone;
 		String smspassword = SystemParam.getParam("OTPSMS_ACCOUNT"); // 簡訊發送帳號
 		
 		try
 		{
 			String urlencode = URLEncoder.encode(sb.toString(), "Big5");
 			HttpClient httpclient = new HttpClient();
 			httpclient.setConnectionTimeout(10000);
 			httpclient.setTimeout(10000);

 			GetMethod getmethod = new GetMethod("http://api.message.net.tw/send.php?longsms=1&id=0800288068&password="+ smspassword + "&tel=" + sendTel + "&msg=" + urlencode
 					+ "&mtype=G&􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊􀁈􀁑􀁆􀁒􀁇􀁌􀁑􀁊encoding=Big5");

 			int statusCode = httpclient.executeMethod(getmethod);
 			System.out.println("statusCode" + statusCode + " " + getmethod.getResponseBodyAsString());
 			String responseText = getmethod.getResponseBodyAsString();

 			//判斷是否有回傳剩餘點數參數，剩餘200、100時發通知出納課
 			if (responseText.indexOf("LCount=") != -1)
 			{
 				String str = responseText.replaceAll("\n|\r", "");// 清除換行符號
 				if (Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 100
 						|| Integer.parseInt(str.substring(str.indexOf("LCount=") + 7, str.indexOf("MsgID"))) == 200)
 				{
 					String content = responseText.replaceFirst("ErrorCode", "訊息代碼");
 					content = content.replaceFirst("LCount", "剩餘點數");
 					content = content.replaceFirst("MsgID000", "簡訊代號");

 					String email = SystemParam.getParam("EMAIL");// 客服信箱
 					sendSysMail(email, content);// 寄發剩餘點數通知
 				}
 			}

 		}
 		catch (UnsupportedEncodingException e)
 		{
 			e.printStackTrace();
 		}
 		catch (HttpException e)
 		{
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 			e.printStackTrace();
 		}
 	}

	private void sendSysMail(String email, String content)
	{
		KycMailUtil kmu = new KycMailUtil();
		kmu.setSubject("網路投保OTP-簡訊服務剩餘儲值點數");
		kmu.setFrom("admin@firstins.com.tw");
		kmu.setMessage(content);
		kmu.addTo(email);
		kmu.sendMail();
	}

	/**
	 * 查詢客戶手機、EMAIL
	 * @param uid
	 * @return String [0]：手機  	String [1]：email 
	 */
	private String[] getIC01Content(String uid){
		
		String sql = "SELECT * FROM IC01PF WHERE C101 = ?";
		String[] result = new String[2];
		
 		Connection con = null;
 		
 		try
 		{
 			con = AS400Connection.getOracleConnection();
 			QueryRunner runner = new QueryRunner();
 			Map mp = (Map) runner.query(con, sql, uid, new TrimedMapHandler());
 			
 			if(mp != null && !mp.isEmpty()){
 				result[0] = mp.get("CA101") != null ? mp.get("CA101").toString() : ""; 
 				result[1] = mp.get("C113") != null ? mp.get("C113").toString() : ""; 
 			}
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

 		return result;
	}
	
	/**
	 * 寄送OTP EMAIL
	 * @param request
	 */
	public void sendOTPMail(HttpServletRequest request ,String otp ,String name , String email)
	{
	   int extime = Integer.parseInt(SystemParam.getParam("OTPEXTIME")) / 60 ;   	

	   //寄Email
	   KycMailUtil sender = new KycMailUtil();

	   //取範本
	   BufferedReader fr;
	   String path = getServlet().getServletContext().getRealPath("/mail/LoginOTP_zh_TW.html");

	   StringBuffer linebf = new StringBuffer();
	   try {
		   fr = new BufferedReader(new InputStreamReader(new FileInputStream(path), "UTF-8"));
		   String line;
		   linebf = new StringBuffer();
		   line = fr.readLine();
		   while (line != null) {
			   linebf.append(line);
			   line = fr.readLine();
		   }

	   }catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }catch (IOException e) {
		   e.printStackTrace();
	   }

	   String msg = linebf.toString();
	   
	   //姓名隱碼
	   StringBuffer hiddenName  = new StringBuffer();
	   if(name.length() < 4){
	      for(int i=0;i<name.length();i++){
	   	   if(i==1){
	   		   hiddenName.append("O");
	   	   }
	   	   else{
	   		   hiddenName.append(name.substring(i,i+1));
	      	   }
	      }
	   }
	   else{
	       for(int i=0;i<name.length();i++){
	   	    if(i==1 || i==2){
	   		    hiddenName.append("O");
	   	    }
	   	    else{
	   		    hiddenName.append(name.substring(i,i+1));
	      	    }
	       }
	   }
	   
	   msg = msg.replaceAll("\\{username\\}", hiddenName.toString());
	   msg = msg.replaceAll("\\{otp\\}", otp);
	   msg = msg.replaceAll("\\{extime\\}", String.valueOf(extime));

	   sender.setSubject("第一保商務網-登入密碼通知");
	   sender.setMessage(msg);
	   sender.addTo(email);
	   sender.sendMail();

	}
	
	 /**
	 * 更新客戶的密碼
	 * @param uid
	 * @param otp
	 */
	private void updateSECAJPassword(String uid,String otp){		
		String sql = "UPDATE SECAJ SET PASSWORD=? WHERE USERID=? ";
 		try
 		{
 			tx_controller.begin(0);
 			QueryRunner runner = new QueryRunner();
 			//加密過後的OTP驗證碼才寫入
 			String[] param={EncryptUtil.getDesEncryptString(otp),uid};
 			runner.update(tx_controller.getConnection(0), sql,param);			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
	}
	
	/**
	 * 查詢客戶的帳號資料
	 * @param uid
	 * @param birth
	 */
	private List<Map> queryAccount(String uid,String birth){		
		String sql = "SELECT * FROM SECAJ LEFT JOIN KYCREG ON RG01=USERID LEFT JOIN IC01PF ON USERID=C101 WHERE USERID=? AND C103=? ";
		List<Map> result =null;
 		try
 		{
 			tx_controller.begin(0);
 			QueryRunner runner = new QueryRunner();
 			
 			String[] param={uid,birth};
 			result=(List<Map>) runner.query(tx_controller.getConnection(0), sql,param,new TrimedMapListHandler());			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		return result;
	}
	
	/**
	 * 產生隨機OTP驗證碼
	 */
	public String randomOTP(){
		
		String otpCode="";
		Random random = new Random();
					
		String code1=String.valueOf(random.nextInt(10));
		String code2=String.valueOf(random.nextInt(10));
		String code3=String.valueOf(random.nextInt(10));
		String code4=String.valueOf(random.nextInt(10));
		String code5=String.valueOf(random.nextInt(10));
		String code6=String.valueOf(random.nextInt(10));
		
		otpCode+=code1+code2+code3+code4+code5+code6;		
		otpCode=requireChangeOTP(otpCode);
		
		return otpCode;
    }
	
	/**
	 * OTP驗證碼排除特定數字
	 * @param otp
	 */
	public static String requireChangeOTP(String otp){
		String correctCode="";
		String check1="4",check2="78",check3="87",check4="38",check5="76";
		
		//有存在4
		if(otp.indexOf(check1)!=-1){
			correctCode=otp.replaceAll(check1, "9");				
		}
		else{
			correctCode=otp;
		}
		
		//有存在78
		if(correctCode.indexOf(check2)!=-1){
			correctCode=correctCode.replaceAll(check2, "99");				
		}
		//有存在87
		if(correctCode.indexOf(check3)!=-1){
			correctCode=correctCode.replaceAll(check3, "99");				
		}
		//有存在38
		if(correctCode.indexOf(check4)!=-1){
			correctCode=correctCode.replaceAll(check4, "99");				
		}
		//有存在76
		if(correctCode.indexOf(check5)!=-1){
			correctCode=correctCode.replaceAll(check5, "99");				
		}
		return correctCode;
	}	
	
	/**
	 * 解鎖帳號
	 * @param uid
	 */
	public void unlockAccount(String uid){
		
		String sql = "UPDATE SECAJ SET ERRCNT=0,STATE='N',STOPCAUSE='0' ,LOCKTIME='' WHERE USERID=? ";		
 		Connection con = null;
 		try
 		{
 			con = AS400Connection.getOracleConnection();
 			QueryRunner runner = new QueryRunner();
 			runner.update(con, sql, uid);		
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}
		
	}

    public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) {
        AsiActionForm form = (AsiActionForm) arg1;
        form.setActionCode(1);
    }

    public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException {
        return null;
    }

    protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException {

    }
}
