package com.kyc.schedule;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.Number3;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.inc.dao.TrimedMapListHandler;


/**
 * 將缺少推薦人代碼的客戶加入推薦人代碼
 * @author Vincent
 *
 */
public class UpdateReferrerCode extends AsiAction
{
	
	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		List<Map> data=getData();
		
		for(int i=0;i<data.size();i++){
			Map map=data.get(i);
			generateReferrerCode(map.get("RG01").toString(),request,map.get("RG03").toString());
		}
		
		arg1.setNextPage(-1);		
	}
	
	/**
	 * 取得缺少推薦人代碼的客戶名單
	 * @return result
	 */
	public List<Map> getData()
	{
		String sql="select * from KYCREG left join IC01PFA on RG01=C01A01 where C01A17 is null";
		List<Map> result=null;		
		try
		{
			tx_controller.begin(0);
			QueryRunner qr = new QueryRunner(); 
			result=(List<Map>)qr.query(tx_controller.getConnection(0), sql,new TrimedMapListHandler());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}	
		return result;
	}
	
	/**
	 * 更新IC01PFA客戶資料(產生推薦人代碼)
	 * @param id
	 * @param request
	 * @param birthday
	 * @return
	 */
	public void generateReferrerCode(String id,HttpServletRequest request,String birthday)
	{
		//已存在就更新
		if(isExistIC01PFA(id)){
			String sql="UPDATE IC01PFA SET C01A17=? WHERE C01A01= ?";
			
			String[] args = new String[2];
	    	args[0] = Number3.getReferrerNumber(getServlet(), request, id, birthday);//取得推薦人代號
	    	args[1] = id;
	    	
	    	tx_controller.begin(0);
			QueryRunner qr=new QueryRunner();
						
			try{
				qr.update(tx_controller.getConnection(0), sql,args);
			}catch(Exception e){
				e.printStackTrace();
			}		
		}
		//不存在就新增
		else{
			String sql="INSERT IC01PFA(C01A01,C01A17) VALUES(?,?)";
			
			String[] args = new String[2];
	    	args[0] = id;
	    	args[1] = Number3.getReferrerNumber(getServlet(), request, id, birthday);//取得推薦人代號;
	    	
	    	tx_controller.begin(0);
			QueryRunner qr=new QueryRunner();
						
			try{
				qr.update(tx_controller.getConnection(0), sql,args);
			}catch(Exception e){
				e.printStackTrace();
			}		
		}		
	}
	
	/**
	 * 找出IC01PFA是否有此人資料
	 * @param id
	 * @return result
	 */
	public boolean isExistIC01PFA(String id)
	{
		boolean result=false;
		List<Map> data=null;
		String sql="select * from IC01PFA where C01A01 = ?";
    	
    	tx_controller.begin(0);
		QueryRunner qr=new QueryRunner();
					
		try{
			data=(List<Map>)qr.query(tx_controller.getConnection(0), sql,id,new TrimedMapListHandler());
			if(data !=null && data.size() !=0){
				result=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}	
		return result;
	}
	
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0)
            form1.setActionCode(GlobalKey.ACTION_SELECT);
        return;
          
	}
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		return null;
	}
}