select count(EML05) from KYCEDMLOG
where EML05 = 1091101;