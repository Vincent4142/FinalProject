/**
 * 
 */
package com.asi.kyc.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

import com.asi.kyc.common.SystemParam;


/**
 * <!--程式說明寫在此-->
 * 
 * @author  ：sergio
 * @version ：$Revision: 1.10 $ $Date: 2007/04/17 01:36:36 $<br>	
 * <p><pre>
 * 存放路徑	：$Header: D:/Repositories/KYC2/JavaSource/com/com/asi/kyc/common/utils/KycMailUtil.java,v 1.10 2007/04/17 01:36:36 cvsuser Exp $  
 * 建立日期	：2006/8/30
 * 異動註記	： 
 * </pre></p>
 */
public class KycMailUtil
{
	private String subject;
	private String from="admin@firstins.com.tw";
	private String[] to,cc,bcc;
	private String content;
	private EmailAttachment[] attachments;
	
	public void sendMail()
	{
		try
		{	
			sendMailExcp();
		}
		catch (NamingException e)
		{
			e.printStackTrace();
		}
		catch (AddressException e)
		{
			e.printStackTrace();
		}
		catch (MessagingException e)
		{
			e.printStackTrace();
		}
	}
	
	public void sendMailExcp() throws NamingException, AddressException, MessagingException
	{
		Session mailsession = getMailSession();
		mailsession.setDebug(false);
		MimeMessage msg1 = new MimeMessage(mailsession);
		msg1.setFrom(new InternetAddress(from));
		
		StringBuffer sb = new StringBuffer();
		//收件人
		if(to!=null)
		{
			for(int i=0;i<to.length;i++)
			{
				if(to[i]!=null&&!to[i].trim().equals(""))
				{
					msg1.addRecipient(Message.RecipientType.TO, new InternetAddress(to[i]));
					sb.append(to[i]).append(",");
				}
			}			
		}
		//副本
		if(cc!=null)
		{
			for(int i=0;i<cc.length;i++)
			{
				if(cc[i]!=null&&!cc[i].trim().equals(""))
				{
					msg1.addRecipient(Message.RecipientType.CC, new InternetAddress(cc[i]));
					sb.append(cc[i]).append(",");
				}
			}			
		}
		//密件副本
		if(bcc!=null)
		{
			for(int i=0;i<bcc.length;i++)
			{
				if(bcc[i]!=null&&!bcc[i].trim().equals(""))
				{
					msg1.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc[i]));
					sb.append(bcc[i]).append(",");
				}
			}			
		}
		
		//用系統參數判斷是否為測試環境，如果是就在標題加上測試信件註記
		if(!SystemParam.getParam("ENV").equals("KYC"))
			msg1.setSubject(new StringBuffer("[[ 測試信件 ]]").append(subject).toString(),"UTF-8");
		else
		{
			msg1.setSubject(subject,"UTF-8");
			msg1.addRecipient(Message.RecipientType.BCC, new InternetAddress(SystemParam.getParam("BCCMAIL")));
		}
		
		BodyPart bp = new MimeBodyPart();
		bp.setContent(content, "text/html;charset=UTF-8");
		Multipart mp = new MimeMultipart();
		mp.addBodyPart(bp);
		msg1.setContent(mp);
		System.out.println("sendMail:"+sb.toString()+"  主旨:"+subject);
		Transport.send(msg1);
	}
	
	/**
	 * 發送mail(含附件，需先addAttachment) 
	 */
	public void sendMailWithAttachments()
	{
		Session mailsession = getMailSession();
		mailsession.setDebug(false);
		// 郵件主體
		HtmlEmail emailBody = new HtmlEmail();
		emailBody.setMailSession(mailsession);
		try
		{
			StringBuffer sb = new StringBuffer();
			if(to!=null)
			{
				List mail = new ArrayList();
				for(int i=0;i<to.length;i++)
				{
					if(to[i]!=null&&!to[i].trim().equals(""))
					{
						mail.add(new InternetAddress(to[i]));
						sb.append(to[i]).append(",");
					}
				}
				emailBody.setTo(mail);// 收件人
			}
			if(cc!=null)
			{
				List mail_ = new ArrayList();
				for(int i=0;i<cc.length;i++)
				{
					if(cc[i]!=null&&!cc[i].trim().equals(""))
					{
						mail_.add(new InternetAddress(cc[i]));
						sb.append(cc[i]).append(",");
					}
				}
				emailBody.setCc(mail_);// 副本
			}
			
			//用系統參數判斷是否為測試環境，如果是就在標題加上測試信件註記
			if(!SystemParam.getParam("ENV").equals("KYC"))
				emailBody.setSubject("[[ 測試信件 ]]" + subject);
			else
			{
				emailBody.setSubject(subject);
				emailBody.addBcc(SystemParam.getParam("BCCMAIL"));// 密件副本
			}
			
			emailBody.setFrom(from);// 寄件人
			if(attachments!=null)
			{
				for(int i=0;i<attachments.length;i++)
				{
					emailBody.attach(attachments[i]);
				}
			}
			
			emailBody.setCharset("UTF-8");
			emailBody.setHtmlMsg(content);//郵件內文
			System.out.println("sendMail:"+sb.toString()+"  主旨:"+subject);
			emailBody.send();
		}
		catch (EmailException e)
		{
			e.printStackTrace();
		}
		catch (AddressException e)
		{
			e.printStackTrace();
		}
	}

	private Session getMailSession()
	{
		Session mailsession = null;
		try
		{
			Context env = (Context) new InitialContext().lookup("java:comp/env");
			mailsession = (Session) env.lookup("mail/MailSession");
		}
		catch (NamingException e)
		{
			e.printStackTrace();
		}
		
		if(mailsession==null)
		{
			Properties props = System.getProperties();
            props.put("mail.transport.protocol", "smtp");
            props.put("mail.host", "e2k.firstins.com.tw");
            mailsession = Session.getDefaultInstance(props, null);
		}
		
		return mailsession;
	}
	
	public void setFrom(String f)
	{
		from  = f;
	}
	public void setSubject(String sub)
	{
		subject = sub;
	}
	public void setMessage(String msg)
	{
		content = msg;
	}
	public void addTo(String to)
	{
		this.to = new String[1];
		this.to[0] = to;
	}
	public void addTo(Object to[])
	{
		String[] t = new String[to.length];
		for(int i=0;i<to.length;i++)
		{
			t[i] = (String) to[i];
		}
		this.to = t;
	}
	public void addCc(Object cc[])
	{
		String[] c = new String[cc.length];
		for(int i=0;i<cc.length;i++)
		{
			c[i] = (String) cc[i];
		}
		this.cc = c;
	}
	public void addBcc(Object bcc[])
	{
		String[] c = new String[bcc.length];
		for(int i=0;i<bcc.length;i++)
		{
			c[i] = (String) bcc[i];
		}
		this.bcc = c;
	}
	public void addAttachment(EmailAttachment att)
	{
		this.attachments = new EmailAttachment[1];
		this.attachments[0] = att;
	}
	public void addAttachment(Object[] att)
	{
		EmailAttachment[] atts = new EmailAttachment[att.length];
		for(int i=0;i<att.length;i++)
		{
			atts[i] = (EmailAttachment)att[i];
		}
		this.attachments = atts;
	}
}
