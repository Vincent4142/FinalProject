package com.kyc.la1.dao;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import com.asi.common.exception.AsiException;
import com.kyc.wms.dao.IDao;

public class COM_LFCPDao extends IDao
{
	public COM_LFCPDao(Connection con)
	{
		super(con);
	}

	public COM_LFCPDao() throws AsiException
	{
		super();
	}
	
	public List<Map> getCOM_LFCP(String lfc01, String lfc02, String lfc03, String lfc04)
	{
		List<Map> list = null;
		String[] args;
		String sql;		
		sql = "SELECT * FROM COM_LFCP WHERE LFC01 = ? AND LFC02 = ? AND LFC03 = ? AND LFC04 = ? ";
		args = new String[4];
		args[0] = lfc01;
		args[1] = lfc02;
		args[2] = lfc03;
		args[3] = lfc04;
						
		try
		{
			QueryRunner runner = new QueryRunner();
			list = (List<Map>) runner.query(con, sql, args, new MapListHandler());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	
	public int insertCOM_LFCP(String lfc01, String lfc02, String lfc03,
			String lfc04, String lfc05, String lfc06, String lfc07,
			String lfc08,String lfc09,String lfc10,String lfc11,
			String lfc12,String lfc13, String sysdate, String systime, String user)
	{
		String sql = "INSERT INTO COM_LFCP (LFC01,LFC02,LFC03,LFC04,LFC05,LFC06,LFC07,LFC08,LFC09,LFC10,LFC11,LFC12,LFC13,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String args[] = new String[19];
		args[0] = lfc01;
		args[1] = lfc02; 
		args[2] = lfc03; 
		args[3] = lfc04;
		args[4] = lfc05;
		args[5] = lfc06;
		args[6] = lfc07;
		args[7] = lfc08;
		args[8] = lfc09;
		args[9] = lfc10;
		args[10] = lfc11;
		args[11] = lfc12;
		args[12] = lfc13;		
		args[13] = sysdate;
		args[14] = systime;
		args[15] = user;
		args[16] = sysdate;
		args[17] = systime;
		args[18] = user;

		int ret = 0;
		try
		{
			QueryRunner runner = new QueryRunner();
			ret = runner.update(con, sql, args);
			runner = null;
			if (ret == 0)
				throw new AsiException("");
			return ret;
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return ret;
	}
	
	public void updateCOM_LFCP(String lfc01, String lfc02, String lfc03,
			String lfc04, String lfc05, String lfc06, String lfc07,
			String lfc08,String lfc09,String lfc10,String lfc11,
			String lfc12,String lfc13, String sysdate, String systime, String user)
	{
		String sql = "UPDATE COM_LFCP SET LFC05=?, LFC06=?, LFC07=?, LFC08=?, LFC09=?, LFC10=?, "
				+ "LFC11=?, LFC12=?, LFC13=?,UPDDT=?,UPDTM=?,UPDUR=? WHERE LFC01=? and LFC02=? and LFC03=? and LFC04=? ";
		String args[] = new String[16];
		args[0] = lfc05;
		args[1] = lfc06; 
		args[2] = lfc07; 
		args[3] = lfc08;
		args[4] = lfc09;
		args[5] = lfc10;
		args[6] = lfc11;
		args[7] = lfc12;
		args[8] = lfc13;
		args[9] = sysdate;
		args[10] = systime;
		args[11] = user;
		args[12] = lfc01;
		args[13] = lfc02;
		args[14] = lfc03;
		args[15] = lfc04;
		try
		{
			QueryRunner runner = new QueryRunner();
			runner.update(con, sql, args);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
