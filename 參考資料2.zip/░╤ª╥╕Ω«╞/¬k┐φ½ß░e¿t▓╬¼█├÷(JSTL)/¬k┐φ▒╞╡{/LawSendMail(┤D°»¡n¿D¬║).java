package com.kyc.schedule;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.kyc.afl.utils.Employee;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.la1.dao.COM_LEMPDao;

/**
 * @author John Lai 2019/12/26 
 * 法遵後送系統 - 超過預定回覆日期EMAIL通知
 */
public class LawSendMail extends AsiAction {

	private StringBuffer errorCatchMsg = null;

	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1,	AsiActionForm arg2) throws AsiException {

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3)
			throws IOException, ServletException {
		return null;
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response)
			throws AsiException {

		errorCatchMsg = new StringBuffer();
		if (arg1.getActionCode() == 1) {
			processMail();
		}

		arg1.setNextPage(-1);
	}

	/**
	 * 寄送超過預定回覆日期郵件 
	 * 每日上午5:30~6:00排程自動寄送逾期未回覆通知。 
	 * 最近回覆日期未填 && 今天日期>預定回覆日期
	 * 
	 * @param actionCode : 1
	 */
	public void processMail() {

		Connection con = null;
		try {
			
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			con = AS400Connection.getOracleConnection();
			COM_LEMPDao com_LempDao = new COM_LEMPDao(con);
			QueryRunner runner = new QueryRunner();
			//負責寄送最近回覆日期為空且已逾預定回覆日期
			String sql = "SELECT lma01, lma09, lma08, lpd02, lpd08 FROM com_lman INNER JOIN com_lpde ON lma01 = lpd01 where (LPD08 is null or LPD08 = 0) and LMA09 > 1081231 and LMA09 < ? ";
			sql+="and LMA01='CP1090378'"; //測試用
			String arg[] = new String[1];
			arg[0] = sysdate;
			List<?> ret = (List<?>) runner.query(con, sql.toString(), arg, new TrimedMapListHandler());
			List<?> sendEmailList = null;
			Employee emp = null;			
			for (int i = 0; i < ret.size(); i++) {
				//存放該單位洗錢、個資、法遵主管的mail
				List<String> manager=new ArrayList<String>();
				
				@SuppressWarnings("rawtypes")
				Map mp = (Map) ret.get(i);
				sendEmailList = com_LempDao.getEmailList(mp.get("lpd02").toString(), mp.get("lma08").toString());
				String recipient = null;
				for (int j = 0; j < sendEmailList.size(); j++) {
					Map<?, ?> map = (Map<?, ?>) sendEmailList.get(j);
					recipient = map.get("lem01").toString();
					emp = Employee.getEmployee(recipient);
					String email = emp.getEmail();
					System.out.println(email);
					manager.add(email);
					sendMail(email, mp.get("lma01").toString(), mp.get("lma09").toString());
				}
				//單位最高主管若又為洗錢、個資、法遵主管則不重複寄送
				String email = emp.getDept().getBoss().getEmail();
				int a=noRepeat(manager,email);
				if(a<0){
					System.out.println(email);
					sendMail(email, mp.get("lma01").toString(), mp.get("lma09").toString());
				}	
			}
			
			//負責寄送實際完成日為空且已逾預定完成日
			String sql2 = "SELECT DISTINCT lma01, lma09, lma08, lpt02, lpt07, lpt06 FROM com_lman INNER JOIN com_lptt ON lma01 = lpt01 where (lpt06 is not null and lpt06 <> 0) and(lpt07 is null or lpt07 = 0) and lpt06 >1081231 and lpt06 < ? ";
			sql2+="and LMA01='CP1090366'"; //測試用
			List<?> ret2 = (List<?>) runner.query(con, sql2.toString(), arg, new TrimedMapListHandler());
			List<?> sendEmailList2 = null;
			Employee emp2 = null;			
			for (int i = 0; i < ret2.size(); i++) {
				//存放該單位洗錢、個資、法遵主管的mail
				List<String> manager=new ArrayList<String>();
				
				@SuppressWarnings("rawtypes")
				Map mp = (Map) ret2.get(i);
				sendEmailList2 = com_LempDao.getEmailList(mp.get("lpt02").toString(), mp.get("lma08").toString());
				String recipient = null;
				for (int j = 0; j < sendEmailList2.size(); j++) {
					Map<?, ?> map = (Map<?, ?>) sendEmailList2.get(j);
					recipient = map.get("lem01").toString();
					emp2 = Employee.getEmployee(recipient);
					String email = emp2.getEmail();
					System.out.println(email);
					manager.add(email);
					sendMail(email, mp.get("lma01").toString(), mp.get("lpt06").toString());
				}
				//單位最高主管若又為洗錢、個資、法遵主管則不重複寄送
				String email = emp2.getDept().getBoss().getEmail();
				int a=noRepeat(manager,email);
				if(a<0){
					System.out.println(email);
					sendMail(email, mp.get("lma01").toString(), mp.get("lpt06").toString());
				}	
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			errorCatchMsg.append(e).append("\r\n\r\n");
		} catch (Exception e) {
			e.printStackTrace();
			errorCatchMsg.append(e).append("\r\n\r\n");
		} finally {
			AS400Connection.closeConnection(con);
		}

		// error message 通知
		if (!errorCatchMsg.toString().equals(""))
			sendSysErrMsg();

	}

	/**
	 * 寄送EMAIL
	 * 
	 * @param email
	 * @param number
	 */
	public void sendMail(String email, String number, String preDate) {
		try {
			KycMailUtil kmu = new KycMailUtil();
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setSubject("法令遵循室後送案件通知 - 後送案號" + number + "應於" + preDate + "前回覆，請  貴單位儘速處理。");
			StringBuffer sb = new StringBuffer();
			sb.append("後送案號" + number + "已逾處理期限，煩請各位單位主管或代理人儘速至 ");
			sb.append("<a href='http://kycapj.firstins.com.tw:9080/kyc/Login.do'>KYC系統</a>");
			sb.append(" 進行法遵後送系統案件回覆作業。");
			sb.append(" 此信件正常是寄給。"+email);  //測試用
			kmu.setMessage(sb.toString());
			//kmu.addTo("johnlai@firstins.com.tw");
			kmu.addTo("w92532@firstins.com.tw");
			//kmu.addTo(email);
			kmu.sendMailWithAttachments();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void sendSysErrMsg() {

		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String systime = DateUtil.getSysTime();
		StringBuffer buf = new StringBuffer();

		if (!errorCatchMsg.toString().equals("")) {
			buf.append("<div>");
			buf.append("<p>").append(sysdate).append(" ").append(systime).append("</p>");
			buf.append("<p>").append(errorCatchMsg).append("</p>");
			buf.append("</div>");
		}

		try {
			KycMailUtil kmu = new KycMailUtil();
			kmu.setSubject("法遵後送錯誤通知-" + sysdate);
			kmu.setFrom("admin@firstins.com.tw");
			kmu.setMessage(buf.toString());
			//kmu.addTo("johnlai@firstins.com.tw");
			kmu.addTo("w92532@firstins.com.tw");
			kmu.sendMail();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public int noRepeat(List<String> manager,String email){
		String[] manager2=new  String[manager.size()];
		for(int k=0;k<manager.size();k++){
			manager2[k]=manager.get(k);
		}
		int a = Arrays.binarySearch(manager2, email);
		return a;
	}

}
