package com.asi.kyc.wb5.actions;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.poi.hssf.usermodel.HSSFFooter;
import org.apache.poi.hssf.usermodel.HeaderFooter;
import org.apache.poi.ss.usermodel.Footer;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFPrintSetup;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.wb5.dao.LuckyDao;
import com.asi.kyc.wb5.forms.WB5M150f;
import com.asi.kyc.wb5.models.WB5M150m;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * 抽獎活動之抽獎程式
 * 
 * @author John Lai 
 * @Create Date：2020/10/8
 */
public class WB5M1501 extends WebAction
{
	public void redefineActionCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
		if (form1.getActionCode() == 0)
		{
			form1.setActionCode(GlobalKey.ACTION_SELECT);
			return;
		}
	}

	public void doProcess(ActionMapping arg0, AsiActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws AsiException
	{
		WB5M150f form = (WB5M150f)arg1;
		Connection con = null;
	
		try
		{
			con = AS400Connection.getOracleConnection();
			form.setResult("");
			
			LuckyDao luckDao = new LuckyDao();
			List<?> luckList = luckDao.getlucklist(con);
			arg2.setAttribute("luckList", luckList);//項目名單
			
			if (arg1.getActionCode() == 1)
			{
				FormFile file = form.getNpaExcel();
				WB5M150m model = new WB5M150m(tx_controller, arg2, arg1);
				model.WB5M150R(file.getInputStream(), servlet,arg2,form);
			} else if (arg1.getActionCode() == 2) {
				String luckyname = luckDao.getluckyName(con, form.getLuck());
				String itemname = luckDao.getluckyName(con, form.getLuck(), form.getQuyNo());
				arg2.setAttribute("luck", form.getLuck());//項目名單
				arg2.setAttribute("quyNo", form.getQuyNo());//項目名單
				arg2.setAttribute("num", form.getNum());//人數
				arg2.setAttribute("luckyName", luckyname);
				arg2.setAttribute("itemName", itemname);
			} else if (arg1.getActionCode() == 6) {
				String luckyname = luckDao.getluckyName(con, form.getLuck());
				String itemname = luckDao.getluckyName(con, form.getLuck(), form.getQuyNo());
				arg2.setAttribute("luck", form.getLuck());//項目名單
				arg2.setAttribute("quyNo", form.getQuyNo());//項目名單
				arg2.setAttribute("num", form.getNum());//人數
				arg2.setAttribute("luckyName", luckyname);
				arg2.setAttribute("itemName", itemname);
				WB5M150m model = new WB5M150m(tx_controller, arg2, arg1);
				model.setLucky(arg2,form);
			} else if (arg1.getActionCode() == 10) {
				String luckyname = luckDao.getluckyName(con, form.getLuck());
				doAction10(form, arg2, arg3, luckyname);
			} else if (arg1.getActionCode() == 11) {
				String luckyname = luckDao.getluckyName(con, form.getLuck());
				doAction11(form, arg2, arg3, luckyname);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			AS400Connection.closeConnection(con);
		}
		if (arg1.getActionCode() == 2 || arg1.getActionCode() == 6)
			arg1.setNextPage(2);
		else
			arg1.setNextPage(1);
	}
	
	private void doAction10(WB5M150f form, HttpServletRequest request,
			HttpServletResponse response, String luckyname) throws AsiException
	{
		try
		{
			XSSFWorkbook workbook = exportExcel10(form, request, luckyname);
			response.setContentType("application/octect-stream");
			response.setHeader("Content-Disposition", "attachment;filename="
					+ "report.xlsx");
			OutputStream os = response.getOutputStream();
			workbook.write(os);
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			tx_controller.close();
		}
	}
	private void doAction11(WB5M150f form, HttpServletRequest request,
			HttpServletResponse response, String luckyname) throws AsiException
	{
		try
		{
			XSSFWorkbook workbook = exportExcel11(form, request, luckyname);
			response.setContentType("application/octect-stream");
			response.setHeader("Content-Disposition", "attachment;filename="
					+ "report.xlsx");
			OutputStream os = response.getOutputStream();
			workbook.write(os);
			os.flush();
			os.close();
			response.setStatus(HttpServletResponse.SC_OK);
			response.flushBuffer();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			tx_controller.close();
		}
	}

	public XSSFWorkbook exportExcel10(WB5M150f f, HttpServletRequest request, String luckyname)
			throws AsiException
	{
		try
		{
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = null;
			String sheetName = "中獎名冊";
			sheet = workBook.createSheet(sheetName);
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));// 跨欄置中

			sheet.setColumnWidth(0, (short) 10 * 256);// 設定欄寬
			sheet.setColumnWidth(1, (short) 5 * 256);
			sheet.setColumnWidth(2, (short) 30 * 256);
			sheet.setColumnWidth(3, (short) 10 * 256);
			sheet.setColumnWidth(4, (short) 20 * 256);
			sheet.setColumnWidth(5, (short) 15 * 256);
			sheet.setColumnWidth(6, (short) 15 * 256);
			sheet.setColumnWidth(7, (short) 15 * 256);
			sheet.setColumnWidth(8, (short) 30 * 256);
			sheet.setColumnWidth(9, (short) 15 * 256);

			sheet.setMargin(XSSFSheet.TopMargin, (double) .36);// 設定上邊界
			sheet.setMargin(XSSFSheet.BottomMargin, (double) .60);// 設定下邊界
			sheet.setMargin(XSSFSheet.LeftMargin, (double) .36);// 設定左邊界
			sheet.setMargin(XSSFSheet.RightMargin, (double) .36);// 設定右邊界

			XSSFPrintSetup ps = (XSSFPrintSetup) sheet.getPrintSetup();// 設定列印選項
			ps.setPaperSize(PrintSetup.A4_PAPERSIZE);// 設定紙張
			ps.setScale((short) 105);// 列印縮放比例
			ps.setLandscape(true);// 橫向列印

			sheet.setRepeatingRows(new CellRangeAddress(0, 2, -1, -1));// 標題列列印區域

			Footer footer = sheet.getFooter();// 設定頁尾
			footer.setCenter(HSSFFooter.font("標楷體", "regular") + "第 "
					+ HeaderFooter.page() + " 頁，共  " + HeaderFooter.numPages()
					+ " 頁 ");

			XSSFCellStyle style01 = workBook.createCellStyle();// 標頭樣式1
			style01.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style01.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			XSSFFont font01 = workBook.createFont();
			font01.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font01.setFontHeight((short) 480);
			font01.setFontName("Arial Unicode MS");
			style01.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			style01.setFont(font01);

			XSSFFont font03 = workBook.createFont();// 欄位字型1
			font03.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font03.setFontHeight((short) 260);// 字體大小
			font03.setFontName("Arial Unicode MS");

			XSSFFont font04 = workBook.createFont();// 欄位字型1
			font04.setFontHeight((short) 260);// 字體大小
			font04.setFontName("Arial Unicode MS");

			XSSFCellStyle style031 = workBook.createCellStyle();// 欄位樣式1
			style031.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style031.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style031.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style031.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style031.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
			style031.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style031.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style031.setFont(font03);

			XSSFCellStyle style032 = workBook.createCellStyle();// 欄位樣式1
			style032.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style032.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style032.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style032.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style032.setAlignment(XSSFCellStyle.ALIGN_RIGHT);// 靠左對齊
			style032.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style032.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style032.setFont(font03);

			XSSFCellStyle style033 = workBook.createCellStyle();// 欄位樣式1
			style033.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style033.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style033.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style033.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style033.setAlignment(XSSFCellStyle.ALIGN_CENTER);// 靠左對齊
			style033.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style033.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style033.setFont(font03);

			XSSFCellStyle style041 = workBook.createCellStyle();// 欄位樣式1
			style041.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style041.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style041.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style041.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style041.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
			style041.setFillForegroundColor(IndexedColors.LEMON_CHIFFON
					.getIndex());
			style041.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style041.setFont(font04);

			XSSFRow row0 = sheet.createRow(0);// 標頭1
			createCell(row0, (short) 0, luckyname, style01);

			XSSFRow row2 = sheet.createRow(1);// 標頭2
			createCell(row2, (short) 0, "獎項", style033);
			createCell(row2, (short) 1, "序", style033);
			createCell(row2, (short) 2, "獎品", style033);
			createCell(row2, (short) 3, "編號", style033);
			createCell(row2, (short) 4, "交易序號", style033);
			createCell(row2, (short) 5, "交易日期", style033);
			createCell(row2, (short) 6, "被保險人姓名", style033);
			createCell(row2, (short) 7, "被保險人手機", style033);
			createCell(row2, (short) 8, "被保險人Email", style033);
			createCell(row2, (short) 9, "總實收保費", style033);

			List<?> rptData = generateData10(request, f);

			for (int j = 0; j < rptData.size(); j++)
			{
				Map<?, ?> currentRowData = (Map<?, ?>) rptData.get(j);
				XSSFRow row = sheet.createRow(j + 2);
				String award = currentRowData.get("award") == null ? ""
						: currentRowData.get("award").toString().trim();
				String prize = currentRowData.get("prize") == null ? ""
						: currentRowData.get("prize").toString().trim();
				String winnum = currentRowData.get("winnum") == null ? ""
						: currentRowData.get("winnum").toString().trim();
				String luckyseq = currentRowData.get("luckyseq") == null ? ""
						: currentRowData.get("luckyseq").toString().trim();
				String lucky01 = currentRowData.get("lucky01") == null ? ""
						: currentRowData.get("lucky01").toString().trim();
				String lucky02 = currentRowData.get("lucky02") == null ? ""
						: currentRowData.get("lucky02").toString().trim();
				String lucky03 = currentRowData.get("lucky03") == null ? ""
						: currentRowData.get("lucky03").toString().trim();
				String lucky04 = currentRowData.get("lucky04") == null ? ""
						: currentRowData.get("lucky04").toString().trim();
				String lucky05 = currentRowData.get("lucky05") == null ? ""
						: currentRowData.get("lucky05").toString().trim();
				String lucky06 = currentRowData.get("lucky06") == null ? ""
						: currentRowData.get("lucky06").toString().trim();


				createCell(row, (short) 0, String.valueOf(award), style041);
				createCell(row, (short) 1, String.valueOf(winnum), style041);
				createCell(row, (short) 2, String.valueOf(prize), style041);
				createCell(row, (short) 3, String.valueOf(luckyseq), style041);
				createCell(row, (short) 4, String.valueOf(lucky01), style041);
				createCell(row, (short) 5, String.valueOf(lucky02), style041);
				createCell(row, (short) 6, String.valueOf(lucky03), style041);
				createCell(row, (short) 7, String.valueOf(lucky04), style041);
				createCell(row, (short) 8, String.valueOf(lucky05), style041);
				createCell(row, (short) 9, String.valueOf(lucky06), style041);

			}
			return workBook;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("decode Data error");
		}
	}
	public XSSFWorkbook exportExcel11(WB5M150f f, HttpServletRequest request, String luckyname)
			throws AsiException
	{
		try
		{
			XSSFWorkbook workBook = new XSSFWorkbook();
			XSSFSheet sheet = null;
			String sheetName = "抽獎名冊";
			sheet = workBook.createSheet(sheetName);
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 6));// 跨欄置中

			sheet.setColumnWidth(0, (short) 10 * 256);
			sheet.setColumnWidth(1, (short) 20 * 256);
			sheet.setColumnWidth(2, (short) 15 * 256);
			sheet.setColumnWidth(3, (short) 15 * 256);
			sheet.setColumnWidth(4, (short) 15 * 256);
			sheet.setColumnWidth(5, (short) 30 * 256);
			sheet.setColumnWidth(6, (short) 15 * 256);

			sheet.setMargin(XSSFSheet.TopMargin, (double) .36);// 設定上邊界
			sheet.setMargin(XSSFSheet.BottomMargin, (double) .60);// 設定下邊界
			sheet.setMargin(XSSFSheet.LeftMargin, (double) .36);// 設定左邊界
			sheet.setMargin(XSSFSheet.RightMargin, (double) .36);// 設定右邊界

			XSSFPrintSetup ps = (XSSFPrintSetup) sheet.getPrintSetup();// 設定列印選項
			ps.setPaperSize(PrintSetup.A4_PAPERSIZE);// 設定紙張
			ps.setScale((short) 105);// 列印縮放比例
			ps.setLandscape(true);// 橫向列印

			sheet.setRepeatingRows(new CellRangeAddress(0, 2, -1, -1));// 標題列列印區域

			Footer footer = sheet.getFooter();// 設定頁尾
			footer.setCenter(HSSFFooter.font("標楷體", "regular") + "第 "
					+ HeaderFooter.page() + " 頁，共  " + HeaderFooter.numPages()
					+ " 頁 ");

			XSSFCellStyle style01 = workBook.createCellStyle();// 標頭樣式1
			style01.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style01.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			XSSFFont font01 = workBook.createFont();
			font01.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font01.setFontHeight((short) 480);
			font01.setFontName("Arial Unicode MS");
			style01.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			style01.setFont(font01);

			XSSFFont font03 = workBook.createFont();// 欄位字型1
			font03.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
			font03.setFontHeight((short) 260);// 字體大小
			font03.setFontName("Arial Unicode MS");

			XSSFFont font04 = workBook.createFont();// 欄位字型1
			font04.setFontHeight((short) 260);// 字體大小
			font04.setFontName("Arial Unicode MS");

			XSSFCellStyle style031 = workBook.createCellStyle();// 欄位樣式1
			style031.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style031.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style031.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style031.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style031.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
			style031.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style031.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style031.setFont(font03);

			XSSFCellStyle style032 = workBook.createCellStyle();// 欄位樣式1
			style032.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style032.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style032.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style032.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style032.setAlignment(XSSFCellStyle.ALIGN_RIGHT);// 靠左對齊
			style032.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style032.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style032.setFont(font03);

			XSSFCellStyle style033 = workBook.createCellStyle();// 欄位樣式1
			style033.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style033.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style033.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style033.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style033.setAlignment(XSSFCellStyle.ALIGN_CENTER);// 靠左對齊
			style033.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE
					.getIndex());
			style033.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style033.setFont(font03);

			XSSFCellStyle style041 = workBook.createCellStyle();// 欄位樣式1
			style041.setBorderBottom(XSSFCellStyle.BORDER_THIN);// 設定下框線樣式
			style041.setBorderLeft(XSSFCellStyle.BORDER_THIN);// 設定左框線樣式
			style041.setBorderRight(XSSFCellStyle.BORDER_THIN);// 設定右框線樣式
			style041.setBorderTop(XSSFCellStyle.BORDER_THIN);// 設定上框線樣式
			style041.setAlignment(XSSFCellStyle.ALIGN_LEFT);// 靠左對齊
			style041.setFillForegroundColor(IndexedColors.LEMON_CHIFFON
					.getIndex());
			style041.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			style041.setFont(font04);

			XSSFRow row0 = sheet.createRow(0);// 標頭1
			createCell(row0, (short) 0, luckyname, style01);

			XSSFRow row2 = sheet.createRow(1);// 標頭2
			createCell(row2, (short) 0, "編號", style033);
			createCell(row2, (short) 1, "交易序號", style033);
			createCell(row2, (short) 2, "交易日期", style033);
			createCell(row2, (short) 3, "被保險人姓名", style033);
			createCell(row2, (short) 4, "被保險人手機", style033);
			createCell(row2, (short) 5, "被保險人Email", style033);
			createCell(row2, (short) 6, "總實收保費", style033);

			List<?> rptData = generateData11(request, f);

			for (int j = 0; j < rptData.size(); j++)
			{
				Map<?, ?> currentRowData = (Map<?, ?>) rptData.get(j);
				XSSFRow row = sheet.createRow(j + 2);
				String luckyseq = currentRowData.get("luckyseq") == null ? ""
						: currentRowData.get("luckyseq").toString().trim();
				String lucky01 = currentRowData.get("lucky01") == null ? ""
						: currentRowData.get("lucky01").toString().trim();
				String lucky02 = currentRowData.get("lucky02") == null ? ""
						: currentRowData.get("lucky02").toString().trim();
				String lucky03 = currentRowData.get("lucky03") == null ? ""
						: currentRowData.get("lucky03").toString().trim();
				String lucky04 = currentRowData.get("lucky04") == null ? ""
						: currentRowData.get("lucky04").toString().trim();
				String lucky05 = currentRowData.get("lucky05") == null ? ""
						: currentRowData.get("lucky05").toString().trim();
				String lucky06 = currentRowData.get("lucky06") == null ? ""
						: currentRowData.get("lucky06").toString().trim();


				createCell(row, (short) 0, String.valueOf(luckyseq), style041);
				createCell(row, (short) 1, String.valueOf(lucky01), style041);
				createCell(row, (short) 2, String.valueOf(lucky02), style041);
				createCell(row, (short) 3, String.valueOf(lucky03), style041);
				createCell(row, (short) 4, String.valueOf(lucky04), style041);
				createCell(row, (short) 5, String.valueOf(lucky05), style041);
				createCell(row, (short) 6, String.valueOf(lucky06), style041);

			}
			return workBook;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new AsiException("decode Data error");
		}
	}

	private void createCell(XSSFRow headerRow, short cellcnt,
			String cellString, XSSFCellStyle style)
	{
		XSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}
	
	private List<?> generateData10(HttpServletRequest request, WB5M150f f)
			throws AsiException
	{
		tx_controller.begin(0);
		List<?> ret = null;
		try
		{
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT award, prize, winnum, luckyseq, lucky01, lucky02, lucky03, lucky04, lucky05, lucky06 ");
			sql.append("FROM kyclucky2 INNER JOIN kyclucky1 ON kyclucky2.luckyid = kyclucky1.luckyid AND kyclucky2.winseq = kyclucky1.seq ");
			sql.append("WHERE kyclucky1.luckyid =? ");
			sql.append("ORDER BY winseq, winnum ");
			System.out.println(sql);
			String[] args = new String[1];
			args[0] = f.getLuck();
			QueryRunner runner = new QueryRunner();
			ret = (List<?>) runner.query(tx_controller.getConnection(0),
					sql.toString(), args, new TrimedMapListHandler());// 查全部資料
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			tx_controller.close();
		}
		return ret;
	}
	
	private List<?> generateData11(HttpServletRequest request, WB5M150f f)
			throws AsiException
	{
		tx_controller.begin(0);
		List<?> ret = null;
		try
		{
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT luckyseq, lucky01, lucky02, lucky03, lucky04, lucky05, lucky06 ");
			sql.append("FROM kyclucky2 ");
			sql.append("WHERE luckyid =? ");
			sql.append("ORDER BY luckyseq ");
			System.out.println(sql);
			String[] args = new String[1];
			args[0] = f.getLuck();
			QueryRunner runner = new QueryRunner();
			ret = (List<?>) runner.query(tx_controller.getConnection(0),
					sql.toString(), args, new TrimedMapListHandler());// 查全部資料
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			tx_controller.close();
		}
		return ret;
	}

}
