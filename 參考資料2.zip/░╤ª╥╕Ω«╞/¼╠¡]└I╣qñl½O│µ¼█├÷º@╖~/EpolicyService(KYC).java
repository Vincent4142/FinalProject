package com.firstins;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeUtility;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.mail.EmailAttachment;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.asi.adm.ad1.actions.KycLogger;
import com.asi.common.IgnoreSSLProtocolSocketFactory;
import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.ConfigUtil;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycMailUtil;
import com.asi.kyc.dao.WB35PFDao;
import com.kyc.afl.utils.WorkDay;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfEncryptor;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

/**
 * 電子保單相關排程程式
 * @author vsg
 *	actionCode == 1 → 產生保單+條款並加上資訊檔，壓縮成zip存至START資料夾
 *	actionCode == 2 → 讀取END資料夾，找zip檔或p1.log。zip檔為完成驗證檔案，解開資料夾查資訊檔，驗證完成則將pdf複製至NAS保單保存資料夾；p1.log為錯誤件，更新記錄檔
 *	actionCode == 3 → 讀取END資料夾，找p2.log。確認驗簽完成，更新記錄檔
 *	actionCode == 4 → 寄發電子保單動作，查詢未寄發且驗簽完成件，並有實體電子保單的，寄發給客戶
 *	actionCode == 5 → 補寄電子保單，由WB4I070p2頁面發動，讀取pdf並直接寄發，更新wb35pf，且加寫至KYCLLOG
 *	actionCode == 6 → 產生旅平險電子保單
 *	actionCode == 7 → 產生HS新視界保單
 *	actionCode == 8 → 產生VI疫苗險保單
 *	actionCode == 11 → 產生車險全險種電子保單
 */
public class EpolicyService extends AsiAction{

	private String userPWD = "";//PDF UserPassword
	private String ownerPWD = SystemParam.getParam("EIP_OWNERPWD");//PDF OwnerPassword

	private String FOLDER_NAS4_EIP_START = SystemParam.getParam("NAS4_EIP_START");// NAS產生上傳檔用
	private String FOLDER_NAS4_EIP_END = SystemParam.getParam("NAS4_EIP_END");// NAS備份回傳資料夾
	private String FOLDER_NAS4_EIP_ACH = SystemParam.getParam("NAS4_EIP_ACH");// NAS保單保存資料夾
	private String FOLDER_EIP_START = SystemParam.getParam("EIP_START");// 電子保單EIP加簽上傳資料夾
	private String FOLDER_EIP_END = SystemParam.getParam("EIP_END");// 電子保單EIP結果資料夾	
	
	private String timestamp = "";//時間戳記
	private StringBuffer txtfilecontent = null;
	private String pdfName = "";//dpf檔名
	private String destFileFolder = "";//目的資料夾
	private String ziFileName = "";//壓縮檔名
	
	private StringBuffer logmsg = null;
	int logcount = 0;
	
	private String spInsNo = null;

	public void doProcess(ActionMapping arg0, AsiActionForm arg1, HttpServletRequest request, HttpServletResponse response) throws AsiException{
		
		List ret = null;
		List list = null;
		
		//查詢出單日為系統日前一工作日的電商車險任意險保單，進行產生保單及加簽送關貿的動作
		if(arg1.getActionCode() == 1){
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			String c231 = WorkDay.getStrWorkDatebyDays("00", sysdate, false, "1");//取系統日減1天的工作日
			String tdate = request.getParameter("tdate") != null ? request.getParameter("tdate") : "";//傳入特定日期
			if(!tdate.equals(""))
				c231 = tdate;
			
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			
			try {
				ret = getEpolicyIns_Ecom(c231 , spInsNo);//查詢取得有電子保單註記資料
				
				if(ret != null && !ret.isEmpty()){
					logmsg = new StringBuffer();
					Map mp = null ;
					String b3518 = "0";//電子保單驗簽成功日期
					
					for (int i = 0; i < ret.size(); i++) {
						mp = (Map) ret.get(i);
						
						b3518 = mp.get("B3518") != null && !mp.get("B3518").toString().equals("null") ? mp.get("B3518").toString() : "0";
						
						if(b3518.equals("0")){
							
							//產生保單PDF
							getReportFile(mp, "WB4R0901");
							
							//產出批次文字檔
							CreateUploadTxt();
							
							//壓縮檔名
							ziFileName = destFileFolder + ".zip";
							//產生壓縮檔至NAS4目錄
							createZipFile(FOLDER_NAS4_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
							//產生壓縮檔至EIP-START目錄
							createZipFile(FOLDER_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);

							//存在資料時先刪除
							if(isWB35pfExit(mp.get("C202").toString(), "", mp.get("C236").toString(), mp.get("C201").toString(), mp.get("C205").toString(), mp.get("C206").toString())){
								deletetWB35PF(mp.get("C202").toString(), "", mp.get("C236").toString());
							}
							//寫入電子保單記錄檔
							insertWB35PF_C(mp);
							
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + mp.get("C202").toString() + " 產生保單並加簽完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " +DateUtil.getSysTime() + "<br>" );

						}
						
					}
					
					//寄發完成log通知
					sendLogEmail("C" ,request, logcount, logmsg.toString(), "產生電子保單並加簽處理");
				}
											
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		//車險所有電子保單，排除電商，進行產生保單及加簽送關貿的動作
		if(arg1.getActionCode() == 11){
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			String c231 = WorkDay.getStrWorkDatebyDays("00", sysdate, false, "1");//取系統日減1天的工作日
			String tdate = request.getParameter("tdate") != null ? request.getParameter("tdate") : "";//傳入特定日期
			if(!tdate.equals(""))
				c231 = tdate;
			
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			
			try {
				ret = getEpolicyIns_CARALL(c231 , spInsNo);//查詢取得有電子保單註記資料
				
				if(ret != null && !ret.isEmpty()){
					logmsg = new StringBuffer();
					Map mp = null ;
					String b3518 = "0";//電子保單驗簽成功日期
					
					for (int i = 0; i < ret.size(); i++) {
						mp = (Map) ret.get(i);
						
						b3518 = mp.get("B3518") != null && !mp.get("B3518").toString().equals("null") ? mp.get("B3518").toString() : "0";
						
						if(b3518.equals("0")){
							
							//產生保單PDF
							getReportFile(mp, "WB4R0901");
							
							//產出批次文字檔
							CreateUploadTxt();
							
							//壓縮檔名
							ziFileName = destFileFolder + ".zip";
							//產生壓縮檔至NAS4目錄
							createZipFile(FOLDER_NAS4_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
							//產生壓縮檔至EIP-START目錄
							createZipFile(FOLDER_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);

							//存在資料時先刪除
							if(isWB35pfExit(mp.get("C202").toString(), "", mp.get("C236").toString(), mp.get("C201").toString(), mp.get("C205").toString(), mp.get("C206").toString())){
								deletetWB35PF(mp.get("C202").toString(), "", mp.get("C236").toString());
							}
							//寫入電子保單記錄檔
							insertWB35PF_C(mp);
							
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + mp.get("C202").toString() + " 產生保單並加簽完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " +DateUtil.getSysTime() + "<br>" );

						}
						
					}
					
					//寄發完成log通知
					sendLogEmail("C" ,request, logcount, logmsg.toString(), "產生電子保單並加簽處理");
				}
											
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		//VI加簽處理
		if(arg1.getActionCode() == 8){
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			String c231 = WorkDay.getStrWorkDatebyDays("00", sysdate, false, "1");//取系統日減1天的工作日
			String tdate = request.getParameter("tdate") != null ? request.getParameter("tdate") : "";//傳入特定日期
			if(!tdate.equals(""))
				c231 = tdate;
			
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			
			try {
				ret = getEpolicyIns_VI(c231 , spInsNo);//查詢取得有電子保單註記資料
				
				if(ret != null && !ret.isEmpty()){
					logmsg = new StringBuffer();
					Map mp = null ;
					String b3518 = "0";//電子保單驗簽成功日期
					
					for (int i = 0; i < ret.size(); i++) {
						mp = (Map) ret.get(i);
						
						b3518 = mp.get("B3518") != null && !mp.get("B3518").toString().equals("null") ? mp.get("B3518").toString() : "0";
						
						if(b3518.equals("0")){
							
							//產生保單PDF
							getReportFile(mp, "WB1R0501");
							
							//產出批次文字檔
							CreateUploadTxt();
							
							//壓縮檔名
							ziFileName = destFileFolder + ".zip";
							//產生壓縮檔至NAS4目錄
							createZipFile(FOLDER_NAS4_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
							//產生壓縮檔至EIP-START目錄
							createZipFile(FOLDER_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);

							//存在資料時先刪除
							if(isWB35pfExit(mp.get("C202").toString(), "", mp.get("C236").toString(), mp.get("C201").toString(), mp.get("C205").toString(), mp.get("C206").toString())){
								deletetWB35PF(mp.get("C202").toString(), "", mp.get("C236").toString());
							}
							//寫入電子保單記錄檔
							insertWB35PF_TA(mp);
							
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + mp.get("C202").toString() + " 產生保單並加簽完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " +DateUtil.getSysTime() + "<br>" );

						}
						
					}
					
					//寄發完成log通知
					sendLogEmail("O" , request, logcount, logmsg.toString(), "產生電子保單並加簽處理");
				}
											
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		//HS加簽處理
		if(arg1.getActionCode() == 7){
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			String c231 = WorkDay.getStrWorkDatebyDays("00", sysdate, false, "1");//取系統日減1天的工作日
			String tdate = request.getParameter("tdate") != null ? request.getParameter("tdate") : "";//傳入特定日期
			if(!tdate.equals(""))
				c231 = tdate;
			
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			
			try {
				ret = getEpolicyIns_HS(c231 , spInsNo);//查詢取得有電子保單註記資料
				
				if(ret != null && !ret.isEmpty()){
					logmsg = new StringBuffer();
					Map mp = null ;
					String b3518 = "0";//電子保單驗簽成功日期
					
					for (int i = 0; i < ret.size(); i++) {
						mp = (Map) ret.get(i);
						
						b3518 = mp.get("B3518") != null && !mp.get("B3518").toString().equals("null") ? mp.get("B3518").toString() : "0";
						
						if(b3518.equals("0")){
							
							//產生保單PDF
							getReportFile(mp, "WB1R0501");
							
							//產出批次文字檔
							CreateUploadTxt();
							
							//壓縮檔名
							ziFileName = destFileFolder + ".zip";
							//產生壓縮檔至NAS4目錄
							createZipFile(FOLDER_NAS4_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
							//產生壓縮檔至EIP-START目錄
							createZipFile(FOLDER_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);

							//存在資料時先刪除
							if(isWB35pfExit(mp.get("C202").toString(), "", mp.get("C236").toString(), mp.get("C201").toString(), mp.get("C205").toString(), mp.get("C206").toString())){
								deletetWB35PF(mp.get("C202").toString(), "", mp.get("C236").toString());
							}
							//寫入電子保單記錄檔
							insertWB35PF_TA(mp);
							
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + mp.get("C202").toString() + " 產生保單並加簽完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " +DateUtil.getSysTime() + "<br>" );

						}
						
					}
					
					//寄發完成log通知
					sendLogEmail("O" , request, logcount, logmsg.toString(), "產生電子保單並加簽處理");
				}
											
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		
		//旅平險保單加簽處理
		if(arg1.getActionCode() == 6){
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			String c231 = WorkDay.getStrWorkDatebyDays("00", sysdate, false, "1");//取系統日減1天的工作日
			String tdate = request.getParameter("tdate") != null ? request.getParameter("tdate") : "";//傳入特定日期
			if(!tdate.equals(""))
				c231 = tdate;
			
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			
			try {
				ret = getEpolicyIns_TA(c231 , spInsNo);//查詢取得有電子保單註記資料
				
				if(ret != null && !ret.isEmpty()){
					logmsg = new StringBuffer();
					Map mp = null ;
					String b3518 = "0";//電子保單驗簽成功日期
					
					for (int i = 0; i < ret.size(); i++) {
						mp = (Map) ret.get(i);
						
						b3518 = mp.get("B3518") != null && !mp.get("B3518").toString().equals("null") ? mp.get("B3518").toString() : "0";
						
						if(b3518.equals("0")){
							
							//產生保單PDF
							getReportFile(mp, "WB1R0501");
							
							//產出批次文字檔
							CreateUploadTxt();
							
							//壓縮檔名
							ziFileName = destFileFolder + ".zip";
							//產生壓縮檔至NAS4目錄
							createZipFile(FOLDER_NAS4_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
							//產生壓縮檔至EIP-START目錄
							createZipFile(FOLDER_EIP_START + "\\" + ziFileName , FOLDER_NAS4_EIP_START + "\\" + destFileFolder);

							//存在資料時先刪除
							if(isWB35pfExit(mp.get("C202").toString(), "", mp.get("C236").toString(), mp.get("C201").toString(), mp.get("C205").toString(), mp.get("C206").toString())){
								deletetWB35PF(mp.get("C202").toString(), "", mp.get("C236").toString());
							}
							//寫入電子保單記錄檔
							insertWB35PF_TA(mp);
							
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + mp.get("C202").toString() + " 產生保單並加簽完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " +DateUtil.getSysTime() + "<br>" );

						}
						
					}
					
					//寄發完成log通知
					sendLogEmail("O" , request, logcount, logmsg.toString(), "產生電子保單並加簽處理");
				}
											
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		
		//查詢關貿驗證結果資料(END)，並更新記錄檔(WB35PF)及移動資料夾的檔案至NAS4
		if(arg1.getActionCode() == 2){
			
			//列出END所有檔案
			list = readDierctory(FOLDER_EIP_END);
			String target_folder = "";
			
			if(list != null && !list.isEmpty()){
				
				logmsg = new StringBuffer();
				for (int j = 0; j < list.size(); j++) {
					
					if(list.get(j).toString().indexOf(".zip") != -1){
						
						//目的資料夾
						target_folder = FOLDER_EIP_END + "\\" + list.get(j).toString().replace(".zip", "");//以空白取代.zip
						//解壓縮
						unZipFile(FOLDER_EIP_END + "\\" + list.get(j).toString() , target_folder );
						
						//讀解壓縮後資料夾所有檔案
						List insidefiles = readDierctory(target_folder);
						
						for (int i = 0; i < insidefiles.size(); i++) {
							//讀解壓縮後的p1.log
							if(insidefiles.get(i).toString().indexOf("_p1.log") != -1){
								try 
								{
									BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(target_folder + "\\" + insidefiles.get(i).toString()), "utf-8"));//讀出時編碼為utf-8不然會有亂碼
									
									String line = null;
									while ((line = br.readLine()) != null)
									{
										if (line.trim().length() > 0)
										{
											String[] mp = line.toString().split("\\|\\|"); //回傳log檔以||分隔
											String filename = mp[0];
											if(filename.indexOf(".pdf") != -1){
												System.out.println(mp[1] + mp[4]);
												if(mp[3].indexOf("S") != -1 ){
													
													Map wb35data = getWB35PFbyPDFname(mp[1], mp[0]);
													
													if(wb35data != null && !wb35data.isEmpty()){
														
														String saveIns = wb35data.get("B3503").toString();
														String saveYear = wb35data.get("B3514").toString();
														String saveMonth = wb35data.get("B3515").toString();
														String saveDate = wb35data.get("B3530").toString();
														String email = wb35data.get("B3527").toString();
														String username = wb35data.get("C230").toString();
														String tdate = wb35data.get("C247").toString();
														
														//存到NAS4的資料夾：ex：\\Nas4\eip\eiptest\Archive\C\109\05\1090519
														String ach_folder = FOLDER_NAS4_EIP_ACH + "\\" + saveIns + "\\" + saveYear + "\\" + saveMonth + "\\" + saveDate;
														
														//保存電子保單位置
														File folder = new File(ach_folder);
														if (!folder.exists())
															folder.mkdirs();

														//複製檔案
														copyfile(target_folder + "\\" + filename, ach_folder + "\\" + filename);
														
														//更新驗簽資料
														String SignedDate = mp[6].substring(0, 8);//取p1中的時間標籤的年月日
														String SignedTime = mp[6].substring(8, 14);//取p1中的時間標籤的時分秒

														updateWB35PFSigned(SignedDate , SignedTime , mp[3], mp[4], mp[1], "", saveIns);
																												
														//log通知用
														logcount++;
														logmsg.append("保單號碼：" + mp[1] + " 電子保單驗簽並歸檔完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );

													}else{
														//log通知用
														logcount++;
														logmsg.append("保單號碼：" + mp[1] + " 找不到電子保單記錄檔！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
													}
													
												}												
											}											
										}
									}
									br.close();

									//copy資料
									copyfile(FOLDER_EIP_END + "\\" + list.get(j).toString(), FOLDER_NAS4_EIP_END + "\\" + list.get(j).toString());
									
									//刪除END資料
									deleteFile(target_folder);
									deleteFile(FOLDER_EIP_END + "\\" + list.get(j).toString());
									
								} catch (FileNotFoundException e) {								
									e.printStackTrace();
								} catch (IOException e) {								
									e.printStackTrace();
								}

							}
							
						}
					//錯誤件不會有zip檔，直接以文字檔回覆
					} else if(list.get(j).toString().indexOf("_p1.log") != -1){ 
						
						try {
							
							BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(FOLDER_EIP_END + "\\" + list.get(j).toString()) , "utf-8"));//讀出時編碼為utf-8不然會有亂碼
							
							String line = null;
							while ((line = br.readLine()) != null)
							{
								if (line.trim().length() > 0)
								{
									String[] mp = line.toString().split("\\|\\|"); //回傳log檔以||分隔
									String filename = mp[0];
									
									if(filename.indexOf(".pdf") != -1){
										
										if(mp.length == 7){//local端程式回覆的錯誤p1.log欄位長度，7個欄位
											
											if(mp[4].indexOf("E") != -1){//錯誤代碼為E開頭
												
												Map wb35data = getWB35PFbyPDFname(mp[1], mp[0]);
												
												if(wb35data != null && !wb35data.isEmpty()){
													
													String saveIns = wb35data.get("B3503").toString();

													//p1錯誤範例：P10CAR_1000L095B9064_2020_B2C.pdf||1000L095B9064||||E2003||簽章失敗||E2003保險公司簽章失敗||20200526063941
													updateWB35PFError(mp[4], mp[5], mp[6], mp[7], mp[1], "", saveIns);

													//log通知用
													logcount++;
													logmsg.append("保單號碼：" + mp[1] + " 驗簽錯誤！ " + mp[4] + " " + mp[5] + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
												}else{													
													//log通知用
													logcount++;
													logmsg.append("保單號碼：" + mp[1] + " WB35PF查無資料，無法驗簽！ " + mp[4] + " " + mp[5] + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
												}												
											}

										}else{//關貿端程式回覆的錯誤p1.log欄位長度，15個欄位
											
											if(mp[7].indexOf("E") != -1){//錯誤代碼為E開頭
												
												Map wb35data = getWB35PFbyPDFname(mp[1], mp[0]);
												
												if(wb35data != null && !wb35data.isEmpty()){
													
													String saveIns = wb35data.get("B3503").toString();

													//p1錯誤範例：P10CAR_1000A091A0170_2020_KYC.pdf||1000A091A0170||||||||||||E2004||簽章失敗||E2004保發簽章失敗||20200513143256||||||||
													updateWB35PFError(mp[7], mp[8], mp[9], mp[10], mp[1], "", saveIns);

													//log通知用
													logcount++;
													logmsg.append("保單號碼：" + mp[1] + " 驗簽錯誤！ " + mp[7] + " " + mp[8] + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );

												}else{
													//log通知用
													logcount++;
													logmsg.append("保單號碼：" + mp[1] + " WB35PF查無資料，無法驗簽！ " + mp[7] + " " + mp[8] + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );													
												}
											}

										}
										
									}
								}
							}
							
							br.close();
							
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						//copy資料
						copyfile(FOLDER_EIP_END + "\\" + list.get(j).toString(), FOLDER_NAS4_EIP_END + "\\" + list.get(j).toString());
						
						//刪除END資料
						deleteFile(FOLDER_EIP_END + "\\" + list.get(j).toString());

					}
				
					
				}
				
				//寄發完成log通知
				sendLogEmail("" ,request, logcount, logmsg.toString(), "電子保單驗簽記錄");
			}

		}
		
		//存證
		if(arg1.getActionCode() == 3){

			//列出所有檔案
			list = readDierctory(FOLDER_EIP_END);
			
			if(list != null && !list.isEmpty()){
				
				logmsg = new StringBuffer();
				
				for (int j = 0; j < list.size(); j++) {
					if(list.get(j).toString().indexOf("_p2.log") != -1){
						
						try {
							
							BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(FOLDER_EIP_END + "\\" + list.get(j).toString()) , "utf-8"));//讀出時編碼為utf-8不然會有亂碼
							
							String line = null;
							while ((line = br.readLine()) != null)
							{
								if (line.trim().length() > 0)
								{
									String[] mp = line.toString().split("\\|\\|"); //回傳log檔以||分隔
									String filename = mp[0];
									if(filename.indexOf(".pdf") != -1){
										
										if(mp[3].indexOf("S") != -1 ){
											
											Map wb35data = getWB35PFbyPDFname(mp[1], mp[0]);
											
											if(wb35data != null && !wb35data.isEmpty()){
												
												String saveIns = wb35data.get("B3503").toString();
												
												String depositDate = mp[6].substring(0, 8);//取p2中的時間標籤的年月日
												String depositTime = mp[6].substring(8, 14);//取p2中的時間標籤的時分秒

												//p2成功範例：P10CAR_1000L094B9148_2020_B2C.pdf||1000L094B9148||||S0000||成功||||20200519104848
												updateWB35PFDeposit(depositDate, depositTime, mp[3], mp[4], mp[1], "", saveIns);

												//log通知用
												logcount++;
												logmsg.append("保單號碼：" + mp[1] + " 存證完成！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
											}else{
												//log通知用
												logcount++;
												logmsg.append("保單號碼：" + mp[1] + " WB35PF查無資料，無法存證！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );												
											}
										}
									}
								}								
							}
							
							br.close();
							
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						//copy資料
						copyfile(FOLDER_EIP_END + "\\" + list.get(j).toString(), FOLDER_NAS4_EIP_END + "\\" + list.get(j).toString());
						
						//刪除END資料
						deleteFile(FOLDER_EIP_END + "\\" + list.get(j).toString());
						
					}
					
				}
				
				//寄發完成log通知
				sendLogEmail("" ,request, logcount, logmsg.toString(), "電子保單存證記錄");

			}

		}
		
		
		//寄發電子保單
		if(arg1.getActionCode() == 4){

			try {
				ret = getUnsentedData();
				
				if(ret != null && !ret.isEmpty()){
					
					logmsg = new StringBuffer();
					Map wb35data = null;
					
					for (int i = 0; i < ret.size(); i++) {
						
						wb35data = (Map) ret.get(i);
						
						String b3501 = wb35data.get("B3501").toString();
						String b3502 = wb35data.get("B3502").toString();
						String b3503 = wb35data.get("B3503").toString();
						String saveYear = wb35data.get("B3514").toString();
						String saveMonth = wb35data.get("B3515").toString();
						String saveDate = wb35data.get("B3530").toString();
						String email = wb35data.get("B3527").toString();
						String filename = wb35data.get("B3509").toString();
						String c204 =  wb35data.get("C204").toString();
						
						//存到NAS4的資料夾：ex：\\Nas4\eip\eiptest\Archive\C\109\05\1090519
						String ach_folder = FOLDER_NAS4_EIP_ACH + "\\" + b3503 + "\\" + saveYear + "\\" + saveMonth + "\\" + saveDate;
						
						//保存電子保單位置
						File attachfile = new File(ach_folder + "\\" + filename);
						if (attachfile.exists()){
						
							//OHS新視界保單不發送電子保單，僅更新註記
							if(c204.equals("OHS")){
								//更新寄發註記
								updateWB35PFSend(b3501, b3502, b3503 , email);
								
							}else{
								//寄發客戶資料
								if(sendPolicyEmail(request, ach_folder + "\\" + filename, wb35data)){
									//更新寄發註記
									updateWB35PFSend(b3501, b3502, b3503 , email);
								}												
								//log通知用
								logcount++;
								logmsg.append("保單號碼：" + b3501 + " 發送電子保單！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
							}
						}else{
							//log通知用
							logcount++;
							logmsg.append("保單號碼：" + b3501 + " 找不到電子保單PDF！請再確認是否有產生！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
						}
					}
					
					//寄發完成log通知
					sendLogEmail("" ,request, logcount, logmsg.toString(), "電子保單寄發記錄");

				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		

		//補寄電子保單
		if(arg1.getActionCode() == 5){
			int error = 0;
			//指定保單號碼
			spInsNo = request.getParameter("spInsNo") != null ? request.getParameter("spInsNo") : "";
			Map wb35data = null;
			
			try {
				if(!spInsNo.equals("")){
					
					wb35data = geWB35PFDataByInsno(spInsNo);
					
					if(wb35data != null && !wb35data.isEmpty()){
						
						logmsg = new StringBuffer();
						
						String b3501 = wb35data.get("B3501").toString();
						String b3502 = wb35data.get("B3502").toString();
						String b3503 = wb35data.get("B3503").toString();
						String saveYear = wb35data.get("B3514").toString();
						String saveMonth = wb35data.get("B3515").toString();
						String saveDate = wb35data.get("B3530").toString();
						String email = wb35data.get("T2114").toString();//旅平險可能批改EMAIL再補發，所以改抓T2114
						String username = wb35data.get("C230").toString();
						String filename = wb35data.get("B3509").toString();
						String c204 =  wb35data.get("C204").toString();
						
						//存到NAS4的資料夾：ex：\\Nas4\eip\eiptest\Archive\C\109\05\1090519
						String ach_folder = FOLDER_NAS4_EIP_ACH + "\\" + b3503 + "\\" + saveYear + "\\" + saveMonth + "\\" + saveDate;
						
						//保存電子保單位置
						File attachfile = new File(ach_folder + "\\" + filename);
						if (attachfile.exists()){
											
							//OHS新視界保單不發送電子保單，僅更新註記
							if(c204.equals("OHS")){
								//更新寄發註記
								updateWB35PFSend(b3501, b3502, b3503 , email);
							}else{								
								//寄發客戶資料
								if(sendPolicyEmail(request, ach_folder + "\\" + filename, wb35data)){
									//更新寄發註記
									updateWB35PFSend(b3501, b3502, b3503 , email);
								}												

								//log通知用
								logcount++;
								logmsg.append("保單號碼：" + b3501 + " 補寄送電子保單！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
							}
						}else{
							//log通知用
							error++;
							logcount++;
							logmsg.append("保單號碼：" + b3501 + " 找不到電子保單PDF！請再確認是否有產生！ " + DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false) + " " + DateUtil.getSysTime() + "<br>" );
						}					
						
						//寄發完成log通知
						sendLogEmail("" ,request, logcount, logmsg.toString(), "電子保單補寄記錄");

						//寫入KYCLLOG記錄檔處理
						KycLogger klg = new KycLogger();
						klg.LoggerWriter(request, this.getClass().getSimpleName(), "", "WB4I0701", "B", "KYC", "", "", "", b3501, "", "", "", "", "", "RS", "", "補寄電子保單記錄", username + " " + email + " " + filename , "", "", "", "");

					}

				}
				
			} catch (Exception e) {
				e.printStackTrace();
				error++;
			}
			finally
			{

				try
				{
					response.setContentType("text/xml;charset=UTF-8");
					response.setHeader("Cache-Control", "no-cache");
					response.getWriter().write("<?xml version=\"1.0\" ?>");
					response.getWriter().write("<out>");
					response.getWriter().write("<mailstatus>");
					response.getWriter().write(error>0 ? "Email寄發有誤，請聯絡資訊專員！":"電子保單寄發成功!");
					response.getWriter().write("</mailstatus>");
					response.getWriter().write("</out>");
					
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}

			
		}

		arg1.setNextPage(-1);
	}

	/**
	 * 查詢特定電子保單件
	 * @return
	 */
	private Map geWB35PFDataByInsno(String insno){			
		Map ret = null;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			
			ret = wb35dao.queryWB35pfByInsno(insno);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	
	/**
	 * 查詢未發送電子保單件
	 * @return
	 */
	private List getUnsentedData(){			
		List ret = null;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			
			ret = wb35dao.queryWB35pfByUnsented();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}
	
	/**
	 * 刪除資料夾或檔案
	 * @param dtFile
	 */
	private void deleteFile(String dtFile){
    	try{
    		File file = new File(dtFile);
    		
    		if(file.isDirectory()){//目錄
    			
    			String[] flist = file.list();
    			for (int i = 0; i < flist.length; i++) {
					
    				File subfile = new File(dtFile + "\\" + flist[i]);
    				if(subfile.exists())
    					if(subfile.delete())
    						System.out.println("Folder inner File delete.");
				}
    			if(file.delete());
    				System.out.println("Folder delete.");

    		}else{//檔案
    			if(file.exists()){
    				if(file.delete());
    					System.out.println("File delete.");
    			}
    		}
        }
        catch(Exception e){
        	System.out.println(e.getMessage());      
        }
	}
	
    /**
     * 複製檔案
     * @param srFile 來源資料完整路徑
     * @param dtFile 目的資料完整路徑
     */
    private static void copyfile(String srFile, String dtFile){

    	InputStream in = null;
    	OutputStream out = null;
    	try{
    		File f1 = new File(srFile);
    		File f2 = new File(dtFile);
    		in = new FileInputStream(f1);
          
    		out = new FileOutputStream(f2);

    		byte[] buf = new byte[1024];
    		int len;
    		while ((len = in.read(buf)) > 0){
    			out.write(buf, 0, len);
    		}
    		System.out.println("File copied.");
        }
        catch(FileNotFoundException ex){
        	System.out.println(ex.getMessage() + " in the specified directory.");
        }
        catch(IOException e){
        	System.out.println(e.getMessage());      
        }
    	finally{    		
    		try {
				in.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}    		
    	}
	}

	/**
	 * 取出核保人員及主管email
	 * @param list
	 * @return
	 */
	private String[] getAuthManList(String list)
	{
		StringBuffer buf = new StringBuffer();
		buf.append("SELECT * FROM SECAJ WHERE USERID IN (" + list + ")");

		List rs = null;
		String[] email = null;

		Connection con = null;
		try
		{
			con = AS400Connection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			rs = (List) runner.query(con, buf.toString(), new MapListHandler());

			email = new String[rs.size()];
			for (int i = 0; i < rs.size(); i++)
			{
				Map m = (Map) rs.get(i);
				email[i] = m.get("EMAIL").toString();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return email;
	}

    /**
     * 寄發LOG通知
     * @param request
     * @param counts
     * @param content
     */
    private void sendLogEmail(String instype , HttpServletRequest request , int counts , String content , String processDesc){
    	
    	try {
    		
			String ec_maillist = CodeUtil.getCodeList(servlet, request, "ECOM-AGENT");//代碼檔設定之電商窗口及主管
			String[] getecemail = getAuthManList(ec_maillist);//取得人員email
			
			String carowner_maillist = CodeUtil.getCodeList(servlet, request, "CAROWNER");//車險窗口
			String[] carowner_email = getAuthManList(carowner_maillist);//取得人員email

			String paowner_maillist = CodeUtil.getCodeList(servlet, request, "PA_OWNER");//傷害險窗口
			String[] paowner_email = getAuthManList(paowner_maillist);//取得人員email

			String EIPowner_maillist = CodeUtil.getCodeList(servlet, request, "EIP_OWNER");//核保集合窗口
			String[] EIPowner_email = getAuthManList(EIPowner_maillist);//取得人員email
			
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			
			KycMailUtil kmu = new KycMailUtil();
			kmu.setSubject("電子保單處理Log： "+ sysdate + " " + processDesc);
			kmu.setMessage(sysdate + " 電子保單處理筆數：共 " + counts + " 筆<br>" + content);
//			kmu.addTo("vsg@firstins.com.tw");
			
			if(instype.equals("C")){
				kmu.addTo(carowner_email);
				kmu.addCc(getecemail);
			}
			else if(instype.equals("O"))
				kmu.addTo(paowner_email);
			else 
				kmu.addTo(EIPowner_email);
			
			kmu.sendMail();

		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    /**
     * 發送email
     * @param request
     * @param username
     * @param attachpath
     * @param insno
     * @param email
     * 
     * @return
     */
    private boolean sendPolicyEmail(HttpServletRequest request , String attachpath , Map mp){
    	boolean isSentOK = false;
		try
		{
			String ecom_tel = SystemParam.getParam("ECOM_TEL"); // 電商服務電話
			String ecom_fax = SystemParam.getParam("ECOM_FAX"); // 電商傳真電話
			
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty("file.resource.loader.path", request.getServletContext().getRealPath("/"));
			ve.init();
			Template t = ve.getTemplate("mail/EIPNotice_zh_TW.html","utf-8");
			VelocityContext context1 = new VelocityContext();
			
			String insno = mp.get("B3501").toString();
			String carno = mp.get("B3507").toString();
			carno = "*" + carno.substring(1, 5) + "*" + carno.substring(6, carno.length());//隱碼處理
			String client_name = mp.get("C230").toString();
			String aquire_name = mp.get("C249").toString();
			String instype = mp.get("B3503").toString();
			String tdate = mp.get("C247").toString();
			String insname = mp.get("T702") != null ? mp.get("T702").toString() : "";
			String email = mp.get("T2114").toString();//旅平險可能批改EMAIL再補發，所以改抓T2114
			
			context1.put("carno", carno);
			context1.put("insno", insno);
			context1.put("tdate", tdate);
			context1.put("ecom_tel", ecom_tel);
			context1.put("ecom_fax", ecom_fax);
			context1.put("insname", insname);
			
			StringBuffer sb = new StringBuffer();
			
			if(instype.equals("C")){//車險
				context1.put("username", client_name);
				//保險說明
				sb.append("<p>您的車號：<font color=\"#FF0000\">").append(carno).append("</font> 被保險人 <font color=\"#0000E3\">").append(client_name).append("</font> 於本公司投保汽車保險").append("<br>保單號碼：<font color=\"#FF0000\">").append(insno).append("</font> ，您的保單資料如附件。");			
				context1.put("notice" , sb.toString());		
				//密碼說明
				context1.put("lidesc" , "密碼：被保險人身分證/統一編號，身分證字號含英文字母為大寫共10位數字；法人車為統編共8位數字。");		
			}else if(instype.equals("O")){//旅平險
				context1.put("username", aquire_name);
				//保險說明
				sb.append("要保人：<font color=\"#0000E3\">").append(aquire_name).append("</font> 於 <font color=\"#FF0000\">")
				.append(tdate).append("</font> 向本公司投保").append(insname).append("<br>保單號碼：<font color=\"#FF0000\">").append(insno).append("</font> ，您的保單資料如附件。");			
				context1.put("notice" , sb.toString());
				//密碼說明
				context1.put("lidesc" , "密碼：主被保險人身分證字號，身分證字號含英文字母為大寫共10位數字。");		
			}
			
			StringWriter sw = new StringWriter();
			t.merge( context1, sw );
			
			EmailAttachment[] attachment = new EmailAttachment[1];
			// 郵件附加檔-電子式保險證
			attachment[0] = new EmailAttachment();
			attachment[0].setPath(attachpath);
			attachment[0].setDisposition(EmailAttachment.ATTACHMENT);
			// 處理附件檔名編碼
			attachment[0].setName(MimeUtility.encodeText(insno + "-電子保單.pdf", "UTF-8", "B"));
			
			KycMailUtil kmu = new KycMailUtil();
			kmu.addAttachment(attachment);
			kmu.setSubject("第一產物保險股份有限公司-電子保單發送通知");
			kmu.setMessage(sw.getBuffer().toString());
			kmu.addTo(email);
//			kmu.addTo("vsg@firstins.com.tw");
			
			//測試機才副本
			if (!SystemParam.getParam("ENV").equals("KYC")){				
//				String EIPowner_maillist = CodeUtil.getCodeList(servlet, request, "EIP_OWNER");//核保集合窗口
//				String[] EIPowner_email = getAuthManList(EIPowner_maillist);//取得人員email
//				kmu.addCc(EIPowner_email);
				String[] ccmail = new String[2];
				ccmail[0] = "vsg@firstins.com.tw";
				ccmail[1] = "vsg5697@gmail.com";
				kmu.addCc(ccmail);
			}
			
			kmu.sendMailWithAttachments();
			
			isSentOK = true;
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return isSentOK;
    }
    

	/**
	 * 查詢是否有電子保單資料
	 * @param b3501
	 * @param b3502
	 * @param b3503
	 * @param b3505
	 * @param b3511
	 * @param b3512
	 * @return
	 */
	private boolean isWB35pfExit(String b3501 , String b3502 ,String b3503 , String b3505 , String b3511 , String b3512){
		
		boolean isExit = false;
		Map ret = null;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		String stry = b3511.substring(0, 3);
		String strdate_west =String.valueOf(Integer.parseInt(stry) + 1911) + b3511.substring(3, 7); 

		String endy = b3512.substring(0, 3);
		String enddate_west =String.valueOf(Integer.parseInt(endy) + 1911) + b3512.substring(3, 7); 

		
		try {
			
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);			
			wb35dao.setB3505(b3505);
			wb35dao.setB3511(strdate_west);
			wb35dao.setB3512(enddate_west);
	
			ret = wb35dao.queryWB35pfByMultiColumn();
			
			if(ret != null && !ret.isEmpty())
				isExit = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return isExit;
	}

    
	/**
	 * 更新寄送記錄
	 * @param b3501	保單號碼
	 * @param b3502	批單號碼
	 * @param b3503	大險別
	 * @return
	 */
	private int updateWB35PFSend(String b3501, String b3502 , String b3503 , String b3527){
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String systime = DateUtil.getSysTime();

			
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3526("Y");
			wb35dao.setB3528(sysdate);
			wb35dao.setB3529(systime);			
			wb35dao.setB3595(systime);
			wb35dao.setB3598(sysdate);
			wb35dao.setB3599("B2C");
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);
			wb35dao.setB3527(b3527);
	
			ret = wb35dao.updateWb35pf_SendEmail();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	/**
	 * 更新錯誤訊息
	 * @param b3522	處理結果代碼
	 * @param b3523	處理結果訊息 
	 * @param b3524	異常訊息
	 * @param b3525	時間戳記
	 * @param b3501	保單號碼
	 * @param b3502	批單號碼
	 * @param b3503	大險別
	 * @return
	 */
	private int updateWB35PFError(String b3522, String b3523, String b3524, String b3525, String b3501, String b3502 , String b3503){
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String systime = DateUtil.getSysTime();
		
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3522(b3522);
			wb35dao.setB3523(b3523);
			wb35dao.setB3524(b3524);
			wb35dao.setB3525(b3525);
			wb35dao.setB3595(systime);
			wb35dao.setB3598(sysdate);
			wb35dao.setB3599("B2C");
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);
	
			ret = wb35dao.updateWb35pf_Error();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	
	/**
	 * 更新存證資訊
	 * @param b3520
	 * @param b3521
	 * @param b3522	處理結果代碼
	 * @param b3523	處理結果訊息 
	 * @param b3501	保單號碼
	 * @param b3502	批單號碼
	 * @param b3503	大險別
	 * @return
	 */
	private int updateWB35PFDeposit(String b3520, String b3521, String b3522, String b3523, String b3501, String b3502 , String b3503){
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String systime = DateUtil.getSysTime();
		
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3520(b3520);
			wb35dao.setB3521(b3521);
			wb35dao.setB3522(b3522);
			wb35dao.setB3523(b3523);
			wb35dao.setB3595(systime);
			wb35dao.setB3598(sysdate);
			wb35dao.setB3599("B2C");
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);
	
			ret = wb35dao.updateWb35pf_Deposit();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	/**
	 * 更新驗簽資資料
	 * @param b3522	處理結果代碼
	 * @param b3523	處理結果訊息 
	 * @param b3501	保單號碼
	 * @param b3502	批單號碼
	 * @param b3503	大險別
	 * @return
	 */
	private int updateWB35PFSigned(String b3518, String b3519, String b3522, String b3523, String b3501, String b3502 , String b3503){
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String sysy = sysdate.substring(0, 3);
			String sysm = sysdate.substring(3, 5);
			String sysdate_west =String.valueOf(Integer.parseInt(sysy) + 1911) + sysdate.substring(3, 7); 
			String systime = DateUtil.getSysTime();

			
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3518(b3518);
			wb35dao.setB3519(b3519);
			wb35dao.setB3522(b3522);
			wb35dao.setB3523(b3523);
			wb35dao.setB3595(systime);
			wb35dao.setB3598(sysdate);
			wb35dao.setB3599("B2C");
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);
	
			ret = wb35dao.updateWb35pf_Signed();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	/**
	 * 刪除資料
	 * @param b3501
	 * @param b3502
	 * @param b3503
	 * @return
	 */
	private int deletetWB35PF(String b3501, String b3502, String b3503){
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3501(b3501);
			wb35dao.setB3502(b3502);
			wb35dao.setB3503(b3503);
			
			ret = wb35dao.deleteWb35pf();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;

	}
	
	/**
	 * 用保單號碼及電子保單檔名查電子保單記錄檔
	 * @param b3501 保單號碼
	 * @param b3509 電子保單檔名
	 * @return
	 */
	private Map getWB35PFbyPDFname(String b3501 , String b3509){
		Map ret = null;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			wb35dao.setB3501(b3501);
			wb35dao.setB3509(b3509);
			
			ret = wb35dao.queryWB35pfByPDFName();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}
	
	/**
	 * 解壓縮檔案
	 * @param zipFilePath 壓縮檔路徑
	 * @param pwd 解壓縮密碼
	 * @param unZipFolder 解壓縮檔資料夾
	 * @return 0-解壓縮成功,other -解壓縮失敗
	 */
	public int unZipFile(String zipFilePath , String unZipFolder)
	{
		System.out.println("開始解壓縮!!");
		
		int ret = 0;
		// 解壓檔案
		File unzipfileFolder = new File(unZipFolder);
		try
		{
			// 檢查是否已存在匯入資料夾，如有則清除內容，無則新增
			if (unzipfileFolder.exists())
			{
				File[] fileArr = unzipfileFolder.listFiles();
				for (int i = 0; i < fileArr.length; i++)
					fileArr[i].delete();
			}
			else
			{
				unzipfileFolder.mkdirs();
			}
			// 解壓檔案
			Process p = Runtime.getRuntime().exec("c:\\PROGRA~1\\7-Zip\\7Z x " + zipFilePath + " -o" + unZipFolder );
			ret = p.waitFor();
			System.out.println("解壓縮完成!!" + (ret == 0 ? "解壓縮成功" : "解壓縮失敗"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		return ret;
	}

	/**
	 * 讀取資料夾
	 * @param folderPath
	 * @return
	 */
	private List readDierctory(String folderPath){
		
        File f = new File(folderPath); //讀取資料夾，要記得將此資料夾放置同個java file裡面
        ArrayList<String> fileList = new ArrayList<String>(); //宣告一的動態陣列為String的型態，目的用來儲存檔名
        if(f.isDirectory()) //如果f讀到的是資料夾，就會執行
        {
        	List listFile = Arrays.asList(f.list());

        	Collections.sort(listFile);
        	
        	System.out.println("filename : "+f.getName()); //印出我們所讀到的資料夾
            String []s=f.list(); //宣告一個list
            System.out.println("size : "+s.length); //印出資料夾裡的檔案個數
            for(int i=0;i<s.length;i++)
            {
                //System.out.println(s[i]);
                fileList.add(s[i]); //將檔名一一存到fileList動態陣列裡面
            }
        }
        for(int i=0;i<fileList.size();i++)
        {
            System.out.println(fileList.get(i)); //印出資料夾內的檔名
        }

        return fileList;
	}

	
	/**
	 * 寫入電子保單記錄檔-For車險
	 * @param mp
	 * @return
	 */
	private int insertWB35PF_C(Map mp){		
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			
			String b3501 = mp.get("C202").toString();//保單
			String b3505 = mp.get("C201").toString();//ID
			String b3507 = mp.get("T2209").toString();//車牌
			String b3527 = mp.get("T2114").toString();//EMAIL
			
			String stry = mp.get("C205").toString().substring(0, 3);
			String strdate_west = String.valueOf(Integer.parseInt(stry) + 1911) + mp.get("C205").toString().substring(3, 7);
			String endy = mp.get("C206").toString().substring(0, 3);
			String enddate_west = String.valueOf(Integer.parseInt(endy) + 1911) + mp.get("C206").toString().substring(3, 7);
			
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String sysy = sysdate.substring(0, 3);
			String sysm = sysdate.substring(3, 5);
			String sysdate_west =String.valueOf(Integer.parseInt(sysy) + 1911) + sysdate.substring(3, 7); 
			String systime = DateUtil.getSysTime();
			
			wb35dao.setB3501(b3501);
			wb35dao.setB3502("");
			wb35dao.setB3503("C");
			wb35dao.setB3504("CAR");
			wb35dao.setB3505(b3505);//被保險人ID
			wb35dao.setB3506(b3505);//要保人ID
			wb35dao.setB3507(b3507);
			wb35dao.setB3508(destFileFolder);
			wb35dao.setB3509(pdfName);
			wb35dao.setB3510("P");//單據種類	P：電子保單、E：批單、Z：批單(無PDF檔)
			wb35dao.setB3511(strdate_west);
			wb35dao.setB3512(enddate_west);
			wb35dao.setB3513("A");//處理方式註記	A：新增、U：資料覆蓋、D：刪除資料
			wb35dao.setB3514(sysy);
			wb35dao.setB3515(sysm);
			wb35dao.setB3516(sysdate_west);
			wb35dao.setB3517(systime);
			wb35dao.setB3518("0");
			wb35dao.setB3519("0");
			wb35dao.setB3520("0");
			wb35dao.setB3521("0");
			wb35dao.setB3522("");
			wb35dao.setB3523("");
			wb35dao.setB3524("");
			wb35dao.setB3525(timestamp);
			wb35dao.setB3526("");
			wb35dao.setB3527(b3527);
			wb35dao.setB3528("0");
			wb35dao.setB3529("0");
			wb35dao.setB3530(sysdate);
			
			wb35dao.setB3594(systime);
			wb35dao.setB3595("0");
			wb35dao.setB3596(sysdate);
			wb35dao.setB3597("KYC");
			wb35dao.setB3598("0");
			wb35dao.setB3599("");
			
			ret = wb35dao.insertWb35pf();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;
	}
	
	/**
	 * 寫入電子保單記錄檔-For旅平險
	 * @param mp
	 * @return
	 */
	private int insertWB35PF_TA(Map mp){		
		int ret = 0;
		
		WB35PFDao wb35dao = null;
		Connection con = null;
		
		try {
			con = AS400Connection.getConnection();
			wb35dao = new WB35PFDao(con);
			
			String b3501 = mp.get("C202").toString();//保單
			String b3505 = mp.get("C201").toString();//被保險人ID
			String b3506 = mp.get("C248").toString();//要保人ID
			String b3527 = mp.get("T2114").toString();//EMAIL
			
			String stry = mp.get("C205").toString().substring(0, 3);
			String strdate_west = String.valueOf(Integer.parseInt(stry) + 1911) + mp.get("C205").toString().substring(3, 7);
			String endy = mp.get("C206").toString().substring(0, 3);
			String enddate_west = String.valueOf(Integer.parseInt(endy) + 1911) + mp.get("C206").toString().substring(3, 7);
			
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String sysy = sysdate.substring(0, 3);
			String sysm = sysdate.substring(3, 5);
			String sysdate_west =String.valueOf(Integer.parseInt(sysy) + 1911) + sysdate.substring(3, 7); 
			String systime = DateUtil.getSysTime();
			
			wb35dao.setB3501(b3501);
			wb35dao.setB3502("");
			wb35dao.setB3503("O");
			wb35dao.setB3504("PAI");
			wb35dao.setB3505(b3505);//被保險人ID
			wb35dao.setB3506(b3506);//要保人ID
			wb35dao.setB3507("");
			wb35dao.setB3508(destFileFolder);
			wb35dao.setB3509(pdfName);
			wb35dao.setB3510("P");//單據種類	P：電子保單、E：批單、Z：批單(無PDF檔)
			wb35dao.setB3511(strdate_west);
			wb35dao.setB3512(enddate_west);
			wb35dao.setB3513("A");//處理方式註記	A：新增、U：資料覆蓋、D：刪除資料
			wb35dao.setB3514(sysy);
			wb35dao.setB3515(sysm);
			wb35dao.setB3516(sysdate_west);
			wb35dao.setB3517(systime);
			wb35dao.setB3518("0");
			wb35dao.setB3519("0");
			wb35dao.setB3520("0");
			wb35dao.setB3521("0");
			wb35dao.setB3522("");
			wb35dao.setB3523("");
			wb35dao.setB3524("");
			wb35dao.setB3525(timestamp);
			wb35dao.setB3526("");
			wb35dao.setB3527(b3527);
			wb35dao.setB3528("0");
			wb35dao.setB3529("0");
			wb35dao.setB3530(sysdate);
			
			wb35dao.setB3594(systime);
			wb35dao.setB3595("0");
			wb35dao.setB3596(sysdate);
			wb35dao.setB3597("KYC");
			wb35dao.setB3598("0");
			wb35dao.setB3599("");
			
			ret = wb35dao.insertWb35pf();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;
	}

	/**
	 * 產生文字批字檔
	 */
	private void CreateUploadTxt(){	
		//文字檔名稱
		String txtName = destFileFolder + ".txt";		
		FileOutputStream fos = null;
		try {
			//產生PDF檔
			fos = new FileOutputStream(FOLDER_NAS4_EIP_START + "\\" + destFileFolder + "\\" + txtName);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			osw.write(txtfilecontent.toString());
			osw.close();								
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 查詢保險明細資料
	 * @param rptType
	 * @param insNo
	 * @return
	 */
	private List getInsHeadData(String rptType , String insNo){
		
		List ret = null;
		StringBuffer sql = new StringBuffer();
		
		if ("1".equals(rptType))// 原始保單
		{
			sql.append("SELECT UB00,UP06,UB08,UB09,HZ13 ");
			sql.append("FROM PFUB ");
			sql.append("LEFT JOIN PFUP ON UP001=UB00 ");
			sql.append("LEFT JOIN PFHZ ON HZ00=UB00 AND HZ01=UB00 ");
			sql.append("WHERE UB00=? ");		
		}
		else if ("2".equals(rptType))// 最新保單
		{
			sql.append("SELECT WB00 UB00,UP06,WB08 UB08,WB09 UB09,HZ13 ");
			sql.append("FROM PFWB "); 
			sql.append("LEFT JOIN PFUP ON UP001=WB00 "); 
			sql.append("LEFT JOIN PFHZ ON HZ00=WB00 AND HZ01=WB00 ");
			sql.append("WHERE WB00=? ");		
		}
		
		Connection con = null;
		try
		{
			con = AS400Connection.getConnection();
			QueryRunner run = new QueryRunner();
			System.out.println(sql.toString());
			ret = (List) run.query(con, sql.toString(), insNo, new TrimedMapListHandler());
		}catch (Exception e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	/**
	 * 組批次查詢資訊檔
	 * @param rptType
	 * @param insNo
	 * @return
	 */
	private String asembleTxt(String rptType , String insNo , String processtype , String filename){
		StringBuffer sb = new StringBuffer();
		List ret = null;

		try
		{
			ret = getInsHeadData(rptType, insNo);
			
			if(ret != null ){
				Map mp = (Map) ret.get(0);
				
				int stryear = Integer.parseInt(mp.get("UB08").toString().substring(0, 3)) + 1911;
				int endyear = Integer.parseInt(mp.get("UB09").toString().substring(0, 3)) + 1911;
				
				sb.append("P").append("||");//單據種類
				sb.append("10").append("||");//保險公司代碼
				sb.append(insNo).append("||");//保單號
				sb.append(mp.get("UP06").toString().trim()).append("||");//要保人身分證號碼
				sb.append(mp.get("UP06").toString().trim()).append("||");//被保人身分證號碼
				sb.append(stryear).append(mp.get("UB08").toString().substring(3, 7)).append("||");//保單生效日
				sb.append(endyear).append(mp.get("UB09").toString().substring(3, 7)).append("||");//保單到期日
				sb.append(processtype).append("||");//處理方式註記
				sb.append(mp.get("HZ13").toString().trim()).append("||");//e-Mail
				sb.append("").append("||");//批單號碼
				sb.append("").append("||");//批單內容概述
				sb.append(filename);//電子保單PDF檔名
				sb.append("\r\n");
			}
		
		}catch (Exception e)
		{
			e.printStackTrace();
		}	
		
		return sb.toString();
	}

	
	/**
	 * 組批次查詢資訊檔_旅平險
	 * @param rptType
	 * @param insNo
	 * @return
	 */
	private String asembleTxt_TA(Map mp , String insNo , String processtype , String filename){
		StringBuffer sb = new StringBuffer();

		try
		{	
			int stryear = Integer.parseInt(mp.get("C205").toString().substring(0, 3)) + 1911;
			int endyear = Integer.parseInt(mp.get("C206").toString().substring(0, 3)) + 1911;
			
			sb.append("P").append("||");//單據種類
			sb.append("10").append("||");//保險公司代碼
			sb.append(insNo).append("||");//保單號
			sb.append(mp.get("C248").toString().trim()).append("||");//要保人身分證號碼
			sb.append(mp.get("C201").toString().trim()).append("||");//被保人身分證號碼
			sb.append(stryear).append(mp.get("C205").toString().substring(3, 7)).append("||");//保單生效日
			sb.append(endyear).append(mp.get("C206").toString().substring(3, 7)).append("||");//保單到期日
			sb.append(processtype).append("||");//處理方式註記
			sb.append(mp.get("T2114").toString().trim()).append("||");//e-Mail
			sb.append("").append("||");//批單號碼
			sb.append("").append("||");//批單內容概述
			sb.append(filename);//電子保單PDF檔名
			sb.append("\r\n");
		
		}catch (Exception e)
		{
			e.printStackTrace();
		}	
		
		return sb.toString();
	}

	
	/**
	 * 建立壓縮檔
	 * @param zipname 壓縮檔名稱
	 * @param fileszip 壓縮目標檔
	 * @param pwd 加密密碼
	 * @return
	 */
	private boolean createZipFile(String zipname, String filefolder )
	{
		boolean ret = false;
		
		try
		{
			System.out.println("開始壓縮!!");
			Process p = Runtime.getRuntime().exec("c:\\PROGRA~1\\7-Zip\\7Z a -tzip " + zipname + " -r " + filefolder + "\\*.pdf " + filefolder + "\\*.txt " );//指定目錄下的pdf,txt都加入壓縮檔
			int end = p.waitFor();
			System.out.println("壓縮完成!!" + (end == 0 ? "壓縮成功" : "壓縮失敗"));

			ret = true;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

		return ret;
	}

	/**
	 * 取得產生保單檔案連結
	 * @param mp 傳入資料Map
	 * @param sendRptAction 報表action
	 */
	private void getReportFile(Map mp , String sendRptAction )
	{
		File folder = new File(FOLDER_NAS4_EIP_START);
		if (!folder.exists())
			folder.mkdirs();
		
		//上傳批次檔的時間戳記
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmssSS");
		timestamp = sdf.format(new Date());
		
		//關貿程式修改不足17碼時會無法成功。長度不足17碼時用0往右補滿
		if(timestamp.length() != 17)
			timestamp = StringUtils.rightPad(timestamp, 17, "0");
		
		String sysyear = timestamp.substring(0, 4);
		
		String source = mp.get("C246").toString();//IC02PF.C246資料來源
		String c203 = mp.get("C203").toString();//IC02PF.C203險別
		String c204 = mp.get("C204").toString();//IC02PF.C204投保型態
		
		String rptType = "1";// 1-原始保單 2-最新保單
		String insNo = mp.get("C202").toString();// 保單號碼
		String angetCode = mp.get("C213").toString();// 招攬人代號
		String sendReportKey = "";
				
		//相關判斷
		String insTypeCode = "";
		if(c203.equals("C1") || c203.equals("C2")){//車險
			//密碼判斷
			userPWD = mp.get("C201").toString();// 被保人id，當加密密碼

			//PDF保單代碼判斷
			insTypeCode = "CAR";
			
			//傳送報表主key
			sendReportKey = rptType + "_" + insNo;
		}
		else if(c203.equals("O")){//傷健險
			//密碼判斷
			userPWD = mp.get("C201").toString();// 要保人id，當加密密碼
			
			//PDF保單代碼判斷
			if(c204.equals("OTA"))//旅平險
				insTypeCode = "PAI";

			//PDF保單代碼判斷
			if(c204.equals("OHS") || c204.equals("OVI"))//HS & VI
			{
				insTypeCode = "HEA";
				source = c204;
			}

			//傳送報表主key
			sendReportKey = insNo;
		}

		//先產生目的資料夾
		destFileFolder = "10_" + timestamp + "_" + source;//批次檔命名規則-保險公司代碼+"_"+時間戳記+"_"+識別碼
		folder = new File(FOLDER_NAS4_EIP_START + "\\" + destFileFolder);
		if (!folder.exists())
			folder.mkdirs();
				
		//PDF單檔名稱
		pdfName = "P10" + insTypeCode + "_" + insNo + "_" + sysyear + "_" + source + ".pdf";
		
		//組保單資訊檔
		txtfilecontent = new StringBuffer();

		byte[] report = new byte[0];
		try
		{
			
			//跳過SSL憑證檢核
			Protocol easyhttps = new Protocol("https", new IgnoreSSLProtocolSocketFactory(), 443);
			Protocol.registerProtocol("https", easyhttps);
			
			String url = getPath("/"+sendRptAction);

			PostMethod postmethod = new PostMethod(url);
		   	postmethod.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
		   	postmethod.addParameter("ckb", sendReportKey);
		   	postmethod.addParameter("rptType", rptType);
		   	postmethod.addParameter("loginId", angetCode);
		   	postmethod.addParameter("addclause", "Y");//附加條款
		   	
		   	HttpClient client = new HttpClient();
		   	client.setConnectionTimeout(50000);
		   	client.setTimeout(50000);
		   	client.executeMethod(postmethod);
		   	System.out.print(pdfName + " ReportGen Start " + sdf.format(new Date()));
		   	
		   	FileOutputStream fos = new FileOutputStream(new File(FOLDER_NAS4_EIP_START + "\\" + destFileFolder + "\\" + pdfName));
		   	report = postmethod.getResponseBody();
		   	System.out.print(pdfName + " ReportGen End " + sdf.format(new Date()));
		   	
		   	encryptPDF(report, fos);
//		   	fos.write(report);
//			fos.write(postmethod.getResponseBody());
			fos.flush();
			fos.close();
			
			if(c203.equals("O"))
				txtfilecontent.append(asembleTxt_TA(mp , insNo , "A", pdfName));
			else
				txtfilecontent.append(asembleTxt("1", insNo , "A", pdfName));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}

	/**
	 * 取得報表路徑
	 * @param url
	 * @return
	 * @throws JspException
	 */
	public String getPath(String url) throws JspException
	{
		String host = System.getProperty("jasper.report-url");
		if (host == null)
		{
			host = ConfigUtil.getConfig(getServlet(), "jasper.report-intra");
		}
		StringBuffer action = new StringBuffer();
		action.append(host).append(url).append(".do");
		System.out.println("report action path : " + action.toString());
		return action.toString();
	}

	/**
	 * PDF加密處理
	 * @param pdf
	 * @param os
	 */
	private void encryptPDF(byte[] pdf , FileOutputStream os){		
		PdfReader reader;
		try {
			reader = new PdfReader(pdf);
			PdfEncryptor.encrypt(reader, os, userPWD.getBytes(), ownerPWD.getBytes(), PdfWriter.AllowPrinting , false); 
		} catch (IOException e) {
			e.printStackTrace();
		} catch (DocumentException e) {
			e.printStackTrace();
		}		
	}

	/**
	 * 查詢註記電子保單的車險保單資料
	 * 先排除電商2招攬人代號
	 * @param c213	招攬人代號
	 * @param c231	出單日
	 * @return
	 */
	private List getEpolicyIns_CARALL(String c231 , String c202){
		
		String main_condition = c202 != null && !c202.equals("") ? "WHERE C202 =? " : "WHERE C231 =? ";
		String arg = c202 != null && !c202.equals("") ? c202 : c231;

		String sql = "SELECT C201,C202,C203,C204,C213,C205,C206,C231,C236,C246,C248,T2114,T2209,UBA45,B3516,B3517,B3518,B3519,B3520,B3521 "
				+ "FROM IC02PF "
				+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+ "LEFT JOIN PT22PF ON T2201=C202 AND T2202=C203 "
				+ "LEFT JOIN PFUB ON UB00=C202 "
				+ "RIGHT JOIN PFUBA ON UB00=UBA00 "
				+ "LEFT JOIN WB35PF ON B3501=C202 AND B3503=C236 " //串電子保單記錄檔，沒有驗簽、存證完成前的都可重送
				+ main_condition
				+ "AND UBA45 ='Y' "
				+ "AND C203 IN ('C1','C2') "
				+ "AND C213 NOT IN ('96370','96883') "
				+ "AND (C223<>'Y' OR C223 IS NULL) "
				+ "AND (C207 NOT IN('0','4') OR C207 IS NULL) "
				+ "AND (B3518 IS NULL OR B3518=0) ";
		
		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, arg, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;

	}

	
	
	/**
	 * 查詢註記電子保單的車險保單資料
	 * @param c213	招攬人代號
	 * @param c231	出單日
	 * @return
	 */
	private List getEpolicyIns_Ecom(String c231 , String c202){
		
		String main_condition = c202 != null && !c202.equals("") ? "WHERE C202 =? " : "WHERE C231 =? ";
		String arg = c202 != null && !c202.equals("") ? c202 : c231;

		String sql = "SELECT C201,C202,C203,C204,C213,C205,C206,C231,C236,C246,C248,T2114,T2209,T1575,B3516,B3517,B3518,B3519,B3520,B3521 FROM IC02PF "
				+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+ "LEFT JOIN PT22PF ON T2201=C202 AND T2202=C203 "
				+ "RIGHT JOIN PT15PF ON C202=T1504 AND T1538=C246 AND RTRIM(T1575)='Y' "
				+ "LEFT JOIN WB35PF ON B3501=C202 AND B3503=C236 " //串電子保單記錄檔，沒有驗簽、存證完成前的都可重送
				+ main_condition
				+ "AND C213 IN ('96370','96883') "
				+ "AND C203 IN ('C1','C2') AND (C223<>'Y' OR C223 IS NULL) AND (C207 NOT IN('0','4') OR C207 IS NULL) ";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, arg, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;

	}

	/**
	 * 查詢註記電子保單的VI保單資料
	 * @param c231	出單日
	 * @return
	 */
	private List getEpolicyIns_VI(String c231 , String c202){
		
		String main_condition = c202 != null && !c202.equals("") ? "WHERE C202 =? " : "WHERE C231 =? ";
		String arg = c202 != null && !c202.equals("") ? c202 : c231;
		String sql = "SELECT C201,C202,C203,C204,C213,C205,C206,C231,C236,C246,C248,T2114,T1575,B3516,B3517,B3518,B3519,B3520,B3521 FROM IC02PF "
				+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+ "RIGHT JOIN PT15PF ON C202=T1504 AND RTRIM(T1575)='Y' AND T1538 <> 'MP' "
				+ "LEFT JOIN WB35PF ON B3501=C202 AND B3503=C236 " //串電子保單記錄檔，沒有驗簽、存證完成前的都可重送
				+ main_condition 
				+ "AND C204='OVI' AND (C223<>'Y' OR C223 IS NULL) AND (C207 NOT IN('0','4') OR C207 IS NULL) ";   

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, arg, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;

	}

	/**
	 * 查詢註記電子保單的HS保單資料
	 * @param c231	出單日
	 * @return
	 */
	private List getEpolicyIns_HS(String c231 , String c202){
		
		String main_condition = c202 != null && !c202.equals("") ? "WHERE C202 =? " : "WHERE C231 =? ";
		String arg = c202 != null && !c202.equals("") ? c202 : c231;
		String sql = "SELECT C201,C202,C203,C204,C213,C205,C206,C231,C236,C246,C248,T2114,T1575,B3516,B3517,B3518,B3519,B3520,B3521 FROM IC02PF "
				+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+ "RIGHT JOIN PT15PF ON C202=T1504 AND RTRIM(T1575)='Y' AND T1538 <> 'MP' "
				+ "LEFT JOIN WB35PF ON B3501=C202 AND B3503=C236 " //串電子保單記錄檔，沒有驗簽、存證完成前的都可重送
				+ main_condition 
				+ "AND C204='OHS' AND (C223<>'Y' OR C223 IS NULL) AND (C207 NOT IN('0','4') OR C207 IS NULL) ";   

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, arg, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;

	}

	/**
	 * 查詢註記電子保單的旅平險保單資料
	 * @param c231	出單日
	 * @return
	 */
	private List getEpolicyIns_TA(String c231 , String c202){
		
		String main_condition = c202 != null && !c202.equals("") ? "WHERE C202 =? " : "WHERE C231 =? ";
		String arg = c202 != null && !c202.equals("") ? c202 : c231;
		String sql = "SELECT C201,C202,C203,C204,C213,C205,C206,C231,C236,C246,C248,T2114,T1575,B3516,B3517,B3518,B3519,B3520,B3521 FROM IC02PF "
				+ "LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+ "RIGHT JOIN PT15PF ON C202=T1504 AND RTRIM(T1575)='Y' AND T1538 <> 'MP' "
				+ "LEFT JOIN WB35PF ON B3501=C202 AND B3503=C236 " //串電子保單記錄檔，沒有驗簽、存證完成前的都可重送
				+ main_condition 
				+ "AND C204='OTA' AND (C223<>'Y' OR C223 IS NULL) AND (C207 NOT IN('0','4') OR C207 IS NULL) ";   

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, arg, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return ret;

	}

	
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1,
			AsiActionForm arg2) throws AsiException
	{

	}

	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1,
			HttpServletRequest arg2, HttpServletResponse arg3)
			throws IOException, ServletException
	{
		return null;
	}
	
}
