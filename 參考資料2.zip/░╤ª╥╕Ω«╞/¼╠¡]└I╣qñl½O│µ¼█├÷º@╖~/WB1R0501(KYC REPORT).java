/*
 *
 * Copyrights (c) 2005 The First Insurance Co, Ltd. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of  
 * The First Insurance Co, Ltd. ("Confidential Information").  
 * You shall not disclose such Confidential Information and shall use 
 * it only in accordance with the terms of the license agreement you 
 * entered into with The First Insurance Co, Ltd. 
 * 
 */
package com.asi.kyc.wb1.actions;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.table.TableModel;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.asi.common.GlobalKey;
import com.asi.common.exception.AsiException;
import com.asi.common.exception.UserException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.CodeUtil;
import com.asi.common.util.DateUtil;
import com.asi.common.util.FormatUtil;
import com.asi.kyc.common.Number;
import com.asi.kyc.common.ReportProvider;
import com.asi.kyc.common.ResultSetDataSource;
import com.asi.kyc.common.SystemParam;
import com.asi.kyc.common.utils.AS400Connection;
import com.asi.kyc.common.utils.KycConnection;
import com.asi.kyc.common.utils.TrimedMapHandler;
import com.asi.kyc.common.utils.TrimedMapListHandler;
import com.asi.kyc.wb1.forms.WB1R050f;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BadPdfFormatException;
import com.lowagie.text.pdf.PdfCopy;
import com.lowagie.text.pdf.PdfReader;


/**
 * 旅平險保單產生程式	
 * @author vsg
 * @Create Date：2020/08/03	
 *
 */
public class WB1R0501 extends AsiAction
{
	private byte[] pdf = null; // 合併所有保單的pdf檔

	private Locale locale = null;

	private static Log logger = null;
	
	private HashMap param;

	private String jasperPage1 = "WB1R050";		//旅平險保單
	private String jasperPage2 = "WB1R051";		//被保險人明細表
	private String jasperPage3 = "WB1R052";		//受益人明細表
	private String jasperPage4 = "WB1R053";		//收據
	
	private String jasperPage5 = "WB1R060";		//HS保單
	private String jasperPage6 = "WB1R061";		//HS收據
	
	private String jasperPage7 = "WB1R070";		//VI保單
	private String jasperPage8 = "WB1R071";		//VI被保險人明細表
	private String jasperPage9 = "WB1R072";		//VI收據
	
	private int people_count = 0;//被保險人數
	
	private static String FOLDER_NAS4_EIP_CLAUSE = SystemParam.getParam("NAS4_EIP_CLAUSE");// NAS條款保存資料夾
	
	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3)
	{
		WB1R050f f = (WB1R050f) arg1;
		f.setActionCode(GlobalKey.ACTION_SELECT);
	}

	public void doProcess(ActionMapping map, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		logger = LogFactory.getLog(WB1R0501.class);
		
		WB1R050f f = (WB1R050f) form;
		String[] input = f.getCkb();// 傳入參數

		boolean addclause = false;//是否附加條款
		if(f.getAddclause() !=null){
			if(f.getAddclause().equals("Y"))
				addclause = true;
		}
		
		tx_controller.begin(0);
		locale = tx_controller.getUserLocale();

		callReportObject(input, addclause , servlet , request);

		response.setContentType("application/pdf");
		response.setHeader("Content-disposition", "attachment; filename=report.pdf");
		
		//pdf = mergePdf(report , addclause, f.getCkb());
		
		// pdf = 傳回來的陣列
		if (pdf != null)
		{
			try
			{
				OutputStream os = response.getOutputStream();
				os.write(pdf, 0, pdf.length);
				os.flush();
				os.close();
			}
			catch (IOException ioe)
			{
				throw new UserException("輸出報表資料時發生錯誤! " + ioe);
			}
		}
		else
		{
			throw new UserException("報表產生失敗");
		}
		form.setNextPage(-1);
	}

	/**
	 * 逐筆產生保單
	 * 
	 * @param choiceReport
	 * @param servlet
	 * @throws AsiException
	 */
	public void callReportObject(String[] choiceReport,boolean addclause, HttpServlet servlet , HttpServletRequest request) throws AsiException
	{
		int reportCount = choiceReport.length; // 勾選的保單總數

		byte[][] report = new byte[reportCount][]; // 存放每份保單的pdf檔
		
		for (int i = 0; i < reportCount; i++)
		{
				report[i] = createReport(request , choiceReport[i]);
		}
		
		pdf = mergePdf(report , addclause , choiceReport);
	}

	/**
	 * 合併報表
	 * @param byte[][] report 每份保單的byte陣列 ，boolean addClause 是否附加條款
	 * @return 合併之pdf報表資料
	 */
	public byte[] mergePdf(byte[][] report , boolean addClause , String[] ckb)
	{
		Document document = new Document();
		PdfCopy pdfcopy = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();

		String insNo = "";// 保單號碼

		try
		{
			pdfcopy = new PdfCopy(document, os);
			document.open();
			for (int i = 0; i < report.length; i++)
			{
				copyPdf(pdfcopy, report[i]);
				
				//附加條款
				if(addClause){
					insNo = ckb[i];
					
					List ret = getClausePDF(insNo);
					
					if(ret != null && !ret.isEmpty()){
						Map mp = null;
						String filepath = "";
						for (int j = 0; j < ret.size(); j++) {
							mp = (Map) ret.get(j);
							
							filepath = FOLDER_NAS4_EIP_CLAUSE + "\\" + mp.get("PA01") + "\\" + mp.get("PA03") + "\\" + mp.get("PA07");
							System.out.println(filepath);
							//加入PDF
							copyPdfFromFile(pdfcopy, filepath);
						}

					}			
				}
			}
						
			os.close();
			document.close();
		}
		catch (DocumentException de)
		{
			logger.error("合併報表時失敗", de);
		}
		catch (IOException ioe)
		{
			logger.error("合併報表時失敗", ioe);
		}
		return os.toByteArray();
	}
	
	/**
	 * 依起保日、條款代號查詢資料
	 * @param strdate
	 * @param pa02
	 * @return
	 */
	private Map getKYCPB(String strdate , String pa02){
		
		Map mp = null;
		//組查詢條款SQL
		String sql = "SELECT * FROM KYCPB "
				+ "LEFT JOIN KYCPA ON PA01=PB01 AND PA02=PB02 AND PA03=PB03 AND "
				+ "(CASE WHEN PB04 ='1' THEN ? ELSE ? END) BETWEEN PA04 AND PA05 " //KYCPB.PB04 日期查詢依據 , 1=保單生效日 2=系統日
				+ "WHERE PA01='O' AND PB05='Y' AND PA02 = ? ";//KYCPB.PB05 是否貼條款 
		
		//查詢條款參數
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String[] args = new String[3];
		args[0] = strdate;//查詢條款參數，保單生效日
		args[1] = sysdate;
		args[2] = pa02;
		
		Connection con = null;

		try {
			con = KycConnection.getOracleConnection();
			QueryRunner runner = new QueryRunner();
			mp = (Map) runner.query(con, sql, args, new TrimedMapHandler());//查詢條款資料		
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}
		
		return mp;
	}

	/**
	 * 取得保單條款
	 * @param rptType 原始保單/最新保單
	 * @param isnno 保單號碼
	 * @return
	 */
	private List getClausePDF(String isnno){
		
		List ret = null;
		String strdate = "";
		Map kycpb = null;
		String pa02 = "";
		
		try 
		{
			ret = getEPSJPFList(isnno);//查詢保單條款清單
			
			if(ret != null && !ret.isEmpty()){
				
				for (int i = 0; i < ret.size(); i++) {
					Map mp = (Map) ret.get(i);
					strdate = mp.get("T2115").toString();//起保日
					pa02 = mp.get("SJ005").toString();//條款代號
					
					kycpb = getKYCPB(strdate, pa02);//查詢條款維護資料
					
					if(kycpb != null && !kycpb.isEmpty()){						
						mp.putAll(kycpb);
					}
				}								
			}		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		
		return ret;
	}

	/**
	 * 複製報表
	 * @param pdfcopy
	 * @param other
	 */
	private static void copyPdfFromFile(PdfCopy pdfcopy, String path)
	{
		try
		{
			PdfReader reader = new PdfReader(path);
			int j = reader.getNumberOfPages();
			for (int k = 0; k < j;)
			{
				k++;
				com.lowagie.text.pdf.PdfImportedPage pdfimportedpage = pdfcopy.getImportedPage(reader, k);
				pdfcopy.addPage(pdfimportedpage);
			}
			com.lowagie.text.pdf.PRAcroForm pracroform = reader.getAcroForm();
			if (pracroform != null)
			{
				pdfcopy.copyAcroForm(reader);
			}
		}
		catch (IOException ioe)
		{
			logger.error("複製報表時失敗", ioe);
		}
		catch (BadPdfFormatException bpfe)
		{
			logger.error("複製報表時失敗", bpfe);
		}
	}

	
	/**
	 * 產生報表
	 * @param template
	 * @param key
	 * @param type
	 * @return
	 * @throws AsiException
	 */
	public byte[] createReport(HttpServletRequest request , String key) throws AsiException
	{
		
		tx_controller.begin(1);
		Connection conn = tx_controller.getConnection(1);
		WB1R0502 wb502 = new WB1R0502(key, conn, locale, servlet);
		WB1R0503 wb503 = new WB1R0503(key, conn, locale, servlet);
		TableModel tm1 = null;
		TableModel tm2 = null;
		
		JRDataSource ds = null;
		JRDataSource ds2 = null;
		JRDataSource ds3 = null;
		Map maintata = null;
		List inscontent = null;

		InputStream is1 = null;
		InputStream is2 = null;
		InputStream is3 = null;
		InputStream is4 = null;

		JasperPrint jpP1 = null;
		JasperPrint jpP2 = null;
		JasperPrint jpP3 = null;
		JasperPrint jpP4 = null;
		
		boolean isHS = false;
		boolean isVI = false;
		
		try
		{
			//判斷是否為HS保單
			if(key.indexOf("HS") != -1)
				isHS = true;
			//判斷是否為HS保單
			if(key.indexOf("VI") != -1)
				isVI = true;
			//置換加入的Template
			if(isHS){
				jasperPage1 = jasperPage5;
				jasperPage4 = jasperPage6;
			}
			if(isVI){
				jasperPage1 = jasperPage7;
				jasperPage4 = jasperPage9;
			}
			
			maintata = getDetail(key);
			inscontent = asembleInsContent(maintata);
			
			ds = new JRMapCollectionDataSource(inscontent);
			gatherParam(request , maintata);//參數處理
			
			List list = new ArrayList();
			
			is1 = ReportProvider.getReport(jasperPage1);
			jpP1 = JasperFillManager.fillReport(is1, param , ds);
			
			list.add(jpP1);
			
			if(!isHS && !isVI){
				//被保人明細
				tm1 = wb502.getTableModel(key);
				if (tm1 != null)
					ds = ResultSetDataSource.build(tm1);
				//動態組特定事故項目的欄位名稱
				String[] column_name = wb502.getPa_spac_name();
				if(column_name.length > 0){
					for (int i = 0; i < column_name.length; i++) {
						param.put("addins0" + (i+1), column_name[i].substring(0, 4) + "/" + column_name[i].substring(4, column_name[i].length()));
					}
				}		
				is2 = ReportProvider.getReport(jasperPage2);
				jpP2 = JasperFillManager.fillReport(is2, param , ds);
					
				list.add(jpP2);
				
				//受益人明細
				tm2 = wb503.getTableModel(key);
				if (tm2 != null)
					ds2 = ResultSetDataSource.build(tm2);
				
				is3 = ReportProvider.getReport(jasperPage3);
				jpP3 = JasperFillManager.fillReport(is3, param , ds2);
				
				list.add(jpP3);
			}		
			//VI被保險人超過兩人以上則加入被保險人名冊
			if(isVI && getPT24PF(key).size() > 1){
				//被保人明細
				tm1 = wb502.getTableModel(key);
				if (tm1 != null)
					ds3 = ResultSetDataSource.build(tm1);
				
				is2 = ReportProvider.getReport(jasperPage8);
				jpP2 = JasperFillManager.fillReport(is2, param , ds3);
				
				list.add(jpP2);
			}
			
			//收據
			is4 = ReportProvider.getReport(jasperPage4);
			jpP4 = JasperFillManager.fillReport(is4, param);
			
			list.add(jpP4);


			//使用下列的方式，可以依照加入list的頁面格式自行展現，不須使用setOrientation的方式處理
			ByteArrayOutputStream baos = new ByteArrayOutputStream();       
			JRPdfExporter exporter = new JRPdfExporter();       
			//this sets the list of jasperPrint objects to be exported and merged
			exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, list);
			//the bookmarks is a neat extra that creates a bookmark for each jasper print
			exporter.setParameter(JRPdfExporterParameter.IS_CREATING_BATCH_MODE_BOOKMARKS, Boolean.TRUE);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, baos);     
			exporter.exportReport();        
//			return baos.toByteArray();
			
			pdf = baos.toByteArray();
//			pdf = JasperExportManager.exportReportToPdf(jpP2);

		}
		catch (JRException jre)
		{
			logger.error("報表編譯失敗", jre);
		}
		catch (IOException ioe)
		{
			logger.error("報表轉PDF時失敗", ioe);
		}
		return pdf;
	}
	
	/**
	 * 轉序號為中文
	 * @param i
	 * @return
	 */
	private String getSnChinese(int i){
		String sn = "";
		
		switch(i) { 
	        case 0:
	        	sn = "一、";
	        	break;
	        case 1: 
	        	sn = "二、";
	        	break;
	        case 2: 
	        	sn = "三、";
	        	break;
	        case 3: 
	        	sn = "四、";
	        	break;
	        case 4: 
	        	sn = "五、";
	        	break;
	        case 5: 
	        	sn = "六、";
	        	break;
	        case 6: 
	        	sn = "七、";
	        	break;
	        case 7: 
	        	sn = "八、";
	        	break;
	        case 8: 
	        	sn = "九、";
	        	break;
	        case 9: 
	        	sn = "十、";
	        	break;
	        default: 
	        	break;
		}
		
        return sn;
    }
		
	/**
	 * HS 查詢交易記錄投保方案
	 * @param key
	 * @return
	 */
	private List getPT18PF(String key){
		
		String sql = "SELECT PT18PF.* FROM PT18PF LEFT JOIN PT15PF ON T1801=T1501 AND T1802=T1502 AND T1803=T1503 WHERE T1504=?";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	
	/**
	 * 查詢旅平險被保險人明細
	 * @param key
	 * @return
	 */
	private List getPT24PF(String key){
		
		String sql = "SELECT * FROM PT24PF WHERE T2401=?";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());
			
			if(ret != null && !ret.isEmpty())
				people_count = ret.size();
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	
	/**
	 * 查詢旅平險保單主要資料檔
	 * @param key
	 * @return
	 */
	private Map getDetail(String key){
		
		String sql = "SELECT T2101,T2136,T2137,T2104,T2105,T2106,T2109,T2110,"
				+"T2115,T2116,T2140,T2142,T2143,T2111,T2113,T2114,T2131,T2132,T2127,T2144,T2145,T2147,"
				+"C213,C231,ZN04,SUBSTR(FBZZPF.ZZ03,18,8) AS ZZ03 "
				+"FROM IC02PF "
				+"LEFT JOIN PT21PF ON T2101=C202 AND T2102=C203 "
				+"LEFT JOIN FBZNPF ON ZN01='E' AND ZN02=SUBSTR(C202,1,4) "
				+"LEFT JOIN FBZZPF ON ZZ01='BO' AND ZZ02=ZN04 "
				+"WHERE C202=? " ; 

		Map ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (Map) runner.query(con, sql, key, new TrimedMapHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}
	
	/**
	 * 以保單號碼查詢適用條款清單
	 * @param key
	 * @return
	 */
	private List getEPSJPFList (String key){
		
		String sql = "SELECT * FROM PT21PF "
				+ "LEFT JOIN EPSJPF ON T2101=SJ001||SJ002 "
				+ "WHERE T2101= ? "; 

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}
	
	/**
	 * 處理適用條款
	 * @param key
	 * @return
	 */
	private String getSj005desc(List ret){	
		String sj005desc = "";
		
		if(ret != null && !ret.isEmpty()){
			for (int i = 0; i < ret.size(); i++) {
				Map mp = (Map) ret.get(i);
				sj005desc += mp.get("SJ005") != null ? mp.get("SJ005").toString() + " " : "";
			}	
		}

		return sj005desc;
	}

	/**
	 * 組合保險內容
	 * @param mp
	 * @return
	 */
	private List asembleInsContent(Map mp){
		
		String key = mp.get("T2101").toString();//保單號碼
		String project = mp.get("T2127") != null ? mp.get("T2127").toString() : "";//專案代碼
		
		String project_vi = mp.get("T2144").toString();//主險保額，用來區別VI計畫別
		String funeral=mp.get("T2145").toString().substring(0,3)+","+mp.get("T2145").toString().substring(3);
		
		List ret = new LinkedList();
		int counts = 0;
		Map addmp = null;
		boolean isHS = false;
		boolean isVI = false;
		
		List pt18pf = null;
		String project_hs = "";
		
		try {
			//判斷是否為HS保單
			if(key.indexOf("HS") != -1)
				isHS = true;
			//判斷是否為VI保單
			if(key.indexOf("VI") != -1)
				isVI = true;
			
			if(!isHS && !isVI){
				//是否有旅平險
				if(getPT24PF(key).size() > 0){
					addmp = new HashMap();
					addmp.put("content", getSnChinese(counts) + "旅行平安保險　　　　　　　　　　　　　　　　　　　　(詳如被保險人名冊)");
					ret.add(counts, addmp);
					counts++;
				}
				//是否有海突
				if(isPt25pfExistOHS(key)){
					addmp = new HashMap();
					addmp.put("content", getSnChinese(counts) + "海外突發疾病醫療保險　　　　　　　　　　　　　　　　(詳如被保險人名冊)");
					ret.add(counts, addmp);
					counts++;
				}
				//是否有個責
				List ep28pf = getEP28PF(project);
				if(ep28pf != null && !ep28pf.isEmpty()){
					addmp = new HashMap();
					addmp.put("content", getSnChinese(counts) + "個人旅遊綜合保險");
					ret.add(counts, addmp);
					counts++;

					ret.addAll(ep28pf);
				}	
			}else{
				getPT24PF(key);//查詢被保險人明細，以計算人數
				
				pt18pf= getPT18PF(key);
				if(pt18pf != null && !pt18pf.isEmpty()){
					Map mp18 =(Map) pt18pf.get(0);	
					project_hs = mp18.get("T1840").toString();
					
				}
				addmp = new HashMap();
				
				if(project_hs.equals("1")){
					
					addmp = new HashMap();
					addmp.put("content", "第一產物新視界健康保險　　　　　　　　　　　　　　　　　　　　　　　　計畫一");
					ret.add(counts, addmp);
					counts++;

					addmp = new HashMap();
					addmp.put("content", "　　HS1 住院醫療費用保險金(同一次住院期間限額)　　　　　　　　　　　 50,000");
					ret.add(counts, addmp);
					counts++;
					
					addmp = new HashMap();
					addmp.put("content", "　　HS2 一般門診手術費用保險金(每次限額)　　　　　　　　　　　　　　　5,000");
					ret.add(counts, addmp);
					counts++;

					addmp = new HashMap();
					addmp.put("content", "　　HS3 眼科特定疾病(白內障及青光眼)門診手術費用保險金(每次限額)　　 25,000");
					ret.add(counts, addmp);
					counts++;
								
				}else if(project_hs.equals("2")){
					
					addmp = new HashMap();
					addmp.put("content", "第一產物新視界健康保險　　　　　　　　　　　　　　　　　　　　　　　　計畫二");
					ret.add(counts, addmp);
					counts++;

					addmp = new HashMap();
					addmp.put("content", "　　HS1 住院醫療費用保險金(同一次住院期間限額)　　　　　　　　　　　 100,000");
					ret.add(counts, addmp);
					counts++;
					
					addmp = new HashMap();
					addmp.put("content", "　　HS2 一般門診手術費用保險金(每次限額)　　　　　　　　　　　　　　　10,000");
					ret.add(counts, addmp);
					counts++;

					addmp = new HashMap();
					addmp.put("content", "　　HS3 眼科特定疾病(白內障及青光眼)門診手術費用保險金(每次限額)　　　25,000");
					ret.add(counts, addmp);
					counts++;
					
				}
				//VI險種
				else{
					if(project_vi.equals("1000")){
						addmp = new HashMap();
						addmp.put("content", "第一產物COVID-19疫苗接種保障綜合保險");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VI  殯葬費用保險金                                               "+funeral);
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI1一般住院日額保險金(最高給付45日)                               1,000");
						ret.add(counts, addmp);
						counts++;

						addmp = new HashMap();
						addmp.put("content", "　　VHI2加護病房或隔離病房住院日額保險金(最高給付45日)                 1,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI3住院關懷保險金(連續住院3日以上，保單年度以給付一次為限)       5,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI4出院慰問保險金(保單年度以給付一次為限)                         2,000");
						ret.add(counts, addmp);
						counts++;
					}
					if(project_vi.equals("2000")){
						addmp = new HashMap();
						addmp.put("content", "第一產物COVID-19疫苗接種保障綜合保險");
						ret.add(counts, addmp);
						counts++;

						addmp = new HashMap();
						addmp.put("content", "　　VI  殯葬費用保險金                                               "+funeral);
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI1一般住院日額保險金(最高給付45日)                               2,000");
						ret.add(counts, addmp);
						counts++;

						addmp = new HashMap();
						addmp.put("content", "　　VHI2加護病房或隔離病房住院日額保險金(最高給付45日)                 2,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI3住院關懷保險金(連續住院3日以上，保單年度以給付一次為限)       10,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI4出院慰問保險金(保單年度以給付一次為限)                         2,000");
						ret.add(counts, addmp);
						counts++;
					}
					else if(project_vi.equals("3000")){
						addmp = new HashMap();
						addmp.put("content", "第一產物COVID-19疫苗接種保障綜合保險");
						ret.add(counts, addmp);
						counts++;

						addmp = new HashMap();
						addmp.put("content", "　　VI  殯葬費用保險金                                               "+funeral);
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI1一般住院日額保險金(最高給付45日)                               3,000");
						ret.add(counts, addmp);
						counts++;

						addmp = new HashMap();
						addmp.put("content", "　　VHI2加護病房或隔離病房住院日額保險金(最高給付45日)                 3,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI3住院關懷保險金(連續住院3日以上，保單年度以給付一次為限)       15,000");
						ret.add(counts, addmp);
						counts++;
						
						addmp = new HashMap();
						addmp.put("content", "　　VHI4出院慰問保險金(保單年度以給付一次為限)                         3,000");
						ret.add(counts, addmp);
						counts++;
					}					
				}
			}
							
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		return ret;
	}
	
	/**
	 * PT25PF是否存在OHS方案
	 * @param key
	 * @return
	 */
	private boolean isPt25pfExistOHS(String key){
		boolean isexit = false;
		String sql = "SELECT * FROM PT25PF WHERE T2501 = ? AND T2506 IN ('OHS')";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());
			if(ret != null && ret.size() > 0)
				isexit = true;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return isexit;
	}

	/**
	 * 查詢個人綜合保險明細
	 * @param key
	 * @return
	 */
	private List getEP28PF(String key){
		
		String sql = "SELECT '　　'||P2805 AS content FROM EP28PF WHERE P2801 = ? ORDER BY P2804";//加空白以縮排

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return ret;
	}

	
	/**
	 * 處理其他參數
	 * @param mp
	 * @throws AsiException
	 */
	public void gatherParam(HttpServletRequest request , Map mp) throws AsiException
	{
		param = new HashMap();
		String img = null;

		param.putAll((HashMap) mp);
		String serialno = "";
		try
		{
			//Logo
			img = ReportProvider.getImage("First_LogoWord.jpg");
			param.put("First_Word", img);
			
			//公司大小章
			img = ReportProvider.getImage("Firstins_Seal_ForEpolicy-M.jpg");
			param.put("Stamp_Company", img);

			//董事長私章
			img = ReportProvider.getImage("President_PS-M.png");
			param.put("Stamp_President", img);

			//董事長小章
			img = ReportProvider.getImage("President_FirstIns_Seal_M.png");
			param.put("Stamp_President_FirstIns", img);

			//核保章
			String zn04 = mp.get("ZN04").toString();
			if(zn04.equals("V") || zn04.equals("W"))//北市區、新北
				img = ReportProvider.getImage("UnderWrite_Seal_VW.jpg");
			else if(zn04.equals("C"))//台中區
				img = ReportProvider.getImage("UnderWrite_Seal_C.jpg");
			else if(zn04.equals("A"))//桃竹區
				img = ReportProvider.getImage("UnderWrite_Seal_A.jpg");
			else if(zn04.equals("K"))//高屏區
				img = ReportProvider.getImage("UnderWrite_Seal_K.jpg");
			else if(zn04.equals("N"))//雲嘉南
				img = ReportProvider.getImage("UnderWrite_Seal_N.jpg");
			param.put("Stamp_UnderWrite", img);

			//印花資料			
			param.put("tax1", CodeUtil.getCodeDesc(servlet,locale,"CAR-TAX1",zn04));
			param.put("tax2", CodeUtil.getCodeDesc(servlet,locale,"CAR-TAX2",zn04));
			param.put("tax3", CodeUtil.getCodeDesc(servlet,locale,"CAR-TAX3",zn04));
			
			//條款
			param.put("SJ005DESC", getSj005desc(getEPSJPFList(mp.get("T2101").toString())));
			
			//旅遊天數計算
			String strd = mp.get("T2115").toString();
			String endd = mp.get("T2116").toString();			
			double tripdays = DateUtil.getDateInterval(DateUtil.ChType, DateUtil.Format_YYYYMMDD, endd , strd);
			param.put("tripdays", String.valueOf((int)tripdays));
			
			// 取流水序號
			String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
			String sysy = sysdate.substring(0, 3);
			String sysdate_west =String.valueOf(Integer.parseInt(sysy) + 1911) + sysdate.substring(3, 7); 
			
			//判斷是否為HS保單
			String key = mp.get("T2101").toString();
			boolean isHS = false;
			if(key.indexOf("HS") != -1)
				isHS = true;
			
			boolean isVI = false;
			if(key.indexOf("VI") != -1)
				isVI = true;

			//取序號
			if(isHS || isVI)
				serialno = Number.getNumber_HS_ReceiptSN(servlet, request, "O", "Z", zn04 , sysdate_west);
			else
				serialno = Number.getNumber_TA_Serial(servlet, request, "O", "T", zn04 , sysdate_west);
			
			insertKYCKZ("1" , mp.get("C213").toString() , mp.get("T2101").toString(), serialno , sysdate_west );
			param.put("serialno", serialno);

			//處理要保人ID隱碼
			String t2137 = mp.get("T2137").toString();
			param.put("t2137d", t2137.substring(0, 3) + "****" + t2137.substring(7, t2137.length()));
			
			//處理被保險人ID隱碼
			String t2105 = mp.get("T2105").toString();
			param.put("t2105d", t2105.substring(0, 3) + "****" + t2105.substring(7, t2105.length()));
			
			//處理手機隱碼
			String t2113 = mp.get("T2113") != null ? mp.get("T2113").toString() : "";
			if(!t2113.equals(""))
				param.put("t2113d", t2113.substring(0, 2) + "*****" + t2113.substring(7, t2113.length()));										
			
			//處理EMAIL隱碼
			String t2114 = mp.get("T2114") != null ? mp.get("T2114").toString() : "";
			if(!t2114.equals(""))
				param.put("t2114d", t2114.substring(0, 2) + "*******" + t2114.substring(t2114.indexOf("@"), t2114.length()));							
			
			//被保險人人數
			param.put("people", String.valueOf(people_count));

			if(people_count == 1)
				param.put("total_pa", String.valueOf(getTotal_PA(mp.get("T2101").toString())));
			else
				param.put("total_pa", "0");
			
			//HS商品文號
			if(isHS)
				param.put("goodscode", "109.12.30一產精字第1090858號函備查、110.01.27一產精字第1100080號函備查");
			//VI商品文號
			else if(isVI)
				param.put("goodscode", "110.06.30一產精字第1100369號函備查");
			else
				param.put("goodscode", "");
			
			//續保單號
			String t2132 = mp.get("T2132") != null ? mp.get("T2132").toString() : "";
			if(!t2132.equals("")){	
				param.put("t2132d1", t2132.substring(0, 4));
				param.put("t2132d2", t2132.substring(4));
			}else{
				param.put("t2132d1", "　　");
				param.put("t2132d2", "　　　　");			
			}

			//年齡計算
			String t2106 = mp.get("T2106") != null ? mp.get("T2106").toString() : "0";
			String ages = "0";
			if(!t2106.equals("0")){
				String byear ="0";
				String bmonth ="0";
				String bdate ="0";
				
				if(t2106.length() == 6){
					byear = t2106.substring(0, 2);
					bmonth = t2106.substring(2, 4);
					bdate = t2106.substring(4, 6);
					
					ages = String.valueOf(getAgeByStrdate(byear, bmonth, bdate, strd));
					
				}else if(t2106.length() == 7){
					byear = t2106.substring(0, 3);
					bmonth = t2106.substring(3, 5);
					bdate = t2106.substring(5, 7);

					ages = String.valueOf(getAgeByStrdate(byear, bmonth, bdate, strd));
				}
				param.put("yearsold", ages);
			}else{
				param.put("yearsold", ages);
			}	
			
			String t2131 = FormatUtil.getDecimalFormat(Integer.parseInt(mp.get("T2131").toString()) , 0);
			param.remove("t2131");
			param.put("t2131", t2131);
			
		}
		catch (JRException jre)
		{
			logger.error("報表編譯失敗", jre);
		}
		catch (IOException ioe)
		{
			logger.error("報表轉PDF時失敗", ioe);
		}
		
	}
	
	/**
	 * 新增 KYCKZ列印序號記錄
	 * @param insType 保單狀態
	 * @param loginId 列印人員
	 * @param insNo 保單號碼
	 * @param receiptno 收據流水編號
	 * @param spCode 核對序號
	 * @throws SQLException
	 */
	private void insertKYCKZ(String insType, String loginId, String insNo, String receiptno, String spCode)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String time = DateUtil.getSysTime();

		StringBuffer sql = new StringBuffer();
		sql.append("INSERT INTO KYCKZ(KZ01,KZ02,KZ03,KZ04,KZ05,CRTDT,CRTTM,CRTUR,UPDDT,UPDTM,UPDUR) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
		String[] param = { insNo, receiptno, insType, spCode, receiptno, sysdate, time, loginId, sysdate, time, loginId };
		
		Connection conn = KycConnection.getOracleConnection();
		try{
			QueryRunner run = new QueryRunner();
			run.update(conn, sql.toString(), param);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally
		{
			KycConnection.closeConnection(conn);
		}
	}
	
	
	/**
	 * 查詢旅平險被保險人傷健險保費總和
	 * @param key
	 * @return
	 */
	private int getTotal_PA(String key){
		int total_pa = 0;
		
		String sql = "SELECT T2405,T2407,SUM(T2430 + OHS_PREMIUM + PA65E1_PREMIUM + PA65F3_PREMIUM + PA67C1_PREMIUM) AS TOTAL_PA_FEE "
				+"FROM ( "
				+"SELECT T2405,T2407,T2430, "
				+"CASE WHEN A0.T2509 IS NULL THEN 0 ELSE A0.T2509 END AS OHS_PREMIUM, "
				+"CASE WHEN A1.T2509 IS NULL THEN 0 ELSE A1.T2509 END AS PA65E1_PREMIUM, "
				+"CASE WHEN A2.T2509 IS NULL THEN 0 ELSE A2.T2509 END AS PA65F3_PREMIUM, "
				+"CASE WHEN A3.T2509 IS NULL THEN 0 ELSE A3.T2509 END AS PA67C1_PREMIUM "
				+"FROM PT24PF  "
				+"LEFT JOIN PT25PF A0 ON A0.T2501=T2401 AND A0.T2502=T2402 AND A0.T2504=T2404 AND A0.T2505=T2405 AND A0.T2506 = 'OHS' "
				+"LEFT JOIN PT25PF A1 ON A1.T2501=T2401 AND A1.T2502=T2402 AND A1.T2504=T2404 AND A1.T2505=T2405 AND A1.T2506||A1.T2507 = 'PA65E1' "
				+"LEFT JOIN PT25PF A2 ON A2.T2501=T2401 AND A2.T2502=T2402 AND A2.T2504=T2404 AND A2.T2505=T2405 AND A2.T2506||A2.T2507 = 'PA65F3' "
				+"LEFT JOIN PT25PF A3 ON A3.T2501=T2401 AND A3.T2502=T2402 AND A3.T2504=T2404 AND A3.T2505=T2405 AND A3.T2506||A3.T2507 = 'PA67C1' "
				+"WHERE T2401=?) A "
				+"GROUP BY T2405,T2407 ";

		List ret = null;
		Connection con = null;
		QueryRunner runner = new QueryRunner();
		try
		{
			con = AS400Connection.getConnection();
			ret = (List) runner.query(con, sql, key, new TrimedMapListHandler());
			
			if(ret != null && !ret.isEmpty()){
				Map mp = (Map) ret.get(0);
				total_pa = Integer.parseInt(mp.get("TOTAL_PA_FEE").toString());
			}
		
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}finally{
			AS400Connection.closeConnection(con);
		}

		return total_pa;
	}

    /**
     * 以起保日計算取得年齡，先以實際年齡計算，大於15歲的以保險年齡計算
     * @param birthYear 出生年
     * @param birthMonth 出生月
     * @param birthDay 出生日
     * @param strdate 起保日
     * @return 
     */
    private int getAgeByStrdate(String birthYear,String birthMonth,String birthDay , String strdate){

    	int strYear = Integer.parseInt(strdate.substring(0, strdate.length()-4));
    	int strMonth = Integer.parseInt(strdate.substring(strdate.length()-4, strdate.length()-2));
    	int strDay = Integer.parseInt(strdate.substring(strdate.length()-2, strdate.length()));
    	
    	int age = strYear - Integer.parseInt(birthYear);
    	
    	if(strDay < Integer.parseInt(birthDay))
    		strMonth--;
    	
    	if(strMonth < Integer.parseInt(birthMonth)){
    		strMonth += 12 - Integer.parseInt(birthMonth);
    		age--;
    	} 		
    	else
    		strMonth -= Integer.parseInt(birthMonth);
    	
    	if(strMonth >= 6)
    		age++;
    	
    	return age;
    }
	
    /**
     * 取得當月的總天數
     * @param strdate
     * @return
     */
    private int getMonthDays(String strdate){
    	
    	int days = 0;
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    	try {

    		Calendar ca = Calendar.getInstance();
    		Date sysdate = ca.getTime();
    		
    		ca.setTime(sdf.parse(String.valueOf(19110000 + Integer.parseInt(strdate))));					
    		ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH)); 
    		String lastday = String.valueOf(Integer.parseInt(sdf.format(ca.getTime())) - 19110000);//取得起日月底日期
    		String lastdate = lastday.substring(5, 7);
    		
    		days = Integer.parseInt(lastdate);
		} catch (Exception e) {
			e.printStackTrace();
		}

    	return days;
    }
    
	/**
	 * 合併報表
	 * 
	 * @param 每份保單的byte陣列
	 * @return 合併之pdf報表資料
	 * @throws Exception
	 */
	public static byte[] mergePdf(byte[][] report)
	{
		Document document = null;
		PdfCopy pdfcopy = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		document = new Document();
		try
		{
			pdfcopy = new PdfCopy(document, os);
			document.open();
			for (int i = 0; i < report.length; i++)
			{
				copyPdf(pdfcopy, report[i]);
			}
			os.close();
			document.close();
		}
		catch (DocumentException de)
		{
			logger.error("合併報表時失敗", de);
		}
		catch (IOException ioe)
		{
			logger.error("合併報表時失敗", ioe);
		}
		return os.toByteArray();
	}

	/**
	 * 複製報表
	 * 
	 * @param pdfcopy
	 * @param other
	 * @throws Exception
	 */
	private static void copyPdf(PdfCopy pdfcopy, byte[] other)
	{
		try
		{
			PdfReader reader = new PdfReader(other);
			int j = reader.getNumberOfPages();
			for (int k = 0; k < j;)
			{
				k++;
				com.lowagie.text.pdf.PdfImportedPage pdfimportedpage = pdfcopy.getImportedPage(reader, k);
				pdfcopy.addPage(pdfimportedpage);
			}
			com.lowagie.text.pdf.PRAcroForm pracroform = reader.getAcroForm();
			if (pracroform != null)
				pdfcopy.copyAcroForm(reader);
		}
		catch (IOException ioe)
		{
			logger.error("複製報表時失敗", ioe);
		}
		catch (BadPdfFormatException bpfe)
		{
			logger.error("複製報表時失敗", bpfe);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asi.common.struts.AsiAction#sessionCheck(org.apache.struts.action.ActionMapping,
	 *      org.apache.struts.action.ActionForm,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward sessionCheck(ActionMapping arg0, ActionForm arg1, HttpServletRequest arg2, HttpServletResponse arg3) throws IOException, ServletException
	{
		// AsiActionForm arg = (AsiActionForm) arg1;
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.asi.common.struts.AsiAction#portalCheck(org.apache.struts.action.ActionMapping,
	 *      javax.servlet.http.HttpServletRequest,
	 *      com.asi.common.struts.AsiActionForm)
	 */
	protected void portalCheck(ActionMapping arg0, HttpServletRequest arg1, AsiActionForm arg2) throws AsiException
	{}
}
