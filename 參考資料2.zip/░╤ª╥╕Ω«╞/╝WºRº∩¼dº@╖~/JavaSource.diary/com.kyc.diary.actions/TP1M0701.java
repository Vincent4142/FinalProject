/*
 * Created on 2020/7/29
 */
package com.kyc.diary.actions;


import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.Codec;
import com.kyc.diary.forms.TP1M070f;
import com.kyc.inc.dao.TrimedMapHandler;
import com.kyc.inc.dao.TrimedMapListHandler;
import com.kyc.sec.actions.WebAction;

/**
 * @author Vincent
 * 作業：工作日誌維護
 */

public class TP1M0701 extends WebAction {

	//開始進來第一頁
	public void redefineActionCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) form;
        if (form1.getActionCode() == 0){
        	form1.setNextPage(1);
        }
          
	}
	
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws AsiException {
		TP1M070f form1=(TP1M070f)form;
		
		//導入新增頁面
		if(form1.getActionCode() == 5){
			form.setNextPage(2);
		}
		//導入修改頁面
		else if(form1.getActionCode() == 6){
			form.setNextPage(3);
		}
		//導入刪除頁面
		else if(form1.getActionCode() == 7){
			form.setNextPage(4);
		}
		//導入查詢頁面
		else if(form1.getActionCode() == 8){
			String sql="SELECT * FROM TEST_DIARY";
			try
			{
				tx_controller.begin(0);
				QueryRunner qr = new QueryRunner(); 
				
				List<Map> m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,new TrimedMapListHandler());
				request.setAttribute("list", m);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			form.setNextPage(5);
		}
		//執行新增作業
		else if(form1.getActionCode() == 10){
			String sql="INSERT INTO TEST_DIARY(CNUMBER,REQUIRE,CREATION_DATE,PROGRESS) VALUES(?,?,?,?)";
			String cnumber=form1.getcNumber();
			String require=form1.getRequire();
			int creation=form1.getCreationDate();
			String progess=form1.getProgress();
			try
			{
				tx_controller.begin(0);
				QueryRunner qr1 = new QueryRunner(); 
				//設定?的參數
				Object[] params = {cnumber,require,creation,progess}; 
				qr1.update(tx_controller.getConnection(0), sql,params);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			form.setNextPage(1);
		}
		//執行修改作業
		else if(form1.getActionCode() == 11){
			String sql="";
			String cnumber=form1.getcNumber();
			int finish=form1.getFinishDate();
			String progess=form1.getProgress();		
			try
			{
				if(finish==0){
					sql="UPDATE TEST_DIARY SET PROGRESS=? WHERE CNUMBER=?";
					tx_controller.begin(0);
					QueryRunner qr2 = new QueryRunner(); 
					//設定?的參數
					Object[] params = {progess,cnumber}; 
					qr2.update(tx_controller.getConnection(0), sql,params);
				}
				else{
					sql="UPDATE TEST_DIARY SET PROGRESS=?,finish_date=? WHERE CNUMBER=?";
					tx_controller.begin(0);
					QueryRunner qr2 = new QueryRunner(); 
					//設定?的參數
					Object[] params = {progess,finish,cnumber}; 
					qr2.update(tx_controller.getConnection(0), sql,params);
				}
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
							
			form.setNextPage(1);
		}
		//執行刪除作業
		else if(form1.getActionCode() == 12){
			String sql="DELETE FROM TEST_DIARY WHERE CNUMBER=?";
			String cnumber=form1.getcNumber();
			
			try
			{
				tx_controller.begin(0);
				QueryRunner qr3 = new QueryRunner(); 
				//設定?的參數
				Object[] params = {cnumber}; 
				qr3.update(tx_controller.getConnection(0), sql,params);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
					
			form.setNextPage(1);
		}
		
		//匯出excel
		else if(form1.getActionCode() == 15){
			String sql="SELECT * FROM TEST_DIARY";
			try
			{
				tx_controller.begin(0);
				QueryRunner qr = new QueryRunner(); 
				
				List<Map> m=(List<Map>)qr.query(tx_controller.getConnection(0), sql,new TrimedMapListHandler());
				getReportFilePath("工作日誌",m);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			form.setNextPage(1);
		}
	}

	//以下為匯出excel方法
	private void getReportFilePath(String filename,List data)
	{
		String sysdate = DateUtil.getSysDate(DateUtil.ChType, DateUtil.Format_YYYYMMDD, false);
		String sysFolder = "D:/增刪改查作業" + "\\" +sysdate;
		String rptPath = "";		
		try
		{
			File ffolder = new File(sysFolder);
			if(!ffolder.exists()){
				ffolder.mkdirs();
			}
			else{
				ffolder.delete();
			}	
			
			HSSFWorkbook workbook = exportExcel(data);
		   	
		   	rptPath = sysFolder + "\\" + filename + ".xls";
		   	FileOutputStream fos = new FileOutputStream(new File(rptPath));
		   	workbook.write(fos);
			fos.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			rptPath = null;
		}
		
		
	}
	
	
	public HSSFWorkbook exportExcel(List data) throws AsiException
	{		
		
		HSSFWorkbook workBook = new HSSFWorkbook();
		HSSFSheet sheet = workBook.createSheet();
		
		sheet.createFreezePane(0, 1);//凍結視窗
		
		sheet.setDefaultRowHeightInPoints(20);//預設列高
		sheet.setDefaultColumnWidth((short)9);//預設欄寬
		sheet.setMargin(HSSFSheet.TopMargin, (double) .30);//設定上邊界
		sheet.setMargin(HSSFSheet.BottomMargin, (double) .30);//設定下邊界
		sheet.setMargin(HSSFSheet.LeftMargin, (double) .30);//設定左邊界
		sheet.setMargin(HSSFSheet.RightMargin, (double) .30);//設定右邊界
		
		HSSFCellStyle style = workBook.createCellStyle();//欄位&Data樣式
		style.setWrapText(false);//自動換行
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);//設定下框線樣式
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);//設定左框線樣式
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);//設定右框線樣式
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);//設定上框線樣式
		
		HSSFRow row = sheet.createRow(0);//欄位名稱
		createCell(row, (short) 0, "聯繫單編號", style);
		createCell(row, (short) 1, "需求說明", style);
		createCell(row, (short) 2, "建立日期", style);
		createCell(row, (short) 3, "結束日期", style);
		createCell(row, (short) 4, "工作進度", style);
	
		
		sheet.setColumnWidth((short)3,(short)4096);//設定受理編號的欄寬，比例1:256
		sheet.setColumnWidth((short)4,(short)4096);//設定保單號碼的欄寬，比例1:256
		
		for (int i = 0; i < data.size(); i++)//Data
		{
			Map currentRowData = (Map) data.get(i);
			row = sheet.createRow(i + 1);
			createCell(row, (short) 0, String.valueOf(currentRowData.get("cnumber")), style);
			createCell(row, (short) 1, String.valueOf(currentRowData.get("require")), style);		
			createCell(row, (short) 2, String.valueOf(currentRowData.get("creation_date")), style);
			createCell(row, (short) 3, String.valueOf(currentRowData.get("finish_date")), style);
			createCell(row, (short) 4, String.valueOf(currentRowData.get("progress")), style);
		
			// 轉為可加總數字
//			HSSFCell cell6 = row.createCell((short) 7);
//			cell6.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
//			cell6.setCellValue(NumberUtils.toDouble(String.valueOf(currentRowData.get("workday"))));
//			cell6.setCellStyle(style);
		}
		
		return workBook;
	}
	private void createCell(HSSFRow headerRow, short cellcnt, String cellString,
			HSSFCellStyle style)
	{
		HSSFCell cell;
		cell = headerRow.createCell(cellcnt);
		cell.setCellValue(cellString);
		cell.setCellStyle(style);
	}
	
}
