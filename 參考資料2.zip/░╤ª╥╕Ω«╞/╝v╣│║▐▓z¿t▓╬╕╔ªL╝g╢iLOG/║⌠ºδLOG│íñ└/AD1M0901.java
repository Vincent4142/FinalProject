
package com.asi.adm.ad1.actions;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.asi.common.exception.AsiException;
import com.asi.common.struts.AsiAction;
import com.asi.common.struts.AsiActionForm;
import com.asi.common.util.DateUtil;
import com.asi.kyc.common.utils.AS400Connection;
import com.kyc.inc.dao.TrimedMapListHandler;

/**
 * @author vsg
 * 建立日期： 2018/12/26
 * 網路投保前後台Log查詢
 *
 */
public class AD1M0901 extends AsiAction
{

	public void redefineActionCode(ActionMapping arg0, ActionForm arg1, HttpServletRequest request, HttpServletResponse response)
	{
		AsiActionForm form1 = (AsiActionForm) arg1;

		if (form1.getActionCode() == 0)
		{
			// 日期預設值
			int sysDate = NumberUtils.toInt(DateUtil.getSysDate(DateUtil.ChType,
					DateUtil.Format_YYYYMMDD, false));
			int sysMon = sysDate / 100;
			int startDate = sysMon * 100;
			startDate += 1; // 查詢日期區間的起日從當月1日起

			request.setAttribute("strymd", String.valueOf(startDate));
			request.setAttribute("endymd", String.valueOf(sysDate));
			
			form1.setActionCode(5);
		}
	}
	public void doProcess(ActionMapping mapping, AsiActionForm form, HttpServletRequest request, HttpServletResponse response) throws AsiException
	{
		List ret = null;

		if (form.getActionCode() == 1)//查詢
		{			
			ret = getKYCLLOG(request);
			
			String startYMD = request.getParameter("startYMD") != null ? request.getParameter("startYMD") : "";
			String endYMD = request.getParameter("endYMD") != null ? request.getParameter("endYMD") : "";
			request.setAttribute("strymd", startYMD);
			request.setAttribute("endymd", endYMD);
			
			request.setAttribute("detail", ret);
			form.setNextPage(1);		
		}else{
			form.setNextPage(1);
		}
	
	}
	
	private List getKYCLLOG(HttpServletRequest request){
		
		List ret = null;
		
		String quickselect = request.getParameter("quickselect") != null ? request.getParameter("quickselect") : "";
		String quicktext = request.getParameter("quicktext") != null ? request.getParameter("quicktext") : "";
		String ll04 = request.getParameter("ll04") != null ? request.getParameter("ll04") : "";
		String ll08 = request.getParameter("ll08") != null ? request.getParameter("ll08") : "";
		String ll17 = request.getParameter("ll17") != null ? request.getParameter("ll17") : "";
		String dateType = request.getParameter("dateType") != null ? request.getParameter("dateType") : "";
		String startYMD = request.getParameter("startYMD") != null ? request.getParameter("startYMD") : "";
		String endYMD = request.getParameter("endYMD") != null ? request.getParameter("endYMD") : "";
		
 		StringBuffer sql = new StringBuffer();
 		sql.append("SELECT * FROM KYCLLOG ");
 		sql.append("WHERE ");
 		
 		//單一條件選擇時
 		if(!quickselect.equals("0") && !quickselect.equals("")){
 			if(quickselect.equals("1"))
 				sql.append("LL05 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("2"))
 				sql.append("LL09 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("3"))
 				sql.append("LL07 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("4"))
 				sql.append("LL26 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("5"))
 				sql.append("LL27 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("6"))
 				sql.append("LL28 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("7"))
 				sql.append("LL29 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("8"))
 				sql.append("LL03 LIKE '%").append(quicktext).append("%' ");			
 			if(quickselect.equals("9"))
 				sql.append("LL20 LIKE '%").append(quicktext).append("%' ");
 			if(quickselect.equals("10"))
 				sql.append("LL30 LIKE '%").append(quicktext).append("%' ");	
 		}else{
 			
 	 		//日期
 	 		if(dateType.equals("1")){
 	 			sql.append("LL10 BETWEEN ").append(startYMD).append(" AND ").append(endYMD).append(" ");
 	 		}else if(dateType.equals("2")){
 	 			sql.append("LL12 BETWEEN ").append(startYMD).append(" AND ").append(endYMD).append(" ");
 	 		}else if(dateType.equals("3")){
 	 			sql.append("LL13 BETWEEN ").append(startYMD).append(" AND ").append(endYMD).append(" ");
 	 		}

 		}
 		
 		if(!ll04.equals("0") && !ll04.equals(""))
 			sql.append("AND LL04 ='").append(ll04).append("' ");
 		
 		if(!ll08.equals("0") && !ll08.equals(""))
 			sql.append("AND LL08 ='").append(ll08).append("' ");

 		if(!ll17.equals("0") && !ll17.equals(""))
 			sql.append("AND LL17 ='").append(ll17).append("' ");
		
 		Connection con = AS400Connection.getOracleConnection();
 		
 		try
 		{
 			QueryRunner runner = new QueryRunner();
 			ret = (List) runner.query(con, sql.toString(), new TrimedMapListHandler());
 			
 		}
 		catch (SQLException e)
 		{
 			e.printStackTrace();
 		}
 		finally{
 			AS400Connection.closeConnection(con);
 		}

		return ret;
	}


}
