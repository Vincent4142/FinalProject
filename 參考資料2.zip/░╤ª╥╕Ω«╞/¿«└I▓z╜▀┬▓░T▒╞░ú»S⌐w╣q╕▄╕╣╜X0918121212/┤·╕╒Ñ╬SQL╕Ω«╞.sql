SELECT jm001,jb00,jm002,jm01,jm10,jb95,jb03,jb10,jb01,ja13,ja14,jb15,jb18,ja004,wc25 
FROM PFJM 
left join pfjb on jb00 = jm001 
right join pfja on ja003 = jm001 
right join pfwc on wc001 = jb01 
WHERE jm01 = '0' and jm002 = '01' and jm10 ='Y' and jb95 = '' and jm001 like '1000__A06%' and jb10>='1061101' and (substr(ja14,1,2)='09' or substr(jb15,1,2)='09')
order by jm001;


select * from PFJM where jm001='101409K00081' 
select * from PFJA where ja003='101409K00081' 
select * from PFJB where jb00='101409K00081' 
select * from PFWC where wc001='10140B0001383' 


select * from PFJM where jm001='101409K00091' 
select * from PFJA where ja003='101409K00091' 
select * from PFJB where jb00='101409K00091' 
select * from PFWC where wc001='10140R0003311' 

--測試用
update PFJM set jm001='100009A06081',jm01='0' where jm001='101409K00081' 
update PFJA set ja003='100009A06081' where ja003='101409K00081' 
update PFJB set jb00='100009A06081',jb95='',jb15='0939467207' where jb00='101409K00081' 


update PFJM set jm001='100009A06091',jm01='0' where jm001='101409K00091' 
update PFJA set ja003='100009A06091' where ja003='101409K00091' 
update PFJB set jb00='100009A06091',jb95='',jb15='0918121212' where jb00='101409K00091' 

update PFJM set jm001='100009A06097',jm01='0' where jm001='101409K00097' 
update PFJA set ja003='100009A06097' where ja003='101409K00097' 
update PFJB set jb00='100009A06097',jb95='',jb15='0900000000' where jb00='101409K00097' 

--還原
update PFJM set jm001='101409K00081',jm01='1091215' where jm001='100009A06081' 
update PFJA set ja003='101409K00081' where ja003='100009A06081' 
update PFJB set jb00='101409K00081',jb95='Y',jb15='' where jb00='100009A06081' 


update PFJM set jm001='101409K00091',jm01='1091203' where jm001='100009A06091' 
update PFJA set ja003='101409K00091' where ja003='100009A06091' 
update PFJB set jb00='101409K00091',jb95='Y',jb15='' where jb00='100009A06091'


update PFJM set jm001='101409K00097',jm01='1100502' where jm001='100009A06097' 
update PFJA set ja003='101409K00097' where ja003='100009A06097' 
update PFJB set jb00='101409K00097',jb95='Y',jb15='' where jb00='100009A06097'
